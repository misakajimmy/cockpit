cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "İptal"
 ],
 "Change performance profile": [
  null,
  "Performans profilini değiştir"
 ],
 "Change profile": [
  null,
  "Profili değiştir"
 ],
 "Communication with tuned has failed": [
  null,
  "tuned ile iletişim başarısız oldu"
 ],
 "Disable tuned": [
  null,
  "tuned'i etkisizleştir"
 ],
 "Failed to disable tuned": [
  null,
  "tuned etkisizleştirme başarısız oldu"
 ],
 "Failed to disabled tuned profile": [
  null,
  "tuned profilini etkisizleştirmesi başarısız oldu"
 ],
 "Failed to enable tuned": [
  null,
  "tuned etkinleştirme başarısız oldu"
 ],
 "Failed to switch profile": [
  null,
  "Profil değiştirme başarısız oldu"
 ],
 "Help": [
  null,
  "Yardım"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "None": [
  null,
  "Yok"
 ],
 "This system is using a custom profile": [
  null,
  "Bu sistem özel bir profil kullanıyor"
 ],
 "This system is using the recommended profile": [
  null,
  "Bu sistem önerilen profili kullanıyor"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned başlatılamadı"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned , sisteminizi izleyen ve belirli iş yükleri altında performansı en iyi hale getiren bir hizmettir. Tuned'ın çekirdeği, sisteminizi farklı kullanım durumları için ayarlayan profillerdir."
 ],
 "Tuned is not available": [
  null,
  "Tuned kullanılabilir değil"
 ],
 "Tuned is not running": [
  null,
  "Tuned çalışmıyor"
 ],
 "Tuned is off": [
  null,
  "Tuned kapalı"
 ],
 "active": [
  null,
  "etkin"
 ],
 "inconsistent": [
  null,
  "tutarsız"
 ],
 "none": [
  null,
  "yok"
 ],
 "recommended": [
  null,
  "önerilir"
 ],
 "show less": [
  null,
  "daha az göster"
 ],
 "show more": [
  null,
  "daha fazla göster"
 ]
});
