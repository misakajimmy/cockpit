cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Change performance profile": [
  null,
  "Perfil alterar o desempenho"
 ],
 "Change profile": [
  null,
  "Alterar o perfil"
 ],
 "Communication with tuned has failed": [
  null,
  "A comunicação com sintonizado falhou"
 ],
 "Disable tuned": [
  null,
  "Desabilitar tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Falha ao desabilitar tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Falha ao habilitar tuned"
 ],
 "Failed to switch profile": [
  null,
  "Falha ao mudar de perfil"
 ],
 "Help": [
  null,
  "Ajuda"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "None": [
  null,
  "Nenhum"
 ],
 "This system is using a custom profile": [
  null,
  "Este sistema está usando um perfil personalizado"
 ],
 "This system is using the recommended profile": [
  null,
  "Este sistema está usando o perfil recomendado"
 ],
 "Tuned has failed to start": [
  null,
  "Falhou ao iniciar Tuned"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  ""
 ],
 "Tuned is not available": [
  null,
  "Tuned não está disponível"
 ],
 "Tuned is not running": [
  null,
  "Tuned não está em execução"
 ],
 "Tuned is off": [
  null,
  "Tuned está fora"
 ],
 "active": [
  null,
  "ativo"
 ],
 "none": [
  null,
  "Nenhum"
 ],
 "recommended": [
  null,
  "recomendado"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ]
});
