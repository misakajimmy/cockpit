cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Change performance profile": [
  null,
  "Endre ytelsesprofil"
 ],
 "Change profile": [
  null,
  "Endre profil"
 ],
 "Communication with tuned has failed": [
  null,
  "Kommunikasjonen med tuned feilet"
 ],
 "Disable tuned": [
  null,
  "Deaktiver tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Kunne ikke deaktivere tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Kunne ikke aktivere tuned"
 ],
 "Failed to switch profile": [
  null,
  "Kunne ikke bytte profil"
 ],
 "Help": [
  null,
  "Hjelp"
 ],
 "Learn more": [
  null,
  "Lær mer"
 ],
 "None": [
  null,
  "Ingen"
 ],
 "This system is using a custom profile": [
  null,
  "Dette systemet bruker en tilpasset profil"
 ],
 "This system is using the recommended profile": [
  null,
  "Dette systemet bruker den anbefalte profilen"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned kunne ikke starte"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned er en tjeneste som overvåker systemet ditt og optimaliserer ytelsen under visse arbeidsbelastninger. Kjernen i Tuned er profiler som justerer systemet ditt for forskjellige brukstilfeller."
 ],
 "Tuned is not available": [
  null,
  "Tuned er ikke tilgjengelig"
 ],
 "Tuned is not running": [
  null,
  "Tuned kjører ikke"
 ],
 "Tuned is off": [
  null,
  "Tuned er av"
 ],
 "active": [
  null,
  "aktiv"
 ],
 "none": [
  null,
  "ingen"
 ],
 "recommended": [
  null,
  "anbefalt"
 ],
 "show less": [
  null,
  "vis mindre"
 ],
 "show more": [
  null,
  "vis mer"
 ]
});
