cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Change performance profile": [
  null,
  "წარმადობის პროფილის შეცვლა"
 ],
 "Change profile": [
  null,
  "პროფილის შეცვლა"
 ],
 "Communication with tuned has failed": [
  null,
  "tuned-თან კავშირის შეცდომა"
 ],
 "Disable tuned": [
  null,
  "tuned-ის გამორთვა"
 ],
 "Failed to disable tuned": [
  null,
  "tuned-ის გამორთვის შეცდომა"
 ],
 "Failed to disabled tuned profile": [
  null,
  "tuned-ის პროფილის გამორთვის შეცდომა"
 ],
 "Failed to enable tuned": [
  null,
  "tuned-ის ჩართვის შეცდომა"
 ],
 "Failed to switch profile": [
  null,
  "პროფილის გადართვის შეცდომა"
 ],
 "Help": [
  null,
  "დახმარება"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "None": [
  null,
  "არცერთი"
 ],
 "This system is using a custom profile": [
  null,
  "ეს სისტემა მორგებულ პროფილს იყენებს"
 ],
 "This system is using the recommended profile": [
  null,
  "ეს სისტემა რეკომენდებულ პროფილს იყენებს"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned-ის გაშვების შეცდომა"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned წარმოადგენს სერვისს, რომელიც უთვალთვალებს თქვენს სისტემას და აოპტიმიზირებს მას ზოგიერთიდატვირთვისთვის. Tuned-ის ბირთვის წარმოადგენს მისი პროფილები, რომლებიც სისტემას სხვადასხვა დატვირთვას ავტომატურად მოარგებს."
 ],
 "Tuned is not available": [
  null,
  "Tuned-ი ხელმიუწვდომელია"
 ],
 "Tuned is not running": [
  null,
  "Tuned-ი გაშვებული არაა"
 ],
 "Tuned is off": [
  null,
  "Tuned გამორთულია"
 ],
 "active": [
  null,
  "აქტიური"
 ],
 "inconsistent": [
  null,
  "არამდგრადი"
 ],
 "none": [
  null,
  "არცერთი"
 ],
 "recommended": [
  null,
  "რეკომენდებულია"
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ]
});
