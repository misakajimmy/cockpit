cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Change performance profile": [
  null,
  "Verander prestatieprofiel"
 ],
 "Change profile": [
  null,
  "Verander profiel"
 ],
 "Communication with tuned has failed": [
  null,
  "Communicatie met tuned is mislukt"
 ],
 "Disable tuned": [
  null,
  "Schakel tuned uit"
 ],
 "Failed to disable tuned": [
  null,
  "Kan tuned niet uitzetten"
 ],
 "Failed to disabled tuned profile": [
  null,
  "Kan tuned profiel niet uitzetten"
 ],
 "Failed to enable tuned": [
  null,
  "Kan tuned niet inschakelen"
 ],
 "Failed to switch profile": [
  null,
  "Kan profiel niet wijzigen"
 ],
 "Help": [
  null,
  "Hulp"
 ],
 "Learn more": [
  null,
  "Kom meer te weten"
 ],
 "None": [
  null,
  "Geen"
 ],
 "This system is using a custom profile": [
  null,
  "Dit systeem gebruikt een aangepast profiel"
 ],
 "This system is using the recommended profile": [
  null,
  "Dit systeem gebruikt het aanbevolen profiel"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned kan niet gestart worden"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned is een service die je systeem bewaakt en de prestaties onder bepaalde werkbelastingen optimaliseert. De kern van Tuned zijn profielen, die je systeem afstemmen op verschillende gebruikssituaties."
 ],
 "Tuned is not available": [
  null,
  "Tuned is niet beschikbaar"
 ],
 "Tuned is not running": [
  null,
  "Tuned is niet actief"
 ],
 "Tuned is off": [
  null,
  "Tuned is uitgeschakeld"
 ],
 "active": [
  null,
  "actief"
 ],
 "inconsistent": [
  null,
  "inconsequent"
 ],
 "none": [
  null,
  "geen"
 ],
 "recommended": [
  null,
  "aanbevolen"
 ],
 "show less": [
  null,
  "toon minder"
 ],
 "show more": [
  null,
  "toon meer"
 ]
});
