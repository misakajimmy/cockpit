cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "Storno"
 ],
 "Change performance profile": [
  null,
  "Změnit profil výkonu"
 ],
 "Change profile": [
  null,
  "Změnit profil"
 ],
 "Communication with tuned has failed": [
  null,
  "Komunikace s procesem služby tuned se nezdařila"
 ],
 "Disable tuned": [
  null,
  "Vypnout proces služby tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Nepodařilo se zakázat proces služby tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Nepodařilo se zapnout tuned"
 ],
 "Failed to switch profile": [
  null,
  "Nepodařilo se přepnout profil"
 ],
 "Help": [
  null,
  "Nápověda"
 ],
 "Learn more": [
  null,
  "Další informace naleznete"
 ],
 "None": [
  null,
  "Žádný"
 ],
 "This system is using a custom profile": [
  null,
  "Tento systém používá uživatelsky určený profil"
 ],
 "This system is using the recommended profile": [
  null,
  "Tento systém používá doporučený profil"
 ],
 "Tuned has failed to start": [
  null,
  "Spuštění procesu služby tuned se nezdařilo"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned je služba která monitoruje váš systém a optimalizuje jeho výkon pod určitými zátěžemi. Jádrem Tuned jsou profily, který ladí váš systém pro různé případy použití."
 ],
 "Tuned is not available": [
  null,
  "Tuned není k dispozici"
 ],
 "Tuned is not running": [
  null,
  "Tuned není spuštěné"
 ],
 "Tuned is off": [
  null,
  "Tuned je vypnuté"
 ],
 "active": [
  null,
  "aktivní"
 ],
 "none": [
  null,
  "nic"
 ],
 "recommended": [
  null,
  "doporučeno"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ]
});
