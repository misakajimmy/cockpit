cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Change performance profile": [
  null,
  "Зміна профілю швидкодії"
 ],
 "Change profile": [
  null,
  "Змінити профіль"
 ],
 "Communication with tuned has failed": [
  null,
  "Не вдалося обмінятися даними з tuned"
 ],
 "Disable tuned": [
  null,
  "Вимкнути tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Не вдалося вимкнути tuned"
 ],
 "Failed to disabled tuned profile": [
  null,
  "Не вдалося вимкнути профіль tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Не вдалося увімкнути tuned"
 ],
 "Failed to switch profile": [
  null,
  "Не вдалося перемкнути профіль"
 ],
 "Help": [
  null,
  "Довідка"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "None": [
  null,
  "Немає"
 ],
 "This system is using a custom profile": [
  null,
  "Ця система використовує нетиповий профіль"
 ],
 "This system is using the recommended profile": [
  null,
  "Ця система використовує рекомендований профіль"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned не вдалося запустити"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned — служба, яка стежить за вашою системою і оптимізує швидкодію за певних умов навантаження. Ядром Tuned є профілі, які налаштовують вашу систему для різних умов користування."
 ],
 "Tuned is not available": [
  null,
  "Tuned недоступна"
 ],
 "Tuned is not running": [
  null,
  "Tuned не запущено"
 ],
 "Tuned is off": [
  null,
  "Tuned вимкнено"
 ],
 "active": [
  null,
  "активний"
 ],
 "inconsistent": [
  null,
  "несумісний"
 ],
 "none": [
  null,
  "немає"
 ],
 "recommended": [
  null,
  "найліпший"
 ],
 "show less": [
  null,
  "показати менше"
 ],
 "show more": [
  null,
  "показати більше"
 ]
});
