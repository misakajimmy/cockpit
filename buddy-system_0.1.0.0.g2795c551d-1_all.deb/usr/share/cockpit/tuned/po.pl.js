cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Change performance profile": [
  null,
  "Zmień profil wydajności"
 ],
 "Change profile": [
  null,
  "Zmień profil"
 ],
 "Communication with tuned has failed": [
  null,
  "Komunikacja z tuned się nie powiodła"
 ],
 "Disable tuned": [
  null,
  "Wyłącz tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Wyłączenie tuned się nie powiodło"
 ],
 "Failed to disabled tuned profile": [
  null,
  "Wyłączenie profilu tuned się nie powiodło"
 ],
 "Failed to enable tuned": [
  null,
  "Włączenie tuned się nie powiodło"
 ],
 "Failed to switch profile": [
  null,
  "Przełączenie profilu się nie powiodło"
 ],
 "Help": [
  null,
  "Pomoc"
 ],
 "Learn more": [
  null,
  "Więcej informacji"
 ],
 "None": [
  null,
  "Brak"
 ],
 "This system is using a custom profile": [
  null,
  "Ten system używa niestandardowego profilu"
 ],
 "This system is using the recommended profile": [
  null,
  "Ten system używa zalecanego profilu"
 ],
 "Tuned has failed to start": [
  null,
  "Uruchomienie tuned się nie powiodło"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned to usługa monitorująca komputer i optymalizująca wydajność w pewnych zadaniach. Rdzeniem Tuned są profile, które dostosowują komputer do różnych zastosowań."
 ],
 "Tuned is not available": [
  null,
  "tuned jest niedostępne"
 ],
 "Tuned is not running": [
  null,
  "tuned nie jest uruchomione"
 ],
 "Tuned is off": [
  null,
  "tuned jest wyłączone"
 ],
 "active": [
  null,
  "aktywne"
 ],
 "inconsistent": [
  null,
  "niespójne"
 ],
 "none": [
  null,
  "brak"
 ],
 "recommended": [
  null,
  "zalecane"
 ],
 "show less": [
  null,
  "wyświetl mniej"
 ],
 "show more": [
  null,
  "wyświetl więcej"
 ]
});
