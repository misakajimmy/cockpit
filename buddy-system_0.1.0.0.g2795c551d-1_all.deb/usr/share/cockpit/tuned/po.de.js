cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Change performance profile": [
  null,
  "Leistungsprofil ändern"
 ],
 "Change profile": [
  null,
  "Profil ändern"
 ],
 "Communication with tuned has failed": [
  null,
  "Kommunikation mit tuned schlug fehl"
 ],
 "Disable tuned": [
  null,
  "Tuned deaktivieren"
 ],
 "Failed to disable tuned": [
  null,
  "Fehler beim Deaktivieren"
 ],
 "Failed to disabled tuned profile": [
  null,
  "Deaktivierung des tuned-Profils ist fehlgeschlagen"
 ],
 "Failed to enable tuned": [
  null,
  "Tuned konnte nicht aktiviert werden"
 ],
 "Failed to switch profile": [
  null,
  "Profil konnte nicht gewechselt werden"
 ],
 "Help": [
  null,
  "Hilfe"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "None": [
  null,
  "Kein"
 ],
 "This system is using a custom profile": [
  null,
  "Dieses System benutzt ein benutzerdefiniertes Profil"
 ],
 "This system is using the recommended profile": [
  null,
  "Dieses System benutzt das empfohlene Profil"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned konnte nicht gestartet werden"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned ist ein Dienst, der Ihr System überwacht und die Leistung unter bestimmten Arbeitsbelastungen optimiert. Das Herzstück von Tuned sind Profile, die Ihr System für verschiedene Anwendungsfälle abstimmen."
 ],
 "Tuned is not available": [
  null,
  "Tuned ist nicht verfügbar"
 ],
 "Tuned is not running": [
  null,
  "Tuned läuft nicht"
 ],
 "Tuned is off": [
  null,
  "Tuned ist ausgeschaltet"
 ],
 "active": [
  null,
  "Aktiv"
 ],
 "inconsistent": [
  null,
  "inkonsistent"
 ],
 "none": [
  null,
  "kein"
 ],
 "recommended": [
  null,
  "empfohlen"
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ]
});
