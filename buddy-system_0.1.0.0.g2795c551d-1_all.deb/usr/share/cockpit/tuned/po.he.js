cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "Cancel": [
  null,
  "ביטול"
 ],
 "Change performance profile": [
  null,
  "החלפת פרופיל ביצועים"
 ],
 "Change profile": [
  null,
  "החלפת פרופיל"
 ],
 "Communication with tuned has failed": [
  null,
  "התקשורת עם tuned נכשלה"
 ],
 "Disable tuned": [
  null,
  "השבתת tuned"
 ],
 "Failed to disable tuned": [
  null,
  "ההשבתה של tuned נכשלה"
 ],
 "Failed to enable tuned": [
  null,
  "ההפעלה של tuned נכשלה"
 ],
 "Failed to switch profile": [
  null,
  "החלפת פרופיל נכשלה"
 ],
 "Help": [
  null,
  "עזרה"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "None": [
  null,
  "אין"
 ],
 "This system is using a custom profile": [
  null,
  "מערכת זו משתמשת בפרופיל מותאם אישית"
 ],
 "This system is using the recommended profile": [
  null,
  "מערכת זו משתמשת בפרופיל המומלץ"
 ],
 "Tuned has failed to start": [
  null,
  "ההפעלה של Tuned נכשלה"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned הוא שירות שעוקב אחר המערכת שלך וממטב את הביצועים תחת עומסים מסוימים. הליבה של Tuned הם פרופילים, שמכוונים את המערכת שלך למגוון מקרי בוחן."
 ],
 "Tuned is not available": [
  null,
  "Tuned אינו זמין"
 ],
 "Tuned is not running": [
  null,
  "Tuned אינו מופעל"
 ],
 "Tuned is off": [
  null,
  "Tuned כבוי"
 ],
 "active": [
  null,
  "פעיל"
 ],
 "none": [
  null,
  "אין"
 ],
 "recommended": [
  null,
  "מומלץ"
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ]
});
