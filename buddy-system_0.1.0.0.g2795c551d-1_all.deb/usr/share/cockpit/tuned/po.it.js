cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "Annulla"
 ],
 "Change performance profile": [
  null,
  "Modifica del profilo performance"
 ],
 "Change profile": [
  null,
  "Cambia profilo"
 ],
 "Communication with tuned has failed": [
  null,
  "Comunicazione con tuned non riuscita"
 ],
 "Disable tuned": [
  null,
  "Disabilita tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Impossibile disabilitare tuned"
 ],
 "Failed to disabled tuned profile": [
  null,
  "Impossibile disabilitare il profilo tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Impossibile abilitare tuned"
 ],
 "Failed to switch profile": [
  null,
  "Impossibile cambiare profilo"
 ],
 "Help": [
  null,
  "Aiuto"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "None": [
  null,
  "Nessuno"
 ],
 "This system is using a custom profile": [
  null,
  "Questo sistema utilizza un profilo personalizzato"
 ],
 "This system is using the recommended profile": [
  null,
  "Questo sistema utilizza il profilo raccomandato"
 ],
 "Tuned has failed to start": [
  null,
  "Impossibile avviare tuned"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "tuned è un servizio che monitora il tuo sistema e ottimizza le prestazioni sotto alcuni carichi di lavoro. il cuore di tuned sono i profili, che ottimizzano il tuo sistema in casi differenti."
 ],
 "Tuned is not available": [
  null,
  "Tuned non è disponibile"
 ],
 "Tuned is not running": [
  null,
  "Tuned non è in esecuzione"
 ],
 "Tuned is off": [
  null,
  "Tuned è disattivato"
 ],
 "active": [
  null,
  "attivo"
 ],
 "none": [
  null,
  "nessuno"
 ],
 "recommended": [
  null,
  "raccomandato"
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ]
});
