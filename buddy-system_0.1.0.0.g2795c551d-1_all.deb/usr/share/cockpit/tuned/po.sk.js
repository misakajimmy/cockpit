cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Change performance profile": [
  null,
  "Zmeniť profil výkonu"
 ],
 "Change profile": [
  null,
  "Zmeniť profil"
 ],
 "Communication with tuned has failed": [
  null,
  "Komunikácia s tuned sa nepodarila"
 ],
 "Disable tuned": [
  null,
  "Vypnúť tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Nepodarilo sa deaktivovať tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Nepodarilo sa aktivovať tuned"
 ],
 "Failed to switch profile": [
  null,
  ""
 ],
 "Help": [
  null,
  "Nápoveda"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "None": [
  null,
  "Žiadny"
 ],
 "This system is using a custom profile": [
  null,
  ""
 ],
 "This system is using the recommended profile": [
  null,
  ""
 ],
 "Tuned has failed to start": [
  null,
  ""
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  ""
 ],
 "Tuned is not available": [
  null,
  ""
 ],
 "Tuned is not running": [
  null,
  ""
 ],
 "Tuned is off": [
  null,
  ""
 ],
 "active": [
  null,
  "Aktívny"
 ],
 "none": [
  null,
  "žiaden"
 ],
 "recommended": [
  null,
  "odporúčaný"
 ],
 "show less": [
  null,
  "ukázať menej"
 ],
 "show more": [
  null,
  "ukázať viac"
 ]
});
