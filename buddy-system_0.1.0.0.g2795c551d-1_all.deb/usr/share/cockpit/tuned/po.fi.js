cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "Peru"
 ],
 "Change performance profile": [
  null,
  "Vaihda suorituskyvyn profiili"
 ],
 "Change profile": [
  null,
  "Vaihda profiili"
 ],
 "Communication with tuned has failed": [
  null,
  "Yhteydenpito tuned:n kanssa epäonnistui"
 ],
 "Disable tuned": [
  null,
  "Poista tuned käytöstä"
 ],
 "Failed to disable tuned": [
  null,
  "tuned:n käytöstä poistaminen epäonnistui"
 ],
 "Failed to disabled tuned profile": [
  null,
  "tuned:n profiilin käytöstä poistaminen epäonnistui"
 ],
 "Failed to enable tuned": [
  null,
  "tuned:n käyttöönotto epäonnistui"
 ],
 "Failed to switch profile": [
  null,
  "Profiilin vaihtaminen epäonnistui"
 ],
 "Help": [
  null,
  "Ohje"
 ],
 "Learn more": [
  null,
  "Opi lisää"
 ],
 "None": [
  null,
  "Ei yhtään"
 ],
 "This system is using a custom profile": [
  null,
  "Tämä järjestelmä käyttää mukautettua profiilia"
 ],
 "This system is using the recommended profile": [
  null,
  "Tämä järjestelmä käyttää suositeltua profiilia"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned:n käynnistys epäonnistui"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned on palvelu, joka valvoo järjestelmääsi ja optimoi suorituskyvyn tietyillä kuormituksilla. Tuned:n ytimessä on profiileja, jotka virittävät järjestelmän eri käyttötapauksiin."
 ],
 "Tuned is not available": [
  null,
  "Tuned ei ole saatavilla"
 ],
 "Tuned is not running": [
  null,
  "Tuned ei ole käynnissä"
 ],
 "Tuned is off": [
  null,
  "Tuned on pois päältä"
 ],
 "active": [
  null,
  "aktiivinen"
 ],
 "inconsistent": [
  null,
  "epäkonsistentti"
 ],
 "none": [
  null,
  "Ei mitään"
 ],
 "recommended": [
  null,
  "suositeltu"
 ],
 "show less": [
  null,
  "näytä vähemmän"
 ],
 "show more": [
  null,
  "näytä enemmän"
 ]
});
