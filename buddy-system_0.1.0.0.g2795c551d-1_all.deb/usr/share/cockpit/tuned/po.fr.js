cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "Annuler"
 ],
 "Change performance profile": [
  null,
  "Modifier le profil de performance"
 ],
 "Change profile": [
  null,
  "Modifier le profil"
 ],
 "Communication with tuned has failed": [
  null,
  "La communication avec tuned a échoué"
 ],
 "Disable tuned": [
  null,
  "Désactiver tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Échec de la désactivation de « tuned »"
 ],
 "Failed to disabled tuned profile": [
  null,
  "Échec de la désactivation du profil « tuned »"
 ],
 "Failed to enable tuned": [
  null,
  "Échec de l’activation de « tuned »"
 ],
 "Failed to switch profile": [
  null,
  "Échec du changement de profil"
 ],
 "Help": [
  null,
  "Aide"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "None": [
  null,
  "Aucun"
 ],
 "This system is using a custom profile": [
  null,
  "Ce système utilise un profil personnalisé"
 ],
 "This system is using the recommended profile": [
  null,
  "Ce système utilise le profil recommandé"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned n’a pas pu démarrer"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned est un service qui surveille votre système et optimise les performances sous certaines charges de travail. Le cœur de Tuned est constitué de profils, qui permettent de régler votre système pour différents cas d’utilisation."
 ],
 "Tuned is not available": [
  null,
  "Tuned n’est pas disponible"
 ],
 "Tuned is not running": [
  null,
  "Tuned ne fonctionne pas"
 ],
 "Tuned is off": [
  null,
  "Tuned est désactivé"
 ],
 "active": [
  null,
  "actif"
 ],
 "inconsistent": [
  null,
  "Incohérent"
 ],
 "none": [
  null,
  "aucun"
 ],
 "recommended": [
  null,
  "conseillé"
 ],
 "show less": [
  null,
  "montrer moins"
 ],
 "show more": [
  null,
  "montrer plus"
 ]
});
