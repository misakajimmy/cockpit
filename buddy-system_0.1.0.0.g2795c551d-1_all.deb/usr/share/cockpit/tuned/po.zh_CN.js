cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "取消"
 ],
 "Change performance profile": [
  null,
  "变更性能配置"
 ],
 "Change profile": [
  null,
  "变更配置"
 ],
 "Communication with tuned has failed": [
  null,
  "与 tuned 通信失败"
 ],
 "Disable tuned": [
  null,
  "禁用 tuned"
 ],
 "Failed to disable tuned": [
  null,
  "禁用 tuned 失败"
 ],
 "Failed to disabled tuned profile": [
  null,
  "禁用调优的配置文件失败"
 ],
 "Failed to enable tuned": [
  null,
  "启用 tuned 失败"
 ],
 "Failed to switch profile": [
  null,
  "切换配置集失败"
 ],
 "Help": [
  null,
  "帮助"
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "None": [
  null,
  "无"
 ],
 "This system is using a custom profile": [
  null,
  "该系统正在使用自定义的配置集"
 ],
 "This system is using the recommended profile": [
  null,
  "该系统正在使用推荐的配置集"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned 启动失败"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned 是一个监控您的系统并优化某些工作负载性能的服务。Tuned 的核心是配置集（profile），使用它为不同的用例调整您的系统。"
 ],
 "Tuned is not available": [
  null,
  "Tuned 不可用"
 ],
 "Tuned is not running": [
  null,
  "Tuned 未运行"
 ],
 "Tuned is off": [
  null,
  "Tuned 已关闭"
 ],
 "active": [
  null,
  "激活"
 ],
 "inconsistent": [
  null,
  "不一致"
 ],
 "none": [
  null,
  "空"
 ],
 "recommended": [
  null,
  "推荐"
 ],
 "show less": [
  null,
  "显示更少"
 ],
 "show more": [
  null,
  "显示更多"
 ]
});
