cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "취소"
 ],
 "Change performance profile": [
  null,
  "성능 프로파일 변경"
 ],
 "Change profile": [
  null,
  "프로파일 변경"
 ],
 "Communication with tuned has failed": [
  null,
  "tuned와의 통신에 실패했습니다"
 ],
 "Disable tuned": [
  null,
  "tuned 비활성화"
 ],
 "Failed to disable tuned": [
  null,
  "tuned 비활성화에 실패했습니다"
 ],
 "Failed to disabled tuned profile": [
  null,
  "조정된 프로파일을 비활성화에 실패함"
 ],
 "Failed to enable tuned": [
  null,
  "tuned 활성화에 실패하였습니다"
 ],
 "Failed to switch profile": [
  null,
  "프로파일 전환에 실패했습니다"
 ],
 "Help": [
  null,
  "도움말"
 ],
 "Learn more": [
  null,
  "더 알아보기"
 ],
 "None": [
  null,
  "없음"
 ],
 "This system is using a custom profile": [
  null,
  "이 시스템은 사용자 정의 프로파일을 사용하고 있습니다"
 ],
 "This system is using the recommended profile": [
  null,
  "이 시스템은 권장 프로파일을 사용하고 있습니다"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned 시작에 실패했습니다"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned는 시스템을 모니터링하고 특정 워크로드에 대해 성능을 최적화하는 서비스입니다. Tuned의 핵심은 다른 사용 사례에 맞게 시스템을 조정하는 프로파일입니다."
 ],
 "Tuned is not available": [
  null,
  "Tuned를 사용 할 수 없습니다"
 ],
 "Tuned is not running": [
  null,
  "Tuned가 동작되지 않음"
 ],
 "Tuned is off": [
  null,
  "Tuned이 종료되어 있습니다"
 ],
 "active": [
  null,
  "활성"
 ],
 "inconsistent": [
  null,
  "일관성 없음"
 ],
 "none": [
  null,
  "없음"
 ],
 "recommended": [
  null,
  "권장 사항"
 ],
 "show less": [
  null,
  "덜 보기"
 ],
 "show more": [
  null,
  "더 보기"
 ]
});
