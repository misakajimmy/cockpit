cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Change performance profile": [
  null,
  "Cambiar el perfil de rendimiento"
 ],
 "Change profile": [
  null,
  "Cambiar el perfil"
 ],
 "Communication with tuned has failed": [
  null,
  "Falló la comunicación con el servicio tuned"
 ],
 "Disable tuned": [
  null,
  "Deshabilitar tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Falló la desactivación del servicio tuned"
 ],
 "Failed to disabled tuned profile": [
  null,
  "Falló la desactivación de un perfil en tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Falló la habilitación de tuned"
 ],
 "Failed to switch profile": [
  null,
  "Falló el cambio de perfil"
 ],
 "Help": [
  null,
  "Ayuda"
 ],
 "Learn more": [
  null,
  "Aprenda más"
 ],
 "None": [
  null,
  "Ninguno"
 ],
 "This system is using a custom profile": [
  null,
  "El sistema utiliza un perfil personalizado"
 ],
 "This system is using the recommended profile": [
  null,
  "El sistema utiliza el perfil recomendado"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned ha fallado al iniciar"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned es un servicio que monitoriza su sistema y optimiza el rendimiendo ante ciertas cargas de trabajo. El núcleo de Tuned son los perfiles, que ecualizan su sistema para distintos tipos de necesidades."
 ],
 "Tuned is not available": [
  null,
  "Tuned no está disponible"
 ],
 "Tuned is not running": [
  null,
  "Tuned no se está ejecutando"
 ],
 "Tuned is off": [
  null,
  "Tuned está apagado"
 ],
 "active": [
  null,
  "activo"
 ],
 "inconsistent": [
  null,
  "inconsistente"
 ],
 "none": [
  null,
  "ninguno"
 ],
 "recommended": [
  null,
  "recomendado"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar más"
 ]
});
