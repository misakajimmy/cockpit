cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Change performance profile": [
  null,
  "Ändra prestandaprofil"
 ],
 "Change profile": [
  null,
  "Ändra profil"
 ],
 "Communication with tuned has failed": [
  null,
  "Kommunikationen med tuned har misslyckats"
 ],
 "Disable tuned": [
  null,
  "Avaktivera tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Misslyckades att avaktivera tuned"
 ],
 "Failed to disabled tuned profile": [
  null,
  "Misslyckades avaktivera en tuned-profil"
 ],
 "Failed to enable tuned": [
  null,
  "Misslyckades att aktivera tuned"
 ],
 "Failed to switch profile": [
  null,
  "Misslyckades att byta profil"
 ],
 "Help": [
  null,
  "Hjälp"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "None": [
  null,
  "Inga"
 ],
 "This system is using a custom profile": [
  null,
  "Detta system använder en anpassad profil"
 ],
 "This system is using the recommended profile": [
  null,
  "Detta system använder den rekommenderade profilen"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned har misslyckats med att starta"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned är en tjänst som övervakar systemet och optimerar prestandan under vissa belastningar. Kärnan av Tuned är profiler, vilka trimmar systemet för olika användningsfall."
 ],
 "Tuned is not available": [
  null,
  "Tuned är inte tillgänglig"
 ],
 "Tuned is not running": [
  null,
  "Tuned kör inte"
 ],
 "Tuned is off": [
  null,
  "Tuned är avslagen"
 ],
 "active": [
  null,
  "aktiv"
 ],
 "inconsistent": [
  null,
  "inkonsekvent"
 ],
 "none": [
  null,
  "ingen"
 ],
 "recommended": [
  null,
  "rekommenderad"
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ]
});
