cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "取消"
 ],
 "Change performance profile": [
  null,
  "更改績效檔案"
 ],
 "Change profile": [
  null,
  "改變檔案"
 ],
 "Communication with tuned has failed": [
  null,
  "與tuned的通信失敗了"
 ],
 "Disable tuned": [
  null,
  "禁用調整"
 ],
 "Failed to disable tuned": [
  null,
  "無法禁用已調整"
 ],
 "Failed to enable tuned": [
  null,
  "無法啟用調整"
 ],
 "Failed to switch profile": [
  null,
  "無法切換配置文件"
 ],
 "Help": [
  null,
  "說明"
 ],
 "None": [
  null,
  "無"
 ],
 "This system is using a custom profile": [
  null,
  "該系統使用自定義配置文件"
 ],
 "This system is using the recommended profile": [
  null,
  "該系統使用推薦的配置文件"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned未能開始"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  ""
 ],
 "Tuned is not available": [
  null,
  "調諧不可用"
 ],
 "Tuned is not running": [
  null,
  "Tuned沒有運行"
 ],
 "Tuned is off": [
  null,
  "Tuned已關閉"
 ],
 "active": [
  null,
  "活性"
 ],
 "none": [
  null,
  "無"
 ],
 "recommended": [
  null,
  "推薦的"
 ],
 "show less": [
  null,
  "顯示較少"
 ],
 "show more": [
  null,
  "顯示更多"
 ]
});
