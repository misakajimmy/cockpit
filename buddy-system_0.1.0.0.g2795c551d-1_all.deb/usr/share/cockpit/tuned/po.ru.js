cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "Отмена"
 ],
 "Change performance profile": [
  null,
  "Изменить профиль производительности"
 ],
 "Change profile": [
  null,
  "Изменить профиль"
 ],
 "Communication with tuned has failed": [
  null,
  "Сбой связи с демоном tuned"
 ],
 "Disable tuned": [
  null,
  "Отключить демон tuned"
 ],
 "Failed to disable tuned": [
  null,
  "Не удалось отключить демон tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Не удалось включить демон tuned"
 ],
 "Failed to switch profile": [
  null,
  "Не удалось переключить профиль"
 ],
 "Help": [
  null,
  "Помощь"
 ],
 "Learn more": [
  null,
  "Подробнее..."
 ],
 "None": [
  null,
  "Нет"
 ],
 "This system is using a custom profile": [
  null,
  "Эта система использует настраиваемый профиль"
 ],
 "This system is using the recommended profile": [
  null,
  "Эта система использует рекомендуемый профиль"
 ],
 "Tuned has failed to start": [
  null,
  "Сбой при запуске демона tuned"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  ""
 ],
 "Tuned is not available": [
  null,
  "Демон tuned недоступен"
 ],
 "Tuned is not running": [
  null,
  "Демон tuned не запущен"
 ],
 "Tuned is off": [
  null,
  "Демон tuned отключен"
 ],
 "active": [
  null,
  "активно"
 ],
 "none": [
  null,
  "нет"
 ],
 "recommended": [
  null,
  "рекомендуется"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ]
});
