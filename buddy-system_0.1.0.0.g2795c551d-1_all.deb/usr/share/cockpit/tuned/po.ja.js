cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "Cancel": [
  null,
  "取り消し"
 ],
 "Change performance profile": [
  null,
  "パフォーマンスプロファイルの変更"
 ],
 "Change profile": [
  null,
  "プロファイルの変更"
 ],
 "Communication with tuned has failed": [
  null,
  "tuned との通信に失敗しました"
 ],
 "Disable tuned": [
  null,
  "tuned の無効化"
 ],
 "Failed to disable tuned": [
  null,
  "tuned の無効化に失敗しました"
 ],
 "Failed to disabled tuned profile": [
  null,
  "tuned プロファイルの無効化に失敗しました"
 ],
 "Failed to enable tuned": [
  null,
  "tuned の有効化に失敗しました"
 ],
 "Failed to switch profile": [
  null,
  "プロファイルの切り替えに失敗しました"
 ],
 "Help": [
  null,
  "ヘルプ"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "None": [
  null,
  "なし"
 ],
 "This system is using a custom profile": [
  null,
  "このシステムはカスタムプロファイルを使用しています"
 ],
 "This system is using the recommended profile": [
  null,
  "このシステムは推奨プロファイルを使用しています"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned の起動に失敗しました"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned は、システムを監視し、特定のワークロードでパフォーマンスを最適化するサービスです。Tuned のコアは、さまざまなユースケースに合わせてシステムを調整するプロファイルです。"
 ],
 "Tuned is not available": [
  null,
  "Tuned が利用できません"
 ],
 "Tuned is not running": [
  null,
  "Tuned が実行中ではありません"
 ],
 "Tuned is off": [
  null,
  "Tuned がオフです"
 ],
 "active": [
  null,
  "アクティブ"
 ],
 "inconsistent": [
  null,
  "一貫性がない"
 ],
 "none": [
  null,
  "なし"
 ],
 "recommended": [
  null,
  "推奨"
 ],
 "show less": [
  null,
  "簡易表示"
 ],
 "show more": [
  null,
  "詳細表示"
 ]
});
