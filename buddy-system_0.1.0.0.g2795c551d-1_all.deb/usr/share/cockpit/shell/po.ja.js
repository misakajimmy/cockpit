cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "$0 ドキュメント"
 ],
 "$0 key changed": [
  null,
  "$0 キーが変更されました"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Cockpit の互換バージョンが $0 にインストールされていません。"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "$0 で新しい SSH キーが $2 の $1 用に作成され、$5 上の $3 の $3 ファイルに追加されました。"
 ],
 "About Web Console": [
  null,
  "Webコンソールについて"
 ],
 "Accept key and connect": [
  null,
  "キーを受け入れて接続"
 ],
 "Accounts": [
  null,
  "アカウント"
 ],
 "Active pages": [
  null,
  "アクティブページ"
 ],
 "Add": [
  null,
  "追加する"
 ],
 "Add key": [
  null,
  "キーを追加する"
 ],
 "Add new host": [
  null,
  "新しいホストを追加する"
 ],
 "Administrative access": [
  null,
  "管理アクセス"
 ],
 "Applications": [
  null,
  "アプリケーション"
 ],
 "Apps": [
  null,
  "アプリ"
 ],
 "Authenticate": [
  null,
  "認証する"
 ],
 "Authentication": [
  null,
  "認証"
 ],
 "Authorize SSH key": [
  null,
  "SSH キーの認証"
 ],
 "Automatic login": [
  null,
  "自動ログイン"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "SSH キー $0 のパスワードを $2 の $1 のログインパスワードに変更することで、自動的にキーが使えるようになります。これで、パスワードなしで $3 にログインできるようになります。"
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "ホスト名、IP アドレス、エイリアス名、または ssh:// URI を指定できます"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Cannot connect to an unknown host": [
  null,
  "不明なホストには接続できません"
 ],
 "Change password": [
  null,
  "パスワードの変更"
 ],
 "Change the password of $0": [
  null,
  "$0 のパスワードを変更します"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "キーを変更すると、オペレーティングシステムを再インストールすることになることが多くあります。ただし、予期しない変更により接続の傍受が試行される場合もあります。"
 ],
 "Choose the language to be used in the application": [
  null,
  "アプリケーションで使用する言語の選択"
 ],
 "Clear search": [
  null,
  "検索の消去"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Close selected pages": [
  null,
  "選択されたページを閉じる"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "cockpit で予期しない内部エラーが発生しました。"
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit は対話型 Linux サーバー管理インターフェースです。"
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit はインストールされていません"
 ],
 "Color": [
  null,
  "色"
 ],
 "Comment": [
  null,
  "コメント"
 ],
 "Configuring kdump": [
  null,
  "kdumpを設定中"
 ],
 "Configuring system settings": [
  null,
  "システム設定の変更"
 ],
 "Confirm key password": [
  null,
  "キーパスワードの確認"
 ],
 "Confirm new key password": [
  null,
  "新しいキーパスワードの確認"
 ],
 "Confirm password": [
  null,
  "パスワードの確認"
 ],
 "Connecting to the machine": [
  null,
  "マシンへ接続中"
 ],
 "Connection error": [
  null,
  "接続エラー"
 ],
 "Connection failed": [
  null,
  "接続に失敗しました"
 ],
 "Contains:": [
  null,
  "含む:"
 ],
 "Continue session": [
  null,
  "セッションを続ける"
 ],
 "Copied": [
  null,
  "コピー済み"
 ],
 "Copy": [
  null,
  "コピー"
 ],
 "Could not contact $0": [
  null,
  "$0 に問い合わせられませんでした"
 ],
 "Create": [
  null,
  "作成"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "新しい SSH キーを作成し、その鍵を承認"
 ],
 "Ctrl-Shift-J": [
  null,
  "Ctrl-Shift-J"
 ],
 "Dark": [
  null,
  "ダーク"
 ],
 "Default": [
  null,
  "デフォルト"
 ],
 "Details": [
  null,
  "詳細"
 ],
 "Development": [
  null,
  "開発"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Disconnected": [
  null,
  "切断されています"
 ],
 "Display language": [
  null,
  "表示言語"
 ],
 "Edit": [
  null,
  "編集"
 ],
 "Edit host": [
  null,
  "ホストを編集する"
 ],
 "Edit hosts": [
  null,
  "ホストを編集する"
 ],
 "Failed to add machine: $0": [
  null,
  "マシンの追加に失敗しました: $0"
 ],
 "Failed to change password": [
  null,
  "パスワードの変更に失敗しました"
 ],
 "Failed to edit machine: $0": [
  null,
  "マシンの編集に失敗しました: $0"
 ],
 "Filter menu items": [
  null,
  "フィルターメニューアイテム"
 ],
 "Fingerprint": [
  null,
  "フィンガープリント"
 ],
 "Help": [
  null,
  "ヘルプ"
 ],
 "Host": [
  null,
  "ホスト"
 ],
 "Hosts": [
  null,
  "ホスト"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  "フィンガープリントが一致している場合は、キーを受け入れて接続をクリックします。一致していない場合は、接続せずに管理者にお問い合わせください。"
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "今後、$0 にパスワードなしで $1 としてログインできるようにするには、$3 上の $2 のログインパスワードをキーパスワードとして使用するか、キーパスワードを空欄のままにしてください。"
 ],
 "Invalid file permissions": [
  null,
  "無効なファイルパーミッション"
 ],
 "Is sshd running on a different port?": [
  null,
  "sshd が別のポートで実行されていますか?"
 ],
 "Kernel dump": [
  null,
  "カーネルダンプ"
 ],
 "Key password": [
  null,
  "キーパスワード"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "GNU LGPL バージョン 2.1 でのライセンス"
 ],
 "Light": [
  null,
  "ライト"
 ],
 "Limit access": [
  null,
  "アクセスの制限"
 ],
 "Limited access": [
  null,
  "制限付きアクセス"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "限定アクセスモードでは、管理者権限が制限されます。Web コンソールの一部の機能が低下します。"
 ],
 "Loading packages...": [
  null,
  "パッケージの読み込み中..."
 ],
 "Log in": [
  null,
  "ログイン"
 ],
 "Log in to $0": [
  null,
  "$0 へのログイン"
 ],
 "Log out": [
  null,
  "ログアウト"
 ],
 "Logs": [
  null,
  "ログ"
 ],
 "Managing LVMs": [
  null,
  "LVM の管理"
 ],
 "Managing NFS mounts": [
  null,
  "NFS マウントの管理"
 ],
 "Managing RAIDs": [
  null,
  "RAID の管理"
 ],
 "Managing VDOs": [
  null,
  "VDO の管理"
 ],
 "Managing VLANs": [
  null,
  "VLAN の管理"
 ],
 "Managing firewall": [
  null,
  "ファイアウォール管理"
 ],
 "Managing networking bonds": [
  null,
  "ネットワークボンディングの管理"
 ],
 "Managing networking bridges": [
  null,
  "ネットワークブリッジの管理"
 ],
 "Managing networking teams": [
  null,
  "ネットワークチームの管理"
 ],
 "Managing partitions": [
  null,
  "パーティション管理"
 ],
 "Managing physical drives": [
  null,
  "物理ドライブの管理"
 ],
 "Managing services": [
  null,
  "サービス管理"
 ],
 "Managing software updates": [
  null,
  "ソフトウェアアップデート管理"
 ],
 "Managing user accounts": [
  null,
  "ユーザーアカウント管理"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "障害に関連するメッセージは、ジャーナルで見つかる場合があります:"
 ],
 "Method": [
  null,
  "メソッド"
 ],
 "Name": [
  null,
  "名前"
 ],
 "Networking": [
  null,
  "ネットワーキング"
 ],
 "New host": [
  null,
  "新規ホスト"
 ],
 "New key password": [
  null,
  "新しいキーパスワード"
 ],
 "New password": [
  null,
  "新規パスワード"
 ],
 "New password was not accepted": [
  null,
  "新規パスワードは受け入れられませんでした"
 ],
 "No results found": [
  null,
  "結果が見つかりません"
 ],
 "No such file or directory": [
  null,
  "このようなファイルまたはディレクトリーがありません"
 ],
 "Not a valid private key": [
  null,
  "有効な秘密鍵ではありません"
 ],
 "Not connected to host": [
  null,
  "ホストに接続されていません"
 ],
 "Old password not accepted": [
  null,
  "古いパスワードは受け入れられません"
 ],
 "Ooops!": [
  null,
  "問題が発生しました!"
 ],
 "Overview": [
  null,
  "概要"
 ],
 "Page name": [
  null,
  "ページ名"
 ],
 "Password": [
  null,
  "パスワード"
 ],
 "Password changed successfully": [
  null,
  "パスワードが正しく変更されました"
 ],
 "Password not accepted": [
  null,
  "パスワードは受け入れられません"
 ],
 "Password tip": [
  null,
  "パスワードヒント"
 ],
 "Path to file": [
  null,
  "ファイルのパス"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "管理者アクセスを得るために認証を行ってください"
 ],
 "Port": [
  null,
  "ポート"
 ],
 "Problem becoming administrator": [
  null,
  "管理者への切り替えに問題が発生しました"
 ],
 "Project website": [
  null,
  "プロジェクト Web サイト"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "ssh-add によるプロンプトがタイムアウトしました"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "ssh-keygen によるプロンプトがタイムアウトしました"
 ],
 "Public key": [
  null,
  "公開鍵"
 ],
 "Reconnect": [
  null,
  "再接続"
 ],
 "Remove": [
  null,
  "削除"
 ],
 "Reviewing logs": [
  null,
  "ログのレビュー"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH キー"
 ],
 "SSH keys": [
  null,
  "SSH キー"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safari ユーザーは、自己署名 CA 証明書をインポートし、信頼する必要があります:"
 ],
 "Search": [
  null,
  "検索"
 ],
 "Select": [
  null,
  "選択"
 ],
 "Services": [
  null,
  "サービス"
 ],
 "Session": [
  null,
  "セッション"
 ],
 "Session is about to expire": [
  null,
  "セッションはまもなく終了します"
 ],
 "Set": [
  null,
  "セット"
 ],
 "Skip main navigation": [
  null,
  "メインナビゲーションをスキップします"
 ],
 "Skip to content": [
  null,
  "コンテンツへスキップ"
 ],
 "Software updates": [
  null,
  "ソフトウェア更新"
 ],
 "Stop editing hosts": [
  null,
  "ホストの編集を停止"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Style": [
  null,
  ""
 ],
 "Switch to administrative access": [
  null,
  "管理者アクセスへの切り替え"
 ],
 "Switch to limited access": [
  null,
  "アクセス制限への切り替え"
 ],
 "System": [
  null,
  "システム"
 ],
 "Terminal": [
  null,
  "端末"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP アドレスまたはホスト名には空白を含めることができません。"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "$2 の $1 の SSH キー $0 は、$5 上の $4 の $3 ファイルに追加されます。"
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH キー $0 はセッションの残りの時間に利用できるようになり、他のホストにもログインできるようになります。"
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0 にログインするための SSH キーはパスワードで保護され、パスワードによるログインを許可しません。$1 にキーのパスワードを指定してください。"
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0 にログインするための SSH キーは保護されています。ログインパスワードでログインするか、$1 で鍵のパスワードを提供することでログインできます。"
 ],
 "The key password can not be empty": [
  null,
  "キーのパスワードは空にすることはできません"
 ],
 "The key passwords do not match": [
  null,
  "キーのパスワードが一致しません"
 ],
 "The machine is rebooting": [
  null,
  "マシンが再起動中です"
 ],
 "The new key password can not be empty": [
  null,
  "新しいキーのパスワードは空にすることはできません"
 ],
 "The password can not be empty": [
  null,
  "パスワードは空にできません"
 ],
 "The passwords do not match.": [
  null,
  "パスワードが一致しません。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "作成されたフィンガープリントは、電子メールを含むパブリックメソッドを介して共有すると問題ありません。"
 ],
 "There are currently no active pages": [
  null,
  "現在アクティブなページはありません"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "マシンへの接続中に予期しないエラーが発生しました。"
 ],
 "This machine has already been added.": [
  null,
  "このマシンはすでに追加されています。"
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "これにより、今後はパスワードなしでログインできるようになります。"
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "ヒント: 他のシステムに対して自動的に認証する場合は、鍵のパスワードをログインパスワードに一致させます。"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "悪意のあるサードパーティーによって接続がインターセプトされないようにするには、ホストキーフィンガープリントを確認してください:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "フィンガープリントを確認するには、マシン上に物理的に置かれるか、信頼できるネットワークを介して $0 で次のコマンドを実行します:"
 ],
 "Toggle": [
  null,
  "切り替え"
 ],
 "Tools": [
  null,
  "ツール"
 ],
 "Turn on administrative access": [
  null,
  "管理者アクセスをオンにする"
 ],
 "Type": [
  null,
  "タイプ"
 ],
 "Unable to contact $0.": [
  null,
  "$0 と通信できません。"
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "該当するホスト $0 に接続できませんでした。そのホストのポート $1 で ssh が実行されていることを確認するか、アドレスで別のポートを指定します。"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "SSH キー認証で $0 にログインできません。パスワードを入力してください。SSH キーを自動ログイン用に設定しておいてください。"
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0 にログインできません。ホストが、パスワードログインまたは SSH キーを受け付けていません。"
 ],
 "Unexpected error": [
  null,
  "予期しないエラー"
 ],
 "Unlock": [
  null,
  "ロック解除"
 ],
 "Unlock key $0": [
  null,
  "ロック解除キー $0"
 ],
 "Update": [
  null,
  "更新"
 ],
 "Use key": [
  null,
  "キーの使用"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "他のシステムに対して認証する場合は次の鍵を使用します"
 ],
 "User name": [
  null,
  "ユーザー名"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS 暗号化の使用"
 ],
 "Using Tang server": [
  null,
  "Tang サーバーの使用"
 ],
 "Web Console": [
  null,
  "Webコンソール"
 ],
 "Web console logo": [
  null,
  "Web コンソールロゴ"
 ],
 "When empty, connect with the current user": [
  null,
  "空の場合は、現在のユーザーに接続します"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "初めて $0 に接続しています。"
 ],
 "You have been logged out due to inactivity.": [
  null,
  "アクティビティーがないためログアウトされました。"
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "自動ログイン用の鍵のパスワードの変更が必要な場合があります。"
 ],
 "You now have administrative access.": [
  null,
  "これで管理者アクセスが可能になりました。"
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "$0 秒後にログアウトされます。"
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "ブラウザーはセッション間のアクセスレベルを記憶します。"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "access": [
  null,
  "アクセス"
 ],
 "active": [
  null,
  "アクティブ"
 ],
 "add-on": [
  null,
  "add-on"
 ],
 "addon": [
  null,
  "addon"
 ],
 "apps": [
  null,
  "apps"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "アセットタグ"
 ],
 "avc": [
  null,
  "avc"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "BIOS"
 ],
 "bond": [
  null,
  "ボンディング"
 ],
 "boot": [
  null,
  "ブート"
 ],
 "bridge": [
  null,
  "ブリッジ"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "コマンド"
 ],
 "console": [
  null,
  "コンソール"
 ],
 "coredump": [
  null,
  "コアダンプ"
 ],
 "cpu": [
  null,
  "CPU"
 ],
 "crash": [
  null,
  "クラッシュ"
 ],
 "date": [
  null,
  "日付"
 ],
 "debug": [
  null,
  "デバッグ"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "無効にする"
 ],
 "disk": [
  null,
  "ディスク"
 ],
 "disks": [
  null,
  "ディスク"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "domain": [
  null,
  "ドメイン"
 ],
 "drive": [
  null,
  "ドライブ"
 ],
 "enable": [
  null,
  "有効にする"
 ],
 "encryption": [
  null,
  "暗号化"
 ],
 "error": [
  null,
  "エラー"
 ],
 "extension": [
  null,
  "拡張"
 ],
 "filesystem": [
  null,
  "ファイルシステム"
 ],
 "firewall": [
  null,
  "ファイアウォール"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "format": [
  null,
  "フォーマット"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "graphs": [
  null,
  "グラフ"
 ],
 "hardware": [
  null,
  "ハードウェア"
 ],
 "history": [
  null,
  "履歴"
 ],
 "host": [
  null,
  "ホスト"
 ],
 "in most browsers": [
  null,
  "多くのブラウザー"
 ],
 "install": [
  null,
  "インストール"
 ],
 "interface": [
  null,
  "インターフェース"
 ],
 "ipv4": [
  null,
  "IPv4"
 ],
 "ipv6": [
  null,
  "IPv6"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "journal": [
  null,
  "ジャーナル"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "鍵"
 ],
 "login": [
  null,
  "ログイン"
 ],
 "luks": [
  null,
  "LUKS"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mac": [
  null,
  "MAC"
 ],
 "machine": [
  null,
  "マシン"
 ],
 "mask": [
  null,
  "マスク"
 ],
 "memory": [
  null,
  "メモリー"
 ],
 "metrics": [
  null,
  "メトリックス"
 ],
 "mitigation": [
  null,
  "軽減"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "マウント"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "network": [
  null,
  "ネットワーク"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "operating system": [
  null,
  "オペレーティングシステム"
 ],
 "os": [
  null,
  "OS"
 ],
 "package": [
  null,
  "パッケージ"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "partition": [
  null,
  "パーティション"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "パスワード"
 ],
 "path": [
  null,
  "パス"
 ],
 "pci": [
  null,
  "PCI"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "パフォーマンス"
 ],
 "plugin": [
  null,
  "プラグイン"
 ],
 "port": [
  null,
  "ポート"
 ],
 "power": [
  null,
  "電源"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "ram": [
  null,
  "RAM"
 ],
 "restart": [
  null,
  "再起動"
 ],
 "roles": [
  null,
  "ロール"
 ],
 "security": [
  null,
  "セキュリティー"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  "シリアル"
 ],
 "service": [
  null,
  "サービス"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ],
 "shell": [
  null,
  "シェル"
 ],
 "show less": [
  null,
  "簡易表示"
 ],
 "show more": [
  null,
  "詳細表示"
 ],
 "shut": [
  null,
  "シャット"
 ],
 "socket": [
  null,
  "ソケット"
 ],
 "sos": [
  null,
  "sos"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "tang"
 ],
 "target": [
  null,
  "ターゲット"
 ],
 "tcp": [
  null,
  "TCP"
 ],
 "team": [
  null,
  "チーム"
 ],
 "time": [
  null,
  "時間"
 ],
 "timer": [
  null,
  "タイマー"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  "単位"
 ],
 "unmask": [
  null,
  "マスク解除"
 ],
 "unmount": [
  null,
  "アンマウント"
 ],
 "user": [
  null,
  "ユーザー"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "ユーザー名"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "version": [
  null,
  "バージョン"
 ],
 "vlan": [
  null,
  "VLAN"
 ],
 "volume": [
  null,
  "ボリューム"
 ],
 "warning": [
  null,
  "警告"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "ゾーン"
 ]
});
