cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "$0 核對"
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  ""
 ],
 "Accept key and connect": [
  null,
  ""
 ],
 "Accounts": [
  null,
  "帳號管理"
 ],
 "Active pages": [
  null,
  "活動頁面"
 ],
 "Add": [
  null,
  "加入"
 ],
 "Add key": [
  null,
  "新增密鑰"
 ],
 "Applications": [
  null,
  "應用程式"
 ],
 "Apps": [
  null,
  ""
 ],
 "Authentication": [
  null,
  "核對"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  ""
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  ""
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Change password": [
  null,
  "更改密碼"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  ""
 ],
 "Choose the language to be used in the application": [
  null,
  "選擇要在應用程式中使用的語言"
 ],
 "Clear search": [
  null,
  ""
 ],
 "Close": [
  null,
  "關閉"
 ],
 "Close selected pages": [
  null,
  "關閉所選頁面"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  ""
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit是一個交互式Linux伺服器管理界面。"
 ],
 "Cockpit is not installed": [
  null,
  "沒有安裝駕駛艙"
 ],
 "Color": [
  null,
  "顏色"
 ],
 "Comment": [
  null,
  "備註"
 ],
 "Connecting to the machine": [
  null,
  "連接到機器"
 ],
 "Connection error": [
  null,
  "連接錯誤"
 ],
 "Connection failed": [
  null,
  ""
 ],
 "Continue session": [
  null,
  ""
 ],
 "Copied": [
  null,
  ""
 ],
 "Copy": [
  null,
  ""
 ],
 "Create": [
  null,
  "建立"
 ],
 "Create a new SSH key and authorize it": [
  null,
  ""
 ],
 "Ctrl-Shift-J": [
  null,
  ""
 ],
 "Dark": [
  null,
  "深色"
 ],
 "Default": [
  null,
  "預設值"
 ],
 "Details": [
  null,
  "詳情"
 ],
 "Development": [
  null,
  ""
 ],
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "Disconnected": [
  null,
  "已離線"
 ],
 "Display language": [
  null,
  "顯示語言"
 ],
 "Edit": [
  null,
  "編輯"
 ],
 "Edit hosts": [
  null,
  ""
 ],
 "Failed to add machine: $0": [
  null,
  "新增機器失敗： $0"
 ],
 "Failed to change password": [
  null,
  "無法更改密碼"
 ],
 "Failed to edit machine: $0": [
  null,
  "無法編輯機器： $0"
 ],
 "Fingerprint": [
  null,
  "指紋"
 ],
 "Help": [
  null,
  "說明"
 ],
 "Host": [
  null,
  "主機"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  ""
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  ""
 ],
 "Invalid file permissions": [
  null,
  "文件權限無效"
 ],
 "Is sshd running on a different port?": [
  null,
  "sshd是否在不同的端口上運行?"
 ],
 "Kernel dump": [
  null,
  "內核轉儲"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  ""
 ],
 "Light": [
  null,
  "淺色"
 ],
 "Limit access": [
  null,
  ""
 ],
 "Limited access": [
  null,
  ""
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  ""
 ],
 "Log in": [
  null,
  "登入"
 ],
 "Log out": [
  null,
  "登出"
 ],
 "Logs": [
  null,
  "系統日誌"
 ],
 "Managing firewall": [
  null,
  "防火牆管理"
 ],
 "Managing user accounts": [
  null,
  ""
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  ""
 ],
 "Method": [
  null,
  ""
 ],
 "Name": [
  null,
  "名稱"
 ],
 "Networking": [
  null,
  "網路作業"
 ],
 "New password": [
  null,
  "新密碼"
 ],
 "New password was not accepted": [
  null,
  "不接受新密碼"
 ],
 "No results found": [
  null,
  ""
 ],
 "No such file or directory": [
  null,
  "沒有相應的文件和目錄"
 ],
 "Not a valid private key": [
  null,
  "不是有效的私鑰"
 ],
 "Old password not accepted": [
  null,
  "舊密碼不被接受"
 ],
 "Ooops!": [
  null,
  "[錯誤]"
 ],
 "Overview": [
  null,
  "主機狀態"
 ],
 "Password": [
  null,
  "密碼"
 ],
 "Password not accepted": [
  null,
  "密碼不被接受"
 ],
 "Path to file": [
  null,
  "文件路徑"
 ],
 "Please authenticate to gain administrative access": [
  null,
  ""
 ],
 "Port": [
  null,
  "連接埠"
 ],
 "Project website": [
  null,
  "項目網站"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "提示通過ssh-add超時"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "通過ssh-keygen提示超時"
 ],
 "Public key": [
  null,
  "公鑰"
 ],
 "Reconnect": [
  null,
  "重新連接"
 ],
 "Remove": [
  null,
  "移除"
 ],
 "SELinux": [
  null,
  ""
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  ""
 ],
 "Search": [
  null,
  ""
 ],
 "Select": [
  null,
  "選擇"
 ],
 "Services": [
  null,
  "服務"
 ],
 "Session": [
  null,
  "作業階段"
 ],
 "Session is about to expire": [
  null,
  ""
 ],
 "Set": [
  null,
  "設置"
 ],
 "Skip main navigation": [
  null,
  ""
 ],
 "Software updates": [
  null,
  "軟件更新"
 ],
 "Stop editing hosts": [
  null,
  ""
 ],
 "Storage": [
  null,
  "儲存裝置"
 ],
 "Style": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  ""
 ],
 "System": [
  null,
  "系統"
 ],
 "Terminal": [
  null,
  "終端機"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  ""
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  ""
 ],
 "The passwords do not match.": [
  null,
  "密碼兩者不相符。"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  ""
 ],
 "There are currently no active pages": [
  null,
  "目前沒有活動頁面"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  ""
 ],
 "This machine has already been added.": [
  null,
  "這台機器已經新增。"
 ],
 "This will allow you to log in without password in the future.": [
  null,
  ""
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "提示：使您的密鑰密碼與您的登錄密碼相匹配，以自動對其他系統進行身份驗證。"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  ""
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  ""
 ],
 "Toggle": [
  null,
  ""
 ],
 "Tools": [
  null,
  ""
 ],
 "Turn on administrative access": [
  null,
  ""
 ],
 "Type": [
  null,
  "類型"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  ""
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  ""
 ],
 "Unexpected error": [
  null,
  "未預期的錯誤"
 ],
 "Unlock": [
  null,
  "解除鎖定"
 ],
 "Update": [
  null,
  "更新"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "使用以下密鑰對其他系統進行身份驗證"
 ],
 "User name": [
  null,
  "使用者名稱"
 ],
 "Using LUKS encryption": [
  null,
  ""
 ],
 "When empty, connect with the current user": [
  null,
  ""
 ],
 "You are connecting to $0 for the first time.": [
  null,
  ""
 ],
 "You have been logged out due to inactivity.": [
  null,
  ""
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  ""
 ],
 "You now have administrative access.": [
  null,
  ""
 ],
 "You will be logged out in $0 seconds.": [
  null,
  ""
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  ""
 ],
 "abrt": [
  null,
  ""
 ],
 "access": [
  null,
  ""
 ],
 "active": [
  null,
  "活性"
 ],
 "add-on": [
  null,
  ""
 ],
 "addon": [
  null,
  ""
 ],
 "apps": [
  null,
  ""
 ],
 "apt-get": [
  null,
  ""
 ],
 "asset tag": [
  null,
  "標籤"
 ],
 "avc": [
  null,
  ""
 ],
 "bash": [
  null,
  ""
 ],
 "bios": [
  null,
  ""
 ],
 "bond": [
  null,
  ""
 ],
 "boot": [
  null,
  ""
 ],
 "bridge": [
  null,
  "橋"
 ],
 "cgroups": [
  null,
  ""
 ],
 "command": [
  null,
  ""
 ],
 "console": [
  null,
  ""
 ],
 "coredump": [
  null,
  ""
 ],
 "cpu": [
  null,
  "處理器"
 ],
 "crash": [
  null,
  "崩潰"
 ],
 "date": [
  null,
  ""
 ],
 "debug": [
  null,
  ""
 ],
 "dimm": [
  null,
  ""
 ],
 "disable": [
  null,
  ""
 ],
 "disk": [
  null,
  "磁碟"
 ],
 "dnf": [
  null,
  ""
 ],
 "domain": [
  null,
  ""
 ],
 "drive": [
  null,
  ""
 ],
 "enable": [
  null,
  "啟用"
 ],
 "encryption": [
  null,
  ""
 ],
 "error": [
  null,
  "錯誤"
 ],
 "extension": [
  null,
  ""
 ],
 "filesystem": [
  null,
  ""
 ],
 "firewall": [
  null,
  ""
 ],
 "format": [
  null,
  ""
 ],
 "fstab": [
  null,
  ""
 ],
 "graphs": [
  null,
  ""
 ],
 "hardware": [
  null,
  ""
 ],
 "host": [
  null,
  "主機"
 ],
 "in most browsers": [
  null,
  ""
 ],
 "install": [
  null,
  ""
 ],
 "interface": [
  null,
  ""
 ],
 "ipv4": [
  null,
  ""
 ],
 "ipv6": [
  null,
  ""
 ],
 "iscsi": [
  null,
  ""
 ],
 "journal": [
  null,
  ""
 ],
 "kdump": [
  null,
  ""
 ],
 "keys": [
  null,
  ""
 ],
 "login": [
  null,
  ""
 ],
 "luks": [
  null,
  ""
 ],
 "lvm2": [
  null,
  ""
 ],
 "mac": [
  null,
  ""
 ],
 "machine": [
  null,
  ""
 ],
 "mask": [
  null,
  ""
 ],
 "memory": [
  null,
  ""
 ],
 "mitigation": [
  null,
  ""
 ],
 "mkfs": [
  null,
  ""
 ],
 "mount": [
  null,
  ""
 ],
 "nbde": [
  null,
  ""
 ],
 "network": [
  null,
  "網絡"
 ],
 "nfs": [
  null,
  ""
 ],
 "operating system": [
  null,
  ""
 ],
 "os": [
  null,
  ""
 ],
 "package": [
  null,
  ""
 ],
 "packagekit": [
  null,
  ""
 ],
 "partition": [
  null,
  ""
 ],
 "passwd": [
  null,
  ""
 ],
 "password": [
  null,
  ""
 ],
 "path": [
  null,
  ""
 ],
 "pci": [
  null,
  ""
 ],
 "plugin": [
  null,
  ""
 ],
 "port": [
  null,
  ""
 ],
 "power": [
  null,
  ""
 ],
 "raid": [
  null,
  ""
 ],
 "ram": [
  null,
  ""
 ],
 "restart": [
  null,
  ""
 ],
 "roles": [
  null,
  ""
 ],
 "security": [
  null,
  "安全性"
 ],
 "semanage": [
  null,
  ""
 ],
 "serial": [
  null,
  ""
 ],
 "service": [
  null,
  ""
 ],
 "setroubleshoot": [
  null,
  ""
 ],
 "shell": [
  null,
  ""
 ],
 "show less": [
  null,
  "顯示較少"
 ],
 "show more": [
  null,
  "顯示更多"
 ],
 "shut": [
  null,
  ""
 ],
 "socket": [
  null,
  ""
 ],
 "sos": [
  null,
  ""
 ],
 "ssh": [
  null,
  ""
 ],
 "systemctl": [
  null,
  ""
 ],
 "systemd": [
  null,
  ""
 ],
 "tang": [
  null,
  ""
 ],
 "target": [
  null,
  ""
 ],
 "tcp": [
  null,
  ""
 ],
 "team": [
  null,
  ""
 ],
 "time": [
  null,
  ""
 ],
 "timer": [
  null,
  ""
 ],
 "udisks": [
  null,
  ""
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  ""
 ],
 "unmask": [
  null,
  ""
 ],
 "unmount": [
  null,
  ""
 ],
 "user": [
  null,
  "使用者"
 ],
 "useradd": [
  null,
  ""
 ],
 "username": [
  null,
  ""
 ],
 "vdo": [
  null,
  ""
 ],
 "version": [
  null,
  ""
 ],
 "vlan": [
  null,
  ""
 ],
 "volume": [
  null,
  ""
 ],
 "warning": [
  null,
  ""
 ],
 "yum": [
  null,
  ""
 ],
 "zone": [
  null,
  ""
 ]
});
