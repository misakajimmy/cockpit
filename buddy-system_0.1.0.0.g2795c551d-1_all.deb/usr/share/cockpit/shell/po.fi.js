cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "$0 -dokumentaatio"
 ],
 "$0 key changed": [
  null,
  "$0 avain muuttunut"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Yhteensopivaa versiota Cockpitistä ei ole asennettu kohteessa $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Uusi SSH-avain nimellä $0 luodaan käyttäjälle $1 koneella $2 ja se lisätään käyttäjän $3 tiedostoon $4 koneella $5."
 ],
 "About Web Console": [
  null,
  "Tietoja Verkkokonsolista"
 ],
 "Accept key and connect": [
  null,
  "Hyväksy avain ja muodosta yhteys"
 ],
 "Accounts": [
  null,
  "Käyttäjätilit"
 ],
 "Active pages": [
  null,
  "Aktiiviset sivut"
 ],
 "Add": [
  null,
  "Lisää"
 ],
 "Add key": [
  null,
  "Lisää avain"
 ],
 "Add new host": [
  null,
  "Lisää uusi kone"
 ],
 "Administrative access": [
  null,
  "Ylläpitäjän käyttöoikeudet"
 ],
 "Applications": [
  null,
  "Sovellukset"
 ],
 "Apps": [
  null,
  "Sovellukset"
 ],
 "Authenticate": [
  null,
  "Tunnistaudu"
 ],
 "Authentication": [
  null,
  "Tunnistautuminen"
 ],
 "Authorize SSH key": [
  null,
  "Valtuuta SSH-avain"
 ],
 "Automatic login": [
  null,
  "Automaattinen sisäänkirjautuminen"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Vaihtamalla SSH-avaimen $0 salasanan käyttäjän $1 kirjautumissalasanaksi koneella $2, avain tulee automaattisesti saataville ja voit kirjautua sisään koneelle $3 jatkossa ilman salasanaa."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Voi olla konenimi, IP-osoite, aliaksen nimi tai ssh:// URI"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Ei voida yhdistää tuntemattomaan koneeseen"
 ],
 "Change password": [
  null,
  "Vaihda salasana"
 ],
 "Change the password of $0": [
  null,
  "Vaihda avaimen $0 salasana"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Muutetut avaimet ovat usein seurausta käyttöjärjestelmän uudelleenasennuksesta. Odottamaton muutos voi kuitenkin tarkoittaa kolmannen osapuolen yritystä siepata yhteys."
 ],
 "Choose the language to be used in the application": [
  null,
  "Valitse sovelluksessa käytettävä kieli"
 ],
 "Clear search": [
  null,
  "Tyhjennä haku"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Close selected pages": [
  null,
  "Sulje valitut sivut"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpitissa oli odottamaton sisäinen virhe."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit on vuorovaikutteinen Linux-palvelimen ylläpitäjän käyttöliittymä."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ei ole asennettu"
 ],
 "Color": [
  null,
  "Väri"
 ],
 "Comment": [
  null,
  "Kommentti"
 ],
 "Configuring kdump": [
  null,
  "kdump:n määrittäminen"
 ],
 "Configuring system settings": [
  null,
  "Järjestelmäasetusten määrittäminen"
 ],
 "Confirm key password": [
  null,
  "Vahvista avaimen salasana"
 ],
 "Confirm new key password": [
  null,
  "Vahvista uusi avaimen salasana"
 ],
 "Confirm password": [
  null,
  "Vahvista salasana"
 ],
 "Connecting to the machine": [
  null,
  "Yhdistetään koneeseen"
 ],
 "Connection error": [
  null,
  "Yhteysvirhe"
 ],
 "Connection failed": [
  null,
  "Yhteys epäonnistui"
 ],
 "Contains:": [
  null,
  "Sisältää:"
 ],
 "Continue session": [
  null,
  "Jatka istuntoa"
 ],
 "Copied": [
  null,
  "Kopioitu"
 ],
 "Copy": [
  null,
  "Kopio"
 ],
 "Could not contact $0": [
  null,
  "Ei saatu yhteyttä kohteeseen $0"
 ],
 "Create": [
  null,
  "Luo"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Luo uusi SSH-avain ja valtuuta se"
 ],
 "Ctrl-Shift-J": [
  null,
  "Ctrl-Vaihto-J"
 ],
 "Dark": [
  null,
  "Tumma"
 ],
 "Default": [
  null,
  "Oletus"
 ],
 "Details": [
  null,
  "Yksityiskohdat"
 ],
 "Development": [
  null,
  "Kehitys"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Disconnected": [
  null,
  "Katkaistu"
 ],
 "Display language": [
  null,
  "Käytettävä kieli"
 ],
 "Edit": [
  null,
  "Muokkaa"
 ],
 "Edit host": [
  null,
  "Muokkaa konetta"
 ],
 "Edit hosts": [
  null,
  "Muokkaa koneita"
 ],
 "Failed to add machine: $0": [
  null,
  "Ei voitu lisätä konetta: $0"
 ],
 "Failed to change password": [
  null,
  "Salasanan vaihtaminen epäonnistui"
 ],
 "Failed to edit machine: $0": [
  null,
  "Koneen muokkaaminen epäonnistui: $0"
 ],
 "Filter menu items": [
  null,
  "Suodata valikkokohteita"
 ],
 "Fingerprint": [
  null,
  "Sormenjälki"
 ],
 "Help": [
  null,
  "Ohje"
 ],
 "Host": [
  null,
  "Kone"
 ],
 "Hosts": [
  null,
  "Koneet"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jos sormenjälki on sama, napsauta 'Hyväksy avain ja muodosta yhteys'. Muussa tapauksessa älä muodosta yhteyttä ja ota yhteyttä järjestelmänvalvojaan."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Jos haluat sallia sisäänkirjautumisen koneelle $0 käyttäjänä $1 ilman salasanaa tulevaisuudessa, käytä käyttäjän $2 sisäänkirjautumissalasanaa koneen $3 avainsalasanana tai jätä avaimen salasana tyhjäksi."
 ],
 "Invalid file permissions": [
  null,
  "Virheelliset tiedosto-oikeudet"
 ],
 "Is sshd running on a different port?": [
  null,
  "Onko sshd käynnissä eri portissa?"
 ],
 "Kernel dump": [
  null,
  "Ytimen tyhjennys"
 ],
 "Key password": [
  null,
  "Avaimen salasana"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Käytetään GNU LGPL -versio 2.1 lisenssiä"
 ],
 "Light": [
  null,
  "Kevyt"
 ],
 "Limit access": [
  null,
  "Rajoita pääsyä"
 ],
 "Limited access": [
  null,
  "Rajoitettu käyttö"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Rajoitettu käyttö -tila rajoittaa ylläpito-oikeuksia. Joitakin verkkokonsolin toimintoja on karsittu."
 ],
 "Loading packages...": [
  null,
  "Ladataan paketteja..."
 ],
 "Log in": [
  null,
  "Kirjaudu sisään"
 ],
 "Log in to $0": [
  null,
  "Kirjaudu kohteeseen $0"
 ],
 "Log out": [
  null,
  "Kirjaudu ulos"
 ],
 "Logs": [
  null,
  "Lokit"
 ],
 "Managing LVMs": [
  null,
  "LVM:den hallinta"
 ],
 "Managing NFS mounts": [
  null,
  "NFS-liitosten hallinta"
 ],
 "Managing RAIDs": [
  null,
  "RAIDien hallinta"
 ],
 "Managing VDOs": [
  null,
  "VDO:iden hallinta"
 ],
 "Managing VLANs": [
  null,
  "VLANien hallinta"
 ],
 "Managing firewall": [
  null,
  "Palomuurin hallinta"
 ],
 "Managing networking bonds": [
  null,
  "Verkkosidosten hallinta"
 ],
 "Managing networking bridges": [
  null,
  "Verkkosiltojen hallinta"
 ],
 "Managing networking teams": [
  null,
  "Verkkojoukkojen hallinta"
 ],
 "Managing partitions": [
  null,
  "Osioiden hallinta"
 ],
 "Managing physical drives": [
  null,
  "Fyysisten asemien hallinta"
 ],
 "Managing services": [
  null,
  "Palvelujen hallinta"
 ],
 "Managing software updates": [
  null,
  "Ohjelmistopäivitysten hallinta"
 ],
 "Managing user accounts": [
  null,
  "Käyttäjätilien hallinta"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Virheeseen liittyvät viestit saattavat löytyä päiväkirjasta:"
 ],
 "Method": [
  null,
  "Menetelmä"
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "Networking": [
  null,
  "Verkko"
 ],
 "New host": [
  null,
  "Uusi kone"
 ],
 "New key password": [
  null,
  "Uuden avaimen salasana"
 ],
 "New password": [
  null,
  "Uusi salasana"
 ],
 "New password was not accepted": [
  null,
  "Uutta salasanaa ei hyväksytty"
 ],
 "No results found": [
  null,
  "Tuloksia ei löytynyt"
 ],
 "No such file or directory": [
  null,
  "Tiedostoa tai hakemistoa ei löydy"
 ],
 "Not a valid private key": [
  null,
  "Ei kelvollinen yksityinen avain"
 ],
 "Not connected to host": [
  null,
  "Ei yhdistetty koneeseen"
 ],
 "Old password not accepted": [
  null,
  "Vanhaa salasanaa ei hyväksytty"
 ],
 "Ooops!": [
  null,
  "Hups!"
 ],
 "Overview": [
  null,
  "Esittely"
 ],
 "Page name": [
  null,
  "Sivun nimi"
 ],
 "Password": [
  null,
  "Salasana"
 ],
 "Password changed successfully": [
  null,
  "Salasanan vaihtaminen onnistui"
 ],
 "Password not accepted": [
  null,
  "Salasanaa ei hyväksytty"
 ],
 "Password tip": [
  null,
  "Salasanan vihje"
 ],
 "Path to file": [
  null,
  "Polku tiedostoon"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Kirjaudu ylläpito-oikeuksien saamiseksi"
 ],
 "Port": [
  null,
  "Portti"
 ],
 "Problem becoming administrator": [
  null,
  "Ongelma ylläpitäjäksi tulemisessa"
 ],
 "Project website": [
  null,
  "Projektin verkkosivusto"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Kysely 'ssh-add':in kautta aikakatkaistiin"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Kysely 'ssh-keygen':in kautta aikakatkaistiin"
 ],
 "Public key": [
  null,
  "Julkinen avain"
 ],
 "Reconnect": [
  null,
  "Yhdistä uudelleen"
 ],
 "Remove": [
  null,
  "Poista"
 ],
 "Reviewing logs": [
  null,
  "Tarkistetaan lokeja"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-avain"
 ],
 "SSH keys": [
  null,
  "SSH-avaimet"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safarin käyttäjien on tuotava itse allekirjoittavan varmentajan varmenne ja luotettava siihen:"
 ],
 "Search": [
  null,
  "Haku"
 ],
 "Select": [
  null,
  "Valitse"
 ],
 "Services": [
  null,
  "Palvelut"
 ],
 "Session": [
  null,
  "Istunto"
 ],
 "Session is about to expire": [
  null,
  "Istunto on päättymässä"
 ],
 "Set": [
  null,
  "Aseta"
 ],
 "Skip main navigation": [
  null,
  "Ohita päävalikko"
 ],
 "Skip to content": [
  null,
  "Siirry sisältöön"
 ],
 "Software updates": [
  null,
  "Ohjelmistopäivitykset"
 ],
 "Stop editing hosts": [
  null,
  "Lopeta koneiden muokkaaminen"
 ],
 "Storage": [
  null,
  "Tallennustila"
 ],
 "Style": [
  null,
  "Tyyli"
 ],
 "Switch to administrative access": [
  null,
  "Vaihda ylläpitäjän käyttöoikeuksiin"
 ],
 "Switch to limited access": [
  null,
  "Vaihda rajoitettuun käyttöön"
 ],
 "System": [
  null,
  "Järjestelmä"
 ],
 "Terminal": [
  null,
  "Pääte"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP-osoite tai konenimi ei voi sisältää välilyöntiä."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Käyttäjän $0:n SSH-avain $1 koneella $2 lisätään käyttäjän $4 tiedostoon $3 koneella $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-avain $0 on käytettävissä koko istunnon ajan ja on käytettävissä myös muille koneille sisäänkirjautumista varten."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu salasanalla, eikä kone salli salasanalla kirjautumista. Anna avaimen $1 salasana."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-avain koneelle $0 sisäänkirjautumista varten on suojattu. Voit kirjautua sisään joko kirjautumissalasanallasi tai antamalla avaimen $1 salasanan."
 ],
 "The key password can not be empty": [
  null,
  "Avaimen salasana ei voi olla tyhjä"
 ],
 "The key passwords do not match": [
  null,
  "Avainsalasanat eivät täsmää"
 ],
 "The machine is rebooting": [
  null,
  "Kone käynnistyy uudelleen"
 ],
 "The new key password can not be empty": [
  null,
  "Uuden avaimen salasana ei voi olla tyhjä"
 ],
 "The password can not be empty": [
  null,
  "Salasana ei voi olla tyhjä"
 ],
 "The passwords do not match.": [
  null,
  "Salasanat eivät täsmää."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Tuloksena oleva sormenjälki sopii jakaa julkisilla menetelmillä, mukaan lukien sähköposti."
 ],
 "There are currently no active pages": [
  null,
  "Tällä hetkellä ei ole aktiivisia sivuja"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Laitteeseen yhdistämisessä tapahtui odottamaton virhe."
 ],
 "This machine has already been added.": [
  null,
  "Tämä kone on jo lisätty."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Tämän avulla voit tulevaisuudessa kirjautua sisään ilman salasanaa."
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Vinkki: Aseta avaimesi salasana samaksi kuin käyttäjätunnuksesi salasana, jotta voit automaattisesti tunnistautua muita järjestelmiä kohden."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Tarkista koneen avaimen sormenjälki varmistaaksesi, että haitallinen kolmas osapuoli ei sieppaa yhteyttä:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Vahvistaaksesi sormenjäljen, suorita seuraava koneella $0 istuessasi fyysisesti koneen ääressä tai luotettavan verkon kautta:"
 ],
 "Toggle": [
  null,
  "Vaihda"
 ],
 "Tools": [
  null,
  "Työkalut"
 ],
 "Turn on administrative access": [
  null,
  "Ota ylläpitäjän käyttöoikeudet käyttöön"
 ],
 "Type": [
  null,
  "Tyyppi"
 ],
 "Unable to contact $0.": [
  null,
  "Ei saada yhteyttä kohteeseen $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Annettuun koneeseen $0 ei voida ottaa yhteyttä. Varmista, että ssh on käynnissä portissa $1, tai määritä toinen portti osoitteeseen."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Ei voida kirjautua sisään koneelle $0 SSH-avaimella. Anna salasana. Haluat ehkä määrittää SSH-avaimesi automaattista kirjautumista varten."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Ei voida kirjautua sisään koneelle $0. Kone ei hyväksy salasanakirjautumista tai mitään SSH-avaimistasi."
 ],
 "Unexpected error": [
  null,
  "Odottamaton virhe"
 ],
 "Unlock": [
  null,
  "Avaa"
 ],
 "Unlock key $0": [
  null,
  "Avaa avaimen $0 lukitus"
 ],
 "Update": [
  null,
  "Päivitä"
 ],
 "Use key": [
  null,
  "Käytä avainta"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Käytä seuraavia avaimia todentamaan muita järjestelmiä kohden"
 ],
 "User name": [
  null,
  "Käyttäjänimi"
 ],
 "Using LUKS encryption": [
  null,
  "Käytetään LUKS-salausta"
 ],
 "Using Tang server": [
  null,
  "Käytetään Tang-palvelinta"
 ],
 "Web Console": [
  null,
  "Verkkokonsoli"
 ],
 "Web console logo": [
  null,
  "Verkkokonsolilogo"
 ],
 "When empty, connect with the current user": [
  null,
  "Tyhjänä ollessa, muodosta yhteys nykyisenä käyttäjänä"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Yhdistät koneeseen $0 ensimmäistä kertaa."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Sinut on kirjautunut ulos toimimattomuuden vuoksi."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Haluat ehkä vaihtaa avaimen salasanan automaattista sisäänkirjautumista varten."
 ],
 "You now have administrative access.": [
  null,
  "Sinulla on nyt ylläpitäjän käyttöoikeudet."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Sinut kirjataan ulos $0 sekunnin kuluttua."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Selaimesi muistaa käyttöoikeustasosi istuntojen ajan."
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "access": [
  null,
  "pääsy"
 ],
 "active": [
  null,
  "aktiivinen"
 ],
 "add-on": [
  null,
  "lisäosa"
 ],
 "addon": [
  null,
  "lisäosa"
 ],
 "apps": [
  null,
  "sovellukset"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "sisältötunniste"
 ],
 "avc": [
  null,
  "avc"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "bond": [
  null,
  "sidos"
 ],
 "boot": [
  null,
  "käynnistys"
 ],
 "bridge": [
  null,
  "silta"
 ],
 "cgroups": [
  null,
  "c-ryhmät"
 ],
 "command": [
  null,
  "komento"
 ],
 "console": [
  null,
  "konsoli"
 ],
 "coredump": [
  null,
  "ytimen tyhjennys"
 ],
 "cpu": [
  null,
  "suoritin"
 ],
 "crash": [
  null,
  "kaatuminen"
 ],
 "date": [
  null,
  "päivämäärä"
 ],
 "debug": [
  null,
  "virheenjäljitys"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "poista käytöstä"
 ],
 "disk": [
  null,
  "levy"
 ],
 "disks": [
  null,
  "levyt"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "domain": [
  null,
  "toimialue"
 ],
 "drive": [
  null,
  "asema"
 ],
 "enable": [
  null,
  "ota käyttöön"
 ],
 "encryption": [
  null,
  "salaus"
 ],
 "error": [
  null,
  "virhe"
 ],
 "extension": [
  null,
  "laajennus"
 ],
 "filesystem": [
  null,
  "tiedostojärjestelmä"
 ],
 "firewall": [
  null,
  "palomuuri"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "format": [
  null,
  "alusta"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "graphs": [
  null,
  "kaaviot"
 ],
 "hardware": [
  null,
  "laitteisto"
 ],
 "history": [
  null,
  "historia"
 ],
 "host": [
  null,
  "kone"
 ],
 "in most browsers": [
  null,
  "useimmissa selaimissa"
 ],
 "install": [
  null,
  "asenna"
 ],
 "interface": [
  null,
  "liitäntä"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "journal": [
  null,
  "päiväkirja"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "avaimet"
 ],
 "login": [
  null,
  "sisäänkirjautuminen"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mac": [
  null,
  "mac"
 ],
 "machine": [
  null,
  "kone"
 ],
 "mask": [
  null,
  "peite"
 ],
 "memory": [
  null,
  "muisti"
 ],
 "metrics": [
  null,
  "mittarit"
 ],
 "mitigation": [
  null,
  "lievennys"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "liitos"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "network": [
  null,
  "verkko"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "operating system": [
  null,
  "käyttöjärjestelmä"
 ],
 "os": [
  null,
  "käyttöjärjestelmä"
 ],
 "package": [
  null,
  "paketti"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "partition": [
  null,
  "osio"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "salasana"
 ],
 "path": [
  null,
  "polku"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "suorituskyky"
 ],
 "plugin": [
  null,
  "kytkettävä"
 ],
 "port": [
  null,
  "portti"
 ],
 "power": [
  null,
  "virta"
 ],
 "raid": [
  null,
  "raid"
 ],
 "ram": [
  null,
  "ram-muisti"
 ],
 "restart": [
  null,
  "käynnistä uudelleen"
 ],
 "roles": [
  null,
  "roolit"
 ],
 "security": [
  null,
  "turvallisuus"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  "sarja"
 ],
 "service": [
  null,
  "palvelu"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ],
 "shell": [
  null,
  "komentotulkki"
 ],
 "show less": [
  null,
  "näytä vähemmän"
 ],
 "show more": [
  null,
  "näytä enemmän"
 ],
 "shut": [
  null,
  "sulje"
 ],
 "socket": [
  null,
  "pistoke"
 ],
 "sos": [
  null,
  "sos"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "tang"
 ],
 "target": [
  null,
  "kohde"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "joukkue"
 ],
 "time": [
  null,
  "aika"
 ],
 "timer": [
  null,
  "ajastin"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  "yksikkö"
 ],
 "unmask": [
  null,
  "poista peite"
 ],
 "unmount": [
  null,
  "irrota"
 ],
 "user": [
  null,
  "käyttäjä"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "käyttäjänimi"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "version": [
  null,
  "versio"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "volume": [
  null,
  "taltio"
 ],
 "warning": [
  null,
  "varoitus"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "vyöhyke"
 ]
});
