cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "Dokumentácia k $0"
 ],
 "$0 key changed": [
  null,
  "$0 kľúč sa zmenil"
 ],
 "About Web Console": [
  null,
  "O webovej konzoli"
 ],
 "Accept key and connect": [
  null,
  "Prijať kľúč a pripojiť"
 ],
 "Accounts": [
  null,
  "Účty"
 ],
 "Active pages": [
  null,
  "Aktívne stránky"
 ],
 "Add": [
  null,
  "Pridať"
 ],
 "Add key": [
  null,
  "Pridať kĺúč"
 ],
 "Add new host": [
  null,
  "Pridať nového hostiteľa"
 ],
 "Administrative access": [
  null,
  "Prístup na úrovni správcu"
 ],
 "Applications": [
  null,
  "Aplikácie"
 ],
 "Apps": [
  null,
  "Aplikácie"
 ],
 "Authenticate": [
  null,
  "Overiť sa"
 ],
 "Authentication": [
  null,
  "Overovanie"
 ],
 "Authorize SSH key": [
  null,
  "Poveriť SSH kľúč"
 ],
 "Automatic login": [
  null,
  "Automatické prihlásenie"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Zmenou hesla k SSH kľuču $0na prihlasovacie heslo užívateľa $1na $2 bude kľúč automaticky sprístupnený a na $3 sa nabudúce prihlásite už bez hesla."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Môže byť názov hostiteľa, IP adresa, alias alebo ssh:// URI"
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Nie je možné sa prihlásiť k neznámemu hostiteľovi"
 ],
 "Change password": [
  null,
  "Zmeniť heslo"
 ],
 "Change the password of $0": [
  null,
  "Zmeniť heslo kľúča $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmenené kľúče sú často výsledkom preinštalovania operačného systému. Avšak neočakávaná zmena môže znamenať, že sa tretia strana snaží odpočúvať vaše spojenie."
 ],
 "Choose the language to be used in the application": [
  null,
  ""
 ],
 "Clear search": [
  null,
  "Vyčistiť vyhľadávanie"
 ],
 "Close": [
  null,
  "Zavrieť"
 ],
 "Close selected pages": [
  null,
  ""
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "V Cockpite nastala neočakávaná vnútorná chyba."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit je interaktívne rozhranie pre správu linuxových serverov."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie je nainštalovaný"
 ],
 "Color": [
  null,
  "Farba"
 ],
 "Comment": [
  null,
  "Komentár"
 ],
 "Configuring kdump": [
  null,
  "Konfigurácia kdump"
 ],
 "Configuring system settings": [
  null,
  ""
 ],
 "Confirm key password": [
  null,
  "Potvrdiť heslo ku kľúči"
 ],
 "Confirm new key password": [
  null,
  "Potvrdiť nové heslo ku kľúču"
 ],
 "Confirm password": [
  null,
  "Potvrdiť heslo"
 ],
 "Connecting to the machine": [
  null,
  ""
 ],
 "Connection error": [
  null,
  "Chyba pripojenia"
 ],
 "Connection failed": [
  null,
  "Pripojenie sa nepodarilo"
 ],
 "Contains:": [
  null,
  "Obsahuje:"
 ],
 "Continue session": [
  null,
  "Pokračovať v relácii"
 ],
 "Copied": [
  null,
  "Skopírované"
 ],
 "Copy": [
  null,
  "Kopírovať"
 ],
 "Create": [
  null,
  "Vytvoriť"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvoriť nový SSH kľúč a poveriť ho"
 ],
 "Ctrl-Shift-J": [
  null,
  "Ctrl-Shift-J"
 ],
 "Dark": [
  null,
  "Tmavý"
 ],
 "Default": [
  null,
  ""
 ],
 "Details": [
  null,
  "Detaily"
 ],
 "Development": [
  null,
  "Vývoj"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Disconnected": [
  null,
  "Odpojené"
 ],
 "Display language": [
  null,
  "Jazyk zobrazenia"
 ],
 "Edit": [
  null,
  "Upraviť"
 ],
 "Edit host": [
  null,
  "Upraviť hostiteľa"
 ],
 "Edit hosts": [
  null,
  "Upraviť hostiteľov"
 ],
 "Failed to add machine: $0": [
  null,
  "Nepodarilo sa pridať stroj: $0"
 ],
 "Failed to change password": [
  null,
  "Nepodarilo sa zmeniť heslo"
 ],
 "Failed to edit machine: $0": [
  null,
  "Nepodarilo sa upraviť stroj: $0"
 ],
 "Fingerprint": [
  null,
  "Odtlačok"
 ],
 "Help": [
  null,
  "Nápoveda"
 ],
 "Host": [
  null,
  "Hostiteľ"
 ],
 "Hosts": [
  null,
  "Hostitelia"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  ""
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Aby v budúcnosti bolo možné prihlasovanie k $0 ako $1 bez hesla, použite prihlasovacie heslo užívateľa $2 na $3 ako heslo ku kľúču alebo heslo ku kľúču nevyplňujte."
 ],
 "Invalid file permissions": [
  null,
  ""
 ],
 "Is sshd running on a different port?": [
  null,
  ""
 ],
 "Kernel dump": [
  null,
  ""
 ],
 "Key password": [
  null,
  "Heslo ku kľúču"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  ""
 ],
 "Light": [
  null,
  "Svetlý"
 ],
 "Limit access": [
  null,
  ""
 ],
 "Limited access": [
  null,
  ""
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  ""
 ],
 "Log in": [
  null,
  "Prihlásiť"
 ],
 "Log out": [
  null,
  "Odhlásiť"
 ],
 "Logs": [
  null,
  "Záznamy udalostí"
 ],
 "Managing firewall": [
  null,
  ""
 ],
 "Managing partitions": [
  null,
  ""
 ],
 "Managing services": [
  null,
  "Správa služieb"
 ],
 "Managing software updates": [
  null,
  "Správa softvérových aktualizácií"
 ],
 "Managing user accounts": [
  null,
  "Správa užívateľských účtov"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  ""
 ],
 "Method": [
  null,
  "Metóda"
 ],
 "Name": [
  null,
  "Názov"
 ],
 "Networking": [
  null,
  "Sieť"
 ],
 "New host": [
  null,
  "Nový hostiteľ"
 ],
 "New key password": [
  null,
  "Nové heslo ku kľúču"
 ],
 "New password": [
  null,
  "Nové heslo"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebolo prijaté"
 ],
 "No results found": [
  null,
  "Neboli nájdené žiadne výsledky"
 ],
 "No such file or directory": [
  null,
  ""
 ],
 "Not a valid private key": [
  null,
  ""
 ],
 "Not connected to host": [
  null,
  "Nepripojené k hostiteľovi"
 ],
 "Old password not accepted": [
  null,
  "Pôvodné heslo nebolo prijaté"
 ],
 "Ooops!": [
  null,
  "Ooops!"
 ],
 "Overview": [
  null,
  "Prehľad"
 ],
 "Page name": [
  null,
  "Názov stránky"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Password not accepted": [
  null,
  "Heslo nebolo prijaté"
 ],
 "Path to file": [
  null,
  "Cesta k súboru"
 ],
 "Please authenticate to gain administrative access": [
  null,
  ""
 ],
 "Port": [
  null,
  "Port"
 ],
 "Project website": [
  null,
  ""
 ],
 "Prompting via ssh-add timed out": [
  null,
  ""
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  ""
 ],
 "Public key": [
  null,
  ""
 ],
 "Reconnect": [
  null,
  "Znovu pripojiť"
 ],
 "Remove": [
  null,
  "Odobrať"
 ],
 "Reviewing logs": [
  null,
  "Vyhodnocovanie záznamov udalostí"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH kľúč"
 ],
 "SSH keys": [
  null,
  "SSH kľúče"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  ""
 ],
 "Search": [
  null,
  "Hľadať"
 ],
 "Select": [
  null,
  "Vybrať"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Session": [
  null,
  "Sedenie"
 ],
 "Session is about to expire": [
  null,
  "Relácia čoskoro skončí"
 ],
 "Set": [
  null,
  "Nastaviť"
 ],
 "Skip main navigation": [
  null,
  "Preskočiť hlavnú navigáciu"
 ],
 "Skip to content": [
  null,
  "Preskočiť na bo"
 ],
 "Software updates": [
  null,
  "Aktualizácie software"
 ],
 "Stop editing hosts": [
  null,
  "Ukončiť upravovanie hostiteľov"
 ],
 "Storage": [
  null,
  "Úložisko"
 ],
 "Style": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  "Prepnúť na obmedzený prístup"
 ],
 "System": [
  null,
  "Systém"
 ],
 "Terminal": [
  null,
  "Terminál"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP adresa alebo názov stroja nemôže obsahovať prázdny znak."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH kľúč $0 bude sprístupnený po celú reláciu a bude k dispozícií tiež pre prihlasovanie se k ostatním strojom."
 ],
 "The key password can not be empty": [
  null,
  "Heslo ku kľúču nemôže byť prázdne"
 ],
 "The key passwords do not match": [
  null,
  "Heslá ku kľúču sa líšia"
 ],
 "The machine is rebooting": [
  null,
  ""
 ],
 "The new key password can not be empty": [
  null,
  "Nové heslo ku kľúču nemôže byť prázdne"
 ],
 "The password can not be empty": [
  null,
  "Heslo nemôže byť prázdne"
 ],
 "The passwords do not match.": [
  null,
  "Heslá sa líšia."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  ""
 ],
 "There are currently no active pages": [
  null,
  ""
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Pri pripojovaní k stroji sa vyskytla neočakávaná chyba."
 ],
 "This machine has already been added.": [
  null,
  ""
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Toto vám umožní sa nabudúce prihlásiť bez hesla."
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Tip: Nastavte si heslo ku kľúču rovnaké ako pre prihlasovanie a budete se voči ostatným systémom overovať automaticky."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  ""
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  ""
 ],
 "Toggle": [
  null,
  ""
 ],
 "Tools": [
  null,
  "Nástroje"
 ],
 "Turn on administrative access": [
  null,
  ""
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unable to contact $0.": [
  null,
  ""
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  ""
 ],
 "Unexpected error": [
  null,
  "Neočakávaná chyba"
 ],
 "Unlock": [
  null,
  "Odomknúť"
 ],
 "Update": [
  null,
  "Aktualizovať"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  ""
 ],
 "User name": [
  null,
  "Užívateľské meno"
 ],
 "Web Console": [
  null,
  "Webová konzola"
 ],
 "When empty, connect with the current user": [
  null,
  ""
 ],
 "You are connecting to $0 for the first time.": [
  null,
  ""
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Boli ste odhlásený z dôvodu neaktivity."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Pre automatické prihlasovanie sa budete možno chcieť zmeniť heslo ku kľúču."
 ],
 "You now have administrative access.": [
  null,
  ""
 ],
 "You will be logged out in $0 seconds.": [
  null,
  ""
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  ""
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "access": [
  null,
  "prístup"
 ],
 "active": [
  null,
  "Aktívny"
 ],
 "add-on": [
  null,
  "doplnok"
 ],
 "addon": [
  null,
  "doplnok"
 ],
 "apps": [
  null,
  "aplikácie"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "Inventárny štítok"
 ],
 "avc": [
  null,
  "avc"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "bond": [
  null,
  "zväzok"
 ],
 "boot": [
  null,
  "boot"
 ],
 "bridge": [
  null,
  "most"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "Príkaz"
 ],
 "console": [
  null,
  "konzola"
 ],
 "coredump": [
  null,
  "výpis jadra"
 ],
 "cpu": [
  null,
  "procesor"
 ],
 "crash": [
  null,
  "pád"
 ],
 "date": [
  null,
  "dátum"
 ],
 "debug": [
  null,
  "ladenie"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "vypnúť"
 ],
 "disk": [
  null,
  "disk"
 ],
 "disks": [
  null,
  "disky"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "domain": [
  null,
  "Doména"
 ],
 "drive": [
  null,
  "jednotka"
 ],
 "enable": [
  null,
  "povoliť"
 ],
 "encryption": [
  null,
  "Šifrovanie"
 ],
 "error": [
  null,
  "Chyba"
 ],
 "extension": [
  null,
  "rozšírenie"
 ],
 "filesystem": [
  null,
  "Súborový systém"
 ],
 "firewall": [
  null,
  "firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "format": [
  null,
  "Formátovať"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "graphs": [
  null,
  "grafy"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "history": [
  null,
  "história"
 ],
 "host": [
  null,
  "stroj"
 ],
 "in most browsers": [
  null,
  "vo väčšine prehliadačov"
 ],
 "install": [
  null,
  "inštalovať"
 ],
 "interface": [
  null,
  "rozhranie"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "journal": [
  null,
  "žurnál"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "kľúče"
 ],
 "login": [
  null,
  "prihlásenie"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mac": [
  null,
  "mac"
 ],
 "machine": [
  null,
  "stroj"
 ],
 "mask": [
  null,
  "maska"
 ],
 "memory": [
  null,
  "pamäť"
 ],
 "metrics": [
  null,
  "metriky"
 ],
 "mitigation": [
  null,
  "zmiernenie"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "mount"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "network": [
  null,
  "sieť"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "operating system": [
  null,
  "Operačný systém"
 ],
 "os": [
  null,
  "os"
 ],
 "package": [
  null,
  "balík"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "partition": [
  null,
  "oddiel"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "heslo"
 ],
 "path": [
  null,
  "umiestnenie"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "výkon"
 ],
 "plugin": [
  null,
  "zásuvný model"
 ],
 "port": [
  null,
  "port"
 ],
 "power": [
  null,
  "napájanie"
 ],
 "raid": [
  null,
  "raid"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "reštartovať"
 ],
 "roles": [
  null,
  "role"
 ],
 "security": [
  null,
  "bezpečnosť"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  "sériové"
 ],
 "service": [
  null,
  "služba"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ],
 "shell": [
  null,
  "shell"
 ],
 "show less": [
  null,
  "ukázať menej"
 ],
 "show more": [
  null,
  "ukázať viac"
 ],
 "shut": [
  null,
  "vypnúť"
 ],
 "socket": [
  null,
  "soket"
 ],
 "sos": [
  null,
  "sos"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "tang"
 ],
 "target": [
  null,
  "cieľ"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "tým"
 ],
 "time": [
  null,
  "čas"
 ],
 "timer": [
  null,
  "časovač"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  "jednotka"
 ],
 "unmask": [
  null,
  "odmaskovať"
 ],
 "unmount": [
  null,
  "odpojiť"
 ],
 "user": [
  null,
  "užívateľ"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "username"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "version": [
  null,
  "Verzia"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "volume": [
  null,
  "zväzok"
 ],
 "warning": [
  null,
  "varovanie"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "zóna"
 ]
});
