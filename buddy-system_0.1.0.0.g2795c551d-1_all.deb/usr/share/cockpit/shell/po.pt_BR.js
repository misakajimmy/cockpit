cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "$0 documentação"
 ],
 "$0 key changed": [
  null,
  "$0 chave alterada"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Uma versão compatível do Cockpit não está instalada em $0."
 ],
 "About Web Console": [
  null,
  "Sobre o console web"
 ],
 "Accept key and connect": [
  null,
  "Aceitar a chave e conectar"
 ],
 "Accounts": [
  null,
  "Contas"
 ],
 "Active pages": [
  null,
  "Páginas Ativas"
 ],
 "Add": [
  null,
  "Adicionar"
 ],
 "Add key": [
  null,
  "Adicionar chave"
 ],
 "Add new host": [
  null,
  "Adicionar um novo host"
 ],
 "Administrative access": [
  null,
  "Acesso administrativo"
 ],
 "Applications": [
  null,
  "Aplicações"
 ],
 "Apps": [
  null,
  "Apps"
 ],
 "Authenticate": [
  null,
  "Autenticar"
 ],
 "Authentication": [
  null,
  "Autenticação"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  ""
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  ""
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Não é possível conectar a um host desconhecido"
 ],
 "Change password": [
  null,
  "Alterar Senha"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  ""
 ],
 "Choose the language to be used in the application": [
  null,
  "Escolha o idioma a ser usado no aplicativo"
 ],
 "Clear search": [
  null,
  "Limpar pesquisa"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Close selected pages": [
  null,
  "Fechar Páginas Selecionadas"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit teve um erro interno inesperado."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit é uma interface interativa de administração de servidor Linux."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit não está instalado"
 ],
 "Color": [
  null,
  "Cor"
 ],
 "Comment": [
  null,
  "Comentário"
 ],
 "Confirm key password": [
  null,
  "Confirme a senha da chave"
 ],
 "Connecting to the machine": [
  null,
  "Conectando a máquina"
 ],
 "Connection error": [
  null,
  "Erro de Conexão"
 ],
 "Connection failed": [
  null,
  "Conexão falhou"
 ],
 "Contains:": [
  null,
  "Contém:"
 ],
 "Copied": [
  null,
  ""
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Create": [
  null,
  "Criar"
 ],
 "Create a new SSH key and authorize it": [
  null,
  ""
 ],
 "Ctrl-Shift-J": [
  null,
  "Ctrl-Shift-J"
 ],
 "Dark": [
  null,
  "Escuro"
 ],
 "Default": [
  null,
  "Padrão"
 ],
 "Details": [
  null,
  "Detalhes"
 ],
 "Development": [
  null,
  "Desenvolvimento"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Disconnected": [
  null,
  "Desconectado"
 ],
 "Display language": [
  null,
  "Linguagem Exibida"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Edit host": [
  null,
  "Editar host"
 ],
 "Edit hosts": [
  null,
  "Editar hosts"
 ],
 "Failed to add machine: $0": [
  null,
  "Falha ao adicionar a máquina: $0"
 ],
 "Failed to change password": [
  null,
  "Falha ao mudar senha"
 ],
 "Failed to edit machine: $0": [
  null,
  "Falha ao editar a máquina: $0"
 ],
 "Fingerprint": [
  null,
  "Digital"
 ],
 "Help": [
  null,
  "Ajuda"
 ],
 "Host": [
  null,
  "Máquina"
 ],
 "Hosts": [
  null,
  "Hosts"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  ""
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  ""
 ],
 "Invalid file permissions": [
  null,
  "Permissão de arquivos inválida"
 ],
 "Is sshd running on a different port?": [
  null,
  "O sshd está sendo executado em uma porta diferente?"
 ],
 "Kernel dump": [
  null,
  "Dump do Kernel"
 ],
 "Key password": [
  null,
  "Nova senha"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  ""
 ],
 "Light": [
  null,
  ""
 ],
 "Limit access": [
  null,
  "Limitar acesso"
 ],
 "Limited access": [
  null,
  "Acesso limitado"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  ""
 ],
 "Log in": [
  null,
  "Entrar"
 ],
 "Log out": [
  null,
  "Log out"
 ],
 "Logs": [
  null,
  "Logs"
 ],
 "Managing firewall": [
  null,
  ""
 ],
 "Managing user accounts": [
  null,
  ""
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  ""
 ],
 "Method": [
  null,
  ""
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Networking": [
  null,
  "Rede"
 ],
 "New host": [
  null,
  "Novo host"
 ],
 "New password": [
  null,
  "Nova Senha"
 ],
 "New password was not accepted": [
  null,
  "Nova senha não foi aceita"
 ],
 "No results found": [
  null,
  "Nenhum resultado encontrado"
 ],
 "No such file or directory": [
  null,
  "Diretório ou arquivo não encontrado"
 ],
 "Not a valid private key": [
  null,
  "Chave privada não válida"
 ],
 "Old password not accepted": [
  null,
  "Senha antiga não aceita"
 ],
 "Ooops!": [
  null,
  "Ooops!"
 ],
 "Overview": [
  null,
  "Visão geral"
 ],
 "Page name": [
  null,
  "Nome da página"
 ],
 "Password": [
  null,
  "Senha"
 ],
 "Password not accepted": [
  null,
  "Senha não aceita"
 ],
 "Path to file": [
  null,
  "Caminho para o arquivo"
 ],
 "Please authenticate to gain administrative access": [
  null,
  ""
 ],
 "Port": [
  null,
  "Porta"
 ],
 "Project website": [
  null,
  "Site do projeto"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "A solicitação via ssh-add expirou"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Solicitação via ssh-keygen expirou"
 ],
 "Public key": [
  null,
  "Chave Pública"
 ],
 "Reconnect": [
  null,
  "Reconectar"
 ],
 "Remove": [
  null,
  "Remover"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Chave SSH"
 ],
 "SSH keys": [
  null,
  "Chave SSH"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  ""
 ],
 "Search": [
  null,
  ""
 ],
 "Select": [
  null,
  "Selecione"
 ],
 "Services": [
  null,
  "Serviços"
 ],
 "Session": [
  null,
  "Sessão"
 ],
 "Session is about to expire": [
  null,
  "A sessão está prestes a expirar"
 ],
 "Set": [
  null,
  "Definir"
 ],
 "Skip main navigation": [
  null,
  ""
 ],
 "Software updates": [
  null,
  "Atualizações de Software"
 ],
 "Stop editing hosts": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Style": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  ""
 ],
 "System": [
  null,
  "Sistema"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "O endereço IP ou nome do host não podem conter espaços."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  ""
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  ""
 ],
 "The key password can not be empty": [
  null,
  "A senha da chave não pode estar vazia"
 ],
 "The key passwords do not match": [
  null,
  "As senhas da chave não coincidem"
 ],
 "The machine is rebooting": [
  null,
  "A máquina esta reiniciando"
 ],
 "The new key password can not be empty": [
  null,
  "A nova senha da chave não pode estar vazia"
 ],
 "The passwords do not match.": [
  null,
  "As senhas não batem."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  ""
 ],
 "There are currently no active pages": [
  null,
  "Atualmente não há páginas ativas"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Ocorreu um erro inesperado enquanto conectava-se à máquina."
 ],
 "This machine has already been added.": [
  null,
  "Esta máquina já foi adicionada."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  ""
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Dica: faça a sua senha de chave corresponder à sua senha de login para autenticar automaticamente contra outros sistemas."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  ""
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  ""
 ],
 "Toggle": [
  null,
  ""
 ],
 "Tools": [
  null,
  "Ferramentas"
 ],
 "Turn on administrative access": [
  null,
  ""
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Não foi possível entrar em contato com o host $0. Certifique-se de que o ssh esteja rodando na porta $1 ou especifique outra porta no endereço."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  ""
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  ""
 ],
 "Unexpected error": [
  null,
  "Erro inesperado"
 ],
 "Unlock": [
  null,
  "Destravar"
 ],
 "Update": [
  null,
  "Atualizar"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Use as seguintes chaves para autenticar contra outros sistemas"
 ],
 "User name": [
  null,
  "Nome do usuário"
 ],
 "Using LUKS encryption": [
  null,
  ""
 ],
 "Web Console": [
  null,
  "Console web"
 ],
 "When empty, connect with the current user": [
  null,
  ""
 ],
 "You are connecting to $0 for the first time.": [
  null,
  ""
 ],
 "You have been logged out due to inactivity.": [
  null,
  ""
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  ""
 ],
 "You now have administrative access.": [
  null,
  ""
 ],
 "You will be logged out in $0 seconds.": [
  null,
  ""
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  ""
 ],
 "abrt": [
  null,
  ""
 ],
 "access": [
  null,
  ""
 ],
 "active": [
  null,
  "ativo"
 ],
 "add-on": [
  null,
  ""
 ],
 "addon": [
  null,
  ""
 ],
 "apps": [
  null,
  ""
 ],
 "apt-get": [
  null,
  ""
 ],
 "asset tag": [
  null,
  ""
 ],
 "avc": [
  null,
  ""
 ],
 "bash": [
  null,
  ""
 ],
 "bios": [
  null,
  ""
 ],
 "bond": [
  null,
  ""
 ],
 "boot": [
  null,
  "inicialização"
 ],
 "bridge": [
  null,
  "ponte"
 ],
 "cgroups": [
  null,
  ""
 ],
 "command": [
  null,
  "comando"
 ],
 "console": [
  null,
  "console"
 ],
 "coredump": [
  null,
  ""
 ],
 "cpu": [
  null,
  ""
 ],
 "crash": [
  null,
  ""
 ],
 "date": [
  null,
  "data"
 ],
 "debug": [
  null,
  "depuração"
 ],
 "dimm": [
  null,
  ""
 ],
 "disable": [
  null,
  "desabilitado"
 ],
 "disk": [
  null,
  "disco"
 ],
 "disks": [
  null,
  "discos"
 ],
 "dnf": [
  null,
  ""
 ],
 "domain": [
  null,
  ""
 ],
 "drive": [
  null,
  ""
 ],
 "enable": [
  null,
  ""
 ],
 "encryption": [
  null,
  ""
 ],
 "error": [
  null,
  "erro"
 ],
 "extension": [
  null,
  "extensão"
 ],
 "filesystem": [
  null,
  "sistema de arquivos"
 ],
 "firewall": [
  null,
  ""
 ],
 "format": [
  null,
  ""
 ],
 "fstab": [
  null,
  ""
 ],
 "graphs": [
  null,
  ""
 ],
 "hardware": [
  null,
  ""
 ],
 "history": [
  null,
  "histórico"
 ],
 "host": [
  null,
  "host"
 ],
 "in most browsers": [
  null,
  ""
 ],
 "install": [
  null,
  ""
 ],
 "interface": [
  null,
  ""
 ],
 "ipv4": [
  null,
  ""
 ],
 "ipv6": [
  null,
  ""
 ],
 "iscsi": [
  null,
  ""
 ],
 "journal": [
  null,
  ""
 ],
 "kdump": [
  null,
  ""
 ],
 "keys": [
  null,
  ""
 ],
 "login": [
  null,
  "login"
 ],
 "luks": [
  null,
  ""
 ],
 "lvm2": [
  null,
  ""
 ],
 "mac": [
  null,
  ""
 ],
 "machine": [
  null,
  ""
 ],
 "mask": [
  null,
  ""
 ],
 "memory": [
  null,
  "memória"
 ],
 "metrics": [
  null,
  "métricas"
 ],
 "mitigation": [
  null,
  ""
 ],
 "mkfs": [
  null,
  ""
 ],
 "mount": [
  null,
  ""
 ],
 "nbde": [
  null,
  ""
 ],
 "network": [
  null,
  "rede"
 ],
 "nfs": [
  null,
  ""
 ],
 "operating system": [
  null,
  "sistema operacional"
 ],
 "os": [
  null,
  ""
 ],
 "package": [
  null,
  "pacote"
 ],
 "packagekit": [
  null,
  ""
 ],
 "partition": [
  null,
  "partição"
 ],
 "passwd": [
  null,
  ""
 ],
 "password": [
  null,
  "senha"
 ],
 "path": [
  null,
  ""
 ],
 "pci": [
  null,
  ""
 ],
 "pcp": [
  null,
  ""
 ],
 "plugin": [
  null,
  ""
 ],
 "port": [
  null,
  ""
 ],
 "power": [
  null,
  ""
 ],
 "raid": [
  null,
  ""
 ],
 "ram": [
  null,
  ""
 ],
 "restart": [
  null,
  ""
 ],
 "roles": [
  null,
  ""
 ],
 "security": [
  null,
  "segurança"
 ],
 "semanage": [
  null,
  ""
 ],
 "serial": [
  null,
  ""
 ],
 "service": [
  null,
  ""
 ],
 "setroubleshoot": [
  null,
  ""
 ],
 "shell": [
  null,
  ""
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ],
 "shut": [
  null,
  ""
 ],
 "socket": [
  null,
  ""
 ],
 "sos": [
  null,
  ""
 ],
 "ssh": [
  null,
  ""
 ],
 "systemctl": [
  null,
  ""
 ],
 "systemd": [
  null,
  ""
 ],
 "tang": [
  null,
  ""
 ],
 "target": [
  null,
  ""
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  ""
 ],
 "time": [
  null,
  ""
 ],
 "timer": [
  null,
  ""
 ],
 "udisks": [
  null,
  ""
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  ""
 ],
 "unmask": [
  null,
  ""
 ],
 "unmount": [
  null,
  ""
 ],
 "user": [
  null,
  "usuário"
 ],
 "useradd": [
  null,
  ""
 ],
 "username": [
  null,
  ""
 ],
 "vdo": [
  null,
  ""
 ],
 "vlan": [
  null,
  ""
 ],
 "warning": [
  null,
  "aviso"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "zona"
 ]
});
