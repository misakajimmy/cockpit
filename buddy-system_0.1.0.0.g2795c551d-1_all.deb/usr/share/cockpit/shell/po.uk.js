cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "Документація з $0"
 ],
 "$0 key changed": [
  null,
  "Змінено ключ $0"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "На $0 не встановлено сумісної версії Cockpit."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Буде створено новий ключ SSH у $0 для $1 на $2 і його буде додано до файла $3 $4 на $5."
 ],
 "About Web Console": [
  null,
  "Про «Вебконсоль»"
 ],
 "Accept key and connect": [
  null,
  "Прийняти ключ і з'єднатися"
 ],
 "Accounts": [
  null,
  "Облікові записи"
 ],
 "Active pages": [
  null,
  "Активні сторінки"
 ],
 "Add": [
  null,
  "Додати"
 ],
 "Add key": [
  null,
  "Додати ключ"
 ],
 "Add new host": [
  null,
  "Додати новий вузол"
 ],
 "Administrative access": [
  null,
  "Адміністративний доступ"
 ],
 "Applications": [
  null,
  "Програми"
 ],
 "Apps": [
  null,
  "Програми"
 ],
 "Authenticate": [
  null,
  "Розпізнавання"
 ],
 "Authentication": [
  null,
  "Розпізнавання"
 ],
 "Authorize SSH key": [
  null,
  "Уповноважити ключ SSH"
 ],
 "Automatic login": [
  null,
  "Автоматичний вхід"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Після зміни пароля до ключа SSH $0 на пароль для входу до системи $1 на $2 доступ до ключа буде автоматично відкрито і ви зможете надалі входити до $3 без пароля."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Це може бути назва вузла, IP-адреса, альтернативна назва або адреса ssh://"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Не вдалося з'єднатися зі невідомим вузлом"
 ],
 "Change password": [
  null,
  "Змінити пароль"
 ],
 "Change the password of $0": [
  null,
  "Змінити пароль до $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Зміна ключів часто є результатом перевстановлення операційної системи. Втім, неочікувана зміна може вказувати на сторонню спробу перехопити дані вашого з'єднання."
 ],
 "Choose the language to be used in the application": [
  null,
  "Виберіть мову перекладу, яку буде використано для інтерфейсу програми"
 ],
 "Clear search": [
  null,
  "Очистити критерій пошуку"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Close selected pages": [
  null,
  "Закрити позначені сторінки"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "У Cockpit сталася неочікувана внутрішня помилка."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit — інтерактивний інтерфейс адміністратора сервера Linux."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не встановлено"
 ],
 "Color": [
  null,
  "Колір"
 ],
 "Comment": [
  null,
  "Коментар"
 ],
 "Configuring kdump": [
  null,
  "Налаштовування kdump"
 ],
 "Configuring system settings": [
  null,
  "Налаштовування параметрів системи"
 ],
 "Confirm key password": [
  null,
  "Підтвердження пароля до ключа"
 ],
 "Confirm new key password": [
  null,
  "Підтвердження нового пароля до ключа"
 ],
 "Confirm password": [
  null,
  "Підтвердження пароля"
 ],
 "Connecting to the machine": [
  null,
  "Встановлюємо з’єднання із комп’ютером"
 ],
 "Connection error": [
  null,
  "Помилка з'єднання"
 ],
 "Connection failed": [
  null,
  "Не вдалося встановити з'єднання"
 ],
 "Contains:": [
  null,
  "Містить:"
 ],
 "Continue session": [
  null,
  "Продовжити сеанс"
 ],
 "Copied": [
  null,
  "Скопійовано"
 ],
 "Copy": [
  null,
  "Копіювати"
 ],
 "Could not contact $0": [
  null,
  "Не вдалося встановити зв’язок із $0"
 ],
 "Create": [
  null,
  "Створити"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Створити ключ SSH і уповноважити його"
 ],
 "Ctrl-Shift-J": [
  null,
  "Ctrl-Shift-J"
 ],
 "Dark": [
  null,
  "Темний"
 ],
 "Default": [
  null,
  "Типовий"
 ],
 "Details": [
  null,
  "Подробиці"
 ],
 "Development": [
  null,
  "Розробка"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Disconnected": [
  null,
  "Роз'єднано"
 ],
 "Display language": [
  null,
  "Мова перекладу"
 ],
 "Edit": [
  null,
  "Змінити"
 ],
 "Edit host": [
  null,
  "Редагувати вузол"
 ],
 "Edit hosts": [
  null,
  "Редагувати вузли"
 ],
 "Failed to add machine: $0": [
  null,
  "Не вдалося додати комп’ютер: $0"
 ],
 "Failed to change password": [
  null,
  "Не вдалося змінити пароль"
 ],
 "Failed to edit machine: $0": [
  null,
  "Не вдалося змінити запис комп’ютера: $0"
 ],
 "Filter menu items": [
  null,
  "Фільтрувати пункти меню"
 ],
 "Fingerprint": [
  null,
  "Відбиток"
 ],
 "Help": [
  null,
  "Довідка"
 ],
 "Host": [
  null,
  "Вузол"
 ],
 "Hosts": [
  null,
  "Вузли"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Якщо відбиток є відповідним, натисніть «Прийняти ключ і з'єднатися». Якщо ж це не так, не встановлюйте з'єднання і повідомте про подію адміністратору."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Щоб уможливити вхід до $0 від імені $1 без пароля надалі, скористайтеся паролем для входу до системи $2 на $3 як паролем до ключа або не заповнюйте поле пароля ключа."
 ],
 "Invalid file permissions": [
  null,
  "Некоректні права доступу до файла"
 ],
 "Is sshd running on a different port?": [
  null,
  "sshd працює на іншому порті?"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Key password": [
  null,
  "Пароль до ключа"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Ліцензовано за умов дотримання GNU LGPL версії 2.1"
 ],
 "Light": [
  null,
  "Світлий"
 ],
 "Limit access": [
  null,
  "Обмежити доступ"
 ],
 "Limited access": [
  null,
  "Обмежений доступ"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Модель із обмеженим доступом обмежує адміністративні привілеї. Функціональні можливості деяких частин вебконсолі буде суттєво зменшено."
 ],
 "Loading packages...": [
  null,
  "Завантаження пакунків…"
 ],
 "Log in": [
  null,
  "Увійти"
 ],
 "Log in to $0": [
  null,
  "Увійти до $0"
 ],
 "Log out": [
  null,
  "Вийти"
 ],
 "Logs": [
  null,
  "Журнали"
 ],
 "Managing LVMs": [
  null,
  "Керування LVM"
 ],
 "Managing NFS mounts": [
  null,
  "Керування монтуванням NFS"
 ],
 "Managing RAIDs": [
  null,
  "Керування RAID"
 ],
 "Managing VDOs": [
  null,
  "Керування VDO"
 ],
 "Managing VLANs": [
  null,
  "Керування VLAN"
 ],
 "Managing firewall": [
  null,
  "Керування брандмауером"
 ],
 "Managing networking bonds": [
  null,
  "Керування зв'язками у мережі"
 ],
 "Managing networking bridges": [
  null,
  "Керування містками у мережі"
 ],
 "Managing networking teams": [
  null,
  "Керування командами у мережі"
 ],
 "Managing partitions": [
  null,
  "Керування розділами диска"
 ],
 "Managing physical drives": [
  null,
  "Керування фізичними дисками"
 ],
 "Managing services": [
  null,
  "Керування службами"
 ],
 "Managing software updates": [
  null,
  "Керування оновленням програм"
 ],
 "Managing user accounts": [
  null,
  "Керування обліковими записами користувачів"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Повідомлення, пов'язані із аварією, яких може не бути у журналі:"
 ],
 "Method": [
  null,
  "Метод"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Networking": [
  null,
  "Робота у мережі"
 ],
 "New host": [
  null,
  "Новий вузол"
 ],
 "New key password": [
  null,
  "Новий пароль до ключа"
 ],
 "New password": [
  null,
  "Новий пароль"
 ],
 "New password was not accepted": [
  null,
  "Новий пароль не прийнято"
 ],
 "No results found": [
  null,
  "Нічого не знайдено"
 ],
 "No such file or directory": [
  null,
  "Немає такого файла або каталогу"
 ],
 "Not a valid private key": [
  null,
  "Некоректний закритий ключ"
 ],
 "Not connected to host": [
  null,
  "Не з'єднано із вузлом"
 ],
 "Old password not accepted": [
  null,
  "Старий пароль не прийнято"
 ],
 "Ooops!": [
  null,
  "Вибачте!"
 ],
 "Overview": [
  null,
  "Огляд"
 ],
 "Page name": [
  null,
  "Назва сторінки"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password changed successfully": [
  null,
  "Пароль успішно змінено"
 ],
 "Password not accepted": [
  null,
  "Пароль не прийнято"
 ],
 "Password tip": [
  null,
  "Підказка щодо пароля"
 ],
 "Path to file": [
  null,
  "Шлях до файла"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Будь ласка, пройдіть розпізнавання, щоб отримати адміністративний доступ"
 ],
 "Port": [
  null,
  "Порт"
 ],
 "Problem becoming administrator": [
  null,
  "Проблеми із набуттям прав адміністратора"
 ],
 "Project website": [
  null,
  "Сайт проєкту"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-add вичерпано"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Час очікування відповіді на запит за допомогою ssh-keygen вичерпано"
 ],
 "Public key": [
  null,
  "Відкритий ключ"
 ],
 "Reconnect": [
  null,
  "Повторно з’єднатися"
 ],
 "Remove": [
  null,
  "Вилучити"
 ],
 "Reviewing logs": [
  null,
  "Перегляд журналів"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Ключ SSH"
 ],
 "SSH keys": [
  null,
  "Ключі SSH"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Користувачам Safari слід імпортувати сертифікат самопідписаного CA і встановити довіру до нього:"
 ],
 "Search": [
  null,
  "Пошук"
 ],
 "Select": [
  null,
  "Вибрати"
 ],
 "Services": [
  null,
  "Служби"
 ],
 "Session": [
  null,
  "Сеанс"
 ],
 "Session is about to expire": [
  null,
  "Строк дії сеансу вичерпується"
 ],
 "Set": [
  null,
  "Встановити"
 ],
 "Skip main navigation": [
  null,
  "Пропустити основну навігацію"
 ],
 "Skip to content": [
  null,
  "Перейти до вмісту"
 ],
 "Software updates": [
  null,
  "Оновлення програм"
 ],
 "Stop editing hosts": [
  null,
  "Припинити редагування вузлів"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Style": [
  null,
  "Стиль"
 ],
 "Switch to administrative access": [
  null,
  "Перемкнутися на адміністративний доступ"
 ],
 "Switch to limited access": [
  null,
  "Перемкнутися на обмежений доступ"
 ],
 "System": [
  null,
  "Система"
 ],
 "Terminal": [
  null,
  "Термінал"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "У IP-адресі або назві вузла не повинно бути пробілів."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Ключ SSH $0 $1 на $2 буде додано до файла $3 $4 на $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Ключ SSH $0 буде доступним протягом решти сеансу і також буде доступним для входу на інші вузли."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено паролем, а на вузлі заборонено вхід без пароля. Буль ласка, вкажіть пароль до ключа у $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Ключ SSH для входу до $0 захищено. Ви можете увійти або за допомогою пароль до вашого облікового запису або вказавши пароль до ключа у $1."
 ],
 "The key password can not be empty": [
  null,
  "Пароль до ключа не може бути порожнім"
 ],
 "The key passwords do not match": [
  null,
  "Паролі до ключа не збігаються"
 ],
 "The machine is rebooting": [
  null,
  "Комп’ютер перезавантажується"
 ],
 "The new key password can not be empty": [
  null,
  "Новий пароль до ключа не може бути порожнім"
 ],
 "The password can not be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "The passwords do not match.": [
  null,
  "Паролі не збігаються."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Відбиток-результат можна поширювати у спосіб із загальним доступом, зокрема електронною поштою."
 ],
 "There are currently no active pages": [
  null,
  "Зараз активних сторінок немає"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Під час спроби встановити з'єднання із комп'ютером сталася неочікувана помилка."
 ],
 "This machine has already been added.": [
  null,
  "Цей комп’ютер вже було додано."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Це надасть вам змогу надалі входити без пароля."
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Підказка: для автоматичного розпізнавання на інших системах встановіть однаковий пароль для ключа і для входу до системи."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Щоб переконатися, що дані вашого з'єднання не буде перехоплено зловмисниками, будь ласка, підтвердьте відбиток ключа вузла:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Щоб перевірити відбиток, віддайте вказану нижче команду для $0 під час безпосередньої роботи на комп'ютері або з використанням надійної мережі:"
 ],
 "Toggle": [
  null,
  "Перемкнути"
 ],
 "Tools": [
  null,
  "Інструменти"
 ],
 "Turn on administrative access": [
  null,
  "Увімкнути адміністративний доступ"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Unable to contact $0.": [
  null,
  "Не вдалося встановити зв'язок із $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Не вдалося встановити зв’язок із вказаним вузлом $0. Переконайтеся, що ssh запущено на порту $1 або вкажіть інший порт у адресі."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Не вдалося увійти до $0 за допомогою розпізнавання за ключем SSH. Будь ласка, вкажіть пароль. Ви можете налаштувати ваші ключі SSH для автоматичного входу до системи."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Не вдалося увійти до $0. Вузол не приймає входу за паролем або будь-яким з ваших ключів SSH."
 ],
 "Unexpected error": [
  null,
  "Неочікувана помилка"
 ],
 "Unlock": [
  null,
  "Розблокувати"
 ],
 "Unlock key $0": [
  null,
  "Розблокувати ключ $0"
 ],
 "Update": [
  null,
  "Оновити"
 ],
 "Use key": [
  null,
  "Використати ключ"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Використати вказані нижче ключі для розпізнавання у інших системах"
 ],
 "User name": [
  null,
  "Ім'я користувача"
 ],
 "Using LUKS encryption": [
  null,
  "З використанням шифрування LUKS"
 ],
 "Using Tang server": [
  null,
  "З використанням сервера Tang"
 ],
 "Web Console": [
  null,
  "Вебконсоль"
 ],
 "Web console logo": [
  null,
  "Логотип вебконсолі"
 ],
 "When empty, connect with the current user": [
  null,
  "Якщо не вказано, з'єднатися із поточним користувачем"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Ви вперше встановлюєте з'єднання із $0."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Вашого користувача було викинуто із системи через неактивність."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Ви можете змінити пароль до ключа для автоматичного входу до системи."
 ],
 "You now have administrative access.": [
  null,
  "Тепер ви маєте адміністративний доступ."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Вашого користувача буде викинуто з системи за $0 секунд."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Ваш браузер запам'ятовуватиме ваш рівень доступу між сеансами."
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "access": [
  null,
  "доступ"
 ],
 "active": [
  null,
  "активний"
 ],
 "add-on": [
  null,
  "додаток"
 ],
 "addon": [
  null,
  "addon"
 ],
 "apps": [
  null,
  "програми"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "мітка активу"
 ],
 "avc": [
  null,
  "avc"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "bond": [
  null,
  "прив’язка"
 ],
 "boot": [
  null,
  "завантаження"
 ],
 "bridge": [
  null,
  "місток"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "команда"
 ],
 "console": [
  null,
  "консоль"
 ],
 "coredump": [
  null,
  "дамп ядра"
 ],
 "cpu": [
  null,
  "процесор"
 ],
 "crash": [
  null,
  "аварія"
 ],
 "date": [
  null,
  "дата"
 ],
 "debug": [
  null,
  "діагностика"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "вимкнути"
 ],
 "disk": [
  null,
  "диск"
 ],
 "disks": [
  null,
  "диски"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "domain": [
  null,
  "домен"
 ],
 "drive": [
  null,
  "диск"
 ],
 "enable": [
  null,
  "увімкнути"
 ],
 "encryption": [
  null,
  "шифрування"
 ],
 "error": [
  null,
  "помилка"
 ],
 "extension": [
  null,
  "розширення"
 ],
 "filesystem": [
  null,
  "файлова система"
 ],
 "firewall": [
  null,
  "брандмауер"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "format": [
  null,
  "формат"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "graphs": [
  null,
  "графіки"
 ],
 "hardware": [
  null,
  "обладнання"
 ],
 "history": [
  null,
  "журнал"
 ],
 "host": [
  null,
  "вузол"
 ],
 "in most browsers": [
  null,
  "у більшості браузерів"
 ],
 "install": [
  null,
  "встановити"
 ],
 "interface": [
  null,
  "інтерфейс"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "journal": [
  null,
  "журнал"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "ключі"
 ],
 "login": [
  null,
  "вхід"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mac": [
  null,
  "mac"
 ],
 "machine": [
  null,
  "машина"
 ],
 "mask": [
  null,
  "маска"
 ],
 "memory": [
  null,
  "пам'ять"
 ],
 "metrics": [
  null,
  "метрика"
 ],
 "mitigation": [
  null,
  "обхід"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "монтування"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "network": [
  null,
  "мережа"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "operating system": [
  null,
  "операційна система"
 ],
 "os": [
  null,
  "ос"
 ],
 "package": [
  null,
  "пакунок"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "partition": [
  null,
  "розділ"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "пароль"
 ],
 "path": [
  null,
  "шлях"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "швидкодія"
 ],
 "plugin": [
  null,
  "додаток"
 ],
 "port": [
  null,
  "порт"
 ],
 "power": [
  null,
  "живлення"
 ],
 "raid": [
  null,
  "raid"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "перезапуск"
 ],
 "roles": [
  null,
  "ролі"
 ],
 "security": [
  null,
  "безпека"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  "послідовний"
 ],
 "service": [
  null,
  "служба"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ],
 "shell": [
  null,
  "оболонка"
 ],
 "show less": [
  null,
  "показати менше"
 ],
 "show more": [
  null,
  "показати більше"
 ],
 "shut": [
  null,
  "вимкнути"
 ],
 "socket": [
  null,
  "сокет"
 ],
 "sos": [
  null,
  "sos"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "tang"
 ],
 "target": [
  null,
  "ціль"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "команда"
 ],
 "time": [
  null,
  "time"
 ],
 "timer": [
  null,
  "секундомір"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  "модуль"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "unmount": [
  null,
  "демонтувати"
 ],
 "user": [
  null,
  "користувач"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "користувач"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "version": [
  null,
  "версія"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "volume": [
  null,
  "том"
 ],
 "warning": [
  null,
  "попередження"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "зона"
 ]
});
