cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "Документация $0"
 ],
 "$0 key changed": [
  null,
  "Изменен $0 ключ"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Совместимая версия Cockpit не установлена на $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Будет создан новый ключ SSH в $0 для $1 на $2 и добавлен в файл $3 $4 на $5."
 ],
 "About Web Console": [
  null,
  "О веб-консоли"
 ],
 "Accept key and connect": [
  null,
  "Принять ключ и подключиться"
 ],
 "Accounts": [
  null,
  "Учётные записи"
 ],
 "Active pages": [
  null,
  "Активные страницы"
 ],
 "Add": [
  null,
  "Добавить"
 ],
 "Add key": [
  null,
  "Добавить ключ"
 ],
 "Add new host": [
  null,
  "Добавить новый узел"
 ],
 "Administrative access": [
  null,
  "Административный доступ"
 ],
 "Applications": [
  null,
  "Приложения"
 ],
 "Apps": [
  null,
  "Приложения"
 ],
 "Authenticate": [
  null,
  "Проверка подлинности"
 ],
 "Authentication": [
  null,
  "Проверка подлинности"
 ],
 "Authorize SSH key": [
  null,
  "Авторизовать SSH-ключ"
 ],
 "Automatic login": [
  null,
  "Автоматический вход"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Если изменить пароль ключа SSH $0 на пароль для входа $1 на $2, ключ будет автоматически доступен, и вы в будущем сможете входить в $3 без пароля."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Может быть именем узла, IP-адресом, псевдонимом или ssh:// URI"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Не удаётся подключиться к неизвестному компьютеру"
 ],
 "Change password": [
  null,
  "Изменить пароль"
 ],
 "Change the password of $0": [
  null,
  "Изменить пароль для $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Изменение ключей часто происходит в результате переустановки операционной системы. Однако неожиданное изменение может указывать на попытку третьей стороны перехватить ваше соединение."
 ],
 "Choose the language to be used in the application": [
  null,
  "Выберите язык, который будет использоваться в приложении"
 ],
 "Clear search": [
  null,
  "Сбросить поиск"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Close selected pages": [
  null,
  "Закрыть выделенные страницы"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "У Cockpit произошла неожиданная внутренняя ошибка."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit — это интерактивный интерфейс администратора серверов Linux."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit не установлен"
 ],
 "Color": [
  null,
  "Цвет"
 ],
 "Comment": [
  null,
  "Комментарий"
 ],
 "Configuring kdump": [
  null,
  "Настройка kdump"
 ],
 "Configuring system settings": [
  null,
  "Настройка параметров системы"
 ],
 "Confirm key password": [
  null,
  "Подтвердите ключевой пароль"
 ],
 "Confirm new key password": [
  null,
  "Подтвердите новый ключевой пароль"
 ],
 "Confirm password": [
  null,
  "Подтвердите пароль"
 ],
 "Connecting to the machine": [
  null,
  "Подключение к компьютеру"
 ],
 "Connection error": [
  null,
  "Ошибка подключения"
 ],
 "Connection failed": [
  null,
  "Ошибка подключения"
 ],
 "Contains:": [
  null,
  "Содержит:"
 ],
 "Continue session": [
  null,
  "Продолжить сессию"
 ],
 "Copied": [
  null,
  "Скопировано"
 ],
 "Copy": [
  null,
  "Копировать"
 ],
 "Create": [
  null,
  "Создать"
 ],
 "Create a new SSH key and authorize it": [
  null,
  ""
 ],
 "Ctrl-Shift-J": [
  null,
  ""
 ],
 "Dark": [
  null,
  "Тёмный"
 ],
 "Default": [
  null,
  "По умолчанию"
 ],
 "Details": [
  null,
  "Подробности"
 ],
 "Development": [
  null,
  "Разработка"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Disconnected": [
  null,
  "Отключено"
 ],
 "Display language": [
  null,
  "Язык интерфейса"
 ],
 "Edit": [
  null,
  "Изменить"
 ],
 "Edit hosts": [
  null,
  ""
 ],
 "Failed to add machine: $0": [
  null,
  "Не удалось добавить компьютер: $0"
 ],
 "Failed to change password": [
  null,
  "Не удалось изменить пароль"
 ],
 "Failed to edit machine: $0": [
  null,
  "Не удалось изменить компьютер: $0"
 ],
 "Fingerprint": [
  null,
  "Отпечаток"
 ],
 "Help": [
  null,
  "Помощь"
 ],
 "Host": [
  null,
  "Узел"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  ""
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  ""
 ],
 "Invalid file permissions": [
  null,
  "Недопустимые разрешения для файлов"
 ],
 "Is sshd running on a different port?": [
  null,
  "Работает ли sshd на другом порту?"
 ],
 "Kernel dump": [
  null,
  "Дамп ядра"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  ""
 ],
 "Light": [
  null,
  "Светлый"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  ""
 ],
 "Log in": [
  null,
  "Войти"
 ],
 "Log out": [
  null,
  "Выход"
 ],
 "Logs": [
  null,
  "Журналы"
 ],
 "Managing firewall": [
  null,
  "Управление межсетевым экраном"
 ],
 "Managing partitions": [
  null,
  "Управление разделами"
 ],
 "Managing services": [
  null,
  "Управление службами"
 ],
 "Managing software updates": [
  null,
  "Управление обновлениями программного обеспечения"
 ],
 "Managing user accounts": [
  null,
  "Управление учетными записями пользователей"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Сообщения, связанные с ошибкой, могут быть найдены в журнале:"
 ],
 "Method": [
  null,
  ""
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "New password": [
  null,
  "Новый пароль"
 ],
 "New password was not accepted": [
  null,
  "Новый пароль не был принят"
 ],
 "No results found": [
  null,
  "Нет результатов"
 ],
 "No such file or directory": [
  null,
  "Нет такого файла или каталога"
 ],
 "Not a valid private key": [
  null,
  "Недопустимый закрытый ключ"
 ],
 "Old password not accepted": [
  null,
  "Старый пароль не был принят"
 ],
 "Ooops!": [
  null,
  "Упс!"
 ],
 "Overview": [
  null,
  "Обзор"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password not accepted": [
  null,
  "Пароль не принят"
 ],
 "Path to file": [
  null,
  "Путь к файлу"
 ],
 "Please authenticate to gain administrative access": [
  null,
  ""
 ],
 "Port": [
  null,
  "Порт"
 ],
 "Project website": [
  null,
  "Веб-сайт проекта"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Превышено время ожидания запроса по ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Превышено время ожидания запроса по ssh-keygen"
 ],
 "Public key": [
  null,
  "Открытый ключ"
 ],
 "Reconnect": [
  null,
  "Повторить подключение"
 ],
 "Remove": [
  null,
  "Удалить"
 ],
 "Reviewing logs": [
  null,
  "Просмотр журналов"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Пользователям Safari необходимо импортировать и установить доверие к самозаверенному сертификату центра сертификации:"
 ],
 "Search": [
  null,
  "Поиск"
 ],
 "Select": [
  null,
  "Выбрать"
 ],
 "Services": [
  null,
  "Службы"
 ],
 "Session": [
  null,
  "Сеанс"
 ],
 "Session is about to expire": [
  null,
  "Сессия истекает"
 ],
 "Set": [
  null,
  "Настроить"
 ],
 "Software updates": [
  null,
  "Обновления программного обеспечения"
 ],
 "Stop editing hosts": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Style": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  ""
 ],
 "System": [
  null,
  "Система"
 ],
 "Terminal": [
  null,
  "Терминал"
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  ""
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  ""
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  ""
 ],
 "The passwords do not match.": [
  null,
  "Пароли не совпадают."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  ""
 ],
 "There are currently no active pages": [
  null,
  "В настоящее время нет активных страниц"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Произошла непредвиденная ошибка при подключении к компьютеру."
 ],
 "This machine has already been added.": [
  null,
  "Этот компьютер уже добавлен."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  ""
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Совет: сделайте пароль ключа и пароль для входа в систему одинаковыми для автоматической проверки подлинности в других системах."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  ""
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  ""
 ],
 "Toggle": [
  null,
  ""
 ],
 "Tools": [
  null,
  ""
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  ""
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  ""
 ],
 "Unexpected error": [
  null,
  "Непредвиденная ошибка"
 ],
 "Unlock": [
  null,
  "Разблокировать"
 ],
 "Update": [
  null,
  "Обновить"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Используйте следующие ключи для проверки подлинности в других системах"
 ],
 "User name": [
  null,
  "Имя пользователя"
 ],
 "Web Console": [
  null,
  "Веб-консоль"
 ],
 "When empty, connect with the current user": [
  null,
  ""
 ],
 "You are connecting to $0 for the first time.": [
  null,
  ""
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Вы вышли из системы из-за неактивности."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  ""
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Вы выйдете из системы через $0 секунд."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  ""
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "access": [
  null,
  "доступ"
 ],
 "active": [
  null,
  "активно"
 ],
 "add-on": [
  null,
  "дополнение"
 ],
 "addon": [
  null,
  "дополнение"
 ],
 "apps": [
  null,
  "программы"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "тег актива"
 ],
 "avc": [
  null,
  "avc"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "bond": [
  null,
  "привязка"
 ],
 "boot": [
  null,
  "загрузка"
 ],
 "bridge": [
  null,
  "мост"
 ],
 "cgroups": [
  null,
  ""
 ],
 "command": [
  null,
  "команда"
 ],
 "console": [
  null,
  "консоль"
 ],
 "coredump": [
  null,
  "дамп ядра"
 ],
 "cpu": [
  null,
  "процессор"
 ],
 "crash": [
  null,
  "сбой"
 ],
 "date": [
  null,
  "дата"
 ],
 "debug": [
  null,
  "отладка"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "отключить"
 ],
 "disk": [
  null,
  "диск"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "domain": [
  null,
  "домен"
 ],
 "drive": [
  null,
  "привод"
 ],
 "enable": [
  null,
  "включить"
 ],
 "encryption": [
  null,
  "шифрование"
 ],
 "error": [
  null,
  "ошибка"
 ],
 "extension": [
  null,
  "расширение"
 ],
 "filesystem": [
  null,
  "файловая система"
 ],
 "firewall": [
  null,
  "Межсетевой экран"
 ],
 "format": [
  null,
  "форматировать"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "graphs": [
  null,
  "графики"
 ],
 "hardware": [
  null,
  "оборудование"
 ],
 "host": [
  null,
  "узел"
 ],
 "in most browsers": [
  null,
  ""
 ],
 "install": [
  null,
  "установить"
 ],
 "interface": [
  null,
  "интерфейс"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "journal": [
  null,
  "журнал"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "ключи"
 ],
 "login": [
  null,
  "вход"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mac": [
  null,
  "mac"
 ],
 "machine": [
  null,
  "компьютер"
 ],
 "mask": [
  null,
  "маска"
 ],
 "memory": [
  null,
  "память"
 ],
 "mitigation": [
  null,
  "защита"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "монтировать"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "network": [
  null,
  "сеть"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "operating system": [
  null,
  "операционная система"
 ],
 "os": [
  null,
  "ОС"
 ],
 "package": [
  null,
  "пакет"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "partition": [
  null,
  "раздел"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "пароль"
 ],
 "path": [
  null,
  "путь"
 ],
 "pci": [
  null,
  "pci"
 ],
 "plugin": [
  null,
  "подключаемый модуль"
 ],
 "port": [
  null,
  "порт"
 ],
 "power": [
  null,
  "питание"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "ram": [
  null,
  "ОЗУ"
 ],
 "restart": [
  null,
  "перезапустить"
 ],
 "roles": [
  null,
  "роли"
 ],
 "security": [
  null,
  "безопасность"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  "последовательный"
 ],
 "service": [
  null,
  "служба"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ],
 "shell": [
  null,
  "оболочка"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "shut": [
  null,
  "закрывать"
 ],
 "socket": [
  null,
  "socket"
 ],
 "sos": [
  null,
  "sos"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "tang"
 ],
 "target": [
  null,
  "цель"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "команда"
 ],
 "time": [
  null,
  "время"
 ],
 "timer": [
  null,
  "таймер"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  "блок"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "unmount": [
  null,
  "размонтировать"
 ],
 "user": [
  null,
  "пользователь"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "имя пользователя"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "version": [
  null,
  "версия"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "volume": [
  null,
  "том"
 ],
 "warning": [
  null,
  "предупреждение"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "зона"
 ]
});
