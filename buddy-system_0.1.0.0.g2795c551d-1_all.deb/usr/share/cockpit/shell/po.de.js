cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "$0 Dokumentation"
 ],
 "$0 key changed": [
  null,
  "$0 Schlüssel geändert"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Eine kompatible Version von Cockpit ist auf $0 nicht installiert."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Ein neuer SSH-Schlüssel unter $0 wird für $1 auf $2 erstellt und zur Datei $3 von $4 auf $5 hinzugefügt."
 ],
 "About Web Console": [
  null,
  "Über Web Console"
 ],
 "Accept key and connect": [
  null,
  "Schlüssel akzeptieren und verbinden"
 ],
 "Accounts": [
  null,
  "Konten"
 ],
 "Active pages": [
  null,
  "Aktive Seiten"
 ],
 "Add": [
  null,
  "Hinzufügen"
 ],
 "Add key": [
  null,
  "Schlüssel hinzufügen"
 ],
 "Add new host": [
  null,
  "Neuen Host hinzufügen"
 ],
 "Administrative access": [
  null,
  "Administrativer Zugang"
 ],
 "Applications": [
  null,
  "Anwendungen"
 ],
 "Apps": [
  null,
  "Apps"
 ],
 "Authenticate": [
  null,
  "Authentifiziere"
 ],
 "Authentication": [
  null,
  "Authentifizierung"
 ],
 "Authorize SSH key": [
  null,
  "SSH-Schlüssel autorisieren"
 ],
 "Automatic login": [
  null,
  "Automatische Anmeldung"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Wenn Sie das Passwort des SSH-Schlüssels $0 in das Anmeldepasswort von $1 auf $2 ändern, wird der Schlüssel automatisch verfügbar gemacht und Sie können sich in Zukunft ohne Passwort auf $3 anmelden."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Kann ein Hostname, eine IP-Adresse, ein Alias-Name oder ein ssh:// URI sein"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Verbindung zu einer unbekannten Maschine nicht möglich"
 ],
 "Change password": [
  null,
  "Passwort ändern"
 ],
 "Change the password of $0": [
  null,
  "Passwort von $0 ändern"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Geänderte Schlüssel sind oft das Ergebnis einer Neuinstallation des Betriebssystems. Allerdings kann eine unerwartete Änderung auf einen Versuch eines Dritten hinweisen, Ihre Verbindung auszuspähen."
 ],
 "Choose the language to be used in the application": [
  null,
  "Wählen Sie die in der Applikation zu verwendende Sprache"
 ],
 "Clear search": [
  null,
  "Suche zurücksetzen"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Close selected pages": [
  null,
  "Ausgewählte Seiten schließen"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit hatte einen unerwarteten Fehler."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit ist ein interaktives Administrationsinterface für Linux Server."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit ist nicht installiert"
 ],
 "Color": [
  null,
  "Farbe"
 ],
 "Comment": [
  null,
  "Kommentar"
 ],
 "Configuring kdump": [
  null,
  "Konfiguriere kdump"
 ],
 "Configuring system settings": [
  null,
  "Konfiguriere System-Einstellungen"
 ],
 "Confirm key password": [
  null,
  "Neues Passwort wiederholen"
 ],
 "Confirm new key password": [
  null,
  "Neues Schlüssel-Passwort wiederholen"
 ],
 "Confirm password": [
  null,
  "Passwort bestätigen"
 ],
 "Connecting to the machine": [
  null,
  "Verbindung zur Maschine wird hergestellt"
 ],
 "Connection error": [
  null,
  "Fehler bei der Verbindung"
 ],
 "Connection failed": [
  null,
  "Verbindung fehlgeschlagen"
 ],
 "Contains:": [
  null,
  "Enthält:"
 ],
 "Continue session": [
  null,
  "Sitzung Fortsetzen"
 ],
 "Copied": [
  null,
  "Kopiert"
 ],
 "Copy": [
  null,
  "Kopieren"
 ],
 "Could not contact $0": [
  null,
  "Konnte $0 nicht kontaktieren"
 ],
 "Create": [
  null,
  "Erstellen"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Einen neuen SSH-Schlüssel erstellen und ihn autorisieren"
 ],
 "Ctrl-Shift-J": [
  null,
  "Strg-Shift-J"
 ],
 "Dark": [
  null,
  "Dunkel"
 ],
 "Default": [
  null,
  "Standard"
 ],
 "Details": [
  null,
  "Details"
 ],
 "Development": [
  null,
  "Entwicklung"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Disconnected": [
  null,
  "Getrennt"
 ],
 "Display language": [
  null,
  "Anzeigesprache"
 ],
 "Edit": [
  null,
  "Bearbeiten"
 ],
 "Edit host": [
  null,
  "Host bearbeiten"
 ],
 "Edit hosts": [
  null,
  "Hosts bearbeiten"
 ],
 "Failed to add machine: $0": [
  null,
  "Maschine konnte nicht hinzugefügt werden: $0"
 ],
 "Failed to change password": [
  null,
  "Passwort konnte nicht geändert werden"
 ],
 "Failed to edit machine: $0": [
  null,
  "Maschine konnte nicht editiert werden: $0"
 ],
 "Filter menu items": [
  null,
  "Menüpunkte filtern"
 ],
 "Fingerprint": [
  null,
  "Fingerabdruck"
 ],
 "Help": [
  null,
  "Hilfe"
 ],
 "Host": [
  null,
  "Host"
 ],
 "Hosts": [
  null,
  "Hosts"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Wenn der Fingerabdruck übereinstimmt, klicke 'Schlüssel akzeptieren und verbinden'. Andernfalls, Verbindung ablehnen und den Administrator kontaktieren."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Um in Zukunft die Anmeldung bei $0 als $1 ohne Passwort zu ermöglichen, verwenden Sie das Anmeldepasswort von $2 auf $3 als Schlüsselpasswort oder lassen Sie das Schlüsselpasswort leer."
 ],
 "Invalid file permissions": [
  null,
  "Ungültige Dateiberechtigungen"
 ],
 "Is sshd running on a different port?": [
  null,
  "Läuft sshd auf einem anderen Port?"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Key password": [
  null,
  "Schlüsselpasswort"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Lizenziert unter der GNU LGPL Version 2.1"
 ],
 "Light": [
  null,
  "Leicht"
 ],
 "Limit access": [
  null,
  "Zugang einschränken"
 ],
 "Limited access": [
  null,
  "Eingeschränkter Zugang"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Der eingeschränkte Zugriffsmodus schränkt die administrativen Rechte ein. Einige Teile der Web-Konsole sind in ihrer Funktionalität eingeschränkt."
 ],
 "Loading packages...": [
  null,
  "Pakete werden geladen..."
 ],
 "Log in": [
  null,
  "Anmelden"
 ],
 "Log in to $0": [
  null,
  "Bei $0 anmelden"
 ],
 "Log out": [
  null,
  "Abmelden"
 ],
 "Logs": [
  null,
  "Protokolle"
 ],
 "Managing LVMs": [
  null,
  "LVMs verwalten"
 ],
 "Managing NFS mounts": [
  null,
  "NFS-Freigaben verwalten"
 ],
 "Managing RAIDs": [
  null,
  "RAIDs verwalten"
 ],
 "Managing VDOs": [
  null,
  "VDOs verwalten"
 ],
 "Managing VLANs": [
  null,
  "VLANs verwalten"
 ],
 "Managing firewall": [
  null,
  "Firewall verwalten"
 ],
 "Managing networking bonds": [
  null,
  ""
 ],
 "Managing networking bridges": [
  null,
  "Netzwerkbrücken verwalten"
 ],
 "Managing networking teams": [
  null,
  ""
 ],
 "Managing partitions": [
  null,
  "Partitionen verwalten"
 ],
 "Managing physical drives": [
  null,
  "Physische Laufwerke verwalten"
 ],
 "Managing services": [
  null,
  "Dienste verwalten"
 ],
 "Managing software updates": [
  null,
  "Software-Aktualisierungen verwalten"
 ],
 "Managing user accounts": [
  null,
  "Benutzerkonten verwalten"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Im Journal finden sich möglicherweise Meldungen zu dem Fehler:"
 ],
 "Method": [
  null,
  "Methode"
 ],
 "Name": [
  null,
  "Name"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "New host": [
  null,
  "Neuer Host"
 ],
 "New key password": [
  null,
  "Neues Schlüsselpasswort"
 ],
 "New password": [
  null,
  "Neues Passwort"
 ],
 "New password was not accepted": [
  null,
  "Das neue Passwort wurde nicht akzeptiert"
 ],
 "No results found": [
  null,
  "Keine Ergebnisse gefunden"
 ],
 "No such file or directory": [
  null,
  "Datei oder Verzeichnis nicht vorhanden"
 ],
 "Not a valid private key": [
  null,
  "Ungültiger privater Schlüssel"
 ],
 "Not connected to host": [
  null,
  "Nicht mit Host verbunden"
 ],
 "Old password not accepted": [
  null,
  "Altes Passwort wurde nicht akzeptiert"
 ],
 "Ooops!": [
  null,
  "Uuups!"
 ],
 "Overview": [
  null,
  "Überblick"
 ],
 "Page name": [
  null,
  "Seitenname"
 ],
 "Password": [
  null,
  "Passwort"
 ],
 "Password changed successfully": [
  null,
  "Passwort erfolgreich geändert"
 ],
 "Password not accepted": [
  null,
  "Passwort wurde nicht akzeptiert"
 ],
 "Password tip": [
  null,
  "Passworthinweis"
 ],
 "Path to file": [
  null,
  "Pfad zur Datei"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Bitte authentifizieren Sie sich, um administrativen Zugriff zu erhalten"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Problem becoming administrator": [
  null,
  "Problem beim Administrator werden"
 ],
 "Project website": [
  null,
  "Projekt-Website"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Die Aufforderung über ssh-add ist abgelaufen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Die Aufforderung über ssh-keygen ist abgelaufen"
 ],
 "Public key": [
  null,
  "Öffentlicher Schlüssel"
 ],
 "Reconnect": [
  null,
  "Erneut verbinden"
 ],
 "Remove": [
  null,
  "Entfernen"
 ],
 "Reviewing logs": [
  null,
  "Protokolle bewerten"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-Schlüssel"
 ],
 "SSH keys": [
  null,
  "SSH-Schlüssel"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safari Benutzer müssen das selbst signierten Zertifikat importieren:"
 ],
 "Search": [
  null,
  "Suche"
 ],
 "Select": [
  null,
  "Auswählen"
 ],
 "Services": [
  null,
  "Dienste"
 ],
 "Session": [
  null,
  "Sitzung"
 ],
 "Session is about to expire": [
  null,
  "Sitzung läuft bald ab"
 ],
 "Set": [
  null,
  "Einstellen"
 ],
 "Skip main navigation": [
  null,
  "Hauptnavigation überspringen"
 ],
 "Skip to content": [
  null,
  "Zum Inhalt springen"
 ],
 "Software updates": [
  null,
  "Aktualisierungen"
 ],
 "Stop editing hosts": [
  null,
  "Bearbeitung von Hosts beenden"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Style": [
  null,
  ""
 ],
 "Switch to administrative access": [
  null,
  "Auf administrativen Zugang umschalten"
 ],
 "Switch to limited access": [
  null,
  "Auf eingeschränkten Zugang umschalten"
 ],
 "System": [
  null,
  "System"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "Die IP-Adresse oder der Hostname darf keine Leerzeichen enthalten."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Der SSH-Schlüssel $0 von $1 auf $2 wird der Datei $3 von $4 auf $5 hinzugefügt."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Der SSH-Schlüssel $0 wird für den Rest der Sitzung zur Verfügung gestellt und steht auch für die Anmeldung bei anderen Hosts zur Verfügung."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Der SSH-Schlüssel für die Anmeldung bei $0 ist durch ein Passwort geschützt, und der Host erlaubt keine Anmeldung mit einem Passwort. Bitte geben Sie das Passwort des Schlüssels auf $1 an."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Der SSH-Schlüssel für die Anmeldung bei $0 ist geschützt. Sie können sich entweder mit Ihrem Anmeldepasswort oder mit dem Passwort des Schlüssels bei $1 anmelden."
 ],
 "The key password can not be empty": [
  null,
  "Das Schlüsselpasswort darf nicht leer sein"
 ],
 "The key passwords do not match": [
  null,
  "Die Schlüsselpasswörter stimmen nicht überein"
 ],
 "The machine is rebooting": [
  null,
  "Die Maschine startet neu"
 ],
 "The new key password can not be empty": [
  null,
  "Das neue Schlüsselpasswort darf nicht leer sein"
 ],
 "The password can not be empty": [
  null,
  "Das Passwort darf nicht leer sein"
 ],
 "The passwords do not match.": [
  null,
  "Die Passwörter stimmen nicht überein."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Der entstandene Fingerabdruck kann über öffentliche Methoden, einschließlich E-Mail, weitergegeben werden."
 ],
 "There are currently no active pages": [
  null,
  "Derzeit sind keine aktiven Seiten vorhanden"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Bei der Verbindung zur Maschine ist ein unerwarteter Fehler aufgetreten."
 ],
 "This machine has already been added.": [
  null,
  "Diese Maschine wurde bereits hinzugefügt"
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Dies ermöglicht es Ihnen, sich in Zukunft ohne Passwort anzumelden."
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Tipp: Wenn Ihr Schlüsselpasswort mit Ihrem Login-Passwort übereinstimmt, können Sie sich an anderen Systemen automatisiert anmelden."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Überprüfen Sie bitte den Fingerabdruck des Host-Schlüssels, um sicherzustellen, dass Ihre Verbindung nicht von einem böswilligen Dritten ausgespäht wird:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Um einen Fingerabdruck zu überprüfen, führen Sie die folgenden Schritte auf $0 aus, während Sie physisch an der Maschine sitzen oder über ein vertrauenswürdiges Netzwerk:"
 ],
 "Toggle": [
  null,
  "Umschalten"
 ],
 "Tools": [
  null,
  "Werkzeuge"
 ],
 "Turn on administrative access": [
  null,
  "Administrator-Zugriff aktivieren"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unable to contact $0.": [
  null,
  "$0 kann nicht kontaktiert werden."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Der angegebene Host $0 kann nicht kontaktiert werden. Stellen Sie sicher, dass ssh auf Port $1 läuft, oder geben Sie einen anderen Port in der Adresse an."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Die Anmeldung bei $0 mit SSH-Schlüsselauthentifizierung ist nicht möglich. Bitte geben Sie das Passwort ein. Vielleicht möchten Sie Ihre SSH-Schlüssel für die automatische Anmeldung einrichten."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Die Anmeldung bei $0 ist nicht möglich. Der Host akzeptiert weder ein Passwort noch einen Ihrer SSH-Schlüssel."
 ],
 "Unexpected error": [
  null,
  "Unerwarteter Fehler"
 ],
 "Unlock": [
  null,
  "Öffnen"
 ],
 "Unlock key $0": [
  null,
  "Schlüssel $0 entsperren"
 ],
 "Update": [
  null,
  "Update"
 ],
 "Use key": [
  null,
  "Schlüssel verwenden"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Benutze die folgenen Schlüssel zur Authentifizierung an anderen Systemen"
 ],
 "User name": [
  null,
  "Benutzername"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS-Verschlüsselung verwenden"
 ],
 "Using Tang server": [
  null,
  "Tang-Server verwenden"
 ],
 "Web Console": [
  null,
  "Web Konsole"
 ],
 "Web console logo": [
  null,
  "Logo der Web-Konsole"
 ],
 "When empty, connect with the current user": [
  null,
  "Wenn leer, mit dem aktuellen Benutzer verbinden"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Sie stellen zum ersten Mal eine Verbindung zu $0 her."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Sie wurden wegen Inaktivität abgemeldet."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Vielleicht möchten Sie das Passwort des Schlüssels für die automatische Anmeldung ändern."
 ],
 "You now have administrative access.": [
  null,
  "Sie haben nun Administrator Zugriff."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Sie werden in $0 Sekunden abgemeldet."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Ihr Browser speichert Ihre Zugriffsstufe über mehrere Sitzungen hinweg."
 ],
 "abrt": [
  null,
  ""
 ],
 "access": [
  null,
  "Zugriff"
 ],
 "active": [
  null,
  "Aktiv"
 ],
 "add-on": [
  null,
  "Add-on"
 ],
 "addon": [
  null,
  "AddOn"
 ],
 "apps": [
  null,
  "Programme"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "Asset-Tag"
 ],
 "avc": [
  null,
  "avc"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "bond": [
  null,
  ""
 ],
 "boot": [
  null,
  "Starten"
 ],
 "bridge": [
  null,
  "Brücke"
 ],
 "cgroups": [
  null,
  ""
 ],
 "command": [
  null,
  "Kommando"
 ],
 "console": [
  null,
  "Konsole"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "CPU"
 ],
 "crash": [
  null,
  "Absturz"
 ],
 "date": [
  null,
  "Datum"
 ],
 "debug": [
  null,
  "Debug"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "deaktivieren"
 ],
 "disk": [
  null,
  "Datenträger"
 ],
 "disks": [
  null,
  "Datenträger"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "domain": [
  null,
  "Domain"
 ],
 "drive": [
  null,
  "Speichergerät"
 ],
 "enable": [
  null,
  "aktivieren"
 ],
 "encryption": [
  null,
  "Verschlüsselung"
 ],
 "error": [
  null,
  "Fehler"
 ],
 "extension": [
  null,
  "Erweiterung"
 ],
 "filesystem": [
  null,
  "Dateisystem"
 ],
 "firewall": [
  null,
  "Firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "format": [
  null,
  "Formatieren"
 ],
 "fstab": [
  null,
  "Fstab"
 ],
 "graphs": [
  null,
  "Kurven"
 ],
 "hardware": [
  null,
  "Hardware"
 ],
 "history": [
  null,
  "Verlauf"
 ],
 "host": [
  null,
  "host"
 ],
 "in most browsers": [
  null,
  "in den meisten Browsern"
 ],
 "install": [
  null,
  "Installation"
 ],
 "interface": [
  null,
  "Schnittstelle"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "journal": [
  null,
  "Journal"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "Schlüssel"
 ],
 "login": [
  null,
  "Login"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mac": [
  null,
  "mac"
 ],
 "machine": [
  null,
  "Maschine"
 ],
 "mask": [
  null,
  "Maske"
 ],
 "memory": [
  null,
  "Speicher"
 ],
 "metrics": [
  null,
  "Kennzahlen"
 ],
 "mitigation": [
  null,
  "Milderung"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "Einhängen"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "network": [
  null,
  "Netzwerk"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "operating system": [
  null,
  "Betriebssystem"
 ],
 "os": [
  null,
  "os"
 ],
 "package": [
  null,
  "Paket"
 ],
 "packagekit": [
  null,
  ""
 ],
 "partition": [
  null,
  "Partition"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "Passwort"
 ],
 "path": [
  null,
  "Pfad"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "Leistung"
 ],
 "plugin": [
  null,
  "Plugin"
 ],
 "port": [
  null,
  "Port"
 ],
 "power": [
  null,
  "Leistung"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "ram": [
  null,
  "Arbeitsspeicher"
 ],
 "restart": [
  null,
  "Neustart"
 ],
 "roles": [
  null,
  "Rollen"
 ],
 "security": [
  null,
  "Sicherheit"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  "Seriell"
 ],
 "service": [
  null,
  "Dienst"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ],
 "shell": [
  null,
  "Shell"
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ],
 "shut": [
  null,
  ""
 ],
 "socket": [
  null,
  "Socket"
 ],
 "sos": [
  null,
  "Sos"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "tang"
 ],
 "target": [
  null,
  "Ziel"
 ],
 "tcp": [
  null,
  "TCP"
 ],
 "team": [
  null,
  "Team"
 ],
 "time": [
  null,
  "Zeit"
 ],
 "timer": [
  null,
  "Timer"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  "Einheit"
 ],
 "unmask": [
  null,
  "Freigeben"
 ],
 "unmount": [
  null,
  "Aushängen"
 ],
 "user": [
  null,
  "Benutzer"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "Benutzername"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "version": [
  null,
  "Version"
 ],
 "vlan": [
  null,
  "VLan"
 ],
 "volume": [
  null,
  "Laufwerk"
 ],
 "warning": [
  null,
  "Warnung"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "Zone"
 ]
});
