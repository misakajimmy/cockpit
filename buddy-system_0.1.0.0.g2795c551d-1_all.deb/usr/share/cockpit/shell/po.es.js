cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "Documentación de $0"
 ],
 "$0 key changed": [
  null,
  "$0 clave cambiada"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "No se ha instalado una versión compatible de Cockpit en $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Se creará una nueva clave SSH en $0 para $1 en $2 y se añadirá al fichero $3 de $4 en $5."
 ],
 "About Web Console": [
  null,
  "Acerca de la consola Web"
 ],
 "Accept key and connect": [
  null,
  "Aceptar la clave y conectar"
 ],
 "Accounts": [
  null,
  "Cuentas"
 ],
 "Active pages": [
  null,
  "Páginas activas"
 ],
 "Add": [
  null,
  "Añadir"
 ],
 "Add key": [
  null,
  "Añadir clave"
 ],
 "Add new host": [
  null,
  "Añadir un nuevo anfitrión"
 ],
 "Administrative access": [
  null,
  "Acceso administrativo"
 ],
 "Applications": [
  null,
  "Aplicaciones"
 ],
 "Apps": [
  null,
  "Aplicaciones"
 ],
 "Authenticate": [
  null,
  "Autenticar"
 ],
 "Authentication": [
  null,
  "Autenticación"
 ],
 "Authorize SSH key": [
  null,
  "Autorizar la clave SSH"
 ],
 "Automatic login": [
  null,
  "Acceso automático"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Al cambiar la contraseña de la clave SSH $0 a la contraseña de acceso de $1 en $2, dicha clave quedará disponible automáticamente y podrá acceder a $3 sin contraseña en el futuro."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Puede ser un hostname, dirección IP, alias, o URI ssh://"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cannot connect to an unknown host": [
  null,
  "No se puede conectar con un anfitrión desconocido"
 ],
 "Change password": [
  null,
  "Cambiar la contraseña"
 ],
 "Change the password of $0": [
  null,
  "Cambiar la contraseña de $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Las llaves cambiadas pueden llevar una reinstalación del sistema operativo. Sin embargo, un cambio inesperado puede indicar un intento de interceptar su conexión mediante un tercero."
 ],
 "Choose the language to be used in the application": [
  null,
  "Seleccione el idioma que se va a utilizar en la aplicación"
 ],
 "Clear search": [
  null,
  "Limpiar la búsqueda"
 ],
 "Close": [
  null,
  "Cerrar"
 ],
 "Close selected pages": [
  null,
  "Cerrar las páginas seleccionadas"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit tuvo un error interno no esperado."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit es una interfaz interactiva que permite la gestión de servidores Linux."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit no está instalado"
 ],
 "Color": [
  null,
  "Color"
 ],
 "Comment": [
  null,
  "Comentario"
 ],
 "Configuring kdump": [
  null,
  "Configurando el servicio de kdump"
 ],
 "Configuring system settings": [
  null,
  "Cambiando la configuración del sistema"
 ],
 "Confirm key password": [
  null,
  "Confirme la contraseña de la clave"
 ],
 "Confirm new key password": [
  null,
  "Confirme la nueva contraseña de la clave"
 ],
 "Confirm password": [
  null,
  "Confirmar contraseña"
 ],
 "Connecting to the machine": [
  null,
  "Conectándose a la máquina"
 ],
 "Connection error": [
  null,
  "Error de conexión"
 ],
 "Connection failed": [
  null,
  "Conexión fallida"
 ],
 "Contains:": [
  null,
  "Contenidos:"
 ],
 "Continue session": [
  null,
  "Continúe con la sesión"
 ],
 "Copied": [
  null,
  "Copiado"
 ],
 "Copy": [
  null,
  "Copiar"
 ],
 "Could not contact $0": [
  null,
  "No se pudo contactar con $0"
 ],
 "Create": [
  null,
  "Crear"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crear una llave SSH y autorizarla"
 ],
 "Ctrl-Shift-J": [
  null,
  "Ctrl-Shift-J"
 ],
 "Dark": [
  null,
  "Oscuro"
 ],
 "Default": [
  null,
  "Predeterminado"
 ],
 "Details": [
  null,
  "Detalles"
 ],
 "Development": [
  null,
  "Desarrollo"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Disconnected": [
  null,
  "Desconectado"
 ],
 "Display language": [
  null,
  "Idioma de visualización"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Edit host": [
  null,
  "Editar anfitrión"
 ],
 "Edit hosts": [
  null,
  "Editar anfitriones"
 ],
 "Failed to add machine: $0": [
  null,
  "Fallo al añadir la máquina: $0"
 ],
 "Failed to change password": [
  null,
  "Error al cambiar contraseña"
 ],
 "Failed to edit machine: $0": [
  null,
  "Fallo al editar máquina: $0"
 ],
 "Filter menu items": [
  null,
  "Filtrar elementos del menú"
 ],
 "Fingerprint": [
  null,
  "Huella dactilar"
 ],
 "Help": [
  null,
  "Ayuda"
 ],
 "Host": [
  null,
  "Anfitrión"
 ],
 "Hosts": [
  null,
  "Anfitriones"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Si la huella coincide, pulse \"Aceptar la clave y conectarse\". En caso contrario, no se conecte y contacte con su administrador."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Para permitir iniciar sesión sin contraseña a $0 en $1 en adelante, use la contraseña de inicio de sesión de $2 en $3 como la contraseña de su clave, o deje la contraseña en blanco."
 ],
 "Invalid file permissions": [
  null,
  "Permisos de archivo invalidos"
 ],
 "Is sshd running on a different port?": [
  null,
  "¿El servicio SSHD está corriendo en un puerto diferente?"
 ],
 "Kernel dump": [
  null,
  "Volcado del kernel"
 ],
 "Key password": [
  null,
  "Contraseña de la clave"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Licenciada bajo la GNU LGPL versión 2.1"
 ],
 "Light": [
  null,
  "Claro"
 ],
 "Limit access": [
  null,
  "Limitar acceso"
 ],
 "Limited access": [
  null,
  "Acceso limitado"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "El modo de acceso limitado restringe los privilegios administrativos. Algunas partes de la consola web tendrán funcionalidad reducida."
 ],
 "Loading packages...": [
  null,
  "Cargando paquetes..."
 ],
 "Log in": [
  null,
  "Iniciar sesión"
 ],
 "Log in to $0": [
  null,
  "Iniciar sesión en $0"
 ],
 "Log out": [
  null,
  "Salir"
 ],
 "Logs": [
  null,
  "Registros"
 ],
 "Managing LVMs": [
  null,
  "Gestión de LVMs"
 ],
 "Managing NFS mounts": [
  null,
  "Gestión de montajes NFS"
 ],
 "Managing RAIDs": [
  null,
  "Gestión de RAIDs"
 ],
 "Managing VDOs": [
  null,
  "Gestión de VDOs"
 ],
 "Managing VLANs": [
  null,
  "Gestión de VLANs"
 ],
 "Managing firewall": [
  null,
  "Gestión del cortafuegos"
 ],
 "Managing networking bonds": [
  null,
  "Gestión de agregaciones de enlaces de red"
 ],
 "Managing networking bridges": [
  null,
  "Gestión de puentes de red"
 ],
 "Managing networking teams": [
  null,
  "Gestión de agregaciones de interfaces de red"
 ],
 "Managing partitions": [
  null,
  "Gestión de particiones"
 ],
 "Managing physical drives": [
  null,
  "Gestión de discos físicos"
 ],
 "Managing services": [
  null,
  "Gestión de servicios"
 ],
 "Managing software updates": [
  null,
  "Gestión de actualizaciones de software"
 ],
 "Managing user accounts": [
  null,
  "Gestión de cuentas de usuario"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Los mensajes relacionados con los fallos se podrían encontrar en la bitácora:"
 ],
 "Method": [
  null,
  "Método"
 ],
 "Name": [
  null,
  "Nombre"
 ],
 "Networking": [
  null,
  "Redes"
 ],
 "New host": [
  null,
  "Añadir un nuevo anfitrión"
 ],
 "New key password": [
  null,
  "Nueva contraseña de la clave"
 ],
 "New password": [
  null,
  "Nueva contraseña"
 ],
 "New password was not accepted": [
  null,
  "No se aceptó la nueva contraseña"
 ],
 "No results found": [
  null,
  "No se encontraron resultados"
 ],
 "No such file or directory": [
  null,
  "No existe el archivo o directorio"
 ],
 "Not a valid private key": [
  null,
  "No es una clave privada válida"
 ],
 "Not connected to host": [
  null,
  "No se ha conectado al anfitrión"
 ],
 "Old password not accepted": [
  null,
  "No se aceptó la contraseña vieja"
 ],
 "Ooops!": [
  null,
  "¡Ooops!"
 ],
 "Overview": [
  null,
  "Visión global"
 ],
 "Page name": [
  null,
  "Nombre de la página"
 ],
 "Password": [
  null,
  "Contraseña"
 ],
 "Password changed successfully": [
  null,
  "Contraseña cambiada con éxito"
 ],
 "Password not accepted": [
  null,
  "Contraseña no válida"
 ],
 "Password tip": [
  null,
  "Consejo sobre la contraseña"
 ],
 "Path to file": [
  null,
  "Ruta al fichero"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentíquese para obtener acceso administrativo"
 ],
 "Port": [
  null,
  "Puerto"
 ],
 "Problem becoming administrator": [
  null,
  "Problema al cambiar a administrador"
 ],
 "Project website": [
  null,
  "Sitio Web del proyecto"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Ha expirado el tiempo de ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Se ha agotado el tiempo de espera para ssh-keygen"
 ],
 "Public key": [
  null,
  "Clave pública"
 ],
 "Reconnect": [
  null,
  "Reconectarse"
 ],
 "Remove": [
  null,
  "Eliminar"
 ],
 "Reviewing logs": [
  null,
  "Revisión de registros"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Clave SSH"
 ],
 "SSH keys": [
  null,
  "Claves SSH"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Los usuarios de Safari tienen que importar y confiar en la CA del certificado autofirmado:"
 ],
 "Search": [
  null,
  "Buscar"
 ],
 "Select": [
  null,
  "Seleccionar"
 ],
 "Services": [
  null,
  "Servicios"
 ],
 "Session": [
  null,
  "Sesión"
 ],
 "Session is about to expire": [
  null,
  "La sesión está apunto de expirar"
 ],
 "Set": [
  null,
  "Establecer"
 ],
 "Skip main navigation": [
  null,
  "Saltar navegación principal"
 ],
 "Skip to content": [
  null,
  "Saltar al contenido"
 ],
 "Software updates": [
  null,
  "Actualizaciones de software"
 ],
 "Stop editing hosts": [
  null,
  "Dejar de editar anfitriones"
 ],
 "Storage": [
  null,
  "Almacenamiento"
 ],
 "Style": [
  null,
  "Estilo"
 ],
 "Switch to administrative access": [
  null,
  "Cambiar a acceso administrativo"
 ],
 "Switch to limited access": [
  null,
  "Pasar a acceso limitado"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "La dirección IP o el nombre de dominio no pueden contener espacios en blanco."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "La clave SSH $0 de $1 en $2 será añadida al archivo $3 de $4 en $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "La clave SSH $0 estará disponible durante el resto de la sesión y también lo estará para unirse a otros anfitriones."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "La clave SSH para iniciar sesión en $0 está protegida por contraseña, y el anfitrión no permite iniciar sesión con contraseña. Por favor, introduzca la contraseña de dicha clave en $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "La clave SSH para iniciar sesión en $0 está protegida. Puedes iniciar sesión tanto con la contraseña de usuario como introduciendo la contraseña de dicha clave en $1."
 ],
 "The key password can not be empty": [
  null,
  "La contraseña de la clave no puede estar vacía"
 ],
 "The key passwords do not match": [
  null,
  "Las contraseñas de la clave no coinciden"
 ],
 "The machine is rebooting": [
  null,
  "La máquina se está reiniciando"
 ],
 "The new key password can not be empty": [
  null,
  "La nueva contraseña de la clave no puede estar vacía"
 ],
 "The password can not be empty": [
  null,
  "La contraseña no puede estar vacía"
 ],
 "The passwords do not match.": [
  null,
  "Las contraseñas no coinciden."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "La huella resultante es apta para compartirse en público, incluyendo correo electrónico."
 ],
 "There are currently no active pages": [
  null,
  "No hay actualmente páginas activas"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Hubo un error no esperado mientra se conectaba a la máquina."
 ],
 "This machine has already been added.": [
  null,
  "Esta máquina ha sido añadida."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Esto te permitirá iniciar sesión sin contraseña en el futuro."
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Consejo: Haga coincidir la contraseña de su clave y su contraseña de acceso para autenticarse de forma automática en otros sistemas."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Para garantizar que su conexión no sea interceptada por un tercero malicioso, por favor verifique la clave de huella del anfitrión:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Para verificar una huella, ejecute lo siguiente en $0 mientras se sitúa físicamente frente a la máquina o a través de una red de confianza:"
 ],
 "Toggle": [
  null,
  "Alternar"
 ],
 "Tools": [
  null,
  "Herramientas"
 ],
 "Turn on administrative access": [
  null,
  "Habilitar el acceso administrativo"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Unable to contact $0.": [
  null,
  "Incapaz de contactar con $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "No se pudo contactar con el servidor $0. Asegúrese de que el servidor está ejecutando el servicio de SSH en el puerto $1, o especifique otro puerto en la dirección facilitada."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "No se pudo iniciar sesión en $0 usando autenticación por clave SSH. Por favor, introduzca la contraseña. Quizás quiera configurar claves SSH para permitir inicios de sesión automáticos."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "No se pudo iniciar sesión en $0. El servidor no acepta inicio de sesión por contraseña ni ninguna de tus claves SSH."
 ],
 "Unexpected error": [
  null,
  "Error inesperado"
 ],
 "Unlock": [
  null,
  "Desbloquear"
 ],
 "Unlock key $0": [
  null,
  "Desbloquear clave $0"
 ],
 "Update": [
  null,
  "Actualizar"
 ],
 "Use key": [
  null,
  "Usar clave"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Se utilizan las siguientes claves para autenticarse con otros sistemas"
 ],
 "User name": [
  null,
  "Nombre de usuario"
 ],
 "Using LUKS encryption": [
  null,
  "Usar cifrado LUKS"
 ],
 "Using Tang server": [
  null,
  "Usar un servidor Tang"
 ],
 "Web Console": [
  null,
  "Consola web"
 ],
 "Web console logo": [
  null,
  "Logotipo de la consola Web"
 ],
 "When empty, connect with the current user": [
  null,
  "Si se deja vacío, se conectará usando el usuario actual"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Te estás conectando con $0 por primera vez."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Se le ha cerrado la sesión por inactividad."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Quizás quieras cambiar la contraseña de la clave para iniciar sesión automáticamente."
 ],
 "You now have administrative access.": [
  null,
  "Ahora tienes acceso administrativo."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Se cerrará la sesión en $0 segundos."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Su navegador recordará su nivel de acceso entre sesiones."
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "access": [
  null,
  "acceso"
 ],
 "active": [
  null,
  "activo"
 ],
 "add-on": [
  null,
  "complemento"
 ],
 "addon": [
  null,
  "complemento"
 ],
 "apps": [
  null,
  "aplicaciones"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "etiqueta de propiedad"
 ],
 "avc": [
  null,
  "avc"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "bond": [
  null,
  "agregación de enlaces"
 ],
 "boot": [
  null,
  "arrancar"
 ],
 "bridge": [
  null,
  "puente"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "comando"
 ],
 "console": [
  null,
  "consola"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "crash": [
  null,
  "colapso"
 ],
 "date": [
  null,
  "fecha"
 ],
 "debug": [
  null,
  "depurar"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "desactivar"
 ],
 "disk": [
  null,
  "disco"
 ],
 "disks": [
  null,
  "discos"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "domain": [
  null,
  "dominio"
 ],
 "drive": [
  null,
  "disco"
 ],
 "enable": [
  null,
  "activar"
 ],
 "encryption": [
  null,
  "cifrado"
 ],
 "error": [
  null,
  "error"
 ],
 "extension": [
  null,
  "extensión"
 ],
 "filesystem": [
  null,
  "sistema de archivos"
 ],
 "firewall": [
  null,
  "cortafuegos"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "format": [
  null,
  "formato"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "graphs": [
  null,
  "gráficos"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "history": [
  null,
  "histórico"
 ],
 "host": [
  null,
  "anfitrión"
 ],
 "in most browsers": [
  null,
  "en la mayoría de los navegadores"
 ],
 "install": [
  null,
  "instalar"
 ],
 "interface": [
  null,
  "interfaz"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "journal": [
  null,
  "journal"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "teclas"
 ],
 "login": [
  null,
  "login"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mac": [
  null,
  "mac"
 ],
 "machine": [
  null,
  "máquina"
 ],
 "mask": [
  null,
  "máscara"
 ],
 "memory": [
  null,
  "memoria"
 ],
 "metrics": [
  null,
  "métricas"
 ],
 "mitigation": [
  null,
  "migitación"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "mount"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "network": [
  null,
  "red"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "operating system": [
  null,
  "sistema operativo"
 ],
 "os": [
  null,
  "so"
 ],
 "package": [
  null,
  "paquete"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "partition": [
  null,
  "partición"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "contraseña"
 ],
 "path": [
  null,
  "ruta"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "rendimiento"
 ],
 "plugin": [
  null,
  "plugin"
 ],
 "port": [
  null,
  "puerto"
 ],
 "power": [
  null,
  "corriente"
 ],
 "raid": [
  null,
  "raid"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "reiniciar"
 ],
 "roles": [
  null,
  "roles"
 ],
 "security": [
  null,
  "seguridad"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  "serie"
 ],
 "service": [
  null,
  "servicio"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ],
 "shell": [
  null,
  "shell"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar más"
 ],
 "shut": [
  null,
  "cerrar"
 ],
 "socket": [
  null,
  "socket"
 ],
 "sos": [
  null,
  "sos"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "tang"
 ],
 "target": [
  null,
  "target"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "equipo"
 ],
 "time": [
  null,
  "hora"
 ],
 "timer": [
  null,
  "temporizador"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  "unit"
 ],
 "unmask": [
  null,
  "desenmascarar"
 ],
 "unmount": [
  null,
  "desmontar"
 ],
 "user": [
  null,
  "usuario"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "nombre de usuario"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "version": [
  null,
  "versión"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "volume": [
  null,
  "volumen"
 ],
 "warning": [
  null,
  "aviso"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "zona"
 ]
});
