cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "$0 documentatie"
 ],
 "$0 key changed": [
  null,
  "$0 sleutel gewijzigd"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Er is geen compatibele versie van Cockpit geïnstalleerd op $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Een nieuwe SSH-sleutel op $0 wordt gemaakt voor $1 op $2 en deze wordt toegevoegd aan het $3-bestand van $4 op $5."
 ],
 "About Web Console": [
  null,
  "Over Web Console"
 ],
 "Accept key and connect": [
  null,
  "Accepteer sleutel en maak verbinding"
 ],
 "Accounts": [
  null,
  "Accounts"
 ],
 "Active pages": [
  null,
  "Actieve pagina's"
 ],
 "Add": [
  null,
  "Toevoegen"
 ],
 "Add key": [
  null,
  "Sleutel toevoegen"
 ],
 "Add new host": [
  null,
  "Nieuwe host toevoegen"
 ],
 "Administrative access": [
  null,
  "Administratieve toegang"
 ],
 "Applications": [
  null,
  "Toepassingen"
 ],
 "Apps": [
  null,
  "Apps"
 ],
 "Authenticate": [
  null,
  "Authenticatie uitvoeren"
 ],
 "Authentication": [
  null,
  "Authenticatie"
 ],
 "Authorize SSH key": [
  null,
  "Autoriseer SSH-sleutel"
 ],
 "Automatic login": [
  null,
  "Automatisch inloggen"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Door het wachtwoord van de SSH-sleutel $0 te wijzigen in het inlogwachtwoord van $1 op $2, wordt de sleutel automatisch beschikbaar gemaakt en kun je in de toekomst zonder wachtwoord inloggen op $3."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Kan een hostnaam, IP-adres, aliasnaam, of ssh:// URI zijn"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Kan niet verbinden met een onbekende host"
 ],
 "Change password": [
  null,
  "Verander wachtwoord"
 ],
 "Change the password of $0": [
  null,
  "Verander het wachtwoord van $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Gewijzigde sleutels zijn vaak het resultaat van een herinstallatie van het besturingssysteem. Een onverwachte wijziging kan echter wijzen op een poging van derden om je verbinding te onderscheppen."
 ],
 "Choose the language to be used in the application": [
  null,
  "Kies de taal die in de toepassing moet worden gebruikt"
 ],
 "Clear search": [
  null,
  "Wis zoekopdrachten"
 ],
 "Close": [
  null,
  "Sluiten"
 ],
 "Close selected pages": [
  null,
  "Sluit geselecteerde pagina's"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit had een onverwachte interne fout."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit is een interactieve Linux-serverbeheerinterface."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit is niet geïnstalleerd"
 ],
 "Color": [
  null,
  "Kleur"
 ],
 "Comment": [
  null,
  "Commentaar"
 ],
 "Configuring kdump": [
  null,
  "kdump configureren"
 ],
 "Configuring system settings": [
  null,
  "Systeeminstellingen configureren"
 ],
 "Confirm key password": [
  null,
  "Bevestig sleutelwachtwoord"
 ],
 "Confirm new key password": [
  null,
  "Bevestig nieuw sleutelwachtwoord"
 ],
 "Confirm password": [
  null,
  "Bevestigen wachtwoord"
 ],
 "Connecting to the machine": [
  null,
  "Verbinding maken met de machine"
 ],
 "Connection error": [
  null,
  "Verbindingsfout"
 ],
 "Connection failed": [
  null,
  "Verbinding mislukte"
 ],
 "Contains:": [
  null,
  "Bevat:"
 ],
 "Continue session": [
  null,
  "Vervolg sessie"
 ],
 "Copied": [
  null,
  "Gekopieerd"
 ],
 "Copy": [
  null,
  "Kopiëren"
 ],
 "Could not contact $0": [
  null,
  "Kon geen contact opnemen met $0"
 ],
 "Create": [
  null,
  "Aanmaken"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Maak een nieuwe SSH-sleutel en autoriseer deze"
 ],
 "Ctrl-Shift-J": [
  null,
  "Ctrl-Shift-J"
 ],
 "Dark": [
  null,
  "Donker"
 ],
 "Default": [
  null,
  "Standaard"
 ],
 "Details": [
  null,
  "Details"
 ],
 "Development": [
  null,
  "Ontwikkeling"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Disconnected": [
  null,
  "Verbinding verbroken"
 ],
 "Display language": [
  null,
  "Schermtaal"
 ],
 "Edit": [
  null,
  "Bewerken"
 ],
 "Edit host": [
  null,
  "Bewerk host"
 ],
 "Edit hosts": [
  null,
  "Bewerk hosts"
 ],
 "Failed to add machine: $0": [
  null,
  "Kan machine niet toevoegen: $0"
 ],
 "Failed to change password": [
  null,
  "Kan wachtwoord niet veranderen"
 ],
 "Failed to edit machine: $0": [
  null,
  "Kan machine niet bewerken: $0"
 ],
 "Filter menu items": [
  null,
  "Filtermenu items"
 ],
 "Fingerprint": [
  null,
  "Vingerafdruk"
 ],
 "Help": [
  null,
  "Hulp"
 ],
 "Host": [
  null,
  "Host"
 ],
 "Hosts": [
  null,
  "Hosts"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Als de vingerafdruk overeenkomt, klik dan op 'Accepteer sleutel en verbind'. Verbind anders niet en neem contact op met je beheerder."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Om in de toekomst inloggen op $0 als $1 zonder wachtwoord toe te staan, gebruik je het inlogwachtwoord van $2 op $3 als het sleutelwachtwoord, of laat je het sleutelwachtwoord leeg."
 ],
 "Invalid file permissions": [
  null,
  "Ongeldige bestandsrechten"
 ],
 "Is sshd running on a different port?": [
  null,
  "Werkt sshd op een andere poort?"
 ],
 "Kernel dump": [
  null,
  "Kerneldump"
 ],
 "Key password": [
  null,
  "Sleutelwachtwoord"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Licentie onder GNU LGPL versie 2.1"
 ],
 "Light": [
  null,
  "Licht"
 ],
 "Limit access": [
  null,
  "Beperk toegang"
 ],
 "Limited access": [
  null,
  "Beperkte toegang"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "De beperkte toegangsmodus beperkt de beheerdersrechten. Sommige delen van de webconsole hebben een verminderde functionaliteit."
 ],
 "Loading packages...": [
  null,
  "Pakketten laden..."
 ],
 "Log in": [
  null,
  "Inloggen"
 ],
 "Log in to $0": [
  null,
  "Log in op $0"
 ],
 "Log out": [
  null,
  "Uitloggen"
 ],
 "Logs": [
  null,
  "Logboeken"
 ],
 "Managing LVMs": [
  null,
  "LVM's beheren"
 ],
 "Managing NFS mounts": [
  null,
  "NFS-aankoppelingen beheren"
 ],
 "Managing RAIDs": [
  null,
  "RAID's beheren"
 ],
 "Managing VDOs": [
  null,
  "VDO's beheren"
 ],
 "Managing VLANs": [
  null,
  "VLAN's beheren"
 ],
 "Managing firewall": [
  null,
  "Firewall beheren"
 ],
 "Managing networking bonds": [
  null,
  "Netwerkbindingen beheren"
 ],
 "Managing networking bridges": [
  null,
  "Netwerkbruggen beheren"
 ],
 "Managing networking teams": [
  null,
  "Netwerkteams beheren"
 ],
 "Managing partitions": [
  null,
  "Partities beheren"
 ],
 "Managing physical drives": [
  null,
  "Fysieke schijven beheren"
 ],
 "Managing services": [
  null,
  "Services beheren"
 ],
 "Managing software updates": [
  null,
  "Software-updates beheren"
 ],
 "Managing user accounts": [
  null,
  "Gebruikersaccounts beheren"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Berichten met betrekking tot de fout zijn mogelijk te vinden in het journaal:"
 ],
 "Method": [
  null,
  "Methode"
 ],
 "Name": [
  null,
  "Naam"
 ],
 "Networking": [
  null,
  "Netwerken"
 ],
 "New host": [
  null,
  "Nieuwe host"
 ],
 "New key password": [
  null,
  "Nieuw sleutelwachtwoord"
 ],
 "New password": [
  null,
  "Nieuw wachtwoord"
 ],
 "New password was not accepted": [
  null,
  "Nieuw wachtwoord is niet geaccepteerd"
 ],
 "No results found": [
  null,
  "Geen resultaten gevonden"
 ],
 "No such file or directory": [
  null,
  "Bestand of map bestaat niet"
 ],
 "Not a valid private key": [
  null,
  "Geen geldige privésleutel"
 ],
 "Not connected to host": [
  null,
  "Niet verbonden met host"
 ],
 "Old password not accepted": [
  null,
  "Oude wachtwoord niet geaccepteerd"
 ],
 "Ooops!": [
  null,
  "Ooops!"
 ],
 "Overview": [
  null,
  "Overzicht"
 ],
 "Page name": [
  null,
  "Paginanaam"
 ],
 "Password": [
  null,
  "Wachtwoord"
 ],
 "Password changed successfully": [
  null,
  "Wachtwoord succesvol gewijzigd"
 ],
 "Password not accepted": [
  null,
  "Wachtwoord wordt niet geaccepteerd"
 ],
 "Password tip": [
  null,
  "Wachtwoord tip"
 ],
 "Path to file": [
  null,
  "Pad naar bestand"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Authenticeer om administratieve toegang te krijgen"
 ],
 "Port": [
  null,
  "Poort"
 ],
 "Problem becoming administrator": [
  null,
  "Probleem om beheerder te worden"
 ],
 "Project website": [
  null,
  "Project website"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Vragen via ssh-add is verlopen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Vragen ssh-keygen is verlopen"
 ],
 "Public key": [
  null,
  "Publieke sleutel"
 ],
 "Reconnect": [
  null,
  "Opnieuw aansluiten"
 ],
 "Remove": [
  null,
  "Verwijderen"
 ],
 "Reviewing logs": [
  null,
  "Logboeken bekijken"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-sleutel"
 ],
 "SSH keys": [
  null,
  "SSH-sleutels"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safari-gebruikers moeten het certificaat van de zelfondertekende CA importeren en vertrouwen:"
 ],
 "Search": [
  null,
  "Zoeken"
 ],
 "Select": [
  null,
  "Selecteren"
 ],
 "Services": [
  null,
  "Services"
 ],
 "Session": [
  null,
  "Sessie"
 ],
 "Session is about to expire": [
  null,
  "Sessie verloopt binnenkort"
 ],
 "Set": [
  null,
  "Instellen"
 ],
 "Skip main navigation": [
  null,
  "Sla de hoofdnavigatie over"
 ],
 "Skip to content": [
  null,
  "Doorgaan naar inhoud"
 ],
 "Software updates": [
  null,
  "Software updates"
 ],
 "Stop editing hosts": [
  null,
  "Stop met het bewerken van hosts"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Style": [
  null,
  "Stijl"
 ],
 "Switch to administrative access": [
  null,
  "Schakel om naar beheerderstoegang"
 ],
 "Switch to limited access": [
  null,
  "Schakel over naar beperkte toegang"
 ],
 "System": [
  null,
  "Systeem"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "Het IP-adres of hostnaam mag geen spaties bevatten."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "De SSH-sleutel $0 van $1 op $2 zal worden toegevoegd aan het $3 bestand van $4 op $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "De SSH-sleutel $0 zal beschikbaar worden gesteld voor de rest van de sessie en zal ook beschikbaar zijn om in te loggen bij andere hosts."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "De SSH-sleutel voor inloggen op $0 is beschermd met een wachtwoord en de host staat inloggen met een wachtwoord niet toe. Geef het wachtwoord van de sleutel op $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "De SSH-sleutel voor inloggen op $0 is beschermd. Je kunt inloggen met je inlogwachtwoord of door het wachtwoord van de sleutel op te geven op $1."
 ],
 "The key password can not be empty": [
  null,
  "Het sleutelwachtwoord mag niet leeg zijn"
 ],
 "The key passwords do not match": [
  null,
  "De sleutelwachtwoorden komen niet overeen"
 ],
 "The machine is rebooting": [
  null,
  "De machine wordt opnieuw opgestart"
 ],
 "The new key password can not be empty": [
  null,
  "Het nieuwe sleutelwachtwoord mag niet leeg zijn"
 ],
 "The password can not be empty": [
  null,
  "Het wachtwoord mag niet leeg zijn"
 ],
 "The passwords do not match.": [
  null,
  "De wachtwoorden komen niet overeen."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "De resulterende vingerafdruk is prima te delen via openbare methoden, inclusief e-mail."
 ],
 "There are currently no active pages": [
  null,
  "Er zijn momenteel geen actieve pagina's"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Er is een onverwachte fout opgetreden tijdens het verbinden met de machine."
 ],
 "This machine has already been added.": [
  null,
  "Deze machine is al toegevoegd."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Hiermee kun je in de toekomst zonder wachtwoord inloggen."
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Tip: zorg ervoor dat je sleutelwachtwoord overeenkomt met je inlogwachtwoord om automatisch te verifiëren bij andere systemen."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Controleer de vingerafdruk van de hostsleutel om ervoor te zorgen dat je verbinding niet wordt onderschept door een kwaadwillende derde partij:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Om een vingerafdruk te verifiëren, voer je het volgende uit op $0 terwijl je fysiek achter de machine zit of via een vertrouwd netwerk:"
 ],
 "Toggle": [
  null,
  "Wissel"
 ],
 "Tools": [
  null,
  "Gereedschappen"
 ],
 "Turn on administrative access": [
  null,
  "Schakel beheerderstoegang in"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Unable to contact $0.": [
  null,
  "Niet mogelijk $0 te contacteren."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Kan geen contact opnemen met opgegeven host $0. Zorg ervoor dat ssh wordt uitgevoerd op poort $1 of specificeer een andere poort in het adres."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Kan niet inloggen op $0 met SSH-sleutelverificatie. Geef het wachtwoord op. Mogelijk wil je jouw SSH-sleutels instellen voor automatisch inloggen."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Kan niet inloggen op $0. De host accepteert geen aanmelden met wachtwoord of een van je SSH-sleutels."
 ],
 "Unexpected error": [
  null,
  "Onverwachte fout"
 ],
 "Unlock": [
  null,
  "Ontgrendelen"
 ],
 "Unlock key $0": [
  null,
  "Ontgrendel sleutel $0"
 ],
 "Update": [
  null,
  "Bijwerken"
 ],
 "Use key": [
  null,
  "Gebruik sleutel"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Gebruik de volgende sleutels om te verifiëren bij andere systemen"
 ],
 "User name": [
  null,
  "Gebruikersnaam"
 ],
 "Using LUKS encryption": [
  null,
  "Gebruikt LUKS-versleuteling"
 ],
 "Using Tang server": [
  null,
  "Gebruikt Tang-server"
 ],
 "Web Console": [
  null,
  "Webconsole"
 ],
 "Web console logo": [
  null,
  "Logo van webconsole"
 ],
 "When empty, connect with the current user": [
  null,
  "Maak verbinding met de huidige gebruiker als deze leeg is"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Je maakt voor de eerste keer verbinding met $0."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Je bent uitgelogd vanwege inactiviteit."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Mogelijk wil je het wachtwoord van de sleutel wijzigen om automatisch in te loggen."
 ],
 "You now have administrative access.": [
  null,
  "Je hebt nu administratieve toegang."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Je wordt over $0 seconden uitgelogd."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Je browser onthoudt je toegangsniveau tijdens sessies."
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "access": [
  null,
  "toegang"
 ],
 "active": [
  null,
  "actief"
 ],
 "add-on": [
  null,
  "toevoeging"
 ],
 "addon": [
  null,
  "toevoeging"
 ],
 "apps": [
  null,
  "apps"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "asset-tag"
 ],
 "avc": [
  null,
  "avc"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "bond": [
  null,
  "binding"
 ],
 "boot": [
  null,
  "opstart"
 ],
 "bridge": [
  null,
  "brug"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "commando"
 ],
 "console": [
  null,
  "console"
 ],
 "coredump": [
  null,
  "core dump"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "crash": [
  null,
  "crash"
 ],
 "date": [
  null,
  "datum"
 ],
 "debug": [
  null,
  "debug"
 ],
 "dimm": [
  null,
  "dim"
 ],
 "disable": [
  null,
  "uitschakelen"
 ],
 "disk": [
  null,
  "schijf"
 ],
 "disks": [
  null,
  "schijven"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "domain": [
  null,
  "domein"
 ],
 "drive": [
  null,
  "station"
 ],
 "enable": [
  null,
  "inschakelen"
 ],
 "encryption": [
  null,
  "versleuteling"
 ],
 "error": [
  null,
  "fout"
 ],
 "extension": [
  null,
  "extensie"
 ],
 "filesystem": [
  null,
  "bestandssysteem"
 ],
 "firewall": [
  null,
  "firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "format": [
  null,
  "formatteren"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "graphs": [
  null,
  "grafieken"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "history": [
  null,
  "geschiedenis"
 ],
 "host": [
  null,
  "host"
 ],
 "in most browsers": [
  null,
  "in de meeste browsers"
 ],
 "install": [
  null,
  "installeren"
 ],
 "interface": [
  null,
  "interface"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "journal": [
  null,
  "logboek"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "sleutels"
 ],
 "login": [
  null,
  "inloggen"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mac": [
  null,
  "mac"
 ],
 "machine": [
  null,
  "machine"
 ],
 "mask": [
  null,
  "masker"
 ],
 "memory": [
  null,
  "geheugen"
 ],
 "metrics": [
  null,
  "metriek"
 ],
 "mitigation": [
  null,
  "matiging"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "aankoppelen"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "network": [
  null,
  "netwerk"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "operating system": [
  null,
  "besturingssysteem"
 ],
 "os": [
  null,
  "os"
 ],
 "package": [
  null,
  "pakket"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "partition": [
  null,
  "partitie"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "wachtwoord"
 ],
 "path": [
  null,
  "pad"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "performance"
 ],
 "plugin": [
  null,
  "plug-in"
 ],
 "port": [
  null,
  "poort"
 ],
 "power": [
  null,
  "vermogen"
 ],
 "raid": [
  null,
  "raid"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "herstarten"
 ],
 "roles": [
  null,
  "rollen"
 ],
 "security": [
  null,
  "veiligheid"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  "serieel"
 ],
 "service": [
  null,
  "service"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ],
 "shell": [
  null,
  "shell"
 ],
 "show less": [
  null,
  "toon minder"
 ],
 "show more": [
  null,
  "toon meer"
 ],
 "shut": [
  null,
  "afsluiten"
 ],
 "socket": [
  null,
  "socket"
 ],
 "sos": [
  null,
  "sos"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "tang"
 ],
 "target": [
  null,
  "doel"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "team"
 ],
 "time": [
  null,
  "tijd"
 ],
 "timer": [
  null,
  "timer"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  "unit"
 ],
 "unmask": [
  null,
  "ontmaskeren"
 ],
 "unmount": [
  null,
  "afkoppelen"
 ],
 "user": [
  null,
  "gebruiker"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "gebruikersnaam"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "version": [
  null,
  "versie"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "volume": [
  null,
  "volume"
 ],
 "warning": [
  null,
  "waarschuwing"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "zone"
 ]
});
