cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "dokumentacja $0"
 ],
 "$0 key changed": [
  null,
  "Zmieniono klucz $0"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 nie zainstalowano zgodnej wersji Cockpit."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Nowy klucz SSH w $0 zostanie utworzony dla użytkownika $1 na komputerze $2 i zostanie dodany do pliku $3 użytkownika $4 na komputerze $5."
 ],
 "About Web Console": [
  null,
  "O programie"
 ],
 "Accept key and connect": [
  null,
  "Przyjmij klucz i połącz się"
 ],
 "Accounts": [
  null,
  "Konta"
 ],
 "Active pages": [
  null,
  "Aktywne strony"
 ],
 "Add": [
  null,
  "Dodaj"
 ],
 "Add key": [
  null,
  "Dodaj klucz"
 ],
 "Add new host": [
  null,
  "Dodaj nowy komputer"
 ],
 "Administrative access": [
  null,
  "Dostęp administracyjny"
 ],
 "Applications": [
  null,
  "Aplikacje"
 ],
 "Apps": [
  null,
  "Aplikacje"
 ],
 "Authenticate": [
  null,
  "Uwierzytelnij"
 ],
 "Authentication": [
  null,
  "Uwierzytelnienie"
 ],
 "Authorize SSH key": [
  null,
  "Upoważnij klucz SSH"
 ],
 "Automatic login": [
  null,
  "Automatyczne logowanie"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Zmieniając hasło klucza SSH $0 na hasło logowania użytkownika $1 na komputerze $2, klucz automatycznie stanie się dostępny i w przyszłości będzie można logować się na komputerze $3 bez hasła."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Może być nazwą komputera, adresem IP, nazwą aliasu lub adresem URI typu ssh://"
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Nie można połączyć się z nieznanym komputerem"
 ],
 "Change password": [
  null,
  "Zmień hasło"
 ],
 "Change the password of $0": [
  null,
  "Zmień hasło klucza $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmienione klucze są często wynikiem przeinstalowania systemu operacyjnego. Nieoczekiwana zmiana może jednak wskazywać na próbę przechwycenia połączenia przez stronę trzecią."
 ],
 "Choose the language to be used in the application": [
  null,
  "Proszę wybrać język używany w aplikacji"
 ],
 "Clear search": [
  null,
  "Wyczyść wyszukiwanie"
 ],
 "Close": [
  null,
  "Zamknij"
 ],
 "Close selected pages": [
  null,
  "Zamknij zaznaczone strony"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Wystąpił nieoczekiwany wewnętrzny błąd w programie Cockpit."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit to interaktywny interfejs do administrowania serwerami Linux."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit nie jest zainstalowany"
 ],
 "Color": [
  null,
  "Kolor"
 ],
 "Comment": [
  null,
  "Komentarz"
 ],
 "Configuring kdump": [
  null,
  "Konfigurowanie kdump"
 ],
 "Configuring system settings": [
  null,
  "Konfigurowanie ustawień systemu"
 ],
 "Confirm key password": [
  null,
  "Potwierdź hasło klucza"
 ],
 "Confirm new key password": [
  null,
  "Potwierdź nowe hasło klucza"
 ],
 "Confirm password": [
  null,
  "Potwierdź hasło"
 ],
 "Connecting to the machine": [
  null,
  "Łączenie z komputerem"
 ],
 "Connection error": [
  null,
  "Błąd połączenia"
 ],
 "Connection failed": [
  null,
  "Połączenie się nie powiodło"
 ],
 "Contains:": [
  null,
  "Zawiera:"
 ],
 "Continue session": [
  null,
  "Kontynuuj sesję"
 ],
 "Copied": [
  null,
  "Skopiowano"
 ],
 "Copy": [
  null,
  "Skopiuj"
 ],
 "Could not contact $0": [
  null,
  "Nie można skontaktować się z $0"
 ],
 "Create": [
  null,
  "Utwórz"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Utwórz nowy klucz SSH i go upoważnij"
 ],
 "Ctrl-Shift-J": [
  null,
  "Ctrl-Shift-J"
 ],
 "Dark": [
  null,
  "Ciemny"
 ],
 "Default": [
  null,
  "Domyślne"
 ],
 "Details": [
  null,
  "Szczegóły"
 ],
 "Development": [
  null,
  "Rozwój"
 ],
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Disconnected": [
  null,
  "Rozłączono"
 ],
 "Display language": [
  null,
  "Język"
 ],
 "Edit": [
  null,
  "Modyfikuj"
 ],
 "Edit host": [
  null,
  "Modyfikuj komputer"
 ],
 "Edit hosts": [
  null,
  "Modyfikuj komputery"
 ],
 "Failed to add machine: $0": [
  null,
  "Dodanie komputera się nie powiodło: $0"
 ],
 "Failed to change password": [
  null,
  "Zmiana hasła się nie powiodła"
 ],
 "Failed to edit machine: $0": [
  null,
  "Modyfikacja komputera się nie powiodła: $0"
 ],
 "Filter menu items": [
  null,
  "Filtruj elementy menu"
 ],
 "Fingerprint": [
  null,
  "Odcisk"
 ],
 "Help": [
  null,
  "Pomoc"
 ],
 "Host": [
  null,
  "Gospodarz"
 ],
 "Hosts": [
  null,
  "Komputery"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Jeśli odcisk się zgadza, należy kliknąć „Przyjmij klucz i połącz się”. W przeciwnym przypadku nie należy się łączyć i należy skontaktować się z administratorem."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Aby umożliwić w przyszłości logowanie na komputerze $0 jako użytkownik $1 bez hasła, należy użyć hasła logowania użytkownika $2 na komputerze $3 jako hasło klucza lub pozostawić hasło klucza puste."
 ],
 "Invalid file permissions": [
  null,
  "Nieprawidłowe uprawnienia pliku"
 ],
 "Is sshd running on a different port?": [
  null,
  "Czy sshd jest uruchomione na innym porcie?"
 ],
 "Kernel dump": [
  null,
  "Zrzut jądra"
 ],
 "Key password": [
  null,
  "Hasło klucza"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Na warunkach licencji GNU LGPL w wersji 2.1"
 ],
 "Light": [
  null,
  "Jasny"
 ],
 "Limit access": [
  null,
  "Ogranicz dostęp"
 ],
 "Limited access": [
  null,
  "Ograniczony dostęp"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Tryb ograniczonego dostępu ogranicza uprawnienia administracyjne. Część konsoli internetowej będzie miała zmniejszoną funkcjonalność."
 ],
 "Loading packages...": [
  null,
  "Wczytywanie pakietów…"
 ],
 "Log in": [
  null,
  "Zaloguj"
 ],
 "Log in to $0": [
  null,
  "Zaloguj się na $0"
 ],
 "Log out": [
  null,
  "Wyloguj"
 ],
 "Logs": [
  null,
  "Dzienniki"
 ],
 "Managing LVMs": [
  null,
  "Zarządzanie LVM"
 ],
 "Managing NFS mounts": [
  null,
  "Zarządzanie punktami montowania NFS"
 ],
 "Managing RAIDs": [
  null,
  "Zarządzanie RAID"
 ],
 "Managing VDOs": [
  null,
  "Zarządzanie VDO"
 ],
 "Managing VLANs": [
  null,
  "Zarządzanie VLAN"
 ],
 "Managing firewall": [
  null,
  "Zarządzanie zaporą sieciową"
 ],
 "Managing networking bonds": [
  null,
  "Zarządzanie wiązaniami sieciowymi"
 ],
 "Managing networking bridges": [
  null,
  "Zarządzanie mostkami sieciowymi"
 ],
 "Managing networking teams": [
  null,
  "Zarządzanie zespołami sieciowymi"
 ],
 "Managing partitions": [
  null,
  "Zarządzanie partycjami"
 ],
 "Managing physical drives": [
  null,
  "Zarządzanie napędami fizycznymi"
 ],
 "Managing services": [
  null,
  "Zarządzanie usługami"
 ],
 "Managing software updates": [
  null,
  "Zarządzanie aktualizacjami oprogramowania"
 ],
 "Managing user accounts": [
  null,
  "Zarządzanie kontami użytkowników"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Być może w dzienniku znajdują się komunikaty związane z niepowodzeniem:"
 ],
 "Method": [
  null,
  "Metoda"
 ],
 "Name": [
  null,
  "Nazwa"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "New host": [
  null,
  "Nowy komputer"
 ],
 "New key password": [
  null,
  "Nowe hasło klucza"
 ],
 "New password": [
  null,
  "Nowe hasło"
 ],
 "New password was not accepted": [
  null,
  "Nie przyjęto nowego hasła"
 ],
 "No results found": [
  null,
  "Brak wyników"
 ],
 "No such file or directory": [
  null,
  "Nie ma takiego pliku lub katalogu"
 ],
 "Not a valid private key": [
  null,
  "Nieprawidłowy klucz prywatny"
 ],
 "Not connected to host": [
  null,
  "Nie połączono z komputerem"
 ],
 "Old password not accepted": [
  null,
  "Nie przyjęto poprzedniego hasła"
 ],
 "Ooops!": [
  null,
  "Ups!"
 ],
 "Overview": [
  null,
  "Przegląd"
 ],
 "Page name": [
  null,
  "Nazwa strony"
 ],
 "Password": [
  null,
  "Hasło"
 ],
 "Password changed successfully": [
  null,
  "Pomyślnie zmieniono hasło"
 ],
 "Password not accepted": [
  null,
  "Nie przyjęto hasła"
 ],
 "Password tip": [
  null,
  "Wskazówka na temat hasła"
 ],
 "Path to file": [
  null,
  "Ścieżka do pliku"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Proszę się uwierzytelnić, aby uzyskać dostęp administracyjny"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Problem becoming administrator": [
  null,
  "Problem podczas zostawania administratorem"
 ],
 "Project website": [
  null,
  "Strona projektu"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Pytanie przez ssh-add przekroczyło czas oczekiwania"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Pytanie przez ssh-keygen przekroczyło czas oczekiwania"
 ],
 "Public key": [
  null,
  "Klucz publiczny"
 ],
 "Reconnect": [
  null,
  "Połącz ponownie"
 ],
 "Remove": [
  null,
  "Usuń"
 ],
 "Reviewing logs": [
  null,
  "Przeglądanie dzienników"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Klucz SSH"
 ],
 "SSH keys": [
  null,
  "Klucze SSH"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Użytkownicy przeglądarki Safari muszą zaimportować certyfikat samopodpisującego CA i oznaczyć go jako zaufany:"
 ],
 "Search": [
  null,
  "Szukaj"
 ],
 "Select": [
  null,
  "Wybierz"
 ],
 "Services": [
  null,
  "Usługi"
 ],
 "Session": [
  null,
  "Sesja"
 ],
 "Session is about to expire": [
  null,
  "Sesja zaraz wygaśnie"
 ],
 "Set": [
  null,
  "Ustaw"
 ],
 "Skip main navigation": [
  null,
  "Pomiń główną nawigację"
 ],
 "Skip to content": [
  null,
  "Przejdź do treści"
 ],
 "Software updates": [
  null,
  "Aktualizacje oprogramowania"
 ],
 "Stop editing hosts": [
  null,
  "Zatrzymaj modyfikowanie komputerów"
 ],
 "Storage": [
  null,
  "Przechowywanie danych"
 ],
 "Style": [
  null,
  "Styl"
 ],
 "Switch to administrative access": [
  null,
  "Przełącz na dostęp administracyjny"
 ],
 "Switch to limited access": [
  null,
  "Przełącz na ograniczony dostęp"
 ],
 "System": [
  null,
  "System"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "Adres IP lub nazwa komputera nie może zawierać spacji."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "Klucz SSH $0 użytkownika $1 na komputerze $2 zostanie dodany do pliku $3 użytkownika $4 na komputerze $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "Klucz SSH $0 stanie się dostępny przez pozostały czas sesji i będzie dostępny do logowania także na innych komputerach."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "Klucz SSH do logowania w $0 jest chroniony hasłem, ale komputer nie zezwala na logowanie za pomocą hasła. Proszę podać hasło klucza w $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "Klucz SSH do logowania w $0 jest chroniony. Można zalogować się za pomocą hasła logowania lub podając hasło klucza w $1."
 ],
 "The key password can not be empty": [
  null,
  "Hasło klucza nie może być puste"
 ],
 "The key passwords do not match": [
  null,
  "Hasła klucza się nie zgadzają"
 ],
 "The machine is rebooting": [
  null,
  "Komputer jest ponownie uruchamiany"
 ],
 "The new key password can not be empty": [
  null,
  "Nowe hasło klucza nie może być puste"
 ],
 "The password can not be empty": [
  null,
  "Hasło nie może być puste"
 ],
 "The passwords do not match.": [
  null,
  "Hasła się nie zgadzają."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Powstały odcisk można udostępniać publicznie, na przykład przez e-mail."
 ],
 "There are currently no active pages": [
  null,
  "Obecnie nie ma aktywnych stron"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Wystąpił nieoczekiwany błąd podczas łączenia z maszyną."
 ],
 "This machine has already been added.": [
  null,
  "Ten komputer został już dodany."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Umożliwi to logowanie bez hasła w przyszłości."
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Wskazówka: ustawienie hasła klucza na takie samo, jak hasło logowania automatycznie uwierzytelni w innych systemach."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby upewnić się, że połączenie nie jest przechwytywane przez szkodliwą stronę trzecią, proszę sprawdzić poprawność odcisku klucza komputera:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Aby sprawdzić poprawność odcisku klucza, należy wykonać poniższe polecenie na $0 fizycznie siedząc przy komputerze lub przez zaufaną sieć:"
 ],
 "Toggle": [
  null,
  "Przełącz"
 ],
 "Tools": [
  null,
  "Narzędzia"
 ],
 "Turn on administrative access": [
  null,
  "Włącz dostęp administracyjny"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unable to contact $0.": [
  null,
  "Nie można skontaktować się z $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Nie można skontaktować się z podanym komputerem $0. Proszę się upewnić, że ma on uruchomioną usługę ssh na porcie $1 lub podać inny port w adresie."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Nie można zalogować się w $0 za pomocą uwierzytelniania kluczem SSH. Proszę podać hasło. Można później skonfigurować klucze SSH do automatycznego logowania."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Nie można zalogować się w $0. Komputer nie przyjmuje logowania hasłem ani żadnego z kluczy SSH użytkownika."
 ],
 "Unexpected error": [
  null,
  "Nieoczekiwany błąd"
 ],
 "Unlock": [
  null,
  "Odblokuj"
 ],
 "Unlock key $0": [
  null,
  "Odblokuj klucz $0"
 ],
 "Update": [
  null,
  "Zaktualizuj"
 ],
 "Use key": [
  null,
  "Użyj klucza"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Użycie poniższych kluczy do uwierzytelniania w innych systemach"
 ],
 "User name": [
  null,
  "Nazwa użytkownika"
 ],
 "Using LUKS encryption": [
  null,
  "Używanie szyfrowania LUKS"
 ],
 "Using Tang server": [
  null,
  "Używanie serwera Tang"
 ],
 "Web Console": [
  null,
  "Konsola internetowa"
 ],
 "Web console logo": [
  null,
  "Logo konsoli internetowej"
 ],
 "When empty, connect with the current user": [
  null,
  "Pozostawienie pustej spowoduje połączenie z obecnym użytkownikiem"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Łączenie z $0 po raz pierwszy."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Wylogowano z powodu nieaktywności."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Można zmienić hasło klucza do automatycznego logowania."
 ],
 "You now have administrative access.": [
  null,
  "Uzyskano dostęp administracyjny."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Wylogowanie nastąpi za $0 s."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Używana przeglądarka będzie pamiętała poziom dostępu użytkownika między sesjami."
 ],
 "abrt": [
  null,
  "ABRT"
 ],
 "access": [
  null,
  "dostęp"
 ],
 "active": [
  null,
  "aktywne"
 ],
 "add-on": [
  null,
  "dodatek"
 ],
 "addon": [
  null,
  "dodatek"
 ],
 "apps": [
  null,
  "aplikacje"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "etykieta zasobu"
 ],
 "avc": [
  null,
  "AVC"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "BIOS"
 ],
 "bond": [
  null,
  "wiązanie"
 ],
 "boot": [
  null,
  "uruchom"
 ],
 "bridge": [
  null,
  "mostek"
 ],
 "cgroups": [
  null,
  "CGroups"
 ],
 "command": [
  null,
  "polecenie"
 ],
 "console": [
  null,
  "konsola"
 ],
 "coredump": [
  null,
  "zrzut core"
 ],
 "cpu": [
  null,
  "procesor"
 ],
 "crash": [
  null,
  "awaria"
 ],
 "date": [
  null,
  "data"
 ],
 "debug": [
  null,
  "debuguj"
 ],
 "dimm": [
  null,
  "DIMM"
 ],
 "disable": [
  null,
  "wyłącz"
 ],
 "disk": [
  null,
  "dysk"
 ],
 "disks": [
  null,
  "dyski"
 ],
 "dnf": [
  null,
  "DNF"
 ],
 "domain": [
  null,
  "domena"
 ],
 "drive": [
  null,
  "napęd"
 ],
 "enable": [
  null,
  "włącz"
 ],
 "encryption": [
  null,
  "szyfrowanie"
 ],
 "error": [
  null,
  "błąd"
 ],
 "extension": [
  null,
  "rozszerzenie"
 ],
 "filesystem": [
  null,
  "system plików"
 ],
 "firewall": [
  null,
  "zapora sieciowa"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "format": [
  null,
  "format"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "graphs": [
  null,
  "wykresy"
 ],
 "hardware": [
  null,
  "sprzęt"
 ],
 "history": [
  null,
  "historia"
 ],
 "host": [
  null,
  "gospodarz"
 ],
 "in most browsers": [
  null,
  "w większości przeglądarek"
 ],
 "install": [
  null,
  "zainstaluj"
 ],
 "interface": [
  null,
  "interfejs"
 ],
 "ipv4": [
  null,
  "IPv4"
 ],
 "ipv6": [
  null,
  "IPv6"
 ],
 "iscsi": [
  null,
  "iSCSI"
 ],
 "journal": [
  null,
  "dziennik"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "klucze"
 ],
 "login": [
  null,
  "logowanie"
 ],
 "luks": [
  null,
  "LUKS"
 ],
 "lvm2": [
  null,
  "LVM2"
 ],
 "mac": [
  null,
  "MAC"
 ],
 "machine": [
  null,
  "komputer"
 ],
 "mask": [
  null,
  "maska"
 ],
 "memory": [
  null,
  "pamięć"
 ],
 "metrics": [
  null,
  "statystyki"
 ],
 "mitigation": [
  null,
  "poprawka zmniejszająca ryzyko"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "montowanie"
 ],
 "nbde": [
  null,
  "NBDE"
 ],
 "network": [
  null,
  "sieć"
 ],
 "nfs": [
  null,
  "NFS"
 ],
 "operating system": [
  null,
  "system operacyjny"
 ],
 "os": [
  null,
  "system operacyjny"
 ],
 "package": [
  null,
  "pakiet"
 ],
 "packagekit": [
  null,
  "PackageKit"
 ],
 "partition": [
  null,
  "partycja"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "hasło"
 ],
 "path": [
  null,
  "ścieżka"
 ],
 "pci": [
  null,
  "PCI"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "wydajność"
 ],
 "plugin": [
  null,
  "wtyczka"
 ],
 "port": [
  null,
  "port"
 ],
 "power": [
  null,
  "zasilanie"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "ram": [
  null,
  "RAM"
 ],
 "restart": [
  null,
  "uruchom ponownie"
 ],
 "roles": [
  null,
  "role"
 ],
 "security": [
  null,
  "bezpieczeństwo"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  "szeregowe"
 ],
 "service": [
  null,
  "usługa"
 ],
 "setroubleshoot": [
  null,
  "SETroubleshoot"
 ],
 "shell": [
  null,
  "powłoka"
 ],
 "show less": [
  null,
  "wyświetl mniej"
 ],
 "show more": [
  null,
  "wyświetl więcej"
 ],
 "shut": [
  null,
  "wyłącz"
 ],
 "socket": [
  null,
  "gniazdo"
 ],
 "sos": [
  null,
  "sos"
 ],
 "ssh": [
  null,
  "SSH"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "Tang"
 ],
 "target": [
  null,
  "cel"
 ],
 "tcp": [
  null,
  "TCP"
 ],
 "team": [
  null,
  "zespołowe"
 ],
 "time": [
  null,
  "czas"
 ],
 "timer": [
  null,
  "licznik"
 ],
 "udisks": [
  null,
  "UDisks"
 ],
 "udp": [
  null,
  "UDP"
 ],
 "unit": [
  null,
  "jednostka"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "unmount": [
  null,
  "odmontowanie"
 ],
 "user": [
  null,
  "użytkownik"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "nazwa użytkownika"
 ],
 "vdo": [
  null,
  "VDO"
 ],
 "version": [
  null,
  "wersja"
 ],
 "vlan": [
  null,
  "VLAN"
 ],
 "volume": [
  null,
  "wolumin"
 ],
 "warning": [
  null,
  "ostrzeżenie"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "strefa"
 ]
});
