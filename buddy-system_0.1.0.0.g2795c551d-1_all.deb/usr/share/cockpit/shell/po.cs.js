cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "Dokumentace k $0"
 ],
 "$0 key changed": [
  null,
  "$0 klíč změněn"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Na $0 není nainstalovaná kompatibilní verze Cockpit."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Na $0 bude vytvořen nový SSH klíč $1 na $2 a bude přidán do souboru $3 $4 na $5."
 ],
 "About Web Console": [
  null,
  "O webové konzole"
 ],
 "Accept key and connect": [
  null,
  "Přijmout klíč a připojit se"
 ],
 "Accounts": [
  null,
  "Účty"
 ],
 "Active pages": [
  null,
  "Aktivní stránky"
 ],
 "Add": [
  null,
  "Přidat"
 ],
 "Add key": [
  null,
  "Přidat klíč"
 ],
 "Add new host": [
  null,
  "Přidat nového hostitele"
 ],
 "Administrative access": [
  null,
  "Přístup na úrovni správce"
 ],
 "Applications": [
  null,
  "Aplikace"
 ],
 "Apps": [
  null,
  "Aplikace"
 ],
 "Authenticate": [
  null,
  "Ověřit se"
 ],
 "Authentication": [
  null,
  "Ověření"
 ],
 "Authorize SSH key": [
  null,
  "Pověřit SSH klíč"
 ],
 "Automatic login": [
  null,
  "Automatické přihlášení"
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Může být název stroje, IP adresa, alternativní název, nebo ssh:// URI adresa"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Nelze se připojit k neznámému hostiteli"
 ],
 "Change password": [
  null,
  "Změnit heslo"
 ],
 "Change the password of $0": [
  null,
  "Změnit heslo $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Změněné klíče jsou často výsledkem přeinstalace operačního systému. Nicméně, neočekávaná změna může značit pokus třetí strany o vložení se do vaší komunikace."
 ],
 "Choose the language to be used in the application": [
  null,
  "Vyberte jazyk aplikace"
 ],
 "Clear search": [
  null,
  "Vyčistit vyhledávání"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Close selected pages": [
  null,
  "Zavřít vybrané stránky"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "V Cockpit došlo k neočekávané vnitřní chybě."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit je interaktivní rozhraní pro správu linuxového serveru."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit není nainstalován"
 ],
 "Color": [
  null,
  "Barva"
 ],
 "Comment": [
  null,
  "Komentář"
 ],
 "Configuring kdump": [
  null,
  "Nastavuje se kdump"
 ],
 "Configuring system settings": [
  null,
  "Probíhá nastavení systému"
 ],
 "Confirm key password": [
  null,
  "Potvrdit heslo ke klíči"
 ],
 "Confirm new key password": [
  null,
  "Potvrdit nové heslo ke klíči"
 ],
 "Confirm password": [
  null,
  "Potvrzení hesla"
 ],
 "Connecting to the machine": [
  null,
  "Připojování ke stroji"
 ],
 "Connection error": [
  null,
  "Chyba připojení"
 ],
 "Connection failed": [
  null,
  "Připojení se nezdařilo"
 ],
 "Contains:": [
  null,
  "Obsahuje:"
 ],
 "Continue session": [
  null,
  "Pokračovat v relaci"
 ],
 "Copied": [
  null,
  "Zkopírováno"
 ],
 "Copy": [
  null,
  "Zkopírovat"
 ],
 "Could not contact $0": [
  null,
  "Nedaří se kontaktovat $0"
 ],
 "Create": [
  null,
  "Vytvořit"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Vytvořit nový SSH klíč a autorizovat ho"
 ],
 "Ctrl-Shift-J": [
  null,
  "Ctrl-Shift-J"
 ],
 "Dark": [
  null,
  "Tmavý"
 ],
 "Default": [
  null,
  "Výchozí"
 ],
 "Details": [
  null,
  "Podrobnosti"
 ],
 "Development": [
  null,
  "Vývoj"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Disconnected": [
  null,
  "Odpojeno"
 ],
 "Display language": [
  null,
  "Jazyk zobrazení"
 ],
 "Edit": [
  null,
  "Upravit"
 ],
 "Edit host": [
  null,
  "Upravit hostitele"
 ],
 "Edit hosts": [
  null,
  "Upravit hostitele"
 ],
 "Failed to add machine: $0": [
  null,
  "Nepodařilo se přidat stroj: $0"
 ],
 "Failed to change password": [
  null,
  "Nepodařilo se změnit heslo"
 ],
 "Failed to edit machine: $0": [
  null,
  "Nepodařilo se upravit stroj: $0"
 ],
 "Filter menu items": [
  null,
  "Filtrovat položky nabídky"
 ],
 "Fingerprint": [
  null,
  "Otisk"
 ],
 "Help": [
  null,
  "Nápověda"
 ],
 "Host": [
  null,
  "Počítač"
 ],
 "Hosts": [
  null,
  "Hostitelé"
 ],
 "Invalid file permissions": [
  null,
  "Neplatná souborová práva"
 ],
 "Is sshd running on a different port?": [
  null,
  "Není sshd spuštěný na jiném portu?"
 ],
 "Kernel dump": [
  null,
  "Výpis paměti jádra"
 ],
 "Key password": [
  null,
  "Heslo ke klíči"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Licencováno pod GNU LGPL verze 2.1"
 ],
 "Light": [
  null,
  "Světlý"
 ],
 "Limit access": [
  null,
  "Omezit přístup"
 ],
 "Limited access": [
  null,
  "Omezený přístup"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Režim omezeného přístupu omezuje oprávnění pro správu. Některé části webové konzole budou poskytovat méně funkcí."
 ],
 "Loading packages...": [
  null,
  "Načítání balíčků…"
 ],
 "Log in": [
  null,
  "Přihlásit"
 ],
 "Log out": [
  null,
  "Odhlásit"
 ],
 "Logs": [
  null,
  "Záznamy událostí"
 ],
 "Managing LVMs": [
  null,
  "Správa LVM svazků"
 ],
 "Managing NFS mounts": [
  null,
  "Správa NFS připojení"
 ],
 "Managing RAIDs": [
  null,
  "Správa RAID polí"
 ],
 "Managing VDOs": [
  null,
  "Správa VDO optimalizátorů"
 ],
 "Managing VLANs": [
  null,
  "Správa VLAN sítí"
 ],
 "Managing firewall": [
  null,
  "Správa brány firewall"
 ],
 "Managing networking bonds": [
  null,
  "Správa síťových spřažení"
 ],
 "Managing networking bridges": [
  null,
  "Správa síťových mostů"
 ],
 "Managing networking teams": [
  null,
  "Správa sdružených síťových připojení"
 ],
 "Managing partitions": [
  null,
  "Správa oddílů"
 ],
 "Managing physical drives": [
  null,
  "Správa fyzických disků"
 ],
 "Managing services": [
  null,
  "Správa služeb"
 ],
 "Managing software updates": [
  null,
  "Správa aktualizací software"
 ],
 "Managing user accounts": [
  null,
  "Správa uživatelských účtů"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Zprávy týkající se nezdaru se mohou nacházet v žurnálu:"
 ],
 "Method": [
  null,
  "Metoda"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "New host": [
  null,
  "Nový hostitel"
 ],
 "New key password": [
  null,
  "Nové heslo ke klíči"
 ],
 "New password": [
  null,
  "Nové heslo"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebylo přijato"
 ],
 "No results found": [
  null,
  "Nenalezeny žádné výsledky"
 ],
 "No such file or directory": [
  null,
  "Žádný takový soubor nebo složka"
 ],
 "Not a valid private key": [
  null,
  "Není platná soukromá část klíče"
 ],
 "Not connected to host": [
  null,
  "Nepřipojeno k hostiteli"
 ],
 "Old password not accepted": [
  null,
  "Původní heslo nebylo přijato"
 ],
 "Ooops!": [
  null,
  "Jejda!"
 ],
 "Overview": [
  null,
  "Přehled"
 ],
 "Page name": [
  null,
  "Název stránky"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Password not accepted": [
  null,
  "Heslo nebylo přijato"
 ],
 "Path to file": [
  null,
  "Popis umístění serveru"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Pro získání přístupu na úrovni správce se prosím ověřte"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Problem becoming administrator": [
  null,
  "Problém s tím, stát se správcem"
 ],
 "Project website": [
  null,
  "Webové stránky projektu"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-add překročen"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Časový limit výzvy prostřednictvím ssh-keygen překročen"
 ],
 "Public key": [
  null,
  "Veřejná část klíče"
 ],
 "Reconnect": [
  null,
  "Znovu připojit"
 ],
 "Remove": [
  null,
  "Odebrat"
 ],
 "Reviewing logs": [
  null,
  "Vyhodnocování záznamu událostí"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH klíč"
 ],
 "SSH keys": [
  null,
  "SSH klíče"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Uživatelé prohlížeče Safari budou potřebovat naimportovat si certifikát samu sebe podepisující certifikační autority a nastavit ji jako důvěryhodnou:"
 ],
 "Search": [
  null,
  "Hledat"
 ],
 "Select": [
  null,
  "Vybrat"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Session": [
  null,
  "Sezení"
 ],
 "Session is about to expire": [
  null,
  "Platnost relace brzy skončí"
 ],
 "Set": [
  null,
  "Nastavit"
 ],
 "Skip main navigation": [
  null,
  "Přeskočit hlavní navigaci"
 ],
 "Skip to content": [
  null,
  "Přeskočit na obsah"
 ],
 "Software updates": [
  null,
  "Aktualizace software"
 ],
 "Stop editing hosts": [
  null,
  "Zastavit upravování hostitelů"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Style": [
  null,
  ""
 ],
 "Switch to administrative access": [
  null,
  "Přepnout na přístup správce"
 ],
 "Switch to limited access": [
  null,
  "Přepnout na omezený přístup"
 ],
 "System": [
  null,
  "Systém"
 ],
 "Terminal": [
  null,
  "Terminál"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP adresa nebo název stroje nemůže obsahovat prázdný znak."
 ],
 "The key password can not be empty": [
  null,
  "Heslo ke klíči je třeba vyplnit"
 ],
 "The key passwords do not match": [
  null,
  "Zadání hesla ke klíči se neshodují"
 ],
 "The machine is rebooting": [
  null,
  "Stroj se restartuje"
 ],
 "The new key password can not be empty": [
  null,
  "Nové heslo ke klíči je třeba vyplnit"
 ],
 "The passwords do not match.": [
  null,
  "Zadání hesla se neshodují."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Výsledný otisk je možné sdílet veřejnými způsoby, včetně e-mailu."
 ],
 "There are currently no active pages": [
  null,
  "V tuto chvíli zde nejsou žádné aktivní stránky"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Při připojování ke stroji došlo k neočekávané chybě."
 ],
 "This machine has already been added.": [
  null,
  "Tento stroj už byl přidán."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Toto vám umožní se napříště přihlašovat bez hesla."
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Tip: Nastavte si heslo ke klíči stejné jako pro přihlašování a budete se vůči ostatním systémům ověřovat automaticky."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Abyste zajistili, že do vašeho připojení není zasahováno záškodnickou třetí stranou, ověřte otisk klíče hostitele:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pokud chcete otisk ověřit, spusťte následující na $0 když jste fyzicky u stroje nebo prostřednictvím důvěryhodné sítě:"
 ],
 "Toggle": [
  null,
  "Přepnout"
 ],
 "Tools": [
  null,
  "Nástroje"
 ],
 "Turn on administrative access": [
  null,
  "Zapnout přístup na úrovni správce"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unable to contact $0.": [
  null,
  "Nedaří se kontaktovat $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Nepodařilo se kontaktovat uvedený stroj $0. Ověřte, že je ssh spuštěno na portu $1 nebo v jeho adrese zadejte jiný port."
 ],
 "Unexpected error": [
  null,
  "Neočekávaná chyba"
 ],
 "Unlock": [
  null,
  "Odemknout"
 ],
 "Update": [
  null,
  "Aktualizovat"
 ],
 "Use key": [
  null,
  "Použít klíč"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Pro ověřování vůči ostatním systémům použít následující klíče"
 ],
 "User name": [
  null,
  "Uživatelské jméno"
 ],
 "Using LUKS encryption": [
  null,
  "S použitím LUKS šifrování"
 ],
 "Using Tang server": [
  null,
  "S použitím Tang serveru"
 ],
 "Web Console": [
  null,
  "Webová konzole"
 ],
 "Web console logo": [
  null,
  "Logo webové konzole"
 ],
 "When empty, connect with the current user": [
  null,
  "Pokud nevyplněno, připojit se jako stávající uživatel"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "K $0 se připojujete poprvé."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Byli jste odhlášeni z důvodu nečinnosti."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Pro automatické přihlašování se nejspíš bude třeba změnit heslo ke klíči."
 ],
 "You now have administrative access.": [
  null,
  "Nyní máte přístup na úrovni správy systému."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Budete odhlášení za $0 sekund."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Váš prohlížeč si bude úroveň přístupu pamatovat i pro příště."
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "access": [
  null,
  "přístup"
 ],
 "active": [
  null,
  "aktivní"
 ],
 "add-on": [
  null,
  "doplněk"
 ],
 "addon": [
  null,
  "doplněk"
 ],
 "apps": [
  null,
  "aplikace"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "inventární štítek"
 ],
 "avc": [
  null,
  "avc"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "bond": [
  null,
  "spřažení"
 ],
 "boot": [
  null,
  "boot"
 ],
 "bridge": [
  null,
  "most"
 ],
 "cgroups": [
  null,
  "řídící skupiny"
 ],
 "command": [
  null,
  "příkaz"
 ],
 "console": [
  null,
  "konzole"
 ],
 "coredump": [
  null,
  "výpis paměti"
 ],
 "cpu": [
  null,
  "procesor"
 ],
 "crash": [
  null,
  "pád"
 ],
 "date": [
  null,
  "datum"
 ],
 "debug": [
  null,
  "ladění"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "vypnout"
 ],
 "disk": [
  null,
  "disk"
 ],
 "disks": [
  null,
  "disky"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "domain": [
  null,
  "doména"
 ],
 "drive": [
  null,
  "jednotka"
 ],
 "enable": [
  null,
  "zapnout"
 ],
 "encryption": [
  null,
  "šifrování"
 ],
 "error": [
  null,
  "chyba"
 ],
 "extension": [
  null,
  "rozšíření"
 ],
 "filesystem": [
  null,
  "souborový systém"
 ],
 "firewall": [
  null,
  "brána firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "format": [
  null,
  "formátovat"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "graphs": [
  null,
  "grafy"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "history": [
  null,
  "historie"
 ],
 "host": [
  null,
  "stroj"
 ],
 "in most browsers": [
  null,
  "ve většině prohlížečů"
 ],
 "install": [
  null,
  "nainstalovat"
 ],
 "interface": [
  null,
  "rozhraní"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "journal": [
  null,
  "žurnál"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "klíče"
 ],
 "login": [
  null,
  "přihlášení"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mac": [
  null,
  "mac adresa"
 ],
 "machine": [
  null,
  "stroj"
 ],
 "mask": [
  null,
  "maska"
 ],
 "memory": [
  null,
  "paměť"
 ],
 "metrics": [
  null,
  "metriky"
 ],
 "mitigation": [
  null,
  "omezení vlivu"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "mount"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "network": [
  null,
  "síť"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "operating system": [
  null,
  "operační systém"
 ],
 "os": [
  null,
  "os"
 ],
 "package": [
  null,
  "balíček"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "partition": [
  null,
  "oddíl"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "heslo"
 ],
 "path": [
  null,
  "popis umístění"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "plugin": [
  null,
  "zásuvný modul"
 ],
 "port": [
  null,
  "port"
 ],
 "power": [
  null,
  "napájení"
 ],
 "raid": [
  null,
  "raid"
 ],
 "ram": [
  null,
  "operační paměť"
 ],
 "restart": [
  null,
  "restartovat"
 ],
 "roles": [
  null,
  "role"
 ],
 "security": [
  null,
  "zabezpečení"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  "sériové"
 ],
 "service": [
  null,
  "služba"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ],
 "shell": [
  null,
  "shell"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "shut": [
  null,
  "vyp"
 ],
 "socket": [
  null,
  "patice"
 ],
 "sos": [
  null,
  "sos"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "tang"
 ],
 "target": [
  null,
  "cíl"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "team"
 ],
 "time": [
  null,
  "čas"
 ],
 "timer": [
  null,
  "časovač"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  "jednotka"
 ],
 "unmask": [
  null,
  "zrušit maskování"
 ],
 "unmount": [
  null,
  "odpojit (unmount)"
 ],
 "user": [
  null,
  "uživatel"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "uživatelské jméno"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "version": [
  null,
  "verze"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "volume": [
  null,
  "svazek"
 ],
 "warning": [
  null,
  "varování"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "zóna"
 ]
});
