cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "$0 დოკუმენტაცია"
 ],
 "$0 key changed": [
  null,
  "$0 გასაღები შეიცვალა"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "$0-ზე არ აყენია Cockpit-ის თავსებადი ვერსია."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "ახალი SSH გასაღები $0-თვის შეიქნება $1-თვის $2-ზე და დაემატება $3 ფაილს $4-ის ფაილს $5-ზე."
 ],
 "About Web Console": [
  null,
  "ვებ კონსოლის შესახებ"
 ],
 "Accept key and connect": [
  null,
  "დაეთანხმეთ გასაღებს და დაუკავშირდით"
 ],
 "Accounts": [
  null,
  "ანგარიშები"
 ],
 "Active pages": [
  null,
  "აქტიური გვერდები"
 ],
 "Add": [
  null,
  "დამატება"
 ],
 "Add key": [
  null,
  "გასაღების დამატება"
 ],
 "Add new host": [
  null,
  "ახალი ჰოსტის დამატება"
 ],
 "Administrative access": [
  null,
  "ადმინისტრატიული წვდომა"
 ],
 "Applications": [
  null,
  "აპლიკაციები"
 ],
 "Apps": [
  null,
  "აპები"
 ],
 "Authenticate": [
  null,
  "ავთენტიკაცია"
 ],
 "Authentication": [
  null,
  "ავთენტიკაცია"
 ],
 "Authorize SSH key": [
  null,
  "SSH გასაღების ავტორიზაცია"
 ],
 "Automatic login": [
  null,
  "ავტომატური შესვლა"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "$1-ის $2-ზე შესასვლელი SSH გასაღების, $0-ზე პაროლის შეცვლით თქვენი გასაღები ავტომატურად გახდება ხელმისაწვდომი. ოპერაციის შემდეგ $3-ზე შესვლას პაროლის გარეშე შეძლებთ."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "შეიძლება იყოს ჰოსტის სახელი, IP მისამართი, DNS სახელი ან ssh://URI"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Cannot connect to an unknown host": [
  null,
  "უცნობ ჰოსტთან მიერთების პრობლემა"
 ],
 "Change password": [
  null,
  "პაროლის შეცვლა"
 ],
 "Change the password of $0": [
  null,
  "$0-ის პაროლის შეცვლა"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "შეცვლილი გასაღებები ხშირად ოპერაციული სისტემის გადაყენებაზე მიუთითებს. ამავე დროს მოულოდნელი ცვლილება კავშირის გადასაჭერად მესამე პირის ჩარევასაც შეიძლება ნიშნავდეს."
 ],
 "Choose the language to be used in the application": [
  null,
  "აირჩიეთ აპლიკაციის ენა"
 ],
 "Clear search": [
  null,
  "ძებნის გასუფთავება"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Close selected pages": [
  null,
  "მონიშნული გვერდების დახურვა"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit-ის შიდა შეცდომა."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit-ი წარმოადგენს ლინუქსის სერვერების ადმინისტრირების ინტერაქტიულ ინტერფეისს."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit-ი დაყენებული არაა"
 ],
 "Color": [
  null,
  "ფერი"
 ],
 "Comment": [
  null,
  "კომენტარი"
 ],
 "Configuring kdump": [
  null,
  "kdump-ის მორგება"
 ],
 "Configuring system settings": [
  null,
  "სისტემის პარამეტრების მორგება"
 ],
 "Confirm key password": [
  null,
  "მეორედ შეიყვანეთ გასაღების პაროლი"
 ],
 "Confirm new key password": [
  null,
  "დაადასტურეთ გასაღების ახალი პაროლი"
 ],
 "Confirm password": [
  null,
  "დაადასტურეთ პაროლი"
 ],
 "Connecting to the machine": [
  null,
  "მანქანასთან დაკავშირება"
 ],
 "Connection error": [
  null,
  "დაკავშირების შეცდომა"
 ],
 "Connection failed": [
  null,
  "დაკავშირების შეცდომა"
 ],
 "Contains:": [
  null,
  "შეიცავს:"
 ],
 "Continue session": [
  null,
  "სესიის გაგრძელება"
 ],
 "Copied": [
  null,
  "დაკოპირებულია"
 ],
 "Copy": [
  null,
  "კოპირება"
 ],
 "Could not contact $0": [
  null,
  "$0-ს ვერ დავუკავშირდი"
 ],
 "Create": [
  null,
  "შექმნა"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "შექმენით SSH-ის ახალი გასაღები და გაატარეთ ავტორიზაცია"
 ],
 "Ctrl-Shift-J": [
  null,
  "Ctrl-Shift-J"
 ],
 "Dark": [
  null,
  "ბლენი"
 ],
 "Default": [
  null,
  "ნაგულისხმები"
 ],
 "Details": [
  null,
  "დეტალები"
 ],
 "Development": [
  null,
  "განვითარება"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Disconnected": [
  null,
  "გამომძვრალია"
 ],
 "Display language": [
  null,
  "ენა"
 ],
 "Edit": [
  null,
  "ჩასწორება"
 ],
 "Edit host": [
  null,
  "ჰოსტის ჩასწორება"
 ],
 "Edit hosts": [
  null,
  "hosts ფაილის ჩასწორება"
 ],
 "Failed to add machine: $0": [
  null,
  "მანქანის დამატების შეცდომა: $0"
 ],
 "Failed to change password": [
  null,
  "პაროლის შეცვლის შეცდომა"
 ],
 "Failed to edit machine: $0": [
  null,
  "მანქანის ჩასწორების შეცდომა: $0"
 ],
 "Filter menu items": [
  null,
  "მენიუს ელემენტების გაფილტვრა"
 ],
 "Fingerprint": [
  null,
  "ანაბეჭდი"
 ],
 "Help": [
  null,
  "დახმარება"
 ],
 "Host": [
  null,
  "ჰოსტი"
 ],
 "Hosts": [
  null,
  "ჰოსტები"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  "თუ ანაბეჭდი ემთხვევა, დააწექით \"გასაღების მიღება და შესვლა\"-ს. ან არ შეხვიდეთ და დაუკავშირდით ადმინისტრატორს."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "მომავალში $1-ზე $0-ით უპაროლოდ შესვლისთვის გამოიყენეთ $2-ის პაროლი $3-ზე როგორც გასაღების პაროლი ან დატოვეთ გასაღების პაროლი ცარიელი."
 ],
 "Invalid file permissions": [
  null,
  "ფაილის არასწორი წვდომები"
 ],
 "Is sshd running on a different port?": [
  null,
  "sshd-ი სხვა პორტზე ხომ არაა გაშვებული?"
 ],
 "Kernel dump": [
  null,
  "ბირთვის დამპი"
 ],
 "Key password": [
  null,
  "გასაღების პაროლი"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "ლიცენზირებულია GNU LGPL -ის ვერსია 2.1-ით"
 ],
 "Light": [
  null,
  "ღია"
 ],
 "Limit access": [
  null,
  "წვდომის შეზღუდვა"
 ],
 "Limited access": [
  null,
  "შეზღუდული წვდომა"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "შეზღუდული წვდომა გისაზღვრავთ ადმინისტრატიულ პრივილეგიებს. ვებ კონსოლის ზოგიერთი ნაწილი შეზღუდული იქნება."
 ],
 "Loading packages...": [
  null,
  "პაკეტების ჩატვირთვა..."
 ],
 "Log in": [
  null,
  "შესვლა"
 ],
 "Log in to $0": [
  null,
  "$0-ში შესვლა"
 ],
 "Log out": [
  null,
  "გასვლა"
 ],
 "Logs": [
  null,
  "ჟურნალი"
 ],
 "Managing LVMs": [
  null,
  "LVM-ის მართვა"
 ],
 "Managing NFS mounts": [
  null,
  "NFS მიმაგრებების მართვა"
 ],
 "Managing RAIDs": [
  null,
  "RAID-ის მართვა"
 ],
 "Managing VDOs": [
  null,
  "VDO-ის მართვა"
 ],
 "Managing VLANs": [
  null,
  "VLAN-ის მართვა"
 ],
 "Managing firewall": [
  null,
  "ბრანდმაუერის მართვა"
 ],
 "Managing networking bonds": [
  null,
  "ქსელის ბარათების გაერთიანების მართვა"
 ],
 "Managing networking bridges": [
  null,
  "ქსელური ხიდების მართვა"
 ],
 "Managing networking teams": [
  null,
  "ქსელური ბარათების გუნდების მართვა"
 ],
 "Managing partitions": [
  null,
  "დამაყოფების მართვა"
 ],
 "Managing physical drives": [
  null,
  "ფიზიკური დისკების მართვა"
 ],
 "Managing services": [
  null,
  "სერვისების მართვა"
 ],
 "Managing software updates": [
  null,
  "პროგრამული უზრუნველყოფის განახლების მართვა"
 ],
 "Managing user accounts": [
  null,
  "მომხმარებლების ანგარიშების მართვა"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "შეტყობინებები ამ შეცდომის შესახებ შეგიძლიათ იპოვოთ ჟურნალში:"
 ],
 "Method": [
  null,
  "მეთოდი"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "New host": [
  null,
  "ახალი ჰოსტი"
 ],
 "New key password": [
  null,
  "გასაღების ახალი პაროლი"
 ],
 "New password": [
  null,
  "ახალი პაროლი"
 ],
 "New password was not accepted": [
  null,
  "ახალი პაროლი მიუღებელია"
 ],
 "No results found": [
  null,
  "შედეგები ნაპოვნი არაა"
 ],
 "No such file or directory": [
  null,
  "ფაილი ან საქაღალდე არ არსებობს"
 ],
 "Not a valid private key": [
  null,
  "არ წარმოადგენს სწორ პირად გასაღებს"
 ],
 "Not connected to host": [
  null,
  "არაა მიერთებული ჰოსტთან"
 ],
 "Old password not accepted": [
  null,
  "ძველი პაროლი მიუღებელია"
 ],
 "Ooops!": [
  null,
  "უკაცრავად!"
 ],
 "Overview": [
  null,
  "გადახედვა"
 ],
 "Page name": [
  null,
  "გვერდის სახელი"
 ],
 "Password": [
  null,
  "პაროლი"
 ],
 "Password changed successfully": [
  null,
  "პაროლი წარმატებით შეიცვალა"
 ],
 "Password not accepted": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Password tip": [
  null,
  "პაროლის მინიშნება"
 ],
 "Path to file": [
  null,
  "ბილიკი ფაილამდე"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "ადმინისტრატორი წვდომის მისაღებად გთხოვთ გაიაროთ ავთენტიკაცია"
 ],
 "Port": [
  null,
  "პორტი"
 ],
 "Problem becoming administrator": [
  null,
  "ადმინისტრატორად გახდომის შეცდომა"
 ],
 "Project website": [
  null,
  "პროექტის ვებგვერდი"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "მოთხოვნას ssh-add-ის გავლით დრო გაუვიდა"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "მოთხოვნას ssh-keygen-ის გავლით დრო გაუვიდა"
 ],
 "Public key": [
  null,
  "საჯარო გასაღები"
 ],
 "Reconnect": [
  null,
  "თავიდან დაკავშირება"
 ],
 "Remove": [
  null,
  "წაშლა"
 ],
 "Reviewing logs": [
  null,
  "ჟურნალის გადახედვა"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH გასაღები"
 ],
 "SSH keys": [
  null,
  "SSH გასაღებები"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safari-ის მომხმარებლებს სჭირდებათ სერტიფიკატის შემოტანა და სანდო სერტიფიკატების სიაში ჩამატება:"
 ],
 "Search": [
  null,
  "ძებნა"
 ],
 "Select": [
  null,
  "არჩევა"
 ],
 "Services": [
  null,
  "სერვისები"
 ],
 "Session": [
  null,
  "სესია"
 ],
 "Session is about to expire": [
  null,
  "სესიას ვადა გასდის"
 ],
 "Set": [
  null,
  "დაყენება"
 ],
 "Skip main navigation": [
  null,
  "მთავარი ნავიგაციის გამოტოვება"
 ],
 "Skip to content": [
  null,
  "შემცველობაზე გადახტომა"
 ],
 "Software updates": [
  null,
  "პროგრამების განახლებები"
 ],
 "Stop editing hosts": [
  null,
  "hosts ფაილის ჩასწორების დამთავრება"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Style": [
  null,
  "სტილი"
 ],
 "Switch to administrative access": [
  null,
  "ადმინისტრატორის წვდომაზე გადართვა"
 ],
 "Switch to limited access": [
  null,
  "შეზღუდულ წვდომებზე გადართვა"
 ],
 "System": [
  null,
  "სისტემა"
 ],
 "Terminal": [
  null,
  "ტერმინალი"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP მისამართი და ჰოსტის სახელი არ შეიძლება ცარიელ ადგილებს შეიცავდეს."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH გასაღები $1-ის $0 $2-ზე დაემატება ფაილ $3-ს $5-ზე $4-ს."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH გასაღები $0 ხელმისაწვდომია სესიის ბოლომდე და ხელმისაწვდომი იქნება სხვა ჰოსტებზე შესასვლელადაც."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "$0-ზე შესასვლელი SSH გასაღები პაროლითაა დაცული და ჰოსტს პაროლით შესვლა გამორთული აქვს. შეიყვანეთ $1-ზე არსებული გასაღების პაროლი."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "$0-ზე შესასვლელი SSH გასაღები დაცულია. შეგიძლიათ შეხვიდეთ ან თქვენი პაროლით ან გასაღები $1-ის პაროლით."
 ],
 "The key password can not be empty": [
  null,
  "გასაღების პაროლი ცარიელი ვერ იქნება"
 ],
 "The key passwords do not match": [
  null,
  "გასაღების პაროლები არ ემთხვევა"
 ],
 "The machine is rebooting": [
  null,
  "მიმდინარეობის მანქანის გადატვირთვა"
 ],
 "The new key password can not be empty": [
  null,
  "გასაღების ახალი საკვანძო სიტყვა ცარიელი ვერ იქნება"
 ],
 "The password can not be empty": [
  null,
  "პაროლი არ შეიძლება ცარიელი იყოს"
 ],
 "The passwords do not match.": [
  null,
  "პაროლები არ ემთხვევა."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "მიღებული ანაბეჭდების გაზიარება პრობლემა არაა."
 ],
 "There are currently no active pages": [
  null,
  "აქტიური გვერდების გარეშე"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "მანქანასთან კავშირის გაუთვალისწინებელი შეცდომა."
 ],
 "This machine has already been added.": [
  null,
  "ეს მანქანა უკვე დამატებულია."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "უფლებას მოგცემთ მომავალში პაროლის გარეშე შეხვიდეთ."
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "მინიშნება: სხვა სისტემებში უპაროლოდ შესასვლელად დაამთხვიეთ თქვენი შესვლის პაროლი გასაღების პაროლს."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "იმაში დასარწმუნებლად, რომ არ ხდება კავშირის გადაჭერა, შეამოწმეთ ჰოსტის ანაბეჭდი:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "ანაბეჭდის შესამოწმებლად გაუშვით ეს ბრძანება $0-ზე როცა ფიზიკურად ან სანდო ქსელით იქნებით შესული მანქანაზე:"
 ],
 "Toggle": [
  null,
  "გადართვა"
 ],
 "Tools": [
  null,
  "ხელსაწყოები"
 ],
 "Turn on administrative access": [
  null,
  "ადმინისტრატორის წვდომების ჩართვა"
 ],
 "Type": [
  null,
  "ტიპი"
 ],
 "Unable to contact $0.": [
  null,
  "$0-თან კავშირის შეცდომა."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "მითითებულ, $0 ჰოსტთან კავშირის პრობლემა. დარწმუნდით, რომ ssh გაშვებულია $1-ე პორტზე ან მიუთითეთ სხვა პორტი."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "$0-ზე SSH გასაღებით ავთენტიკაციის შესვლის პრობლემა. შეიყვანეთ პაროლი. ავტომატური შესვლისთვის შეიძლება საჭირო გახდეს თქვენი SSH გასაღებების მორგება."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "$0-ზე შესვლის პრობლემა. ჰოსტი არ იღებს პაროლით შესვლას ან არცერთ თქვენს SSH გასაღებს."
 ],
 "Unexpected error": [
  null,
  "მოულოდნელი შეცდომა"
 ],
 "Unlock": [
  null,
  "განბლოკვა"
 ],
 "Unlock key $0": [
  null,
  "გასაღების განბლოკვა: $0"
 ],
 "Update": [
  null,
  "განახლება"
 ],
 "Use key": [
  null,
  "გასაღების გამოყენება"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "ამ გასაღებების სხვა სისტემებში შესასვლელად გამოყენება"
 ],
 "User name": [
  null,
  "მომხმარებლის სახელი"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS დაშიფვრის გამოყენებით"
 ],
 "Using Tang server": [
  null,
  "Tang სერვერის გამოყენებით"
 ],
 "Web Console": [
  null,
  "ვებ კონსოლი"
 ],
 "Web console logo": [
  null,
  "ვებ კონსოლის ლოგო"
 ],
 "When empty, connect with the current user": [
  null,
  "როცა ცარიელია, მიმდინარე მომხმარებლით შესვლა"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "$0-ს პირველად უკავშირდებით."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "გამოხვედით უქმედ ყოფნის გამო."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "ავტომატურად შესაცვლელად შეიძლება გასაღების პაროლის შეცვლა მოგიწიოთ."
 ],
 "You now have administrative access.": [
  null,
  "ახლა გაქვთ ადმინისტრატორის წვდომა."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "გახვალთ $0 წამში."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "თქვენი ბრაუზერი თქვენი წვდომის დონეებს სესიებს შორისაც დაიმახსოვრებს."
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "access": [
  null,
  "წვდომა"
 ],
 "active": [
  null,
  "აქტიური"
 ],
 "add-on": [
  null,
  "დამატება"
 ],
 "addon": [
  null,
  "დამატება"
 ],
 "apps": [
  null,
  "აპები"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "აქტივის ჭდე"
 ],
 "avc": [
  null,
  "avc"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "bond": [
  null,
  "გადაბმა"
 ],
 "boot": [
  null,
  "ჩატვირთვა"
 ],
 "bridge": [
  null,
  "ხიდი"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "ბრძანება"
 ],
 "console": [
  null,
  "კონსოლი"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "პროცესორი"
 ],
 "crash": [
  null,
  "ავარია"
 ],
 "date": [
  null,
  "თარიღი"
 ],
 "debug": [
  null,
  "შეცდომების მოძებნა"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "გამორთვა"
 ],
 "disk": [
  null,
  "დისკი"
 ],
 "disks": [
  null,
  "დისკები"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "domain": [
  null,
  "დომენი"
 ],
 "drive": [
  null,
  "დისკი"
 ],
 "enable": [
  null,
  "ჩართვა"
 ],
 "encryption": [
  null,
  "დაშიფვრა"
 ],
 "error": [
  null,
  "შეცდომა"
 ],
 "extension": [
  null,
  "გაფართოება"
 ],
 "filesystem": [
  null,
  "ფაილური სისტემა"
 ],
 "firewall": [
  null,
  "ბრანდმაუერი"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "format": [
  null,
  "ფორმატი"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "graphs": [
  null,
  "გრაფიკები"
 ],
 "hardware": [
  null,
  "აპარატურა"
 ],
 "history": [
  null,
  "ისტორია"
 ],
 "host": [
  null,
  "ჰოსტი"
 ],
 "in most browsers": [
  null,
  "ბრაუზერების უმეტესობაში"
 ],
 "install": [
  null,
  "დაყენება"
 ],
 "interface": [
  null,
  "ინტერფეისი"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "journal": [
  null,
  "ჟურნალი"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "გასაღებები"
 ],
 "login": [
  null,
  "შესვლა"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mac": [
  null,
  "mac"
 ],
 "machine": [
  null,
  "მანქანა"
 ],
 "mask": [
  null,
  "ნიღაბი"
 ],
 "memory": [
  null,
  "მეხსიერება"
 ],
 "metrics": [
  null,
  "მეტრიკები"
 ],
 "mitigation": [
  null,
  "შემოვლა"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "მიმაგრება"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "network": [
  null,
  "ქსელი"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "operating system": [
  null,
  "ოპერაციული სისტემა"
 ],
 "os": [
  null,
  "ოპერაციული სისტემა"
 ],
 "package": [
  null,
  "პაკეტი"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "partition": [
  null,
  "განყოფილება"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "პაროლი"
 ],
 "path": [
  null,
  "ბილიკი"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "წარმადობა"
 ],
 "plugin": [
  null,
  "ჩადგმა"
 ],
 "port": [
  null,
  "პორტი"
 ],
 "power": [
  null,
  "კვება"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "რესტარტი"
 ],
 "roles": [
  null,
  "როლები"
 ],
 "security": [
  null,
  "უსაფრთხოება"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  "მიმდევრობითი"
 ],
 "service": [
  null,
  "სერვისი"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ],
 "shell": [
  null,
  "გარსი"
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ],
 "shut": [
  null,
  "გათიშვა"
 ],
 "socket": [
  null,
  "სოკეტი"
 ],
 "sos": [
  null,
  "sos"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "tang"
 ],
 "target": [
  null,
  "მიზანი"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "გუნდი"
 ],
 "time": [
  null,
  "დრო"
 ],
 "timer": [
  null,
  "ტაიმერი"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  "მოდული"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "unmount": [
  null,
  "მოძრობა"
 ],
 "user": [
  null,
  "მომხმარებელი"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "მომხმარებლის სახელი"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "version": [
  null,
  "ვერსია"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "volume": [
  null,
  "საცავი"
 ],
 "warning": [
  null,
  "გაფრთხილება"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "ზონა"
 ]
});
