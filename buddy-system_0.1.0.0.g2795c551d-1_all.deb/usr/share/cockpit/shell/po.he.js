cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "$0 documentation": [
  null,
  "התיעוד של $0"
 ],
 "$0 key changed": [
  null,
  "המפתח $0 השתנה"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "לא מותקנת גרסה תואמת של Cockpit ב־$0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "מפתח SSH חדש תחת $0 ייווצר עבור $1 על גבי $2 והוא יתווסף לקובץ $3 של $4 על גבי $5."
 ],
 "About Web Console": [
  null,
  "על המסוף המקוון"
 ],
 "Accept key and connect": [
  null,
  "לקבל את המפתח ולהתחבר"
 ],
 "Accounts": [
  null,
  "חשבונות"
 ],
 "Active pages": [
  null,
  "עמודים פעילים"
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "Add key": [
  null,
  "הוספת מפתח"
 ],
 "Add new host": [
  null,
  "הוספת מארח חדש"
 ],
 "Administrative access": [
  null,
  "גישה ניהולית"
 ],
 "Applications": [
  null,
  "יישומים"
 ],
 "Apps": [
  null,
  "יישומים"
 ],
 "Authenticate": [
  null,
  "אימות"
 ],
 "Authentication": [
  null,
  "אימות"
 ],
 "Authorize SSH key": [
  null,
  "אישור מפתח SSH"
 ],
 "Automatic login": [
  null,
  "כניסה אוטומטית"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "החלפת סיסמת מפתח ה־SSH‏ $0 לסיסמת הכניסה של $1 על גבי $2, תוביל לכך שהמפתח אוטומטית יהיה זמין ותהיה לך אפשרות להיכנס אל $3 ללא סיסמה בעתיד."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "יכול להיות שם מארח, כתובת IP, שם כינוי או כתובת ssh://‎ מלאה"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Cannot connect to an unknown host": [
  null,
  "לא ניתן להתחבר למארח לא ידוע"
 ],
 "Change password": [
  null,
  "החלפת סיסמה"
 ],
 "Change the password of $0": [
  null,
  "החלפת הסיסמה של $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "מפתחות שהוחלפו הם לעתים תוצאה של התקנת מערכת הפעלה מחדש. עם זאת, שינוי בלתי צפוי עשוי להעיד שגורם צד־שלישי מנסה ליירט את החיבור שלך."
 ],
 "Choose the language to be used in the application": [
  null,
  "נא לבחור את שפת היישום לשימוש"
 ],
 "Clear search": [
  null,
  "ניקוי החיפוש"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Close selected pages": [
  null,
  "סגירת העמודים הנבחרים"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "ב־Cockpit אירעה שגיאה בלתי צפויה."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit הוא מנשק אינטראקטיבי לניהול שרתי לינוקס."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit אינו מותקן"
 ],
 "Color": [
  null,
  "צבע"
 ],
 "Comment": [
  null,
  "הערה"
 ],
 "Configuring kdump": [
  null,
  "kdump מוגדר"
 ],
 "Configuring system settings": [
  null,
  "הגדרות המערכת מוגדרות"
 ],
 "Confirm key password": [
  null,
  "אישור סיסמת מפתח"
 ],
 "Confirm new key password": [
  null,
  "אישור סיסמה חדשה למפתח"
 ],
 "Confirm password": [
  null,
  "אישור סיסמה"
 ],
 "Connecting to the machine": [
  null,
  "מתבצעת התחברות למכונה"
 ],
 "Connection error": [
  null,
  "שגיאת התחברות"
 ],
 "Connection failed": [
  null,
  "ההתחברות נכשלה"
 ],
 "Contains:": [
  null,
  "מכיל:"
 ],
 "Continue session": [
  null,
  "להמשיך הפעלה"
 ],
 "Copied": [
  null,
  "הועתק"
 ],
 "Copy": [
  null,
  "העתקה"
 ],
 "Could not contact $0": [
  null,
  "לא ניתן ליצור קשר עם $0"
 ],
 "Create": [
  null,
  "יצירה"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "ליצור מפתח SSH חדש ולאשר אותו"
 ],
 "Ctrl-Shift-J": [
  null,
  "Ctrl-Shift-J"
 ],
 "Dark": [
  null,
  "כהה"
 ],
 "Default": [
  null,
  "בררת מחדל"
 ],
 "Details": [
  null,
  "פרטים"
 ],
 "Development": [
  null,
  "פיתוח"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Disconnected": [
  null,
  "מנותק"
 ],
 "Display language": [
  null,
  "שפת התצוגה"
 ],
 "Edit": [
  null,
  "עריכה"
 ],
 "Edit host": [
  null,
  "עריכת מארח"
 ],
 "Edit hosts": [
  null,
  "עריכת מארחים"
 ],
 "Failed to add machine: $0": [
  null,
  "הוספת המכונה נכשלה: $0"
 ],
 "Failed to change password": [
  null,
  "החלפת הסיסמה נכשלה"
 ],
 "Failed to edit machine: $0": [
  null,
  "עריכת המכונה נכשלה: $0"
 ],
 "Filter menu items": [
  null,
  "סינון פריטי תפריט"
 ],
 "Fingerprint": [
  null,
  "טביעת אצבע"
 ],
 "Help": [
  null,
  "עזרה"
 ],
 "Host": [
  null,
  "מארח"
 ],
 "Hosts": [
  null,
  "מארחים"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  "אם טביעת האצבע תואמת, יש ללחוץ על ‚לקבל את המפתח ולהתחבר’. אחרת, לא להתחבר וליצור קשר עם הנהלת המערכת."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "כדי לאפשר כניסה אל $0 בתור $1 ללא סיסמה בעתיד, עליך להשתמש בסיסמת הכניסה של $2 על גבי $3 כסיסמת המפתח או להשאיר את סיסמת המפתח ריקה."
 ],
 "Invalid file permissions": [
  null,
  "הרשאות הקובץ שגויות"
 ],
 "Is sshd running on a different port?": [
  null,
  "האם sshd פועל על פתחה אחרת?"
 ],
 "Kernel dump": [
  null,
  "היטל ליבה"
 ],
 "Key password": [
  null,
  "סיסמת מפתח"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "בכפוף לרישיון LGPL מבית GNU בגרסה 2.1"
 ],
 "Light": [
  null,
  "בהירה"
 ],
 "Limit access": [
  null,
  "הגבלת גישה"
 ],
 "Limited access": [
  null,
  "גישה מוגבלת"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "מצב גישה מוגבלת מגביל את ההרשאות הניהוליות. חלקים מסוימים במסוף המקוון יפעלו באופן חלקי."
 ],
 "Loading packages...": [
  null,
  "החבילות נטענות…"
 ],
 "Log in": [
  null,
  "כניסה"
 ],
 "Log in to $0": [
  null,
  "כניסה אל $0"
 ],
 "Log out": [
  null,
  "יציאה"
 ],
 "Logs": [
  null,
  "יומנים"
 ],
 "Managing LVMs": [
  null,
  "ניהול LVMים"
 ],
 "Managing NFS mounts": [
  null,
  "ניהול עיגוני NFS"
 ],
 "Managing RAIDs": [
  null,
  "ניהול RAIDים"
 ],
 "Managing VDOs": [
  null,
  "ניהול VDOים"
 ],
 "Managing VLANs": [
  null,
  "ניהול VLANים"
 ],
 "Managing firewall": [
  null,
  "ניהול חומת אש"
 ],
 "Managing networking bonds": [
  null,
  "ניהול מאגדי רשת"
 ],
 "Managing networking bridges": [
  null,
  "ניהול גישורי רשת"
 ],
 "Managing networking teams": [
  null,
  "ניהול ציוותי רשת"
 ],
 "Managing partitions": [
  null,
  "ניהול מחיצות"
 ],
 "Managing physical drives": [
  null,
  "ניהול כוננים פיזיים"
 ],
 "Managing services": [
  null,
  "ניהול שירותים"
 ],
 "Managing software updates": [
  null,
  "ניהול עדכוני תכנה"
 ],
 "Managing user accounts": [
  null,
  "ניהול חשבונות משתמשים"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "ניתן למצוא הודעות שקשורות בכשל בז׳ורנל:"
 ],
 "Method": [
  null,
  "שיטה"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "New host": [
  null,
  "מארח חדש"
 ],
 "New key password": [
  null,
  "סיסמה חדשה למפתח"
 ],
 "New password": [
  null,
  "סיסמה חדשה"
 ],
 "New password was not accepted": [
  null,
  "הסיסמה החדשה לא התקבלה"
 ],
 "No results found": [
  null,
  "לא נמצאו תוצאות"
 ],
 "No such file or directory": [
  null,
  "אין קובץ או תיקייה בשם הזה"
 ],
 "Not a valid private key": [
  null,
  "לא מפתח פרטי תקני"
 ],
 "Not connected to host": [
  null,
  "לא מחובר למארח"
 ],
 "Old password not accepted": [
  null,
  "הסיסמה הישנה לא התקבלה"
 ],
 "Ooops!": [
  null,
  "אופס!"
 ],
 "Overview": [
  null,
  "סקירה"
 ],
 "Page name": [
  null,
  "שם העמוד"
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Password not accepted": [
  null,
  "הסיסמה לא התקבלה"
 ],
 "Path to file": [
  null,
  "הנתיב לקובץ"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "נא לעבור אימות כדי לקבל גישת ניהול"
 ],
 "Port": [
  null,
  "פתחה"
 ],
 "Project website": [
  null,
  "אתר המיזם"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-add תם"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "משך הצגת הבקשה דרך ssh-keygen תם"
 ],
 "Public key": [
  null,
  "מפתח ציבורי"
 ],
 "Reconnect": [
  null,
  "התחברות מחדש"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "Reviewing logs": [
  null,
  "היומנים נסקרים"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "מפתח SSH"
 ],
 "SSH keys": [
  null,
  "מפתחות SSH"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "משתמשי Safari צריכים לייבא ולתת אמון באישור מרשות האישורים שנחתמה עצמית:"
 ],
 "Search": [
  null,
  "חיפוש"
 ],
 "Select": [
  null,
  "בחירה"
 ],
 "Services": [
  null,
  "שירותים"
 ],
 "Session": [
  null,
  "הפעלה"
 ],
 "Session is about to expire": [
  null,
  "תוקף ההפעלה עומד לפוג"
 ],
 "Set": [
  null,
  "הגדרה"
 ],
 "Skip main navigation": [
  null,
  "דילוג על הניווט הראשי"
 ],
 "Skip to content": [
  null,
  "דילוג לתוכן"
 ],
 "Software updates": [
  null,
  "עדכוני תכנה"
 ],
 "Stop editing hosts": [
  null,
  "הפסקת עריכת מארחים"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Style": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  "העברה לגישה מוגבלת"
 ],
 "System": [
  null,
  "מערכת"
 ],
 "Terminal": [
  null,
  "מסוף"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "כתובת ה־IP או שם המארח לא יכולים להכיל רווח."
 ],
 "The key password can not be empty": [
  null,
  "סיסמת המפתח לא יכולה להישאר ריקה"
 ],
 "The key passwords do not match": [
  null,
  "סיסמאות המפתח אינן תואמות"
 ],
 "The machine is rebooting": [
  null,
  "המכונה מופעלת מחדש"
 ],
 "The new key password can not be empty": [
  null,
  "סיסמת המפתח החדשה לא יכולה להישאר ריקה"
 ],
 "The passwords do not match.": [
  null,
  "הסיסמאות אינן תואמות."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "זה בסדר לשתף את טביעת האצבע באופן ציבורי, לרבות בדוא״ל."
 ],
 "There are currently no active pages": [
  null,
  "אין דפים פעילים כרגע"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "הייתה שגיאה בלתי צפויה בעת ההתחברות למכונה."
 ],
 "This machine has already been added.": [
  null,
  "מכונה זו כבר נוספה."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "הגדרה זו תאפשר לך להיכנס ללא סיסמה בעתיד."
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "עצה: אפשר להגדיר את סיסמת המפתח שלך כמו סיסמת הכניסה שלך כדי להתאמת אוטומטית מול מערכות אחרות."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "כדי לוודא שהחיבור שלך לא מיורט על ידי גורמי צד־שלישי זדוניים, נא לאמת את טביעת האצבע של מפתח המארח:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "כדי לאמת את טביעת האצבע, יש להריץ את הפקודה הבאה על $0 במהלך ישיבה פיזית מול המכונה או דרך רשת מהימנה:"
 ],
 "Toggle": [
  null,
  "בורר"
 ],
 "Tools": [
  null,
  "כלים"
 ],
 "Turn on administrative access": [
  null,
  "הפעלת גישה ניהולית"
 ],
 "Type": [
  null,
  "סוג"
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "לא ניתן ליצור קשר עם המארח שסופק $0. נא לוודא שיש לו ssh פעיל בפתחה $1 או לציין פתחה אחרת בכתובת."
 ],
 "Unexpected error": [
  null,
  "שגיאה בלתי צפויה"
 ],
 "Unlock": [
  null,
  "שחרור"
 ],
 "Update": [
  null,
  "עדכון"
 ],
 "Use key": [
  null,
  "להשתמש במפתח"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "להשתמש במפתחות הבאים כדי להתאמת מול שרתים אחרים"
 ],
 "User name": [
  null,
  "שם משתמש"
 ],
 "Using LUKS encryption": [
  null,
  "באמצעות הצפנת LUKS"
 ],
 "Using Tang server": [
  null,
  "באמצעות שרת Tang"
 ],
 "Web Console": [
  null,
  "מסוף מקוון"
 ],
 "When empty, connect with the current user": [
  null,
  "כאשר ריק, להתחבר עם המשתמש הנוכחי"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "זאת ההתחברות הראשונה שלך אל $0."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "יצאת מהמערכת עקב חוסר פעילות."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "יתכן שעדיף לך להחליף את הסיסמה של המפתח לטובת כניסה אוטומטית."
 ],
 "You now have administrative access.": [
  null,
  "מעתה יש לך גישה ניהולית."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "המערכת תוציא אותך בעוד $0 שניות."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "הדפדפן שלך יזכור את רמת הגישה שלך בין הפעלות."
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "access": [
  null,
  "גישה"
 ],
 "active": [
  null,
  "פעיל"
 ],
 "add-on": [
  null,
  "תוספת"
 ],
 "addon": [
  null,
  "תוספת"
 ],
 "apps": [
  null,
  "יישומים"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "תג נכס"
 ],
 "avc": [
  null,
  "avc"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "bond": [
  null,
  "מאגד"
 ],
 "boot": [
  null,
  "עלייה"
 ],
 "bridge": [
  null,
  "גשר"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "פקודה"
 ],
 "console": [
  null,
  "מסוף"
 ],
 "coredump": [
  null,
  "היטל ליבה"
 ],
 "cpu": [
  null,
  "מעבד"
 ],
 "crash": [
  null,
  "קריסה"
 ],
 "date": [
  null,
  "תאריך"
 ],
 "debug": [
  null,
  "ניפוי שגיאות"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "השבתה"
 ],
 "disk": [
  null,
  "כונן"
 ],
 "disks": [
  null,
  "כוננים"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "domain": [
  null,
  "שם תחום"
 ],
 "drive": [
  null,
  "כונן"
 ],
 "enable": [
  null,
  "הפעלה"
 ],
 "encryption": [
  null,
  "הצפנה"
 ],
 "error": [
  null,
  "שגיאה"
 ],
 "extension": [
  null,
  "הרחבה"
 ],
 "filesystem": [
  null,
  "מערכת קבצים"
 ],
 "firewall": [
  null,
  "חומת אש"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "format": [
  null,
  "פרמוט"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "graphs": [
  null,
  "תרשימים"
 ],
 "hardware": [
  null,
  "חומרה"
 ],
 "history": [
  null,
  "היסטוריה"
 ],
 "host": [
  null,
  "מארח"
 ],
 "in most browsers": [
  null,
  "ברוב הדפדפנים"
 ],
 "install": [
  null,
  "התקנה"
 ],
 "interface": [
  null,
  "מנשק"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "journal": [
  null,
  "ז׳ורנל"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "מפתחות"
 ],
 "login": [
  null,
  "כניסה"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mac": [
  null,
  "mac"
 ],
 "machine": [
  null,
  "מכונה"
 ],
 "mask": [
  null,
  "מסכה"
 ],
 "memory": [
  null,
  "זיכרון"
 ],
 "metrics": [
  null,
  "מדדים"
 ],
 "mitigation": [
  null,
  "אפחות"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "עיגון"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "network": [
  null,
  "רשת"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "operating system": [
  null,
  "מערכת הפעלה"
 ],
 "os": [
  null,
  "מערכת הפעלה"
 ],
 "package": [
  null,
  "חבילה"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "partition": [
  null,
  "מחיצה"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "סיסמה"
 ],
 "path": [
  null,
  "נתיב"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "plugin": [
  null,
  "תוסף"
 ],
 "port": [
  null,
  "פתחה"
 ],
 "power": [
  null,
  "חשמל"
 ],
 "raid": [
  null,
  "raid"
 ],
 "ram": [
  null,
  "זיכרון"
 ],
 "restart": [
  null,
  "הפעלה מחדש"
 ],
 "roles": [
  null,
  "תפקידים"
 ],
 "security": [
  null,
  "אבטחה"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  "טורי"
 ],
 "service": [
  null,
  "שירות"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ],
 "shell": [
  null,
  "מעטפת"
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ],
 "shut": [
  null,
  "לסגור"
 ],
 "socket": [
  null,
  "שקע"
 ],
 "sos": [
  null,
  "חירום"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "tang"
 ],
 "target": [
  null,
  "יעד"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "ציוות"
 ],
 "time": [
  null,
  "זמן"
 ],
 "timer": [
  null,
  "קוצב זמן"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  "יחידה"
 ],
 "unmask": [
  null,
  "הסרת מיסוך"
 ],
 "unmount": [
  null,
  "ניתוק"
 ],
 "user": [
  null,
  "משתמש"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "שם משתמש"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "version": [
  null,
  "גרסה"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "volume": [
  null,
  "כרך"
 ],
 "warning": [
  null,
  "אזהרה"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "אזור"
 ]
});
