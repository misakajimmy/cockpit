cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "$0 dokumentasjon"
 ],
 "$0 key changed": [
  null,
  "$0 nøkkel endret"
 ],
 "About Web Console": [
  null,
  "Om Web konsoll"
 ],
 "Accept key and connect": [
  null,
  "Godta nøkkel og koble til"
 ],
 "Accounts": [
  null,
  "Kontoer"
 ],
 "Active pages": [
  null,
  "Aktive sider"
 ],
 "Add": [
  null,
  "Legg til"
 ],
 "Add key": [
  null,
  "Legg til nøkkel"
 ],
 "Add new host": [
  null,
  "Legg til ny vert"
 ],
 "Administrative access": [
  null,
  "Administrativ tilgang"
 ],
 "Applications": [
  null,
  "Applikasjoner"
 ],
 "Apps": [
  null,
  "Apper"
 ],
 "Authenticate": [
  null,
  "Autentiser"
 ],
 "Authentication": [
  null,
  "Autentisering"
 ],
 "Automatic login": [
  null,
  "Automatisk pålogging"
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Kan være et vertsnavn, IP-adresse, aliasnavn eller ssh:// URI"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Kan ikke koble til en ukjent vert"
 ],
 "Change password": [
  null,
  "Endre passord"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Endrede nøkler er ofte resultatet av reinstallering av operativsystemet. Imidlertid kan en uventet endring indikere et tredjepartsforsøk på å fange opp forbindelsen din."
 ],
 "Choose the language to be used in the application": [
  null,
  ""
 ],
 "Clear search": [
  null,
  "Tøm søket"
 ],
 "Close": [
  null,
  "Lukk"
 ],
 "Close selected pages": [
  null,
  "Lukk valgte sider"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit hadde en uventet intern feil."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit er et interaktivt administrasjonsgrensesnitt for Linux-server."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit er ikke installert"
 ],
 "Color": [
  null,
  "Farge"
 ],
 "Comment": [
  null,
  "Kommentar"
 ],
 "Configuring kdump": [
  null,
  "Konfigurerer kdump"
 ],
 "Configuring system settings": [
  null,
  "Konfigurere systeminnstillinger"
 ],
 "Confirm key password": [
  null,
  "Bekreft nøkkel-passord"
 ],
 "Confirm new key password": [
  null,
  "Bekreft nytt nøkkel-passord"
 ],
 "Connecting to the machine": [
  null,
  "Kobler til maskinen"
 ],
 "Connection error": [
  null,
  "Tilkoblingsfeil"
 ],
 "Connection failed": [
  null,
  "Tilkoblingen feilet"
 ],
 "Contains:": [
  null,
  "Inneholder:"
 ],
 "Continue session": [
  null,
  "Fortsett økt"
 ],
 "Copied": [
  null,
  ""
 ],
 "Copy": [
  null,
  "Kopier"
 ],
 "Create": [
  null,
  "Opprett"
 ],
 "Ctrl-Shift-J": [
  null,
  "Ctrl-Shift-J"
 ],
 "Dark": [
  null,
  "Mørk"
 ],
 "Default": [
  null,
  ""
 ],
 "Details": [
  null,
  "Detaljer"
 ],
 "Development": [
  null,
  "Utvikling"
 ],
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Disconnected": [
  null,
  "Frakoblet"
 ],
 "Display language": [
  null,
  "Visnings språk"
 ],
 "Edit": [
  null,
  "Rediger"
 ],
 "Edit host": [
  null,
  "Rediger vert"
 ],
 "Edit hosts": [
  null,
  "Rediger verter"
 ],
 "Failed to add machine: $0": [
  null,
  "Kunne ikke legge til maskin: $0"
 ],
 "Failed to change password": [
  null,
  "Kunne ikke endre passord"
 ],
 "Failed to edit machine: $0": [
  null,
  "Kunne ikke redigere maskin: $0"
 ],
 "Fingerprint": [
  null,
  "Fingeravtrykk"
 ],
 "Help": [
  null,
  "Hjelp"
 ],
 "Host": [
  null,
  "Vert"
 ],
 "Hosts": [
  null,
  "Verter"
 ],
 "Invalid file permissions": [
  null,
  "Ugyldige filtillatelser"
 ],
 "Is sshd running on a different port?": [
  null,
  "Kjører sshd på en annen port?"
 ],
 "Kernel dump": [
  null,
  "Kjerne dump"
 ],
 "Key password": [
  null,
  "Nøkkel-passord"
 ],
 "Light": [
  null,
  "Lys"
 ],
 "Limit access": [
  null,
  "Begrens tilgang"
 ],
 "Limited access": [
  null,
  "Begrenset tilgang"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Begrenset tilgangsmodus begrenser administrative rettigheter. Noen deler av webkonsollet har redusert funksjonalitet."
 ],
 "Log in": [
  null,
  "Logg inn"
 ],
 "Log out": [
  null,
  "Logg ut"
 ],
 "Logs": [
  null,
  "Logger"
 ],
 "Managing LVMs": [
  null,
  "Administrere LVMer"
 ],
 "Managing NFS mounts": [
  null,
  "Administrere NFS-monteringer"
 ],
 "Managing RAIDs": [
  null,
  "Administrere RAIDer"
 ],
 "Managing VDOs": [
  null,
  "Administrere VDOer"
 ],
 "Managing VLANs": [
  null,
  "Administrere VLAN"
 ],
 "Managing firewall": [
  null,
  "Administrere brannmur"
 ],
 "Managing networking bonds": [
  null,
  "Administrere nettverksbindinger"
 ],
 "Managing networking bridges": [
  null,
  "Administrere nettverksbroer"
 ],
 "Managing networking teams": [
  null,
  "Administrere nettverksteam"
 ],
 "Managing partitions": [
  null,
  "Administrere partisjoner"
 ],
 "Managing physical drives": [
  null,
  "Administrere fysiske disker"
 ],
 "Managing services": [
  null,
  "Administrere tjenester"
 ],
 "Managing software updates": [
  null,
  "Administrere programvareoppdateringer"
 ],
 "Managing user accounts": [
  null,
  "Administrere brukerkontoer"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Meldinger relatert til feilen kan finnes i journalen:"
 ],
 "Method": [
  null,
  "Metode"
 ],
 "Name": [
  null,
  "Navn"
 ],
 "Networking": [
  null,
  "Nettverk"
 ],
 "New host": [
  null,
  "Ny vert"
 ],
 "New key password": [
  null,
  "Nytt nøkkelpassord"
 ],
 "New password": [
  null,
  "Nytt passord"
 ],
 "New password was not accepted": [
  null,
  "Nytt passord ble ikke godtatt"
 ],
 "No results found": [
  null,
  "Ingen resultater funnet"
 ],
 "No such file or directory": [
  null,
  "Ingen slik fil eller katalog"
 ],
 "Not a valid private key": [
  null,
  "Ikke en gyldig privat nøkkel"
 ],
 "Not connected to host": [
  null,
  "Ikke koblet til verten"
 ],
 "Old password not accepted": [
  null,
  "Gammelt passord aksepteres ikke"
 ],
 "Ooops!": [
  null,
  ""
 ],
 "Overview": [
  null,
  "Oversikt"
 ],
 "Page name": [
  null,
  "Sidenavn"
 ],
 "Password": [
  null,
  "Passord"
 ],
 "Password not accepted": [
  null,
  "Passord ikke akseptert"
 ],
 "Path to file": [
  null,
  "Sti til fil"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentiser for å få administrativ tilgang"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Project website": [
  null,
  "Prosjektets nettsted"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Spørring via ssh-add ble tidsavbrutt"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Spørring via ssh-keygen ble tidsavbrutt"
 ],
 "Public key": [
  null,
  "Offentlig nøkkel"
 ],
 "Reconnect": [
  null,
  "Koble til på nytt"
 ],
 "Remove": [
  null,
  "Fjern"
 ],
 "Reviewing logs": [
  null,
  ""
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-nøkkel"
 ],
 "SSH keys": [
  null,
  "SSH-nøkler"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safari-brukere må importere og stole på sertifikatet for den selvsignerende CA:"
 ],
 "Search": [
  null,
  "Søk"
 ],
 "Select": [
  null,
  "Velg"
 ],
 "Services": [
  null,
  "Tjenester"
 ],
 "Session": [
  null,
  "Økt"
 ],
 "Session is about to expire": [
  null,
  "Økten er i ferd med å utløpe"
 ],
 "Set": [
  null,
  "Sett"
 ],
 "Skip main navigation": [
  null,
  ""
 ],
 "Skip to content": [
  null,
  "Gå til innhold"
 ],
 "Software updates": [
  null,
  "Programvare oppdateringer"
 ],
 "Stop editing hosts": [
  null,
  "Slutt å redigere verter"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Style": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  "Bytt til begrenset tilgang"
 ],
 "System": [
  null,
  "System"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP-adressen eller vertsnavnet kan ikke inneholde mellomrom."
 ],
 "The key password can not be empty": [
  null,
  "Nøkkelpassordet kan ikke være tomt"
 ],
 "The key passwords do not match": [
  null,
  "Nøkkelpassordene stemmer ikke overens"
 ],
 "The machine is rebooting": [
  null,
  "Maskinen starter på nytt"
 ],
 "The new key password can not be empty": [
  null,
  "Det nye nøkkelpassordet kan ikke være tomt"
 ],
 "The passwords do not match.": [
  null,
  "Passordene samsvarer ikke."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Det resulterende fingeravtrykket er greit å dele via offentlige metoder, inkludert e-post."
 ],
 "There are currently no active pages": [
  null,
  "Det er for øyeblikket ingen aktive sider"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Det oppsto en uventet feil under tilkoblingen til maskinen."
 ],
 "This machine has already been added.": [
  null,
  "Denne maskinen er allerede lagt til."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Dette vil tillate deg å logge på uten passord i fremtiden."
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Tips: Gjør at nøkkelpassordet ditt samsvarer med påloggingspassordet ditt for automatisk autentisering mot andre systemer."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "For å sikre at forbindelsen din ikke blir fanget opp av en ondsinnet tredjepart, må du verifisere vertsnøkkelens fingeravtrykk:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "For å bekrefte et fingeravtrykk, kjør følgende på $ 0 mens du sitter fysisk ved maskinen eller gjennom et pålitelig nettverk:"
 ],
 "Toggle": [
  null,
  ""
 ],
 "Tools": [
  null,
  "Verktøy"
 ],
 "Turn on administrative access": [
  null,
  "Slå på administrativ tilgang"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Kan ikke kontakte den angitte verten $0. Forsikre deg om at den har ssh på port $1, eller angi en annen port i adressen."
 ],
 "Unexpected error": [
  null,
  "Uventet feil"
 ],
 "Unlock": [
  null,
  "Lås opp"
 ],
 "Update": [
  null,
  "Oppdater"
 ],
 "Use key": [
  null,
  "Bruk nøkkel"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Bruk følgende nøkler for å autentisere mot andre systemer"
 ],
 "User name": [
  null,
  "Brukernavn"
 ],
 "Using LUKS encryption": [
  null,
  "Bruker LUKS-kryptering"
 ],
 "Using Tang server": [
  null,
  "Bruker Tang-server"
 ],
 "Web Console": [
  null,
  "Web konsoll"
 ],
 "When empty, connect with the current user": [
  null,
  ""
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Du kobler til $0 for første gang."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Du har blitt logget ut på grunn av inaktivitet."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Det kan være lurt å endre passordet til nøkkelen for automatisk pålogging."
 ],
 "You now have administrative access.": [
  null,
  "Du har nå administrativ tilgang."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Du blir logget ut om $0 sekunder."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Nettleseren din husker tilgangsnivået ditt på tvers av øktene."
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "access": [
  null,
  "tilgang"
 ],
 "active": [
  null,
  "aktiv"
 ],
 "add-on": [
  null,
  "tillegg"
 ],
 "addon": [
  null,
  "tillegg"
 ],
 "apps": [
  null,
  "apper"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "eiendomsmerke"
 ],
 "avc": [
  null,
  "avc"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "bond": [
  null,
  "binding"
 ],
 "boot": [
  null,
  "oppstart"
 ],
 "bridge": [
  null,
  "bro"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "kommando"
 ],
 "console": [
  null,
  "konsoll"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "crash": [
  null,
  "krasj"
 ],
 "date": [
  null,
  "dato"
 ],
 "debug": [
  null,
  "debug"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "deaktiver"
 ],
 "disk": [
  null,
  "disk"
 ],
 "disks": [
  null,
  "disker"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "domain": [
  null,
  "domene"
 ],
 "drive": [
  null,
  "dIsk"
 ],
 "enable": [
  null,
  "aktiver"
 ],
 "encryption": [
  null,
  "kryptering"
 ],
 "error": [
  null,
  "feil"
 ],
 "extension": [
  null,
  "utvidelse"
 ],
 "filesystem": [
  null,
  "filsystem"
 ],
 "firewall": [
  null,
  "brannmur"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "format": [
  null,
  "format"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "graphs": [
  null,
  "grafer"
 ],
 "hardware": [
  null,
  "maskinvare"
 ],
 "history": [
  null,
  "historikk"
 ],
 "host": [
  null,
  "vert"
 ],
 "in most browsers": [
  null,
  "i de fleste nettlesere"
 ],
 "install": [
  null,
  "installer"
 ],
 "interface": [
  null,
  "grensesnitt"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "journal": [
  null,
  "journal"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "nøkler"
 ],
 "login": [
  null,
  ""
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mac": [
  null,
  "mac"
 ],
 "machine": [
  null,
  "maskin"
 ],
 "mask": [
  null,
  "maske"
 ],
 "memory": [
  null,
  "minne"
 ],
 "metrics": [
  null,
  ""
 ],
 "mitigation": [
  null,
  ""
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "monter"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "network": [
  null,
  "nettverk"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "operating system": [
  null,
  "operativsystem"
 ],
 "os": [
  null,
  "os"
 ],
 "package": [
  null,
  "pakke"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "partition": [
  null,
  "partisjon"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "passord"
 ],
 "path": [
  null,
  "sti"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "plugin": [
  null,
  "utvidelse"
 ],
 "port": [
  null,
  "port"
 ],
 "power": [
  null,
  ""
 ],
 "raid": [
  null,
  "raid"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "omstart"
 ],
 "roles": [
  null,
  "roller"
 ],
 "security": [
  null,
  "sikkerhet"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  ""
 ],
 "service": [
  null,
  "tjeneste"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ],
 "shell": [
  null,
  "skall"
 ],
 "show less": [
  null,
  "vis mindre"
 ],
 "show more": [
  null,
  "vis mer"
 ],
 "shut": [
  null,
  ""
 ],
 "socket": [
  null,
  ""
 ],
 "sos": [
  null,
  "sos"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "tang"
 ],
 "target": [
  null,
  "mål"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "team"
 ],
 "time": [
  null,
  "tid"
 ],
 "timer": [
  null,
  "timer"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  "enhet"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "unmount": [
  null,
  "unmount"
 ],
 "user": [
  null,
  "bruker"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "brukernavn"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "version": [
  null,
  "versjon"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "volume": [
  null,
  "volum"
 ],
 "warning": [
  null,
  "advarsel"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "sone"
 ]
});
