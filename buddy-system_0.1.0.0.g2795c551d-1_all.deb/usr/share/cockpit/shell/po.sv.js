cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "$0 dokumentation"
 ],
 "$0 key changed": [
  null,
  "$0 nyckel ändrad"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Ingen kompatibel version av Cockpit är installerad på $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "En ny SSH-nyckel på $0 kommer att skapas för $1 på $2 och den kommer att läggas till $3-filen på $4 på $5."
 ],
 "About Web Console": [
  null,
  "Om webkonsolen"
 ],
 "Accept key and connect": [
  null,
  "Acceptera nyckel och anslut"
 ],
 "Accounts": [
  null,
  "Konton"
 ],
 "Active pages": [
  null,
  "Aktiva sidor"
 ],
 "Add": [
  null,
  "Lägg till"
 ],
 "Add key": [
  null,
  "Lägg till nyckel"
 ],
 "Add new host": [
  null,
  "Lägg till ny värd"
 ],
 "Administrative access": [
  null,
  "Administrativ tillgång"
 ],
 "Applications": [
  null,
  "Program"
 ],
 "Apps": [
  null,
  "Program"
 ],
 "Authenticate": [
  null,
  "Autentisera"
 ],
 "Authentication": [
  null,
  "Autentisering"
 ],
 "Authorize SSH key": [
  null,
  "Auktorisera SSH-nyckel"
 ],
 "Automatic login": [
  null,
  "Automatisk inloggning"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Genom att ändra lösenordet för SSH-nyckeln $0 till inloggningslösenordet $1 på $2, kommer nyckeln automatiskt att göras tillgänglig och du kan logga in på $3 utan lösenord i framtiden."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Kan vara ett värdnamn, IP-adress, aliasnamn eller ssh:// URI"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Kan inte ansluta till en okänd maskin"
 ],
 "Change password": [
  null,
  "Ändra lösenord"
 ],
 "Change the password of $0": [
  null,
  "Ändra lösenord av $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Ändrade nycklar är ofta resultatet av en ominstallation av operativsystemet. En oväntad förändring kan dock indikera ett försök från tredje part att avlyssna din anslutning."
 ],
 "Choose the language to be used in the application": [
  null,
  "Välj språk som skall användas i programmet"
 ],
 "Clear search": [
  null,
  "Nollställ sökning"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Close selected pages": [
  null,
  "Stäng valda sidor"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit hade ett oväntat internt fel."
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit är ett interaktivt administratörsgränssnitt för Linuxservrar."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit är inte installerat"
 ],
 "Color": [
  null,
  "Färg"
 ],
 "Comment": [
  null,
  "Kommentar"
 ],
 "Configuring kdump": [
  null,
  "Konfigurerar kdump"
 ],
 "Configuring system settings": [
  null,
  "Konfigurerar systeminställningar"
 ],
 "Confirm key password": [
  null,
  "Bekräfta lösenord för nyckel"
 ],
 "Confirm new key password": [
  null,
  "Bekräfta nytt lösenord för nyckel"
 ],
 "Confirm password": [
  null,
  "Bekräfta lösenord"
 ],
 "Connecting to the machine": [
  null,
  "Ansluter till maskinen"
 ],
 "Connection error": [
  null,
  "Anslutningsfel"
 ],
 "Connection failed": [
  null,
  "Anslutningen misslyckades"
 ],
 "Contains:": [
  null,
  "Innehåller:"
 ],
 "Continue session": [
  null,
  "Fortsätt session"
 ],
 "Copied": [
  null,
  "Kopierade"
 ],
 "Copy": [
  null,
  "Kopiera"
 ],
 "Could not contact $0": [
  null,
  "Kunde inte kontakta $0"
 ],
 "Create": [
  null,
  "Skapa"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Skapa en ny SSH-nyckel och auktorisera den"
 ],
 "Ctrl-Shift-J": [
  null,
  "Ctrl-Skift-J"
 ],
 "Dark": [
  null,
  "Mörk"
 ],
 "Default": [
  null,
  "Standard"
 ],
 "Details": [
  null,
  "Detaljer"
 ],
 "Development": [
  null,
  "Utveckling"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Disconnected": [
  null,
  "Frånkopplad"
 ],
 "Display language": [
  null,
  "Visningsspråk"
 ],
 "Edit": [
  null,
  "Redigera"
 ],
 "Edit host": [
  null,
  "Redigera värd"
 ],
 "Edit hosts": [
  null,
  "Redigera värdar"
 ],
 "Failed to add machine: $0": [
  null,
  "Misslyckades att lägga till en maskin: $0"
 ],
 "Failed to change password": [
  null,
  "Misslyckades att ändra lösenord"
 ],
 "Failed to edit machine: $0": [
  null,
  "Misslyckades att redigera en maskin: $0"
 ],
 "Filter menu items": [
  null,
  "Filtrera menyalternativ"
 ],
 "Fingerprint": [
  null,
  "Fingeravtryck"
 ],
 "Help": [
  null,
  "Hjälp"
 ],
 "Host": [
  null,
  "Värd"
 ],
 "Hosts": [
  null,
  "Värdar"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Om fingeravtrycket stämmer, klicka på 'Acceptera nyckel och anslut'. Annars, anslut inte och kontakta din administratör."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "För att tillåta inloggning till $0 som $1 utan lösenord i framtiden, använd inloggningslösenordet $2 på $3 som nyckellösenord, eller lämna nyckellösenordet tomt."
 ],
 "Invalid file permissions": [
  null,
  "Felaktiga filrättigheter"
 ],
 "Is sshd running on a different port?": [
  null,
  "Kör sshd på en annan port?"
 ],
 "Kernel dump": [
  null,
  "Kärndump"
 ],
 "Key password": [
  null,
  "Nyckellösenord"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Licensierad under GNU LGPL version 2.1"
 ],
 "Light": [
  null,
  "Ljust"
 ],
 "Limit access": [
  null,
  "Begränsa tillgång"
 ],
 "Limited access": [
  null,
  "Begränsad tillgång"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Begränsat läge begränsar administratörsprivilegier och tar bort funktionalitet i delar av webbkonsolen."
 ],
 "Loading packages...": [
  null,
  "Läser in paket..."
 ],
 "Log in": [
  null,
  "Logga in"
 ],
 "Log in to $0": [
  null,
  "Logga in till $0"
 ],
 "Log out": [
  null,
  "Logga ut"
 ],
 "Logs": [
  null,
  "Loggar"
 ],
 "Managing LVMs": [
  null,
  "Hantera LVM:er"
 ],
 "Managing NFS mounts": [
  null,
  "Hantera NFS-monteringar"
 ],
 "Managing RAIDs": [
  null,
  "Hantera RAID:ar"
 ],
 "Managing VDOs": [
  null,
  "Hantera VDO:er"
 ],
 "Managing VLANs": [
  null,
  "Hantera VLAN"
 ],
 "Managing firewall": [
  null,
  "Hantera brandvägg"
 ],
 "Managing networking bonds": [
  null,
  "Hantera nätverksbindningar"
 ],
 "Managing networking bridges": [
  null,
  "Hantera nätverksbryggor"
 ],
 "Managing networking teams": [
  null,
  "Hantera nätverksteam"
 ],
 "Managing partitions": [
  null,
  "Hantera partitioner"
 ],
 "Managing physical drives": [
  null,
  "Hantera fysiska diskar"
 ],
 "Managing services": [
  null,
  "Hantera tjänster"
 ],
 "Managing software updates": [
  null,
  "Hantera programuppdateringar"
 ],
 "Managing user accounts": [
  null,
  "Hantera användarkonton"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "Meddelanden angående detta fel kan finnas i journalen:"
 ],
 "Method": [
  null,
  "Metod"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "New host": [
  null,
  "Ny värd"
 ],
 "New key password": [
  null,
  "Nytt nyckellösenord"
 ],
 "New password": [
  null,
  "Nytt lösenord"
 ],
 "New password was not accepted": [
  null,
  "Det nya lösenordet godtogs inte"
 ],
 "No results found": [
  null,
  "Inga resultat funna"
 ],
 "No such file or directory": [
  null,
  "Filen eller katalogen finns inte"
 ],
 "Not a valid private key": [
  null,
  "Inte en giltig privat nyckel"
 ],
 "Not connected to host": [
  null,
  "Inte ansluten till värd"
 ],
 "Old password not accepted": [
  null,
  "Det gamla lösenordet accepterades inte"
 ],
 "Ooops!": [
  null,
  "Hoppsan!"
 ],
 "Overview": [
  null,
  "Översikt"
 ],
 "Page name": [
  null,
  "Sidnamn"
 ],
 "Password": [
  null,
  "Lösenord"
 ],
 "Password changed successfully": [
  null,
  "Lösenordet har ändrats"
 ],
 "Password not accepted": [
  null,
  "Lösenordet accepterades inte"
 ],
 "Password tip": [
  null,
  "Lösenordstips"
 ],
 "Path to file": [
  null,
  "Sökväg till filen"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentisera för att få administrativ åtkomst"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Problem becoming administrator": [
  null,
  "Problem med att bli administratör"
 ],
 "Project website": [
  null,
  "Projektwebbsajt"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-add"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via ssh-keygen"
 ],
 "Public key": [
  null,
  "Publik nyckel"
 ],
 "Reconnect": [
  null,
  "Återanslut"
 ],
 "Remove": [
  null,
  "Ta bort"
 ],
 "Reviewing logs": [
  null,
  "Granska loggar"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "SSH-nyckel"
 ],
 "SSH keys": [
  null,
  "SSH-nycklar"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Safari-användare måste importera och lita på certifikatet för den självsignerande CA:"
 ],
 "Search": [
  null,
  "Sök"
 ],
 "Select": [
  null,
  "Välj"
 ],
 "Services": [
  null,
  "Tjänster"
 ],
 "Session": [
  null,
  "Session"
 ],
 "Session is about to expire": [
  null,
  "Sessionen är på väg att löpa ut"
 ],
 "Set": [
  null,
  "Sätt"
 ],
 "Skip main navigation": [
  null,
  "Hoppa över huvudnavigationen"
 ],
 "Skip to content": [
  null,
  "Hoppa till innehållet"
 ],
 "Software updates": [
  null,
  "Programvaruuppdateringar"
 ],
 "Stop editing hosts": [
  null,
  "Sluta redigera värdar"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Style": [
  null,
  ""
 ],
 "Switch to administrative access": [
  null,
  "Byt till administrativ åtkomst"
 ],
 "Switch to limited access": [
  null,
  "Byt till begränsad åtkomst"
 ],
 "System": [
  null,
  "System"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "IP-adressen eller värdnamnet får inte innehålla blanktecken."
 ],
 "The SSH key $0 of $1 on $2 will be added to the $3 file of $4 on $5.": [
  null,
  "SSH-nyckeln $0 av $1 på $2 kommer att läggas till $3-filen på $4 på $5."
 ],
 "The SSH key $0 will be made available for the remainder of the session and will be available for login to other hosts as well.": [
  null,
  "SSH-nyckeln $0 kommer att göras tillgänglig för resten av sessionen och kommer att vara tillgänglig för inloggning även för andra värdar."
 ],
 "The SSH key for logging in to $0 is protected by a password, and the host does not allow logging in with a password. Please provide the password of the key at $1.": [
  null,
  "SSH-nyckeln för att logga in på $0 är skyddad av ett lösenord, och värden tillåter inte inloggning med ett lösenord. Vänligen ange lösenordet för nyckeln på $1."
 ],
 "The SSH key for logging in to $0 is protected. You can log in with either your login password or by providing the password of the key at $1.": [
  null,
  "SSH-nyckeln för att logga in på $0 är skyddad. Du kan logga in med antingen ditt inloggningslösenord eller genom att ange lösenordet för nyckeln för $1."
 ],
 "The key password can not be empty": [
  null,
  "Nyckellösenordet får inte vara tomt"
 ],
 "The key passwords do not match": [
  null,
  "Nyckellösenorden stämmer inte överens"
 ],
 "The machine is rebooting": [
  null,
  "Maskinen startar om"
 ],
 "The new key password can not be empty": [
  null,
  "Det nya nyckellösenordet får inte vara tomt"
 ],
 "The password can not be empty": [
  null,
  "Lösenordet får inte vara tomt"
 ],
 "The passwords do not match.": [
  null,
  "Lösenorden stämmer inte överens."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Det resulterande fingeravtrycket går bra att dela via offentliga metoder, inklusive e-post."
 ],
 "There are currently no active pages": [
  null,
  "Det finns för närvarande inga aktiva sidor"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Det uppstod ett oväntat fel vid anslutning till maskinen."
 ],
 "This machine has already been added.": [
  null,
  "Denna maskin har redan lagts till."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Detta gör att du kan logga in utan lösenord i framtiden."
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Tips: gör så att ditt nyckellösenord stämmer med ditt inloggningslösenord för att automatiskt autentisera mot andra system."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "För att säkerställa att din anslutning inte fångas upp av en skadlig tredje part, vänligen verifiera värdnyckelns fingeravtryck:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "För att verifiera ett fingeravtryck, kör följande på $0 medan du fysiskt sitter vid maskinen eller genom ett pålitligt nätverk:"
 ],
 "Toggle": [
  null,
  "Växla"
 ],
 "Tools": [
  null,
  "Verktyg"
 ],
 "Turn on administrative access": [
  null,
  "Aktivera administrativ åtkomst"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unable to contact $0.": [
  null,
  "Det går inte att kontakta $0."
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Det går inte att kontakta den givna värden $0. Se till att ssh körs på port $1, eller ange en annan port i adressen."
 ],
 "Unable to log in to $0 using SSH key authentication. Please provide the password. You may want to set up your SSH keys for automatic login.": [
  null,
  "Det går inte att logga in på $0 med SSH-nyckelautentisering. Ange lösenordet. Du kanske vill ställa in dina SSH-nycklar för automatisk inloggning."
 ],
 "Unable to log in to $0. The host does not accept password login or any of your SSH keys.": [
  null,
  "Det går inte att logga in på $0. Värden accepterar inte lösenordsinloggning eller någon av dina SSH-nycklar."
 ],
 "Unexpected error": [
  null,
  "Oväntat fel"
 ],
 "Unlock": [
  null,
  "Lås upp"
 ],
 "Unlock key $0": [
  null,
  "Lås upp nyckel $0"
 ],
 "Update": [
  null,
  "Uppdatera"
 ],
 "Use key": [
  null,
  "Använd nyckel"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Använd följande nycklar för att autentisera mot andra system"
 ],
 "User name": [
  null,
  "Användarnamn"
 ],
 "Using LUKS encryption": [
  null,
  "Använder LUKS-kryptering"
 ],
 "Using Tang server": [
  null,
  "Använder Tang-server"
 ],
 "Web Console": [
  null,
  "Webbkonsol"
 ],
 "Web console logo": [
  null,
  "Webbkonsolens logotyp"
 ],
 "When empty, connect with the current user": [
  null,
  "När tomt, anslut med den aktuella användaren"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Du ansluter till $0 för första gången."
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Du har blivit utloggad på grund av inaktivitet."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Du kanske vill ändra lösenordet för nyckeln för automatisk inloggning."
 ],
 "You now have administrative access.": [
  null,
  "Du har nu administrativ åtkomst."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Du kommer att loggas ut om $0 sekunder."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Din webbläsare kommer ihåg din åtkomstnivå över sessioner."
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "access": [
  null,
  "åtkomst"
 ],
 "active": [
  null,
  "aktiv"
 ],
 "add-on": [
  null,
  "tillägg"
 ],
 "addon": [
  null,
  "tillägg"
 ],
 "apps": [
  null,
  "program"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "tillgångstagg"
 ],
 "avc": [
  null,
  "avc"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "bond": [
  null,
  "bindning"
 ],
 "boot": [
  null,
  "start"
 ],
 "bridge": [
  null,
  "brygga"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "kommando"
 ],
 "console": [
  null,
  "konsol"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "crash": [
  null,
  "krasch"
 ],
 "date": [
  null,
  "datum"
 ],
 "debug": [
  null,
  "felsök"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "avaktivera"
 ],
 "disk": [
  null,
  "disk"
 ],
 "disks": [
  null,
  "diskar"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "domain": [
  null,
  "domän"
 ],
 "drive": [
  null,
  "disk"
 ],
 "enable": [
  null,
  "aktivera"
 ],
 "encryption": [
  null,
  "kryptering"
 ],
 "error": [
  null,
  "fel"
 ],
 "extension": [
  null,
  "tillägg"
 ],
 "filesystem": [
  null,
  "filsystem"
 ],
 "firewall": [
  null,
  "brandvägg"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "format": [
  null,
  "formatera"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "graphs": [
  null,
  "grafer"
 ],
 "hardware": [
  null,
  "hårdvara"
 ],
 "history": [
  null,
  "historik"
 ],
 "host": [
  null,
  "värd"
 ],
 "in most browsers": [
  null,
  "i de flesta webbläsare"
 ],
 "install": [
  null,
  "installera"
 ],
 "interface": [
  null,
  "gränssnitt"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "journal": [
  null,
  "journal"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "nycklar"
 ],
 "login": [
  null,
  "login"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mac": [
  null,
  "mac"
 ],
 "machine": [
  null,
  "maskin"
 ],
 "mask": [
  null,
  "mask"
 ],
 "memory": [
  null,
  "minne"
 ],
 "metrics": [
  null,
  "mått"
 ],
 "mitigation": [
  null,
  "rättningar"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "montering"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "network": [
  null,
  "nätverk"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "operating system": [
  null,
  "operativsystem"
 ],
 "os": [
  null,
  "os"
 ],
 "package": [
  null,
  "paket"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "partition": [
  null,
  "partition"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "lösenord"
 ],
 "path": [
  null,
  "sökväg"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "prestanda"
 ],
 "plugin": [
  null,
  "insticksmodul"
 ],
 "port": [
  null,
  "port"
 ],
 "power": [
  null,
  "ström"
 ],
 "raid": [
  null,
  "raid"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "starta om"
 ],
 "roles": [
  null,
  "roller"
 ],
 "security": [
  null,
  "säkerhet"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  "seriell"
 ],
 "service": [
  null,
  "tjänst"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ],
 "shell": [
  null,
  "skal"
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ],
 "shut": [
  null,
  "stäng"
 ],
 "socket": [
  null,
  "uttag"
 ],
 "sos": [
  null,
  "sos"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "tang"
 ],
 "target": [
  null,
  "mål"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "team"
 ],
 "time": [
  null,
  "tid"
 ],
 "timer": [
  null,
  "timer"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  "enhet"
 ],
 "unmask": [
  null,
  "avmaskera"
 ],
 "unmount": [
  null,
  "avmontera"
 ],
 "user": [
  null,
  "användare"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "användarnamn"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "version": [
  null,
  "version"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "volume": [
  null,
  "volym"
 ],
 "warning": [
  null,
  "varning"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "zon"
 ]
});
