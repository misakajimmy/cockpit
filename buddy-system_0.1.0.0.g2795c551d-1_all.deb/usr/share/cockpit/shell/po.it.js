cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "$0 documentation": [
  null,
  "Documentazione $0"
 ],
 "$0 key changed": [
  null,
  "Chiave $0 modificata"
 ],
 "A compatible version of Cockpit is not installed on $0.": [
  null,
  "Una versione compatibile di Cockpit non è installata su $0."
 ],
 "A new SSH key at $0 will be created for $1 on $2 and it will be added to the $3 file of $4 on $5.": [
  null,
  "Una nuova chiave SSH in $0 verrà creata per $1 su $2 e sarà aggiunta al file $3 di $4 su $5."
 ],
 "About Web Console": [
  null,
  "Informazioni su Web Console"
 ],
 "Accept key and connect": [
  null,
  "Accetta la chiave e connetti"
 ],
 "Accounts": [
  null,
  "Account"
 ],
 "Active pages": [
  null,
  "Pagine attive"
 ],
 "Add": [
  null,
  "Aggiungi"
 ],
 "Add key": [
  null,
  "Aggiungi chiave"
 ],
 "Add new host": [
  null,
  "Aggiungi un nuovo host"
 ],
 "Administrative access": [
  null,
  "Accesso amministrativo"
 ],
 "Applications": [
  null,
  "Applicazioni"
 ],
 "Apps": [
  null,
  "Applicazioni"
 ],
 "Authenticate": [
  null,
  "Autenticare"
 ],
 "Authentication": [
  null,
  "Autenticazione"
 ],
 "Authorize SSH key": [
  null,
  "Autorizza chiave SSH"
 ],
 "Automatic login": [
  null,
  "Accesso automatico"
 ],
 "By changing the password of the SSH key $0 to the login password of $1 on $2, the key will be automatically made available and you can log in to $3 without password in the future.": [
  null,
  "Cambiando la password della chiave SSH $0 con la password di accesso di $1 su $2, la chiave sarà automaticamente resa disponibile e potrai in futuro accedere a $3 senza password."
 ],
 "Can be a hostname, IP address, alias name, or ssh:// URI": [
  null,
  "Può essere un hostname, un indirizzo IP, un alias, o un URI ssh://"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Cannot connect to an unknown host": [
  null,
  "Impossibile connettersi a un host sconosciuto"
 ],
 "Change password": [
  null,
  "Cambia password"
 ],
 "Change the password of $0": [
  null,
  "Cambia la password di $0"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "La modifica delle chiavi sono di solito il risultato di una reinstallazione del sistema. Tuttavia, una modifica inaspettata può indicare un tentativo di intercettazione da parte di un soggetto terzo."
 ],
 "Choose the language to be used in the application": [
  null,
  "Scegliere la lingua da utilizzare nell'applicazione"
 ],
 "Clear search": [
  null,
  "Cancella Ricerca"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Close selected pages": [
  null,
  "Chiudere le pagine selezionate"
 ],
 "Cockpit had an unexpected internal error.": [
  null,
  "Cockpit ha avuto un errore interno inaspettato"
 ],
 "Cockpit is an interactive Linux server admin interface.": [
  null,
  "Cockpit è un'interfaccia amministrativa interattiva per server Linux."
 ],
 "Cockpit is not installed": [
  null,
  "Cockpit non è installato"
 ],
 "Color": [
  null,
  "Colore"
 ],
 "Comment": [
  null,
  "Commento"
 ],
 "Configuring kdump": [
  null,
  "Configurazione di kdump"
 ],
 "Configuring system settings": [
  null,
  "Configurazione delle impostazioni di sistema"
 ],
 "Confirm key password": [
  null,
  "Conferma la password chiave"
 ],
 "Confirm new key password": [
  null,
  "Conferma la nuova password chiave"
 ],
 "Confirm password": [
  null,
  "Conferma la password"
 ],
 "Connecting to the machine": [
  null,
  "Collegamento alla macchina"
 ],
 "Connection error": [
  null,
  "Errore di connessione"
 ],
 "Connection failed": [
  null,
  "Connessione fallita"
 ],
 "Contains:": [
  null,
  "Contiene:"
 ],
 "Continue session": [
  null,
  "Continua la sessione"
 ],
 "Copied": [
  null,
  "Copiato"
 ],
 "Copy": [
  null,
  "Copia"
 ],
 "Could not contact $0": [
  null,
  "Impossibile contattare $0"
 ],
 "Create": [
  null,
  "Crea"
 ],
 "Create a new SSH key and authorize it": [
  null,
  "Crea una nuova chiave SSH e autorizzala"
 ],
 "Ctrl-Shift-J": [
  null,
  "Ctrl-Shift-J"
 ],
 "Dark": [
  null,
  "Scuro"
 ],
 "Default": [
  null,
  "Predefinito"
 ],
 "Details": [
  null,
  "Dettagli"
 ],
 "Development": [
  null,
  "Sviluppo"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Disconnected": [
  null,
  "Disconnesso"
 ],
 "Display language": [
  null,
  "Lingua di visualizzazione"
 ],
 "Edit": [
  null,
  "Modifica"
 ],
 "Edit host": [
  null,
  "Modifica host"
 ],
 "Edit hosts": [
  null,
  "Modifica host"
 ],
 "Failed to add machine: $0": [
  null,
  "Impossibile aggiungere la macchina: $0"
 ],
 "Failed to change password": [
  null,
  "Impossibile cambiare la password"
 ],
 "Failed to edit machine: $0": [
  null,
  "Impossibile modificare la macchina: $0"
 ],
 "Filter menu items": [
  null,
  "Filtra oggetti menu"
 ],
 "Fingerprint": [
  null,
  "Impronta digitale"
 ],
 "Help": [
  null,
  "Aiuto"
 ],
 "Host": [
  null,
  "Host"
 ],
 "Hosts": [
  null,
  "Host"
 ],
 "If the fingerprint matches, click 'Accept key and connect'. Otherwise, do not connect and contact your administrator.": [
  null,
  "Se l'impronta digitale coincide, clicca 'Accetta la chiave e connetti'. Altrimenti, non connettere e contatta l'amministratore."
 ],
 "In order to allow log in to $0 as $1 without password in the future, use the login password of $2 on $3 as the key password, or leave the key password blank.": [
  null,
  "Per consentire l'accesso a $0 come $1 senza password in futuro, utilizza la password di accesso di $2 su $3 come password della chiave, o lascia vuota la password della chiave."
 ],
 "Invalid file permissions": [
  null,
  "Autorizzazioni file non valide"
 ],
 "Is sshd running on a different port?": [
  null,
  "sshd è in esecuzione su una porta diversa?"
 ],
 "Kernel dump": [
  null,
  "Kernel dump"
 ],
 "Key password": [
  null,
  "Password della chiave"
 ],
 "Licensed under GNU LGPL version 2.1": [
  null,
  "Concesso in licenza sotto GNU LGPL versione 2.1"
 ],
 "Light": [
  null,
  "Chiaro"
 ],
 "Limit access": [
  null,
  "Limitare l'accesso"
 ],
 "Limited access": [
  null,
  "Accesso limitato"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "La modalità di accesso limitato limita i privilegi di amministratore. Alcune parti della Web Console avranno funzionalità ridotte."
 ],
 "Loading packages...": [
  null,
  "Caricamento pacchetti..."
 ],
 "Log in": [
  null,
  "Accedi"
 ],
 "Log in to $0": [
  null,
  "Entra in $0"
 ],
 "Log out": [
  null,
  "Esci"
 ],
 "Logs": [
  null,
  "Log"
 ],
 "Managing LVMs": [
  null,
  "Gestione dei LVM"
 ],
 "Managing NFS mounts": [
  null,
  "Gestione dei montaggi NFS"
 ],
 "Managing RAIDs": [
  null,
  "Gestione RAID"
 ],
 "Managing VDOs": [
  null,
  "Gestione VDO"
 ],
 "Managing VLANs": [
  null,
  "Gestione VLAN"
 ],
 "Managing firewall": [
  null,
  "Gestione del firewall"
 ],
 "Managing networking bonds": [
  null,
  "Gestendo bond di rete"
 ],
 "Managing networking bridges": [
  null,
  "Gestendo ponti della rete"
 ],
 "Managing networking teams": [
  null,
  "Gestendo team della rete"
 ],
 "Managing partitions": [
  null,
  "Gestione delle partizioni"
 ],
 "Managing physical drives": [
  null,
  "Gestione dei drive fisici"
 ],
 "Managing services": [
  null,
  "Gestione dei servizi"
 ],
 "Managing software updates": [
  null,
  "Gestione degli aggiornamenti software"
 ],
 "Managing user accounts": [
  null,
  "Gestione degli account utente"
 ],
 "Messages related to the failure might be found in the journal:": [
  null,
  "I messaggi relativi all'errore potrebbero essere trovati nel registro:"
 ],
 "Method": [
  null,
  "Metodo"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Networking": [
  null,
  "Rete"
 ],
 "New host": [
  null,
  "Nuovo host"
 ],
 "New key password": [
  null,
  "Nuova password della chiave"
 ],
 "New password": [
  null,
  "Nuova password"
 ],
 "New password was not accepted": [
  null,
  "La nuova password non è stata accettata"
 ],
 "No results found": [
  null,
  "nessun risultato trovato"
 ],
 "No such file or directory": [
  null,
  "Nessun file o directory"
 ],
 "Not a valid private key": [
  null,
  "Chiave privata invalida"
 ],
 "Not connected to host": [
  null,
  "Non connesso all'host"
 ],
 "Old password not accepted": [
  null,
  "Vecchia password non accettata"
 ],
 "Ooops!": [
  null,
  "Ooops!"
 ],
 "Overview": [
  null,
  "Panoramica"
 ],
 "Page name": [
  null,
  "Nome pagina"
 ],
 "Password": [
  null,
  "Password"
 ],
 "Password not accepted": [
  null,
  "Password non accettata"
 ],
 "Path to file": [
  null,
  "Percorso del file"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autenticarsi per ottenere l'accesso amministrativo"
 ],
 "Port": [
  null,
  "Porta"
 ],
 "Project website": [
  null,
  "Sito web del progetto"
 ],
 "Prompting via ssh-add timed out": [
  null,
  "Richiesta tramite ssh-add scaduta"
 ],
 "Prompting via ssh-keygen timed out": [
  null,
  "Richiesta tramite ssh-keygen scaduta"
 ],
 "Public key": [
  null,
  "Chiave pubblica"
 ],
 "Reconnect": [
  null,
  "Ricollego"
 ],
 "Remove": [
  null,
  "Elimina"
 ],
 "Reviewing logs": [
  null,
  "Revisione dei log"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "SSH key": [
  null,
  "Chiave SSH"
 ],
 "SSH keys": [
  null,
  "Chiavi SSH"
 ],
 "Safari users need to import and trust the certificate of the self-signing CA:": [
  null,
  "Gli utenti di Safari devono importare e fidarsi del certificato della CA autofirmata:"
 ],
 "Search": [
  null,
  "Ricerca"
 ],
 "Select": [
  null,
  "Seleziona"
 ],
 "Services": [
  null,
  "Servizi"
 ],
 "Session": [
  null,
  "Sessione"
 ],
 "Session is about to expire": [
  null,
  "La sessione sta per scadere"
 ],
 "Set": [
  null,
  "Imposta"
 ],
 "Skip main navigation": [
  null,
  "Salta la navigazione principale"
 ],
 "Skip to content": [
  null,
  "Salta al contenuto"
 ],
 "Software updates": [
  null,
  "Aggiornamenti software"
 ],
 "Stop editing hosts": [
  null,
  "Interrompi la modifica degli host"
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Style": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  "Passa ad accesso limitato"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "Terminal": [
  null,
  "Terminale"
 ],
 "The IP address or hostname cannot contain whitespace.": [
  null,
  "L'indirizzo IP o il nome host non possono contenere spazi."
 ],
 "The key password can not be empty": [
  null,
  "La password della chiave non può essere vuota"
 ],
 "The key passwords do not match": [
  null,
  "Le password della chiave non corrispondono"
 ],
 "The new key password can not be empty": [
  null,
  "La nuova password della chiave non può essere vuota"
 ],
 "The passwords do not match.": [
  null,
  "Le password non corrispondono."
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L'impronta digitale risultante è idonea per la condivisione pubblica, email inclusa."
 ],
 "There are currently no active pages": [
  null,
  "Attualmente non ci sono pagine attive"
 ],
 "There was an unexpected error while connecting to the machine.": [
  null,
  "Si è verificato un errore imprevisto durante la connessione alla macchina."
 ],
 "This machine has already been added.": [
  null,
  "Questa macchina è già stata aggiunta."
 ],
 "This will allow you to log in without password in the future.": [
  null,
  "Ciò ti consentirà di accedere senza password in futuro."
 ],
 "Tip: Make your key password match your login password to automatically authenticate against other systems.": [
  null,
  "Suggerimento: fai in modo che la password della tua chiave corrisponda alla password di accesso per l'autenticazione automatica in altri sistemi."
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Per assicurare che la connessione non sia intercettata da un soggetto terzo malelvolo, verifica l'impronta digitale dell'host:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Per verificare un'impronta digitale, esegui su $0 mentre sei fisicamente di fronte alla macchina o attraverso una rete fidata:"
 ],
 "Toggle": [
  null,
  "Attiva/disattiva"
 ],
 "Tools": [
  null,
  "Strumenti"
 ],
 "Turn on administrative access": [
  null,
  "Attiva l'accesso amministrativo"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Unable to contact the given host $0. Make sure it has ssh running on port $1, or specify another port in the address.": [
  null,
  "Impossibile contattare l'host specificato $0. Assicurati che ssh sia in esecuzione sulla porta $1 o specifica un'altra porta nell'indirizzo."
 ],
 "Unexpected error": [
  null,
  "Errore imprevisto"
 ],
 "Unlock": [
  null,
  "Sblocca"
 ],
 "Update": [
  null,
  "Aggiorna"
 ],
 "Use the following keys to authenticate against other systems": [
  null,
  "Utilizza le seguenti chiavi per autenticarti in altri sistemi"
 ],
 "User name": [
  null,
  "Nome utente"
 ],
 "Web Console": [
  null,
  "Web Console"
 ],
 "When empty, connect with the current user": [
  null,
  "Se vuoti, connetti con l'utente corrente"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Collegamento a $0 per la prima volta"
 ],
 "You have been logged out due to inactivity.": [
  null,
  "Sei stato disconnesso per inattività."
 ],
 "You may want to change the password of the key for automatic login.": [
  null,
  "Potrebbe essere necessario modificare la password della chiave per l'accesso automatico."
 ],
 "You now have administrative access.": [
  null,
  "Ora hai accesso amministrativo."
 ],
 "You will be logged out in $0 seconds.": [
  null,
  "Verrai disconnesso tra $0 secondi."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Il tuo browser ricorderà il tuo livello di accesso tra le sessioni."
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "access": [
  null,
  "accesso"
 ],
 "active": [
  null,
  "attivo"
 ],
 "add-on": [
  null,
  "add-on"
 ],
 "addon": [
  null,
  "componente aggiuntivo"
 ],
 "apps": [
  null,
  "applicazioni"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "asset tag": [
  null,
  "asset tag"
 ],
 "avc": [
  null,
  "avc"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "bond": [
  null,
  "bond"
 ],
 "boot": [
  null,
  "avvio"
 ],
 "bridge": [
  null,
  "bridge"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "comando"
 ],
 "console": [
  null,
  "console"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "crash": [
  null,
  "crash"
 ],
 "date": [
  null,
  "data"
 ],
 "debug": [
  null,
  "debug"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "disabilita"
 ],
 "disk": [
  null,
  "disco"
 ],
 "disks": [
  null,
  "dischi"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "domain": [
  null,
  "dominio"
 ],
 "drive": [
  null,
  "disco"
 ],
 "enable": [
  null,
  "abilita"
 ],
 "encryption": [
  null,
  "crittografia"
 ],
 "error": [
  null,
  "errore"
 ],
 "extension": [
  null,
  "estensione"
 ],
 "filesystem": [
  null,
  "file system"
 ],
 "firewall": [
  null,
  "firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "graphs": [
  null,
  "grafici"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "history": [
  null,
  "cronologia"
 ],
 "host": [
  null,
  "host"
 ],
 "in most browsers": [
  null,
  "nella maggior parte dei browser"
 ],
 "install": [
  null,
  "installa"
 ],
 "interface": [
  null,
  "interfaccia"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "journal": [
  null,
  "registro"
 ],
 "kdump": [
  null,
  "kdump"
 ],
 "keys": [
  null,
  "chiavi"
 ],
 "login": [
  null,
  "accesso"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mac": [
  null,
  "mac"
 ],
 "machine": [
  null,
  "macchina"
 ],
 "mask": [
  null,
  "maschera"
 ],
 "memory": [
  null,
  "memoria"
 ],
 "metrics": [
  null,
  "metriche"
 ],
 "mitigation": [
  null,
  "mitigazione"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "mount"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "network": [
  null,
  "rete"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "operating system": [
  null,
  "sistema operativo"
 ],
 "os": [
  null,
  "os"
 ],
 "package": [
  null,
  "pacchetto"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "partition": [
  null,
  "partizione"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "password"
 ],
 "path": [
  null,
  "percorso"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "plugin": [
  null,
  "plugin"
 ],
 "port": [
  null,
  "porta"
 ],
 "power": [
  null,
  "alimentazione"
 ],
 "raid": [
  null,
  "raid"
 ],
 "ram": [
  null,
  "ram"
 ],
 "restart": [
  null,
  "riavvia"
 ],
 "roles": [
  null,
  "ruoli"
 ],
 "security": [
  null,
  "sicurezza"
 ],
 "semanage": [
  null,
  "semanage"
 ],
 "serial": [
  null,
  "seriale"
 ],
 "service": [
  null,
  "servizio"
 ],
 "setroubleshoot": [
  null,
  "setroubleshoot"
 ],
 "shell": [
  null,
  "shell"
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ],
 "shut": [
  null,
  "shut"
 ],
 "socket": [
  null,
  "socket"
 ],
 "sos": [
  null,
  "sos"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "tang": [
  null,
  "tang"
 ],
 "target": [
  null,
  "destinazione"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "team"
 ],
 "time": [
  null,
  "ora"
 ],
 "timer": [
  null,
  "timer"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "udp": [
  null,
  "udp"
 ],
 "unit": [
  null,
  "unità"
 ],
 "unmount": [
  null,
  "smonta"
 ],
 "user": [
  null,
  "utente"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "nome utente"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "version": [
  null,
  "versione"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "volume": [
  null,
  "volume"
 ],
 "warning": [
  null,
  "avviso"
 ],
 "yum": [
  null,
  "yum"
 ],
 "zone": [
  null,
  "zona"
 ]
});
