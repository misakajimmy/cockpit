cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 ГиБ"
 ],
 "$0 critical hit": [
  null,
  "$0 критическое попадание",
  "$0 попадания, включая критическое",
  "$0 попаданий, включая критическое"
 ],
 "$0 failed login attempt": [
  null,
  "$0 неудачная попытка входа в систему",
  "$0 неудачные попытки входа в систему",
  "$0 неудачных попыток входа в систему"
 ],
 "$0 important hit": [
  null,
  "$0 важное попадание",
  "$0 попадания, включая важное",
  "$0 попаданий, включая важное"
 ],
 "$0 is not available from any repository.": [
  null,
  "Компонент $0 недоступен в репозиториях."
 ],
 "$0 low severity hit": [
  null,
  "$0 попадание с низким уровнем серьезности",
  "$0 попадания с низким уровнем серьезности",
  "$0 попаданий с низким уровнем серьезности"
 ],
 "$0 moderate hit": [
  null,
  "$0 умеренное попадание",
  "$0 попадания, включая умеренные",
  "$0 попаданий, включая умеренные"
 ],
 "$0 service has failed": [
  null,
  "Сбой $0 службы",
  "Сбой $0 служб",
  "Сбой $0 служб"
 ],
 "$0 will be installed.": [
  null,
  "Будет выполнена установка $0."
 ],
 "$0: crash at $1": [
  null,
  "$0: сбой в $1"
 ],
 "1 minute": [
  null,
  "1 минута"
 ],
 "10th": [
  null,
  "10-го числа"
 ],
 "11th": [
  null,
  "11-го числа"
 ],
 "12th": [
  null,
  "12-го числа"
 ],
 "13th": [
  null,
  "13-го числа"
 ],
 "14th": [
  null,
  "14-го числа"
 ],
 "15th": [
  null,
  "15-го числа"
 ],
 "16th": [
  null,
  "16-го числа"
 ],
 "17th": [
  null,
  "17-го числа"
 ],
 "18th": [
  null,
  "18-го числа"
 ],
 "19th": [
  null,
  "19-го числа"
 ],
 "1st": [
  null,
  "1-го числа"
 ],
 "20 minutes": [
  null,
  "20 минут"
 ],
 "20th": [
  null,
  "20-го числа"
 ],
 "21th": [
  null,
  "21-го числа"
 ],
 "22th": [
  null,
  "22-го числа"
 ],
 "23th": [
  null,
  "23-го числа"
 ],
 "24th": [
  null,
  "24-го числа"
 ],
 "25th": [
  null,
  "25-го числа"
 ],
 "26th": [
  null,
  "26-го числа"
 ],
 "27th": [
  null,
  "27-го числа"
 ],
 "28th": [
  null,
  "28-го числа"
 ],
 "29th": [
  null,
  "29-го числа"
 ],
 "2nd": [
  null,
  "2-го числа"
 ],
 "30th": [
  null,
  "30-го числа"
 ],
 "31st": [
  null,
  "31-го числа"
 ],
 "3rd": [
  null,
  "3-го числа"
 ],
 "40 minutes": [
  null,
  "40 минут"
 ],
 "4th": [
  null,
  "4-го числа"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "5th": [
  null,
  "5-го числа"
 ],
 "60 minutes": [
  null,
  "60 минут"
 ],
 "6th": [
  null,
  "6-го числа"
 ],
 "7th": [
  null,
  "7-го числа"
 ],
 "8th": [
  null,
  "8-го числа"
 ],
 "9th": [
  null,
  "9-го числа"
 ],
 "Absent": [
  null,
  "Отсутствует"
 ],
 "Active since ": [
  null,
  "Активно с"
 ],
 "Active state": [
  null,
  "Активное состояние"
 ],
 "Add": [
  null,
  "Добавить"
 ],
 "Additional actions": [
  null,
  "Дополнительные действия"
 ],
 "Additional packages:": [
  null,
  "Дополнительные пакеты:"
 ],
 "Administrative access": [
  null,
  "Административный доступ"
 ],
 "Advanced TCA": [
  null,
  "Расширенный TCA"
 ],
 "After": [
  null,
  "After="
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "После выхода из домена только пользователи с локальными учётными данными смогут выполнить вход в эту систему. Это также может повлиять и на другие службы, поскольку параметры разрешения DNS и список доверенных центров сертификации могут измениться."
 ],
 "After system boot": [
  null,
  "После загрузки системы"
 ],
 "Alert and above": [
  null,
  "Оповещения и выше"
 ],
 "Alias": [
  null,
  "Псевдоним"
 ],
 "All": [
  null,
  "Все"
 ],
 "All-in-one": [
  null,
  "Все в одном"
 ],
 "Allow running (unmask)": [
  null,
  "Разрешить выполнение (снять маску)"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Любая текстовая строка в сообщениях журнала может быть отфильтрована. Строка также может быть представлена в виде регулярного выражения. Также поддерживает фильтрацию по полям журнала сообщений. Это значения, разделенные пробелами, в форме ПОЛЕ=ЗНАЧЕНИЕ, где значение может быть списком возможных значений, разделенных запятыми."
 ],
 "Appearance": [
  null,
  "Стиль отображения"
 ],
 "Apply and reboot": [
  null,
  "Применить и перезагрузить"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Применение новой политики... Это может занять несколько минут."
 ],
 "Asset tag": [
  null,
  "Тег актива"
 ],
 "At minute": [
  null,
  "В минуту"
 ],
 "At specific time": [
  null,
  "В определённое время"
 ],
 "Authenticate": [
  null,
  "Проверка подлинности"
 ],
 "Automatically starts": [
  null,
  "Запускается автоматически"
 ],
 "Automatically using NTP": [
  null,
  "Автоматически с использованием серверов NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматически с использованием определённых серверов NTP"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "Дата BIOS"
 ],
 "BIOS version": [
  null,
  "Версия BIOS"
 ],
 "Bad": [
  null,
  "Плохо"
 ],
 "Bad setting": [
  null,
  "Плохой параметр"
 ],
 "Before": [
  null,
  "Before="
 ],
 "Binds to": [
  null,
  "BindsTo="
 ],
 "Black": [
  null,
  "Чёрный"
 ],
 "Blade": [
  null,
  "Ультракомпактный сервер"
 ],
 "Blade enclosure": [
  null,
  "Корзина"
 ],
 "Boot": [
  null,
  "Загрузка"
 ],
 "Bound by": [
  null,
  "BoundBy="
 ],
 "Bus expansion chassis": [
  null,
  "Корпус расширения шины"
 ],
 "CPU": [
  null,
  "ЦП"
 ],
 "CPU security": [
  null,
  "Безопасность процессора"
 ],
 "CPU security toggles": [
  null,
  "Переключатели безопасности ЦП"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Не удается найти журналы на основе текущего сочетания фильтров."
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Cancel poweroff": [
  null,
  "Отменить выключение"
 ],
 "Cancel reboot": [
  null,
  "Отменить перезагрузку"
 ],
 "Cannot be enabled": [
  null,
  "Не может быть активирован"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Не удается присоединиться к домену, потому что на этой системе нет realmd"
 ],
 "Cannot schedule event in the past": [
  null,
  "Невозможно запланировать событие в прошлом"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Change crypto policy": [
  null,
  "Изменить правила шифрования"
 ],
 "Change host name": [
  null,
  "Изменить имя узла"
 ],
 "Change performance profile": [
  null,
  "Изменить профиль производительности"
 ],
 "Change profile": [
  null,
  "Изменить профиль"
 ],
 "Change system time": [
  null,
  "Изменить системное время"
 ],
 "Checking installed software": [
  null,
  "Проверка установленного программного обеспечения"
 ],
 "Class": [
  null,
  "Класс"
 ],
 "Clear 'Failed to start'": [
  null,
  "Очистить «Сбой запуска»"
 ],
 "Client software": [
  null,
  "Клиентское программное обеспечение"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Command": [
  null,
  "Команда"
 ],
 "Command not found": [
  null,
  "Команда не найдена"
 ],
 "Communication with tuned has failed": [
  null,
  "Сбой связи с демоном tuned"
 ],
 "Compact PCI": [
  null,
  "Компактный PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Не выполнено условие $0=$1"
 ],
 "Condition failed": [
  null,
  "Условие не выполнено"
 ],
 "Configuration": [
  null,
  "Настройка"
 ],
 "Configuring system settings": [
  null,
  "Настройка параметров системы"
 ],
 "Confirm deletion of $0": [
  null,
  "Подтвердите удаление $0"
 ],
 "Conflicted by": [
  null,
  "ConflictedBy="
 ],
 "Conflicts": [
  null,
  "Conflicts="
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Не удалось подключиться к dbus: $0"
 ],
 "Consists of": [
  null,
  "ConsistsOf="
 ],
 "Contacted domain": [
  null,
  "Связь с доменом установлена"
 ],
 "Controller": [
  null,
  "Контроллер"
 ],
 "Convertible": [
  null,
  "Компьютер-трансформер"
 ],
 "Copy": [
  null,
  "Копировать"
 ],
 "Copy to clipboard": [
  null,
  "Копировать в буфер обмена"
 ],
 "Crash reporting": [
  null,
  "Сообщение о сбое"
 ],
 "Create timer": [
  null,
  "Создать таймер"
 ],
 "Critical and above": [
  null,
  "Критические оповещения и выше"
 ],
 "Crypto Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  ""
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Текущая сессия"
 ],
 "Daily": [
  null,
  ""
 ],
 "Dark": [
  null,
  "Тёмный"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  ""
 ],
 "Debug and above": [
  null,
  "Отладочные сообщения и выше"
 ],
 "Decrease by one": [
  null,
  ""
 ],
 "Delay": [
  null,
  "Задержка"
 ],
 "Delete": [
  null,
  "Удалить"
 ],
 "Deletion will remove the following files:": [
  null,
  ""
 ],
 "Description": [
  null,
  "Описание"
 ],
 "Desktop": [
  null,
  "Настольный компьютер"
 ],
 "Detachable": [
  null,
  "Съёмный компьютер"
 ],
 "Details": [
  null,
  "Подробности"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Отключить одновременную многопотоковость"
 ],
 "Disable tuned": [
  null,
  "Отключить демон tuned"
 ],
 "Disabled": [
  null,
  "Отключено"
 ],
 "Disallow running (mask)": [
  null,
  "Запретить выполнение (добавить маску)"
 ],
 "Docking station": [
  null,
  "Стыковочный узел"
 ],
 "Domain": [
  null,
  "Домен"
 ],
 "Domain address": [
  null,
  "Адрес домена"
 ],
 "Domain administrator name": [
  null,
  "Имя администратора домена"
 ],
 "Domain administrator password": [
  null,
  "Пароль администратора домена"
 ],
 "Don't repeat": [
  null,
  "Без повтора"
 ],
 "Downloading $0": [
  null,
  "Загрузка $0"
 ],
 "Dual rank": [
  null,
  "Двухранговая"
 ],
 "Embedded PC": [
  null,
  "Встраиваемый компьютер"
 ],
 "Enabled": [
  null,
  "Включено"
 ],
 "Entry at $0": [
  null,
  "Запись в $0"
 ],
 "Error": [
  null,
  "Ошибка"
 ],
 "Error and above": [
  null,
  "Сообщения об ошибках и выше"
 ],
 "Expansion chassis": [
  null,
  "Корпус расширения"
 ],
 "Extended information": [
  null,
  "Расширенная информация"
 ],
 "FIPS is not properly enabled": [
  null,
  ""
 ],
 "Failed to disable tuned": [
  null,
  "Не удалось отключить демон tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Не удалось включить демон tuned"
 ],
 "Failed to start": [
  null,
  "Сбой запуска"
 ],
 "Failed to switch profile": [
  null,
  "Не удалось переключить профиль"
 ],
 "Forbidden from running": [
  null,
  "Выполнение запрещено"
 ],
 "Fridays": [
  null,
  "По пятницам"
 ],
 "General": [
  null,
  "Общее"
 ],
 "Hardware information": [
  null,
  "Сведения об оборудовании"
 ],
 "Health": [
  null,
  "Здоровье"
 ],
 "Help": [
  null,
  "Помощь"
 ],
 "Hierarchy ID": [
  null,
  ""
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  ""
 ],
 "Hostname": [
  null,
  "Имя узла"
 ],
 "Hours": [
  null,
  "ч"
 ],
 "ID": [
  null,
  "Идентификатор"
 ],
 "Identifier": [
  null,
  ""
 ],
 "Increase by one": [
  null,
  ""
 ],
 "Info and above": [
  null,
  "Информационные сообщения и выше"
 ],
 "Insights: ": [
  null,
  "Анализ: "
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Install software": [
  null,
  "Установка программного обеспечения"
 ],
 "Installing $0": [
  null,
  "Установка $0"
 ],
 "Invalid date format": [
  null,
  "Недопустимый формат даты"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Недопустимый формат даты и недопустимый формат времени"
 ],
 "Invalid time format": [
  null,
  "Недопустимый формат времени"
 ],
 "IoT gateway": [
  null,
  "Шлюз Интернета вещей"
 ],
 "Join": [
  null,
  "Присоединиться"
 ],
 "Join domain": [
  null,
  "Присоединиться к домену"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Присоединение к этому домену требует установки realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Присоединение к этому домену не поддерживается"
 ],
 "Joins namespace of": [
  null,
  "JoinsNamespaceOf="
 ],
 "Journal": [
  null,
  "Журнал"
 ],
 "Journal entry": [
  null,
  "Запись в журнале"
 ],
 "Journal entry not found": [
  null,
  "Запись в журнале не найдена"
 ],
 "Laptop": [
  null,
  "Полноразмерный ноутбук"
 ],
 "Last 24 hours": [
  null,
  "Последние 24 часа"
 ],
 "Last 7 days": [
  null,
  "Последние 7 дней"
 ],
 "Learn more": [
  null,
  "Подробнее..."
 ],
 "Leave domain": [
  null,
  "Выйти из домена"
 ],
 "Light": [
  null,
  "Светлый"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  ""
 ],
 "Listing unit files": [
  null,
  ""
 ],
 "Listing unit files failed: $0": [
  null,
  ""
 ],
 "Load earlier entries": [
  null,
  "Загрузить более ранние записи"
 ],
 "Loading...": [
  null,
  "Загрузка..."
 ],
 "Log messages": [
  null,
  "Сообщения журнала"
 ],
 "Login format": [
  null,
  "Формат учётной записи"
 ],
 "Logs": [
  null,
  "Журналы"
 ],
 "Low profile desktop": [
  null,
  "Низкопрофильный настольный компьютер"
 ],
 "Lunch box": [
  null,
  "Портативный компьютер в ударопрочном корпусе"
 ],
 "Machine ID": [
  null,
  "Идентификатор системы"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Отпечатки SSH-ключей компьютера"
 ],
 "Main server chassis": [
  null,
  "Главный серверный корпус"
 ],
 "Managing services": [
  null,
  "Управление службами"
 ],
 "Manually": [
  null,
  "Вручную"
 ],
 "Mask service": [
  null,
  "Скрыть службу"
 ],
 "Masked": [
  null,
  "Скрыто"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Маскирование службы делает невозможным выполнение всех связанных с ней служб. Эффект может оказаться серьёзнее, чем кажется. Подтвердите маскирование данной службы."
 ],
 "Memory": [
  null,
  "Память"
 ],
 "Memory technology": [
  null,
  "Технология памяти"
 ],
 "Merged": [
  null,
  ""
 ],
 "Message to logged in users": [
  null,
  "Сообщение для вошедших пользователей"
 ],
 "Method": [
  null,
  ""
 ],
 "Mini PC": [
  null,
  "Мини-ПК"
 ],
 "Mini tower": [
  null,
  "Компьютер в корпусе «мини-башня»"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Количество минут должно лежать в интервале от 0 до 59"
 ],
 "Minutes": [
  null,
  "мин"
 ],
 "Mitigations": [
  null,
  "Меры по защите"
 ],
 "Model": [
  null,
  "Модель"
 ],
 "Mondays": [
  null,
  "По понедельникам"
 ],
 "Monthly": [
  null,
  ""
 ],
 "Multi-system chassis": [
  null,
  "Корпус для нескольких систем"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Need at least one NTP server": [
  null,
  "Требуется по крайней мере один сервер NTP"
 ],
 "No": [
  null,
  "Нет"
 ],
 "No delay": [
  null,
  "Без задержки"
 ],
 "No host keys found.": [
  null,
  "Ключи узла не найдены."
 ],
 "No log entries": [
  null,
  "Нет записей в журнале"
 ],
 "No logs found": [
  null,
  "Журналов не найдено"
 ],
 "No results found": [
  null,
  "Нет результатов"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  ""
 ],
 "No rule hits": [
  null,
  "Нет совпадений с правилами"
 ],
 "None": [
  null,
  "Нет"
 ],
 "Not connected to Insights": [
  null,
  "Нет подключения к Insights"
 ],
 "Not found": [
  null,
  "Не найдено"
 ],
 "Not running": [
  null,
  "Не работает"
 ],
 "Not synchronized": [
  null,
  "Не синхронизировано"
 ],
 "Note": [
  null,
  "Примечание"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Notice and above": [
  null,
  "Уведомления и выше"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "On failure": [
  null,
  "OnFailure="
 ],
 "Only emergency": [
  null,
  "Только экстренные оповещения"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  ""
 ],
 "Other": [
  null,
  "Прочее"
 ],
 "Overview": [
  null,
  "Обзор"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "Part of": [
  null,
  "PartOf="
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Paste": [
  null,
  "Вставить"
 ],
 "Path": [
  null,
  "Путь"
 ],
 "Paths": [
  null,
  "Пути"
 ],
 "Pause": [
  null,
  "Приостановить"
 ],
 "Performance profile": [
  null,
  "Профиль производительности"
 ],
 "Peripheral chassis": [
  null,
  "Корпус для периферийных устройств"
 ],
 "Pinned unit": [
  null,
  ""
 ],
 "Pizza box": [
  null,
  "Ультратонкий корпус"
 ],
 "Please authenticate to gain administrative access": [
  null,
  ""
 ],
 "Portable": [
  null,
  "Портативный компьютер"
 ],
 "Present": [
  null,
  "Присутствует"
 ],
 "Pretty host name": [
  null,
  "Автоматическое имя узла"
 ],
 "Previous boot": [
  null,
  "Предыдущая загрузка"
 ],
 "Priority": [
  null,
  "Приоритет"
 ],
 "Problem details": [
  null,
  "Подробности проблемы"
 ],
 "Problem info": [
  null,
  "Информация о проблеме"
 ],
 "Propagates reload to": [
  null,
  "PropagatesReloadTo="
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  ""
 ],
 "RAID chassis": [
  null,
  "Корпус для RAID-массива"
 ],
 "Rack mount chassis": [
  null,
  "Монтируемый в стойку корпус"
 ],
 "Rank": [
  null,
  "Ранг"
 ],
 "Read more...": [
  null,
  "Подробнее..."
 ],
 "Read-only": [
  null,
  "Только для чтения"
 ],
 "Real host name": [
  null,
  "Реальное имя узла"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Реальное имя узла может содержать только строчные буквы, цифры, тире и точки (с заполненными поддоменами)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Реальное имя узла должно содержать не более 64 символов"
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  ""
 ],
 "Reload": [
  null,
  "Перезагрузить"
 ],
 "Reload propagated from": [
  null,
  "ReloadPropagatedFrom="
 ],
 "Removals:": [
  null,
  "Для удаления:"
 ],
 "Remove": [
  null,
  "Удалить"
 ],
 "Removing $0": [
  null,
  "Удаление $0"
 ],
 "Repeat weekly": [
  null,
  "Повторять еженедельно"
 ],
 "Report": [
  null,
  "Сообщить"
 ],
 "Report to ABRT Analytics": [
  null,
  "Сообщить в ABRT Analytics"
 ],
 "Reported; no links available": [
  null,
  "Сообщение сделано; нет ссылок"
 ],
 "Reporting failed": [
  null,
  "Сообщение не удалось"
 ],
 "Reporting was canceled": [
  null,
  "Отчеты отменены"
 ],
 "Reports:": [
  null,
  "Отчеты:"
 ],
 "Required by": [
  null,
  "RequiredBy="
 ],
 "Required by ": [
  null,
  "Требуется для "
 ],
 "Requires": [
  null,
  "Requires="
 ],
 "Requires administration access to edit": [
  null,
  "Для изменения необходимы права администратора"
 ],
 "Requisite": [
  null,
  "Requisite="
 ],
 "Requisite of": [
  null,
  "RequisiteOf="
 ],
 "Reset": [
  null,
  "Сброс"
 ],
 "Restart": [
  null,
  "Перезапустить"
 ],
 "Resume": [
  null,
  "Возобновить"
 ],
 "Reviewing logs": [
  null,
  "Просмотр журналов"
 ],
 "Run on": [
  null,
  ""
 ],
 "Running": [
  null,
  "Работает"
 ],
 "Saturdays": [
  null,
  "По субботам"
 ],
 "Save": [
  null,
  "Сохранить"
 ],
 "Save and reboot": [
  null,
  "Сохранить и перезагрузить"
 ],
 "Scheduled poweroff at $0": [
  null,
  ""
 ],
 "Scheduled reboot at $0": [
  null,
  ""
 ],
 "Sealed-case PC": [
  null,
  "Компьютер с невскрываемым корпусом"
 ],
 "Search": [
  null,
  "Поиск"
 ],
 "Seconds": [
  null,
  "с"
 ],
 "Secure shell keys": [
  null,
  "Ключи Secure Shell"
 ],
 "Send": [
  null,
  "Отправить"
 ],
 "Server software": [
  null,
  "Серверное программное обеспечение"
 ],
 "Service logs": [
  null,
  "Журналы службы"
 ],
 "Services": [
  null,
  "Службы"
 ],
 "Set hostname": [
  null,
  "Установить название узла"
 ],
 "Set time": [
  null,
  "Настроить время"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show fingerprints": [
  null,
  "Показать отпечатки"
 ],
 "Show messages containing given string.": [
  null,
  ""
 ],
 "Show messages for the specified systemd unit.": [
  null,
  ""
 ],
 "Show messages from a specific boot.": [
  null,
  ""
 ],
 "Show more relationships": [
  null,
  ""
 ],
 "Show relationships": [
  null,
  ""
 ],
 "Shut down": [
  null,
  "Завершение работы"
 ],
 "Shutdown": [
  null,
  "Выключить"
 ],
 "Since": [
  null,
  ""
 ],
 "Single rank": [
  null,
  "Одноранговая"
 ],
 "Size": [
  null,
  "Размер"
 ],
 "Slot": [
  null,
  "Слот"
 ],
 "Sockets": [
  null,
  "Сокеты"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Программные обходные решения помогают предотвратить проблемы безопасности ЦП. Побочным эффектом этих мер является снижение производительности. Вы изменяете эти параметры на свой страх и риск."
 ],
 "Space-saving computer": [
  null,
  "Компактный компьютер"
 ],
 "Specific time": [
  null,
  "Определённое время"
 ],
 "Speed": [
  null,
  "Скорость"
 ],
 "Start": [
  null,
  "Запустить"
 ],
 "Start and enable": [
  null,
  "Включить и запустить"
 ],
 "Start service": [
  null,
  "Запустить службу"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  ""
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  ""
 ],
 "State": [
  null,
  "Состояние"
 ],
 "Static": [
  null,
  "Статически"
 ],
 "Status": [
  null,
  "Состояние"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Остановить"
 ],
 "Stop and disable": [
  null,
  "Остановить и отключить"
 ],
 "Stub": [
  null,
  ""
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  ""
 ],
 "Sundays": [
  null,
  "По воскресеньям"
 ],
 "Switch to limited access": [
  null,
  ""
 ],
 "Synchronized": [
  null,
  "Синхронизировано"
 ],
 "System": [
  null,
  "Система"
 ],
 "System information": [
  null,
  "Сведения о системе"
 ],
 "System time": [
  null,
  "Системное время"
 ],
 "Tablet": [
  null,
  "Планшетный ПК"
 ],
 "Targets": [
  null,
  "Цели"
 ],
 "Terminal": [
  null,
  "Терминал"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Пользователю $0 не разрешено изменять параметры, влияющие на безопасность ЦП"
 ],
 "This may take a while": [
  null,
  "Это может занять некоторое время"
 ],
 "This system is using a custom profile": [
  null,
  "Эта система использует настраиваемый профиль"
 ],
 "This system is using the recommended profile": [
  null,
  "Эта система использует рекомендуемый профиль"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Эта служба не предназначена для явного включения."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  ""
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  ""
 ],
 "Thursdays": [
  null,
  "По четвергам"
 ],
 "Time zone": [
  null,
  "Часовой пояс"
 ],
 "Timers": [
  null,
  "Таймеры"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Total size: $0": [
  null,
  "Общий размер: $0"
 ],
 "Tower": [
  null,
  "Компьютер в корпусе «башня»"
 ],
 "Transient": [
  null,
  ""
 ],
 "Triggered by": [
  null,
  "TriggeredBy="
 ],
 "Triggers": [
  null,
  "Triggers="
 ],
 "Tuesdays": [
  null,
  "По вторникам"
 ],
 "Tuned has failed to start": [
  null,
  "Сбой при запуске демона tuned"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  ""
 ],
 "Tuned is not available": [
  null,
  "Демон tuned недоступен"
 ],
 "Tuned is not running": [
  null,
  "Демон tuned не запущен"
 ],
 "Tuned is off": [
  null,
  "Демон tuned отключен"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Unit": [
  null,
  "Устройство"
 ],
 "Unknown": [
  null,
  "Неизвестно"
 ],
 "Until": [
  null,
  ""
 ],
 "Updating status...": [
  null,
  "Обновление состояния..."
 ],
 "Usage": [
  null,
  "Использование"
 ],
 "User": [
  null,
  "Пользователь"
 ],
 "Validating address": [
  null,
  "Проверка адреса"
 ],
 "Vendor": [
  null,
  "Производитель"
 ],
 "Version": [
  null,
  "Версия"
 ],
 "View all logs": [
  null,
  ""
 ],
 "View hardware details": [
  null,
  "Просмотреть сведения об оборудовании"
 ],
 "View login history": [
  null,
  ""
 ],
 "View metrics and history": [
  null,
  ""
 ],
 "View report": [
  null,
  "Просмотреть отчет"
 ],
 "Waiting for input…": [
  null,
  "Ожидание входных данных…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Ожидание завершения других операций управления программным обеспечением"
 ],
 "Waiting to start…": [
  null,
  "Ожидание пуска…"
 ],
 "Wanted by": [
  null,
  "WantedBy="
 ],
 "Wants": [
  null,
  "Wants="
 ],
 "Warning and above": [
  null,
  "Предупреждающие сообщения и выше"
 ],
 "Web console is running in limited access mode.": [
  null,
  ""
 ],
 "Wednesdays": [
  null,
  "По средам"
 ],
 "Weeks": [
  null,
  "нед"
 ],
 "White": [
  null,
  "Белый"
 ],
 "Yearly": [
  null,
  ""
 ],
 "Yes": [
  null,
  "Да"
 ],
 "You may try to load older entries.": [
  null,
  "Вы можете попробовать загрузить более старые записи."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  ""
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 байтов двоичных данных]"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "active": [
  null,
  "активно"
 ],
 "asset tag": [
  null,
  "тег актива"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "загрузка"
 ],
 "cgroups": [
  null,
  ""
 ],
 "command": [
  null,
  "команда"
 ],
 "console": [
  null,
  "консоль"
 ],
 "coredump": [
  null,
  "дамп ядра"
 ],
 "cpu": [
  null,
  "процессор"
 ],
 "crash": [
  null,
  "сбой"
 ],
 "date": [
  null,
  "дата"
 ],
 "debug": [
  null,
  "отладка"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "отключить"
 ],
 "domain": [
  null,
  "домен"
 ],
 "edit": [
  null,
  "редактировать"
 ],
 "enable": [
  null,
  "включить"
 ],
 "error": [
  null,
  "ошибка"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "не удалось отобразить список SSH-ключей узла: $0"
 ],
 "graphs": [
  null,
  "графики"
 ],
 "hardware": [
  null,
  "оборудование"
 ],
 "host": [
  null,
  "узел"
 ],
 "journal": [
  null,
  "журнал"
 ],
 "journalctl manpage": [
  null,
  ""
 ],
 "machine": [
  null,
  "компьютер"
 ],
 "mask": [
  null,
  "маска"
 ],
 "memory": [
  null,
  "память"
 ],
 "mitigation": [
  null,
  "защита"
 ],
 "network": [
  null,
  "сеть"
 ],
 "none": [
  null,
  "нет"
 ],
 "of $0 CPU": [
  null,
  "из $0 процессора",
  "из $0 процессоров",
  "из $0 процессоров"
 ],
 "operating system": [
  null,
  "операционная система"
 ],
 "os": [
  null,
  "ОС"
 ],
 "path": [
  null,
  "путь"
 ],
 "pci": [
  null,
  "pci"
 ],
 "power": [
  null,
  "питание"
 ],
 "ram": [
  null,
  "ОЗУ"
 ],
 "recommended": [
  null,
  "рекомендуется"
 ],
 "restart": [
  null,
  "перезапустить"
 ],
 "running $0": [
  null,
  "выполняется $0"
 ],
 "serial": [
  null,
  "последовательный"
 ],
 "service": [
  null,
  "служба"
 ],
 "shell": [
  null,
  "оболочка"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "shut": [
  null,
  "закрывать"
 ],
 "socket": [
  null,
  "socket"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "цель"
 ],
 "time": [
  null,
  "время"
 ],
 "timer": [
  null,
  "таймер"
 ],
 "unit": [
  null,
  "блок"
 ],
 "unknown": [
  null,
  "неизвестно"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "version": [
  null,
  "версия"
 ],
 "warning": [
  null,
  "предупреждение"
 ]
});
