cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "「重大な影響」を含む $0 件が該当"
 ],
 "$0 failed login attempt": [
  null,
  "$0 がログインの試行に失敗しました"
 ],
 "$0 important hit": [
  null,
  "「重要な影響」を含む $0 件が該当"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 は、あらゆるリポジトリーから利用できません。"
 ],
 "$0 low severity hit": [
  null,
  "「低度の影響」を含む $0 件が該当"
 ],
 "$0 moderate hit": [
  null,
  "「中程度の影響」を含む $0 件が該当"
 ],
 "$0 service has failed": [
  null,
  "失敗したサービスの数 ($0)"
 ],
 "$0 will be installed.": [
  null,
  "$0 がインストールされます。"
 ],
 "$0: crash at $1": [
  null,
  "$0: $1 でクラッシュ"
 ],
 "1 minute": [
  null,
  "1 分"
 ],
 "10th": [
  null,
  "10 日"
 ],
 "11th": [
  null,
  "11 日"
 ],
 "12th": [
  null,
  "12 日"
 ],
 "13th": [
  null,
  "13 日"
 ],
 "14th": [
  null,
  "14 日"
 ],
 "15th": [
  null,
  "15 日"
 ],
 "16th": [
  null,
  "16 日"
 ],
 "17th": [
  null,
  "17 日"
 ],
 "18th": [
  null,
  "18 日"
 ],
 "19th": [
  null,
  "19 日"
 ],
 "1st": [
  null,
  "1 日"
 ],
 "20 minutes": [
  null,
  "20 分"
 ],
 "20th": [
  null,
  "20 日"
 ],
 "21th": [
  null,
  "21 日"
 ],
 "22th": [
  null,
  "22 日"
 ],
 "23th": [
  null,
  "23 日"
 ],
 "24th": [
  null,
  "24 日"
 ],
 "25th": [
  null,
  "25 日"
 ],
 "26th": [
  null,
  "26 日"
 ],
 "27th": [
  null,
  "27 日"
 ],
 "28th": [
  null,
  "28 日"
 ],
 "29th": [
  null,
  "29 日"
 ],
 "2nd": [
  null,
  "2 日"
 ],
 "30th": [
  null,
  "30 日"
 ],
 "31st": [
  null,
  "31 日"
 ],
 "3rd": [
  null,
  "3 日"
 ],
 "40 minutes": [
  null,
  "40 分"
 ],
 "4th": [
  null,
  "4 日"
 ],
 "5 minutes": [
  null,
  "5 分"
 ],
 "5th": [
  null,
  "5 日"
 ],
 "60 minutes": [
  null,
  "60 分"
 ],
 "6th": [
  null,
  "6 日"
 ],
 "7th": [
  null,
  "7 日"
 ],
 "8th": [
  null,
  "8 日"
 ],
 "9th": [
  null,
  "9 日"
 ],
 "Absent": [
  null,
  "不在"
 ],
 "Active since ": [
  null,
  "以降アクティブ "
 ],
 "Active state": [
  null,
  "アクティブな状態"
 ],
 "Add": [
  null,
  "追加する"
 ],
 "Additional actions": [
  null,
  "その他の動作"
 ],
 "Additional packages:": [
  null,
  "追加のパッケージ:"
 ],
 "Administrative access": [
  null,
  "管理アクセス"
 ],
 "Advanced TCA": [
  null,
  "高度な TCA"
 ],
 "After": [
  null,
  "後"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "ドメインの終了後は、ローカル認証情報を持つユーザーだけが、このマシンにログインできます。DNS 解決設定および信頼される CA の一覧が変更する可能性があるため、他のサービスにも影響を及ぼす場合があります。"
 ],
 "After system boot": [
  null,
  "システムブート後"
 ],
 "Alert and above": [
  null,
  "アラート以上のレベル"
 ],
 "Alias": [
  null,
  "エイリアス"
 ],
 "All": [
  null,
  "すべて"
 ],
 "All-in-one": [
  null,
  "オールインワン"
 ],
 "Allow running (unmask)": [
  null,
  "実行を許可 (マスク解除)"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "ログメッセージのテキスト文字列はフィルターでフィルタリングできます。文字列は、正規表現の形式でも指定できます。また、メッセージログフィールドによるフィルタリングもサポートできます。これらは、FIELD=VALUE の形式でスペースで区切った値は、使用できる値のカンマ区切りのリストになります。"
 ],
 "Appearance": [
  null,
  "外観"
 ],
 "Apply and reboot": [
  null,
  "適用して再起動する"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "新しいポリシーを適用しています... これには数分かかる場合があります。"
 ],
 "Asset tag": [
  null,
  "アセットタグ"
 ],
 "At minute": [
  null,
  "分"
 ],
 "At specific time": [
  null,
  "特定の時間"
 ],
 "Authenticate": [
  null,
  "認証する"
 ],
 "Automatically starts": [
  null,
  "自動起動"
 ],
 "Automatically using NTP": [
  null,
  "NTP を自動的に使用"
 ],
 "Automatically using specific NTP servers": [
  null,
  "特定の NTP サーバーを自動的に使用"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS の日付"
 ],
 "BIOS version": [
  null,
  "BIOS のバージョン"
 ],
 "Bad": [
  null,
  "正しくない"
 ],
 "Bad setting": [
  null,
  "正しくない設定"
 ],
 "Before": [
  null,
  "前"
 ],
 "Binds to": [
  null,
  "バインドする"
 ],
 "Black": [
  null,
  "黒"
 ],
 "Blade": [
  null,
  "ブレード"
 ],
 "Blade enclosure": [
  null,
  "ブレードエンクロージャー"
 ],
 "Boot": [
  null,
  "ブート"
 ],
 "Bound by": [
  null,
  "バインドされた"
 ],
 "Bus expansion chassis": [
  null,
  "バス拡張シャーシ"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "CPU セキュリティー"
 ],
 "CPU security toggles": [
  null,
  "CPU セキュリティートグル"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "現在のフィルターの組み合わせを使用して、ログを見つけることができません。"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Cancel poweroff": [
  null,
  "電源オフの取り消し"
 ],
 "Cancel reboot": [
  null,
  "再起動の取り消し"
 ],
 "Cannot be enabled": [
  null,
  "有効にできません"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "realmd がこのシステムで利用できないため、ドメインに参加できません"
 ],
 "Cannot schedule event in the past": [
  null,
  "過去のイベントはスケジュールできません"
 ],
 "Change": [
  null,
  "変更"
 ],
 "Change crypto policy": [
  null,
  "暗号化ポリシーの変更"
 ],
 "Change host name": [
  null,
  "ホスト名の変更"
 ],
 "Change performance profile": [
  null,
  "パフォーマンスプロファイルの変更"
 ],
 "Change profile": [
  null,
  "プロファイルの変更"
 ],
 "Change system time": [
  null,
  "システム時間の変更"
 ],
 "Checking installed software": [
  null,
  "インストールされたソフトウェアの確認中"
 ],
 "Class": [
  null,
  "クラス"
 ],
 "Clear 'Failed to start'": [
  null,
  "'起動に失敗' を消去"
 ],
 "Clear all filters": [
  null,
  "すべてのフィルターの消去"
 ],
 "Client software": [
  null,
  "クライアントソフトウェア"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Command": [
  null,
  "コマンド"
 ],
 "Command not found": [
  null,
  "コマンドが見つかりません"
 ],
 "Communication with tuned has failed": [
  null,
  "tuned との通信に失敗しました"
 ],
 "Compact PCI": [
  null,
  "PCI の圧縮"
 ],
 "Condition $0=$1 was not met": [
  null,
  "条件 $0=$1 を満たしていませんでした"
 ],
 "Condition failed": [
  null,
  "条件が満たされませんでした"
 ],
 "Configuration": [
  null,
  "設定"
 ],
 "Configuring system settings": [
  null,
  "システム設定の変更"
 ],
 "Confirm deletion of $0": [
  null,
  "$0 の削除を確定する"
 ],
 "Conflicted by": [
  null,
  "競合する"
 ],
 "Conflicts": [
  null,
  "競合"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "dbus への接続に失敗しました: $0"
 ],
 "Consists of": [
  null,
  "構成するもの"
 ],
 "Contacted domain": [
  null,
  "接続されたドメイン"
 ],
 "Controller": [
  null,
  "コントローラー"
 ],
 "Convertible": [
  null,
  "変換可能"
 ],
 "Copy": [
  null,
  "コピー"
 ],
 "Copy to clipboard": [
  null,
  "クリップボードにコピー"
 ],
 "Crash reporting": [
  null,
  "クラッシュの報告"
 ],
 "Create timer": [
  null,
  "タイマーの作成"
 ],
 "Critical and above": [
  null,
  "重大以上のレベル"
 ],
 "Crypto Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "暗号化ポリシーは、TLS、IPSec、SSH、DNSSec、および Kerberos プロトコルに対応するコア暗号化サブシステムを設定するシステムコンポーネントです。"
 ],
 "Crypto policy": [
  null,
  "暗号化ポリシー"
 ],
 "Crypto policy is inconsistent": [
  null,
  "暗号化ポリシーに一貫性がありません"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "現在の起動"
 ],
 "Custom crypto policy": [
  null,
  "カスタム暗号化ポリシー"
 ],
 "Daily": [
  null,
  "毎日"
 ],
 "Dark": [
  null,
  "ダーク"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "日付の指定は、YYYY-MM-DD hh:mm:ss の形式にする必要があります。または、文字列は 'yesterday'、'today'、'tomorrow' が理解されます。'now' は現在の時刻を指します。最後に、相対時間を指定できます。最後に、ハイフン (-) または '+' を付けることができます"
 ],
 "Debug and above": [
  null,
  "デバッグ以上のレベル"
 ],
 "Decrease by one": [
  null,
  "1 つ減らす"
 ],
 "Delay": [
  null,
  "遅延"
 ],
 "Delay must be a number": [
  null,
  "遅延は数字である必要があります"
 ],
 "Delete": [
  null,
  "削除"
 ],
 "Deletion will remove the following files:": [
  null,
  "削除すると、以下のファイルが削除されます:"
 ],
 "Description": [
  null,
  "説明"
 ],
 "Desktop": [
  null,
  "デスクトップ"
 ],
 "Detachable": [
  null,
  "割り当て解除可能"
 ],
 "Details": [
  null,
  "詳細"
 ],
 "Disable simultaneous multithreading": [
  null,
  "同時マルチスレッディングの無効化"
 ],
 "Disable tuned": [
  null,
  "tuned の無効化"
 ],
 "Disabled": [
  null,
  "無効"
 ],
 "Disallow running (mask)": [
  null,
  "実行を禁止 (マスク)"
 ],
 "Docking station": [
  null,
  "ドッキングステーション"
 ],
 "Does not automatically start": [
  null,
  "自動起動しません"
 ],
 "Domain": [
  null,
  "ドメイン"
 ],
 "Domain address": [
  null,
  "ドメインアドレス"
 ],
 "Domain administrator name": [
  null,
  "ドメイン管理者名"
 ],
 "Domain administrator password": [
  null,
  "ドメイン管理者パスワード"
 ],
 "Domain could not be contacted": [
  null,
  "ドメイン に接続できませんでした"
 ],
 "Domain is not supported": [
  null,
  "ドメインはサポートされません"
 ],
 "Don't repeat": [
  null,
  "繰り返さない"
 ],
 "Downloading $0": [
  null,
  "$0 をダウンロード中"
 ],
 "Dual rank": [
  null,
  "デュアルランク"
 ],
 "Edit /etc/motd": [
  null,
  "/etc/motd を編集する"
 ],
 "Edit motd": [
  null,
  "motd を編集する"
 ],
 "Embedded PC": [
  null,
  "組み込み PC"
 ],
 "Enabled": [
  null,
  "有効"
 ],
 "Entry at $0": [
  null,
  "$0 でのエントリー"
 ],
 "Error": [
  null,
  "エラー"
 ],
 "Error and above": [
  null,
  "エラー以上のレベル"
 ],
 "Error message": [
  null,
  "エラーメッセージ"
 ],
 "Expansion chassis": [
  null,
  "拡張シャーシ"
 ],
 "Extended information": [
  null,
  "拡張情報"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS が適切に有効化されていません"
 ],
 "Failed to disable tuned": [
  null,
  "tuned の無効化に失敗しました"
 ],
 "Failed to disabled tuned profile": [
  null,
  "tuned プロファイルの無効化に失敗しました"
 ],
 "Failed to enable tuned": [
  null,
  "tuned の有効化に失敗しました"
 ],
 "Failed to fetch logs": [
  null,
  "ログの取得に失敗しました"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "変更を /etc/motd に保存できませんでした"
 ],
 "Failed to start": [
  null,
  "起動に失敗しました"
 ],
 "Failed to switch profile": [
  null,
  "プロファイルの切り替えに失敗しました"
 ],
 "File state": [
  null,
  "ファイル状態"
 ],
 "Filter by name or description": [
  null,
  "名前または説明による絞り込み"
 ],
 "Filters": [
  null,
  "フィルター"
 ],
 "Font size": [
  null,
  "フォントのサイズ"
 ],
 "Forbidden from running": [
  null,
  "実行が禁止されています"
 ],
 "Frame number": [
  null,
  "フレーム番号"
 ],
 "Free-form search": [
  null,
  "フリーフォーム検索"
 ],
 "Fridays": [
  null,
  "毎週金曜日"
 ],
 "General": [
  null,
  "全般"
 ],
 "Generated": [
  null,
  "生成しました"
 ],
 "Go to $0": [
  null,
  "$0 に移動"
 ],
 "Handheld": [
  null,
  "ハンドヘルド"
 ],
 "Hardware information": [
  null,
  "ハードウェア情報"
 ],
 "Health": [
  null,
  "ヘルス"
 ],
 "Help": [
  null,
  "ヘルプ"
 ],
 "Hierarchy ID": [
  null,
  "階層 ID"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "攻撃対象が増えるという代償を払ってでも、相互運用性を高めます。"
 ],
 "Hostname": [
  null,
  "ホスト名"
 ],
 "Hourly": [
  null,
  "1 時間ごと"
 ],
 "Hours": [
  null,
  "時"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "識別子"
 ],
 "Increase by one": [
  null,
  "1 つ増やす"
 ],
 "Indirect": [
  null,
  "間接"
 ],
 "Info and above": [
  null,
  "情報以上のレベル"
 ],
 "Insights: ": [
  null,
  "Insights: "
 ],
 "Install": [
  null,
  "インストール"
 ],
 "Install software": [
  null,
  "ソフトウェアをインストール"
 ],
 "Installing $0": [
  null,
  "$0 をインストール中"
 ],
 "Invalid": [
  null,
  "無効"
 ],
 "Invalid date format": [
  null,
  "無効な日付形式"
 ],
 "Invalid date format and invalid time format": [
  null,
  "無効な日付形式と無効な時間形式"
 ],
 "Invalid time format": [
  null,
  "無効な時間形式"
 ],
 "Invalid timezone": [
  null,
  "無効なタイムゾーン"
 ],
 "IoT gateway": [
  null,
  "IoT ゲートウェイ"
 ],
 "Join": [
  null,
  "参加"
 ],
 "Join domain": [
  null,
  "ドメイン参加"
 ],
 "Joining": [
  null,
  "参加する"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "ドメインに参加するには、realmd のインストールが必要です"
 ],
 "Joining this domain is not supported": [
  null,
  "このドメインの参加はサポートされていません"
 ],
 "Joins namespace of": [
  null,
  "名前空間に参加"
 ],
 "Journal": [
  null,
  "ジャーナル"
 ],
 "Journal entry": [
  null,
  "ジャーナルエントリー"
 ],
 "Journal entry not found": [
  null,
  "ジャーナルエントリーが見つかりません"
 ],
 "Laptop": [
  null,
  "ラップトップ"
 ],
 "Last 24 hours": [
  null,
  "過去 24 時間"
 ],
 "Last 7 days": [
  null,
  "過去 7 日間"
 ],
 "Last successful login:": [
  null,
  "最後の正常ログイン:"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "Leave $0": [
  null,
  "$0 の脱退"
 ],
 "Leave domain": [
  null,
  "ドメインの脱退"
 ],
 "Light": [
  null,
  "ライト"
 ],
 "Limit access": [
  null,
  "アクセスの制限"
 ],
 "Limited access": [
  null,
  "制限付きアクセス"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "限定アクセスモードでは、管理者権限が制限されます。Web コンソールの一部の機能が低下します。"
 ],
 "Limits": [
  null,
  "制限"
 ],
 "Linked": [
  null,
  "リンク済み"
 ],
 "Listen": [
  null,
  "リッスン"
 ],
 "Listing unit files": [
  null,
  "ユニットファイルの一覧表示"
 ],
 "Listing unit files failed: $0": [
  null,
  "ユニットファイルの一覧表示に失敗しました: $0"
 ],
 "Listing units": [
  null,
  "ユニットの一覧表示"
 ],
 "Listing units failed: $0": [
  null,
  "ユニットの一覧表示に失敗しました: $0"
 ],
 "Load earlier entries": [
  null,
  "以前のエントリーのロード"
 ],
 "Loading earlier entries": [
  null,
  "以前のエントリーの読み込み"
 ],
 "Loading keys...": [
  null,
  "キーをロード中..."
 ],
 "Loading of SSH keys failed": [
  null,
  "SSH キーの読み込みに失敗しました"
 ],
 "Loading of units failed": [
  null,
  "ユニットの読み込みに失敗しました"
 ],
 "Loading unit failed: $0": [
  null,
  "ユニットの読み込みに失敗しました: $0"
 ],
 "Loading...": [
  null,
  "ロード中..."
 ],
 "Log messages": [
  null,
  "ログメッセージ"
 ],
 "Login format": [
  null,
  "ログインフォーマット"
 ],
 "Logs": [
  null,
  "ログ"
 ],
 "Low profile desktop": [
  null,
  "低プロファイルデスクトップ"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Machine ID": [
  null,
  "マシン ID"
 ],
 "Machine SSH key fingerprints": [
  null,
  "マシンSSH 鍵フィンガープリント"
 ],
 "Main server chassis": [
  null,
  "メインサーバーシャーシ"
 ],
 "Maintenance": [
  null,
  "メンテナンス"
 ],
 "Managing services": [
  null,
  "サービス管理"
 ],
 "Manually": [
  null,
  "手動"
 ],
 "Mask service": [
  null,
  "サービスのマスク"
 ],
 "Masked": [
  null,
  "マスク"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "サービスをマスクすると、すべての依存するユニットが実行されなくなります。大きな影響が及ぶ可能性があります。このユニットをマスクすることを確認してください。"
 ],
 "Memory": [
  null,
  "メモリ"
 ],
 "Memory technology": [
  null,
  "メモリーテクノロジー"
 ],
 "Merged": [
  null,
  "マージ済み"
 ],
 "Message to logged in users": [
  null,
  "ログインしているユーザーへのメッセージ"
 ],
 "Method": [
  null,
  "メソッド"
 ],
 "Mini PC": [
  null,
  "ミニ PC"
 ],
 "Mini tower": [
  null,
  "ミニタワー"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "分は 0〜59 の数字である必要があります"
 ],
 "Minutes": [
  null,
  "分"
 ],
 "Mitigations": [
  null,
  "緩和"
 ],
 "Model": [
  null,
  "モデル"
 ],
 "Mondays": [
  null,
  "毎週月曜日"
 ],
 "Monthly": [
  null,
  "毎月"
 ],
 "Multi-system chassis": [
  null,
  "マルチシステムシャーシ"
 ],
 "NTP server": [
  null,
  "NTP サーバー"
 ],
 "Name": [
  null,
  "名前"
 ],
 "Need at least one NTP server": [
  null,
  "少なくとも 1 つの NTP サーバーが必要です"
 ],
 "No": [
  null,
  "いいえ"
 ],
 "No delay": [
  null,
  "遅延なし"
 ],
 "No host keys found.": [
  null,
  "ホストキーが見つかりません。"
 ],
 "No log entries": [
  null,
  "ログエントリーなし"
 ],
 "No logs found": [
  null,
  "ログが見つかりません"
 ],
 "No matching results": [
  null,
  "一致する結果はありません"
 ],
 "No results found": [
  null,
  "結果が見つかりません"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "絞り込みの基準と一致する結果がありません。結果を見るためには全ての絞り込み基準を解除してください。"
 ],
 "No rule hits": [
  null,
  "ルールヒットなし"
 ],
 "None": [
  null,
  "なし"
 ],
 "Not connected to Insights": [
  null,
  "Insights に接続されていません"
 ],
 "Not found": [
  null,
  "見つかりません"
 ],
 "Not permitted to configure realms": [
  null,
  "レルムの設定が許可されていません"
 ],
 "Not running": [
  null,
  "実行中ではありません"
 ],
 "Not synchronized": [
  null,
  "同期されていません"
 ],
 "Note": [
  null,
  "注記"
 ],
 "Notebook": [
  null,
  "ノートブック"
 ],
 "Notice and above": [
  null,
  "注意以上のレベル"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "On failure": [
  null,
  "障害発生時"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "アルファベット、数字、:、 _ 、.、@、- のみを使用できます"
 ],
 "Only emergency": [
  null,
  "緊急のみ"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "FIPS モードで起動する場合は、承認および許可されたアルゴリズムのみを使用してください。"
 ],
 "Other": [
  null,
  "その他"
 ],
 "Overview": [
  null,
  "概要"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit がクラッシュしました"
 ],
 "Part of": [
  null,
  "一部"
 ],
 "Password": [
  null,
  "パスワード"
 ],
 "Paste": [
  null,
  "貼り付け"
 ],
 "Paste error": [
  null,
  "貼り付けエラー"
 ],
 "Path": [
  null,
  "パス"
 ],
 "Paths": [
  null,
  "パス"
 ],
 "Pause": [
  null,
  "一時停止"
 ],
 "Performance profile": [
  null,
  "パフォーマンスプロファイル"
 ],
 "Peripheral chassis": [
  null,
  "周辺機器シャーシ"
 ],
 "Pick date": [
  null,
  "日付けの選択"
 ],
 "Pin unit": [
  null,
  "ユニットを固定する"
 ],
 "Pinned unit": [
  null,
  "固定されたユニット"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "管理者アクセスを得るために認証を行ってください"
 ],
 "Portable": [
  null,
  "ポータブル"
 ],
 "Present": [
  null,
  "存在"
 ],
 "Pretty host name": [
  null,
  "プリティホスト名"
 ],
 "Previous boot": [
  null,
  "以前のブート"
 ],
 "Priority": [
  null,
  "優先度"
 ],
 "Problem becoming administrator": [
  null,
  "管理者への切り替えに問題が発生しました"
 ],
 "Problem details": [
  null,
  "問題の詳細"
 ],
 "Problem info": [
  null,
  "問題の情報"
 ],
 "Propagates reload to": [
  null,
  "再ロード先を伝搬"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "相互運用性を犠牲にして、近い将来に予想される攻撃から保護します。"
 ],
 "RAID chassis": [
  null,
  "RAID シャーシ"
 ],
 "Rack mount chassis": [
  null,
  "ラックマウントシャーシ"
 ],
 "Rank": [
  null,
  "ランク"
 ],
 "Read more...": [
  null,
  "さらに読む..."
 ],
 "Read-only": [
  null,
  "読み取り専用"
 ],
 "Real host name": [
  null,
  "実際のホスト名"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "実際のホスト名には小文字、数字、ダッシュ、およびピリオドのみを使用できます (入力されたサブドメインを含む)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "実際のホスト名は 64 文字以下である必要があります"
 ],
 "Reapply and reboot": [
  null,
  "再適用して再起動する"
 ],
 "Reboot": [
  null,
  "再起動"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "現在の脅威モデルに推奨される安全な設定。"
 ],
 "Reload": [
  null,
  "再ロード"
 ],
 "Reload propagated from": [
  null,
  "伝搬元を再ロード"
 ],
 "Reloading": [
  null,
  "リロード中"
 ],
 "Removals:": [
  null,
  "削除:"
 ],
 "Remove": [
  null,
  "削除"
 ],
 "Removing $0": [
  null,
  "$0 を削除中"
 ],
 "Repeat": [
  null,
  "繰り返し"
 ],
 "Repeat monthly": [
  null,
  "毎月繰り返す"
 ],
 "Repeat weekly": [
  null,
  "毎週繰り返す"
 ],
 "Report": [
  null,
  "レポート"
 ],
 "Report to ABRT Analytics": [
  null,
  "ABRT アナリティクスへ報告します"
 ],
 "Reported; no links available": [
  null,
  "報告済み、利用可能なリンクはありません"
 ],
 "Reporting failed": [
  null,
  "報告に失敗しました"
 ],
 "Reporting was canceled": [
  null,
  "報告はキャンセルされました"
 ],
 "Reports:": [
  null,
  "レポート:"
 ],
 "Required by": [
  null,
  "必要とされる"
 ],
 "Required by ": [
  null,
  "以下により必要 "
 ],
 "Requires": [
  null,
  "必要"
 ],
 "Requires administration access to edit": [
  null,
  "編集には管理者アクセスが必要"
 ],
 "Requisite": [
  null,
  "必須"
 ],
 "Requisite of": [
  null,
  "必須の"
 ],
 "Reset": [
  null,
  "リセット"
 ],
 "Restart": [
  null,
  "再起動"
 ],
 "Resume": [
  null,
  "再開"
 ],
 "Review crypto policy": [
  null,
  "暗号化ポリシーを確認する"
 ],
 "Reviewing logs": [
  null,
  "ログのレビュー"
 ],
 "Run at": [
  null,
  "以下で実行"
 ],
 "Run on": [
  null,
  "以下で実行"
 ],
 "Running": [
  null,
  "実行中"
 ],
 "Saturdays": [
  null,
  "毎週土曜日"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Save and reboot": [
  null,
  "保存および再起動"
 ],
 "Save changes": [
  null,
  "変更の保存"
 ],
 "Scheduled poweroff at $0": [
  null,
  "電源オフが $0 に予定されています"
 ],
 "Scheduled reboot at $0": [
  null,
  "再起動が $0 に予定されています"
 ],
 "Sealed-case PC": [
  null,
  "シールドケース PC"
 ],
 "Search": [
  null,
  "検索"
 ],
 "Seconds": [
  null,
  "秒"
 ],
 "Secure shell keys": [
  null,
  "安全なシェルキー"
 ],
 "Select a identifier": [
  null,
  "識別子の選択"
 ],
 "Send": [
  null,
  "送信"
 ],
 "Server software": [
  null,
  "サーバーソフトウェア"
 ],
 "Service logs": [
  null,
  "サービスログ"
 ],
 "Services": [
  null,
  "サービス"
 ],
 "Set hostname": [
  null,
  "ホスト名を設定します"
 ],
 "Set time": [
  null,
  "時間の設定"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "すべてのスレッドの表示"
 ],
 "Show fingerprints": [
  null,
  "フィンガープリントの表示"
 ],
 "Show messages containing given string.": [
  null,
  "与えられた文字列が含まれるメッセージを表示します。"
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "指定した systemd ユニットのメッセージを表示します。"
 ],
 "Show messages from a specific boot.": [
  null,
  "特定のブートのメッセージを表示します。"
 ],
 "Show more relationships": [
  null,
  "その他の関係の表示"
 ],
 "Show relationships": [
  null,
  "関係の表示"
 ],
 "Shut down": [
  null,
  "シャットダウン"
 ],
 "Shutdown": [
  null,
  "シャットダウン"
 ],
 "Since": [
  null,
  "フィルター開始時刻"
 ],
 "Single rank": [
  null,
  "シングルランク"
 ],
 "Size": [
  null,
  "サイズ"
 ],
 "Slot": [
  null,
  "スロット"
 ],
 "Sockets": [
  null,
  "ソケット"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "ソフトウェアベースの回避策により、CPU セキュリティー問題を回避します。これらの緩和策にはパフォーマンスの低下という副次的な影響があります。リスクをご理解の上、これらの設定を変更してください。"
 ],
 "Space-saving computer": [
  null,
  "省スペースコンピューター"
 ],
 "Specific time": [
  null,
  "特定の時間"
 ],
 "Speed": [
  null,
  "速度"
 ],
 "Start": [
  null,
  "起動"
 ],
 "Start and enable": [
  null,
  "起動と有効化"
 ],
 "Start service": [
  null,
  "サービスの開始"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "指定の日付以降のエントリーまたは新しいエントリーを表示します。"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "指定の日付以前のエントリーまたはそれ以前のエントリーを表示します。"
 ],
 "State": [
  null,
  "状態"
 ],
 "Static": [
  null,
  "静的"
 ],
 "Status": [
  null,
  "ステータス"
 ],
 "Stick PC": [
  null,
  "スティッキー PC"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Stop and disable": [
  null,
  "停止と無効化"
 ],
 "Stub": [
  null,
  "スタブ"
 ],
 "Sub-Chassis": [
  null,
  "サブシャーシ"
 ],
 "Sub-Notebook": [
  null,
  "サブノート"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "systemd シグナルへのサブスクライブに失敗しました: $0"
 ],
 "Successfully copied to keyboard": [
  null,
  "キーボードにコピーされました"
 ],
 "Sundays": [
  null,
  "毎週日曜日"
 ],
 "Switch to administrative access": [
  null,
  "管理者アクセスへの切り替え"
 ],
 "Switch to limited access": [
  null,
  "アクセス制限への切り替え"
 ],
 "Synchronized": [
  null,
  "同期済み"
 ],
 "Synchronized with $0": [
  null,
  "$0 と同期済み"
 ],
 "Synchronizing": [
  null,
  "同期中"
 ],
 "System": [
  null,
  "システム"
 ],
 "System information": [
  null,
  "システム情報"
 ],
 "System time": [
  null,
  "システム時間"
 ],
 "Systemd units": [
  null,
  "システム単位"
 ],
 "Tablet": [
  null,
  "タブレット"
 ],
 "Targets": [
  null,
  "ターゲット"
 ],
 "Terminal": [
  null,
  "端末"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "ユーザー $0 は、cpu セキュリティー緩和の変更を許可されていません"
 ],
 "The user $0 is not permitted to change crypto policies": [
  null,
  "ユーザー $0 は、暗号化ポリシーの変更を許可されていません"
 ],
 "This field cannot be empty": [
  null,
  "このフィールドは必須の項目です"
 ],
 "This may take a while": [
  null,
  "これにはしばらく時間がかかることがあります"
 ],
 "This system is using a custom profile": [
  null,
  "このシステムはカスタムプロファイルを使用しています"
 ],
 "This system is using the recommended profile": [
  null,
  "このシステムは推奨プロファイルを使用しています"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "このユニットは明示的に有効にするよう設計されていません。"
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "これにより、_BOOT_ID=' 一致を追加します。指定のない場合は、現在のブートのログが表示されます。ブート ID を省略すると、正のオフセットはジャーナルの開始からブートを探します。また、ゼロまたはゼロ未満のオフセットは、ジャーナルの最後からブートを探します。したがって、1 は時系列順でジャーナルで見つかった最初のブートを意味し、2 は 2 番目のブートを意味します (以下、同様)。また、-0 は最後のブート、-1 は最後の前のブートとなります。"
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "これにより、'_SYSTEMD_UNIT='、'COREDUMP_UNIT='、'UNIT=' と一致させ、指定のユニットに対する考えられるメッセージをすべて特定します。複数のユニットをコンマで区切ることができます。 "
 ],
 "Thursdays": [
  null,
  "毎週木曜日"
 ],
 "Time": [
  null,
  "時間"
 ],
 "Time zone": [
  null,
  "タイムゾーン"
 ],
 "Timer creation failed": [
  null,
  "タイマーの作成に失敗しました"
 ],
 "Timer deletion failed": [
  null,
  "タイマーの削除に失敗しました"
 ],
 "Timers": [
  null,
  "タイマー"
 ],
 "Toggle date picker": [
  null,
  "日付選択の切り替え"
 ],
 "Toggle filters": [
  null,
  "フィルターの切り替え"
 ],
 "Total size: $0": [
  null,
  "合計サイズ: $0"
 ],
 "Tower": [
  null,
  "タワー"
 ],
 "Transient": [
  null,
  "一時的"
 ],
 "Trigger": [
  null,
  "トリガー"
 ],
 "Triggered by": [
  null,
  "トリガー元"
 ],
 "Triggers": [
  null,
  "トリガー"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 との同期を試行中です"
 ],
 "Tuesdays": [
  null,
  "毎週火曜日"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned の起動に失敗しました"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned は、システムを監視し、特定のワークロードでパフォーマンスを最適化するサービスです。Tuned のコアは、さまざまなユースケースに合わせてシステムを調整するプロファイルです。"
 ],
 "Tuned is not available": [
  null,
  "Tuned が利用できません"
 ],
 "Tuned is not running": [
  null,
  "Tuned が実行中ではありません"
 ],
 "Tuned is off": [
  null,
  "Tuned がオフです"
 ],
 "Turn on administrative access": [
  null,
  "管理者アクセスをオンにする"
 ],
 "Type": [
  null,
  "タイプ"
 ],
 "Type to filter": [
  null,
  "フィルターのために入力"
 ],
 "Unit": [
  null,
  "ユニット"
 ],
 "Unit not found": [
  null,
  "単位が見つかりません"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Unpin unit": [
  null,
  "ユニットの固定を解除する"
 ],
 "Until": [
  null,
  "フィルター終了時刻"
 ],
 "Updating status...": [
  null,
  "ステータスを更新中..."
 ],
 "Uptime": [
  null,
  "稼働時間"
 ],
 "Usage": [
  null,
  "使用率"
 ],
 "User": [
  null,
  "ユーザー"
 ],
 "Validating address": [
  null,
  "アドレスの検証"
 ],
 "Vendor": [
  null,
  "ベンダー"
 ],
 "Version": [
  null,
  "バージョン"
 ],
 "View all logs": [
  null,
  "すべてのログの表示"
 ],
 "View all services": [
  null,
  "すべてのサービスの表示"
 ],
 "View hardware details": [
  null,
  "ハードウェアの詳細の表示"
 ],
 "View login history": [
  null,
  "ログイン履歴の表示"
 ],
 "View metrics and history": [
  null,
  "メトリックスおよび履歴の表示"
 ],
 "View report": [
  null,
  "レポートの表示"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "メモリー情報を表示するには、管理アクセスが必要です。"
 ],
 "Waiting for input…": [
  null,
  "入力を待機中…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "他のソフトウェア管理オペレーションが終了するまで待機中"
 ],
 "Waiting to start…": [
  null,
  "開始を待機中…"
 ],
 "Wanted by": [
  null,
  "望まれる"
 ],
 "Wants": [
  null,
  "望む"
 ],
 "Warning and above": [
  null,
  "警告以上のレベル"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Web コンソールが制限付きアクセスモードで実行されています。"
 ],
 "Wednesdays": [
  null,
  "毎週水曜日"
 ],
 "Weekly": [
  null,
  "毎週"
 ],
 "Weeks": [
  null,
  "週"
 ],
 "White": [
  null,
  "白"
 ],
 "Yearly": [
  null,
  "毎年"
 ],
 "Yes": [
  null,
  "はい"
 ],
 "You may try to load older entries.": [
  null,
  "古いエントリーのロードを試行することができます。"
 ],
 "You now have administrative access.": [
  null,
  "これで管理者アクセスが可能になりました。"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "お使いのブラウザーでは、コンテキストメニューからの貼り付けが許可されていません。Shift+Insert を使用できます。"
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "ブラウザーはセッション間のアクセスレベルを記憶します。"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[バイナリーデータの $0 バイト]"
 ],
 "[binary data]": [
  null,
  "[バイナリーデータ]"
 ],
 "[no data]": [
  null,
  "[データなし]"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "active": [
  null,
  "アクティブ"
 ],
 "asset tag": [
  null,
  "アセットタグ"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "BIOS"
 ],
 "boot": [
  null,
  "ブート"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "コマンド"
 ],
 "console": [
  null,
  "コンソール"
 ],
 "coredump": [
  null,
  "コアダンプ"
 ],
 "cpu": [
  null,
  "CPU"
 ],
 "crash": [
  null,
  "クラッシュ"
 ],
 "date": [
  null,
  "日付"
 ],
 "debug": [
  null,
  "デバッグ"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "無効にする"
 ],
 "disks": [
  null,
  "ディスク"
 ],
 "domain": [
  null,
  "ドメイン"
 ],
 "edit": [
  null,
  "編集"
 ],
 "enable": [
  null,
  "有効にする"
 ],
 "error": [
  null,
  "エラー"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "ssh ホスト鍵の一覧表示に失敗しました: $0"
 ],
 "graphs": [
  null,
  "グラフ"
 ],
 "hardware": [
  null,
  "ハードウェア"
 ],
 "history": [
  null,
  "履歴"
 ],
 "host": [
  null,
  "ホスト"
 ],
 "inconsistent": [
  null,
  "一貫性がない"
 ],
 "journal": [
  null,
  "ジャーナル"
 ],
 "journalctl manpage": [
  null,
  "journalctl man ページ"
 ],
 "machine": [
  null,
  "マシン"
 ],
 "mask": [
  null,
  "マスク"
 ],
 "memory": [
  null,
  "メモリー"
 ],
 "metrics": [
  null,
  "メトリックス"
 ],
 "mitigation": [
  null,
  "軽減"
 ],
 "network": [
  null,
  "ネットワーク"
 ],
 "none": [
  null,
  "なし"
 ],
 "of $0 CPU": [
  null,
  "CPU 数 ($0)"
 ],
 "operating system": [
  null,
  "オペレーティングシステム"
 ],
 "os": [
  null,
  "OS"
 ],
 "path": [
  null,
  "パス"
 ],
 "pci": [
  null,
  "PCI"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "パフォーマンス"
 ],
 "power": [
  null,
  "電源"
 ],
 "ram": [
  null,
  "RAM"
 ],
 "recommended": [
  null,
  "推奨"
 ],
 "restart": [
  null,
  "再起動"
 ],
 "running $0": [
  null,
  "実行中 $0"
 ],
 "serial": [
  null,
  "シリアル"
 ],
 "service": [
  null,
  "サービス"
 ],
 "shell": [
  null,
  "シェル"
 ],
 "show less": [
  null,
  "簡易表示"
 ],
 "show more": [
  null,
  "詳細表示"
 ],
 "shut": [
  null,
  "シャット"
 ],
 "socket": [
  null,
  "ソケット"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "ターゲット"
 ],
 "time": [
  null,
  "時間"
 ],
 "timer": [
  null,
  "タイマー"
 ],
 "unit": [
  null,
  "単位"
 ],
 "unknown": [
  null,
  "不明"
 ],
 "unmask": [
  null,
  "マスク解除"
 ],
 "version": [
  null,
  "バージョン"
 ],
 "warning": [
  null,
  "警告"
 ],
 "dialog-title\u0004Domain": [
  null,
  "ドメイン"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "ドメインへの参加"
 ],
 "from <host>\u0004from $0": [
  null,
  "$0 から"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "$1 の $0 から"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "$0 上"
 ]
});
