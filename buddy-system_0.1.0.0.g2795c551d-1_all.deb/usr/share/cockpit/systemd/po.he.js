cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "פגיעה חמורה אחת",
  "$0 פגיעות, כולל חמורות",
  "$0 פגיעות, כולל חמורות",
  "$0 פגיעות, כולל חמורות"
 ],
 "$0 failed login attempt": [
  null,
  "ניסיון כניסה שנכשל",
  "שני ניסיונות כניסה שנכשלו",
  "$0 ניסיונות כניסה שנכשלו",
  "$0 ניסיונות כניסה שנכשלו"
 ],
 "$0 important hit": [
  null,
  "פגיעה חשובה אחת",
  "$0 פגיעות חשובות",
  "$0 פגיעות חשובות",
  "$0 פגיעות חשובות"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 אינו זמין מאף מאגר."
 ],
 "$0 low severity hit": [
  null,
  "פגיעה אחת בדרגת חומרה נמוכה",
  "$0 פגיעות בדרגת חומרה נמוכה",
  "$0 פגיעות בדרגת חומרה נמוכה",
  "$0 פגיעות בדרגת חומרה נמוכה"
 ],
 "$0 moderate hit": [
  null,
  "פגיעה אחת בינונית",
  "$0 פגיעות, כולל בינוניות",
  "$0 פגיעות, כולל בינוניות",
  "$0 פגיעות, כולל בינוניות"
 ],
 "$0 service has failed": [
  null,
  "שירות אחד נכשל",
  "$0 שירותים נכשלו",
  "$0 שירותים נכשלו",
  "$0 שירותים נכשלו"
 ],
 "$0 will be installed.": [
  null,
  "$0 יותקן."
 ],
 "$0: crash at $1": [
  null,
  "$0: קריסה ב־$1"
 ],
 "1 minute": [
  null,
  "דקה"
 ],
 "10th": [
  null,
  "עשירי"
 ],
 "11th": [
  null,
  "אחד עשר"
 ],
 "12th": [
  null,
  "שניים עשר"
 ],
 "13th": [
  null,
  "שלושה עשר"
 ],
 "14th": [
  null,
  "ארבעה עשר"
 ],
 "15th": [
  null,
  "חמישה עשר"
 ],
 "16th": [
  null,
  "שישה עשר"
 ],
 "17th": [
  null,
  "שבעה עשר"
 ],
 "18th": [
  null,
  "שמונה עשר"
 ],
 "19th": [
  null,
  "תשעה עשר"
 ],
 "1st": [
  null,
  "אחד"
 ],
 "20 minutes": [
  null,
  "20 דקות"
 ],
 "20th": [
  null,
  "עשרים"
 ],
 "21th": [
  null,
  "עשרים ואחד"
 ],
 "22th": [
  null,
  "עשרים ושניים"
 ],
 "23th": [
  null,
  "עשרים ושלושה"
 ],
 "24th": [
  null,
  "עשרים וארבעה"
 ],
 "25th": [
  null,
  "עשרים וחמישה"
 ],
 "26th": [
  null,
  "עשרים ושישה"
 ],
 "27th": [
  null,
  "עשרים ושבעה"
 ],
 "28th": [
  null,
  "עשרים ושמונה"
 ],
 "29th": [
  null,
  "עשרים ותשעה"
 ],
 "2nd": [
  null,
  "שניים"
 ],
 "30th": [
  null,
  "שלושים"
 ],
 "31st": [
  null,
  "שלושים ואחד"
 ],
 "3rd": [
  null,
  "שלושה"
 ],
 "40 minutes": [
  null,
  "40 דקות"
 ],
 "4th": [
  null,
  "ארבעה"
 ],
 "5 minutes": [
  null,
  "5 דקות"
 ],
 "5th": [
  null,
  "חמישה"
 ],
 "60 minutes": [
  null,
  "60 דקות"
 ],
 "6th": [
  null,
  "שישה"
 ],
 "7th": [
  null,
  "שבעה"
 ],
 "8th": [
  null,
  "שמונה"
 ],
 "9th": [
  null,
  "תשעה"
 ],
 "Absent": [
  null,
  "חסר"
 ],
 "Active since ": [
  null,
  "פעיל מאז "
 ],
 "Active state": [
  null,
  "מצב פעיל"
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "Additional actions": [
  null,
  "פעולות נוספות"
 ],
 "Additional packages:": [
  null,
  "חבילות נוספות:"
 ],
 "Administrative access": [
  null,
  "גישה ניהולית"
 ],
 "Advanced TCA": [
  null,
  "TCA מתקדם"
 ],
 "After": [
  null,
  "אחרי"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "לאחר עזיבת שם התחום, רק משתמשים עם פרטי גישה מקומיים יוכלו להיכנס למכונה הזאת. זה עשוי להשפיע על שירותים אחרים כגון פתרון בעזרת DNS ורשימת רשויות האישורים המהימנות עשויה להשתנות."
 ],
 "After system boot": [
  null,
  "לאחר עליית המערכת"
 ],
 "Alert and above": [
  null,
  "אזעקה ומעלה"
 ],
 "Alias": [
  null,
  "כינוי"
 ],
 "All": [
  null,
  "הכול"
 ],
 "All-in-one": [
  null,
  "אול אין ואן"
 ],
 "Allow running (unmask)": [
  null,
  "לאפשר הרצה (ביטול מיסוך)"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  ""
 ],
 "Appearance": [
  null,
  "מראה"
 ],
 "Apply and reboot": [
  null,
  "החלה והפעלה מחדש"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "המדיניות החדשה חלה… עשוי לארוך מספר דקות."
 ],
 "Asset tag": [
  null,
  "תג נכס"
 ],
 "At minute": [
  null,
  "בדקה"
 ],
 "At specific time": [
  null,
  "במועד מסוים"
 ],
 "Authenticate": [
  null,
  "אימות"
 ],
 "Automatically starts": [
  null,
  "מתחיל אוטומטית"
 ],
 "Automatically using NTP": [
  null,
  "אוטומטית באמצעות NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "אוטומטית באמצעות שרתי NTP מסוימים"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "תאריך BIOS"
 ],
 "BIOS version": [
  null,
  "גרסת BIOS"
 ],
 "Bad": [
  null,
  "פסול"
 ],
 "Bad setting": [
  null,
  "הגדרה פסולה"
 ],
 "Before": [
  null,
  "לפני"
 ],
 "Binds to": [
  null,
  "מתאגד אל"
 ],
 "Black": [
  null,
  "שחור"
 ],
 "Blade": [
  null,
  "בלייד"
 ],
 "Blade enclosure": [
  null,
  "אריזת בלייד"
 ],
 "Boot": [
  null,
  "עלייה"
 ],
 "Bound by": [
  null,
  "מאוגד על ידי"
 ],
 "Bus expansion chassis": [
  null,
  "שלדת הרחבת אפיקים"
 ],
 "CPU": [
  null,
  "מעבד"
 ],
 "CPU security": [
  null,
  "אבטחת מעבד"
 ],
 "CPU security toggles": [
  null,
  "מתגי אבטחת מעבד"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "לא ניתן למצוא יומנים עם שילוב המסננים הנוכחי."
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Cancel poweroff": [
  null,
  "ביטול כיבוי"
 ],
 "Cancel reboot": [
  null,
  "ביטול הפעלה מחדש"
 ],
 "Cannot be enabled": [
  null,
  "לא ניתן להפעיל"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "לא ניתן להצטרף לשם תחום כיוון ש־realmd לא זמין במערכת הזו"
 ],
 "Cannot schedule event in the past": [
  null,
  "לא ניתן לתזמן אירוע לעבר"
 ],
 "Change": [
  null,
  "החלפה"
 ],
 "Change crypto policy": [
  null,
  "החלפת מדיניות קריפטוגרפית"
 ],
 "Change host name": [
  null,
  "החלפת שם מארח"
 ],
 "Change performance profile": [
  null,
  "החלפת פרופיל ביצועים"
 ],
 "Change profile": [
  null,
  "החלפת פרופיל"
 ],
 "Change system time": [
  null,
  "החלפת שעון המערכת"
 ],
 "Checking installed software": [
  null,
  "התכנה שמותקנת נבדקת"
 ],
 "Class": [
  null,
  "מחלקה"
 ],
 "Clear 'Failed to start'": [
  null,
  "לנקות ‚התחלה נכשלה’"
 ],
 "Clear all filters": [
  null,
  "ניקוי כל המסננים"
 ],
 "Client software": [
  null,
  "תכנה מצד לקוח"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Command": [
  null,
  "פקודה"
 ],
 "Command not found": [
  null,
  "הפקודה לא נמצאה"
 ],
 "Communication with tuned has failed": [
  null,
  "התקשורת עם tuned נכשלה"
 ],
 "Compact PCI": [
  null,
  "PCI חסכוני"
 ],
 "Condition $0=$1 was not met": [
  null,
  "התנאי $0=$1 לא התקיים"
 ],
 "Condition failed": [
  null,
  "התנאי נכשל"
 ],
 "Configuration": [
  null,
  "הגדרות"
 ],
 "Configuring system settings": [
  null,
  "הגדרות המערכת מוגדרות"
 ],
 "Confirm deletion of $0": [
  null,
  "אישור המחיקה של $0"
 ],
 "Conflicted by": [
  null,
  "בסתירה עם"
 ],
 "Conflicts": [
  null,
  "סותר"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "החיבור ל־dbus נכשל: $0"
 ],
 "Consists of": [
  null,
  "מורכב מ־"
 ],
 "Contacted domain": [
  null,
  "שם תחום שנוצר אתו קשר"
 ],
 "Controller": [
  null,
  "בקר"
 ],
 "Convertible": [
  null,
  "מתהפך"
 ],
 "Copy": [
  null,
  "העתקה"
 ],
 "Copy to clipboard": [
  null,
  "העתקה ללוח הגזירים"
 ],
 "Crash reporting": [
  null,
  "דיווח על קריסות"
 ],
 "Create timer": [
  null,
  "יצירת מתזמן"
 ],
 "Critical and above": [
  null,
  "חמור ומעלה"
 ],
 "Crypto Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  ""
 ],
 "Crypto policy": [
  null,
  "מדיניות קריפטוגרפית"
 ],
 "Crypto policy is inconsistent": [
  null,
  "המדיניות הקרפיטוגרפית אינה אחידה"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "עלייה נוכחית"
 ],
 "Custom crypto policy": [
  null,
  "מדיניות קריפטוגרפית משלך"
 ],
 "Daily": [
  null,
  "יומי"
 ],
 "Dark": [
  null,
  "כהה"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  ""
 ],
 "Debug and above": [
  null,
  "ניפוי שגיאות ומעלה"
 ],
 "Decrease by one": [
  null,
  "להקטין באחד"
 ],
 "Delay": [
  null,
  "השהיה"
 ],
 "Delay must be a number": [
  null,
  "השהיה חייבת להיות מספר"
 ],
 "Delete": [
  null,
  "מחיקה"
 ],
 "Deletion will remove the following files:": [
  null,
  "מחיקה תסיר את הקבצים הבאים:"
 ],
 "Description": [
  null,
  "תיאור"
 ],
 "Desktop": [
  null,
  "שולחן עבודה"
 ],
 "Detachable": [
  null,
  "נתיק"
 ],
 "Details": [
  null,
  "פרטים"
 ],
 "Disable simultaneous multithreading": [
  null,
  "השבתת ריבוי תהליכים מקבילי"
 ],
 "Disable tuned": [
  null,
  "השבתת tuned"
 ],
 "Disabled": [
  null,
  "מושבת"
 ],
 "Disallow running (mask)": [
  null,
  "לא לאפשר הרצה (מיסוך)"
 ],
 "Docking station": [
  null,
  "תחנת עגינה"
 ],
 "Does not automatically start": [
  null,
  "לא מתחיל אוטומטית"
 ],
 "Domain": [
  null,
  "שם תחום"
 ],
 "Domain address": [
  null,
  "כתובת שם תחום"
 ],
 "Domain administrator name": [
  null,
  "שם מנהל שם תחום"
 ],
 "Domain administrator password": [
  null,
  "סיסמת מנהל שם תחום"
 ],
 "Domain could not be contacted": [
  null,
  "לא ניתן ליצור קשר עם שם התחום"
 ],
 "Domain is not supported": [
  null,
  "שם התחום אינו נתמך"
 ],
 "Don't repeat": [
  null,
  "לא לחזור"
 ],
 "Downloading $0": [
  null,
  "$0 בהורדה"
 ],
 "Dual rank": [
  null,
  "דו־צדדי"
 ],
 "Edit /etc/motd": [
  null,
  "עריכת ‎/etc/motd"
 ],
 "Edit motd": [
  null,
  "עריכת ההודעה היומית"
 ],
 "Embedded PC": [
  null,
  "מחשב משובץ"
 ],
 "Enabled": [
  null,
  "מופעל"
 ],
 "Entry at $0": [
  null,
  "רשומה ב־$0"
 ],
 "Error": [
  null,
  "שגיאה"
 ],
 "Error and above": [
  null,
  "שגיאה ומעלה"
 ],
 "Error message": [
  null,
  "הודעת שגיאה"
 ],
 "Expansion chassis": [
  null,
  "שלדת הרחבה"
 ],
 "Extended information": [
  null,
  "פירוט מורחב"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS לא מופעל כראוי"
 ],
 "Failed to disable tuned": [
  null,
  "ההשבתה של tuned נכשלה"
 ],
 "Failed to enable tuned": [
  null,
  "ההפעלה של tuned נכשלה"
 ],
 "Failed to fetch logs": [
  null,
  "משיכת יומנים נכשלה"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "שמירת השינויים ב־‎/etc/motd נכשלה"
 ],
 "Failed to start": [
  null,
  "ההפעלה נכשלה"
 ],
 "Failed to switch profile": [
  null,
  "החלפת פרופיל נכשלה"
 ],
 "File state": [
  null,
  "מצב הקובץ"
 ],
 "Filter by name or description": [
  null,
  "סינון לפי שם או תיאור"
 ],
 "Filters": [
  null,
  "מסננים"
 ],
 "Font size": [
  null,
  "גודל גופן"
 ],
 "Forbidden from running": [
  null,
  "נאסר עליו לפעול"
 ],
 "Frame number": [
  null,
  "מספר מסגרת"
 ],
 "Free-form search": [
  null,
  "חיפוש חופשי"
 ],
 "Fridays": [
  null,
  "ימי שישי"
 ],
 "General": [
  null,
  "כללי"
 ],
 "Generated": [
  null,
  "נוצר"
 ],
 "Go to $0": [
  null,
  "לעבור אל $0"
 ],
 "Handheld": [
  null,
  "נישא"
 ],
 "Hardware information": [
  null,
  "פרטי חומרה"
 ],
 "Health": [
  null,
  "בריאות"
 ],
 "Help": [
  null,
  "עזרה"
 ],
 "Hierarchy ID": [
  null,
  "מזהה היררכיה"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  ""
 ],
 "Hostname": [
  null,
  "שם מארח"
 ],
 "Hourly": [
  null,
  "שעתי"
 ],
 "Hours": [
  null,
  "שעות"
 ],
 "ID": [
  null,
  "מזהה"
 ],
 "Identifier": [
  null,
  "מזהה"
 ],
 "Increase by one": [
  null,
  "להגדיל באחד"
 ],
 "Indirect": [
  null,
  "עקיף"
 ],
 "Info and above": [
  null,
  "מידע ומעלה"
 ],
 "Insights: ": [
  null,
  "תובנות: "
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Install software": [
  null,
  "התקנת תכנה"
 ],
 "Installing $0": [
  null,
  "$0 בהתקנה"
 ],
 "Invalid": [
  null,
  "שגוי"
 ],
 "Invalid date format": [
  null,
  "מבנה התאריך שגוי"
 ],
 "Invalid date format and invalid time format": [
  null,
  "מבנה תאריך שגוי ומבנה שעה שגוי"
 ],
 "Invalid time format": [
  null,
  "מבנה השעה שגוי"
 ],
 "Invalid timezone": [
  null,
  "אזור זמן שגוי"
 ],
 "IoT gateway": [
  null,
  "שער גישה IoT"
 ],
 "Join": [
  null,
  "הצטרפות"
 ],
 "Join domain": [
  null,
  "הצטרפות לשם תחום"
 ],
 "Joining": [
  null,
  "הצטרפות"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "הצטרפות לשם תחום דורש את התקנת realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "אין תמיכה בהצטרפות לשם התחום הזה"
 ],
 "Joins namespace of": [
  null,
  "מצטרף למרחב השם של"
 ],
 "Journal": [
  null,
  "ז׳ורנל"
 ],
 "Journal entry": [
  null,
  "רשומת ז׳ורנל"
 ],
 "Journal entry not found": [
  null,
  "רשומת הז׳ורנל לא נמצאה"
 ],
 "Laptop": [
  null,
  "מחשב נייד"
 ],
 "Last 24 hours": [
  null,
  "24 השעות האחרונות"
 ],
 "Last 7 days": [
  null,
  "7 הימים האחרונים"
 ],
 "Last successful login:": [
  null,
  "כניסה אחרונה שהצליחה:"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "Leave $0": [
  null,
  "לעזוב את $0"
 ],
 "Leave domain": [
  null,
  "עזיבת שם התחום"
 ],
 "Light": [
  null,
  "בהירה"
 ],
 "Limit access": [
  null,
  "הגבלת גישה"
 ],
 "Limited access": [
  null,
  "גישה מוגבלת"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "מצב גישה מוגבלת מגביל את ההרשאות הניהוליות. חלקים מסוימים במסוף המקוון יפעלו באופן חלקי."
 ],
 "Limits": [
  null,
  "הגבלות"
 ],
 "Linked": [
  null,
  "מקושר"
 ],
 "Listen": [
  null,
  "האזנה"
 ],
 "Listing unit files": [
  null,
  ""
 ],
 "Listing unit files failed: $0": [
  null,
  ""
 ],
 "Load earlier entries": [
  null,
  "טעינת רשומות קודמות"
 ],
 "Loading earlier entries": [
  null,
  "רשומות קודמות נטענות"
 ],
 "Loading keys...": [
  null,
  "המפתחות נטענים…"
 ],
 "Loading of SSH keys failed": [
  null,
  "טעינת מפתחות ה־SSH נכשלה"
 ],
 "Loading...": [
  null,
  "בטעינה…"
 ],
 "Log messages": [
  null,
  "הודעות יומן"
 ],
 "Login format": [
  null,
  "תצורת כניסה"
 ],
 "Logs": [
  null,
  "יומנים"
 ],
 "Low profile desktop": [
  null,
  "מחשב שולחני עם פרופיל נמוך"
 ],
 "Lunch box": [
  null,
  "קופסת אוכל"
 ],
 "Machine ID": [
  null,
  "מזהה מכונה"
 ],
 "Machine SSH key fingerprints": [
  null,
  "טביעות אצבע מפתח SSH של מכונה"
 ],
 "Main server chassis": [
  null,
  "שלדת שרת ראשית"
 ],
 "Maintenance": [
  null,
  "תחזוקה"
 ],
 "Managing services": [
  null,
  "ניהול שירותים"
 ],
 "Manually": [
  null,
  "ידנית"
 ],
 "Mask service": [
  null,
  "מיסוך שירות"
 ],
 "Masked": [
  null,
  "ממוסך"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "מיסוך שירות מונע מכל היחידות התלויות לפעול. להגדרה זו עשויה להיות השפעה גדולה מהצפוי. נא לאשר שברצונך למסך את היחידה הזאת."
 ],
 "Memory": [
  null,
  "זיכרון"
 ],
 "Memory technology": [
  null,
  "טכנולוגיית זיכרון"
 ],
 "Merged": [
  null,
  ""
 ],
 "Message to logged in users": [
  null,
  "הודעה למשתמשים שנמצאים במערכת"
 ],
 "Method": [
  null,
  "שיטה"
 ],
 "Mini PC": [
  null,
  "מחשב מוקטן"
 ],
 "Mini tower": [
  null,
  "מארז מוקטן"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "דקה חייבת להיות מספר בין 0 ל־59"
 ],
 "Minutes": [
  null,
  "דקות"
 ],
 "Mitigations": [
  null,
  "אפחותים"
 ],
 "Model": [
  null,
  "דגם"
 ],
 "Mondays": [
  null,
  "ימי שני"
 ],
 "Monthly": [
  null,
  "חודשי"
 ],
 "Multi-system chassis": [
  null,
  "שלדה למגוון מערכות"
 ],
 "NTP server": [
  null,
  "שרת NTP"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Need at least one NTP server": [
  null,
  "נדרש שרת NTP אחד לפחות"
 ],
 "No": [
  null,
  "לא"
 ],
 "No delay": [
  null,
  "אין השהיה"
 ],
 "No host keys found.": [
  null,
  "לא נמצאו מפתחות מארחים."
 ],
 "No log entries": [
  null,
  "אין רשומות ביומן"
 ],
 "No logs found": [
  null,
  "לא נמצאו יומנים"
 ],
 "No matching results": [
  null,
  "אין כללים תואמים"
 ],
 "No results found": [
  null,
  "לא נמצאו תוצאות"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "לא נמצאו תוצאות לתנאי המסנן. יש לנקות את כל המסננים כדי להציג תוצאות."
 ],
 "No rule hits": [
  null,
  "אין פגיעות בכללים"
 ],
 "None": [
  null,
  "אין"
 ],
 "Not connected to Insights": [
  null,
  "לא מחובר לתובנות"
 ],
 "Not found": [
  null,
  "לא נמצא"
 ],
 "Not running": [
  null,
  "לא פועל"
 ],
 "Not synchronized": [
  null,
  "לא מסונכרן"
 ],
 "Note": [
  null,
  "הערה"
 ],
 "Notebook": [
  null,
  "מחברת"
 ],
 "Notice and above": [
  null,
  "הודעה ומעלה"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "On failure": [
  null,
  "בעת כשל"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "מותר רק אותיות באנגלית, מספרים, : , _ , . , @ , -"
 ],
 "Only emergency": [
  null,
  "חירום בלבד"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  ""
 ],
 "Other": [
  null,
  "אחר"
 ],
 "Overview": [
  null,
  "סקירה"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit קרס"
 ],
 "Part of": [
  null,
  "חלק מתוך"
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Paste": [
  null,
  "הדבקה"
 ],
 "Path": [
  null,
  "נתיב"
 ],
 "Paths": [
  null,
  "נתיבים"
 ],
 "Pause": [
  null,
  "השהיה"
 ],
 "Performance profile": [
  null,
  "פרופיל ביצועים"
 ],
 "Peripheral chassis": [
  null,
  "שלדת התקנים חיצוניים"
 ],
 "Pick date": [
  null,
  "בחירת תאריך"
 ],
 "Pinned unit": [
  null,
  ""
 ],
 "Pizza box": [
  null,
  "קופסת פיצה"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "נא לעבור אימות כדי לקבל גישת ניהול"
 ],
 "Portable": [
  null,
  "נייד"
 ],
 "Present": [
  null,
  "נוכחי"
 ],
 "Pretty host name": [
  null,
  "שם מארח יפה"
 ],
 "Previous boot": [
  null,
  "עלייה קודמת"
 ],
 "Priority": [
  null,
  "עדיפות"
 ],
 "Problem details": [
  null,
  "פרטי הבעיה"
 ],
 "Problem info": [
  null,
  "מידע על הבעיה"
 ],
 "Propagates reload to": [
  null,
  "מפיץ רענון אל"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  ""
 ],
 "RAID chassis": [
  null,
  "שלדת RAID"
 ],
 "Rack mount chassis": [
  null,
  "שלדת מעגן מתלה (Rack)"
 ],
 "Rank": [
  null,
  "דירוג"
 ],
 "Read more...": [
  null,
  "מידע נוסף…"
 ],
 "Read-only": [
  null,
  "קריאה בלבד"
 ],
 "Real host name": [
  null,
  "שם המארח האמתי"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "שם המארח האמתי יכול להכיל רק אותיות קטנות באנגלית, ספרות, מינוסים ונקודות (עם תת־שמות תחום מאוכלסים)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "אורך שם התחום האמתי חייב להיות קצר מ־64 תווים"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  ""
 ],
 "Reload": [
  null,
  "רענון"
 ],
 "Reload propagated from": [
  null,
  "הטעינה הופצה מהמקור"
 ],
 "Removals:": [
  null,
  "הסרות:"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "Removing $0": [
  null,
  "$0 בהסרה"
 ],
 "Repeat": [
  null,
  "לחזור"
 ],
 "Repeat monthly": [
  null,
  "לחזור באופן חודשי"
 ],
 "Repeat weekly": [
  null,
  "לחזור באופן שבועי"
 ],
 "Report": [
  null,
  "דיווח"
 ],
 "Report to ABRT Analytics": [
  null,
  "דיווח לניתוח של ABRT"
 ],
 "Reported; no links available": [
  null,
  "מדווח, אין קישורים זמינים"
 ],
 "Reporting failed": [
  null,
  "הדיווח נכשל"
 ],
 "Reporting was canceled": [
  null,
  "הדיווח בוטל"
 ],
 "Reports:": [
  null,
  "דיווחים:"
 ],
 "Required by": [
  null,
  "נדרש על ידי"
 ],
 "Required by ": [
  null,
  "נדרש על ידי "
 ],
 "Requires": [
  null,
  "דורש"
 ],
 "Requires administration access to edit": [
  null,
  "נדרשת גישה ניהולית כדי לערוך"
 ],
 "Requisite": [
  null,
  "הכרח"
 ],
 "Requisite of": [
  null,
  "הכרח של"
 ],
 "Reset": [
  null,
  "איפוס"
 ],
 "Restart": [
  null,
  "הפעלה מחדש"
 ],
 "Resume": [
  null,
  "המשך"
 ],
 "Reviewing logs": [
  null,
  "היומנים נסקרים"
 ],
 "Run on": [
  null,
  ""
 ],
 "Running": [
  null,
  "פועל"
 ],
 "Saturdays": [
  null,
  "שבתות"
 ],
 "Save": [
  null,
  "שמירה"
 ],
 "Save and reboot": [
  null,
  "שמירה והפעלה מחדש"
 ],
 "Save changes": [
  null,
  "שמירת השינויים"
 ],
 "Scheduled poweroff at $0": [
  null,
  ""
 ],
 "Scheduled reboot at $0": [
  null,
  ""
 ],
 "Sealed-case PC": [
  null,
  "מחשב במארז אטום"
 ],
 "Search": [
  null,
  "חיפוש"
 ],
 "Seconds": [
  null,
  "שניות"
 ],
 "Secure shell keys": [
  null,
  "מפתחות מעטפת מאובטחת"
 ],
 "Send": [
  null,
  "שליחה"
 ],
 "Server software": [
  null,
  "התכנה בשרת"
 ],
 "Service logs": [
  null,
  "יומני שירות"
 ],
 "Services": [
  null,
  "שירותים"
 ],
 "Set hostname": [
  null,
  "הגדרת שם מארח"
 ],
 "Set time": [
  null,
  "הגדרת שעה"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "להציג את כל התהליכונים"
 ],
 "Show fingerprints": [
  null,
  "הצגת טביעות אצבע"
 ],
 "Show messages containing given string.": [
  null,
  ""
 ],
 "Show messages for the specified systemd unit.": [
  null,
  ""
 ],
 "Show messages from a specific boot.": [
  null,
  ""
 ],
 "Show more relationships": [
  null,
  ""
 ],
 "Show relationships": [
  null,
  ""
 ],
 "Shut down": [
  null,
  "כיבוי"
 ],
 "Shutdown": [
  null,
  "כיבוי"
 ],
 "Since": [
  null,
  ""
 ],
 "Single rank": [
  null,
  "שורה אחת"
 ],
 "Size": [
  null,
  "גודל"
 ],
 "Slot": [
  null,
  "משבצת"
 ],
 "Sockets": [
  null,
  "שקעים"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "מעקפי תכנה מסייעים למנוע תקלות אבטחה במעבד. לאפחותים אלו יש השפעות לוואי בדמות הפחתת ביצועים. שינוי ההגדרות האלו הוא על אחריותך בלבד."
 ],
 "Space-saving computer": [
  null,
  "מחשב חסכוני במקום"
 ],
 "Specific time": [
  null,
  "זמן מסוים"
 ],
 "Speed": [
  null,
  "מהירות"
 ],
 "Start": [
  null,
  "התחלה"
 ],
 "Start and enable": [
  null,
  "התחלה והפעלה"
 ],
 "Start service": [
  null,
  "התחלת שירות"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  ""
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  ""
 ],
 "State": [
  null,
  "מצב"
 ],
 "Static": [
  null,
  "סטטי"
 ],
 "Status": [
  null,
  "מצב"
 ],
 "Stick PC": [
  null,
  "מחשב מקלון"
 ],
 "Stop": [
  null,
  "עצירה"
 ],
 "Stop and disable": [
  null,
  "עצירה והשבתה"
 ],
 "Stub": [
  null,
  ""
 ],
 "Sub-Chassis": [
  null,
  "תת שלדה"
 ],
 "Sub-Notebook": [
  null,
  "תת מחברת"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  ""
 ],
 "Sundays": [
  null,
  "ימי ראשון"
 ],
 "Switch to limited access": [
  null,
  "העברה לגישה מוגבלת"
 ],
 "Synchronized": [
  null,
  "מסונכרן"
 ],
 "Synchronized with $0": [
  null,
  "מסונכרן עם $0"
 ],
 "Synchronizing": [
  null,
  "מתבצע סנכרון"
 ],
 "System": [
  null,
  "מערכת"
 ],
 "System information": [
  null,
  "פרטי המערכת"
 ],
 "System time": [
  null,
  "שעון המערכת"
 ],
 "Systemd units": [
  null,
  "יחידות Systemd"
 ],
 "Tablet": [
  null,
  "מחשב לוח"
 ],
 "Targets": [
  null,
  "יעדים"
 ],
 "Terminal": [
  null,
  "מסוף"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "המשתמש $0 אינו מורשה לשנות את אפחותי אבטחת המעבד"
 ],
 "This field cannot be empty": [
  null,
  "שדה זה לא יכול להישאר ריק"
 ],
 "This may take a while": [
  null,
  "פעולה זו עשויה לארוך זמן מה"
 ],
 "This system is using a custom profile": [
  null,
  "מערכת זו משתמשת בפרופיל מותאם אישית"
 ],
 "This system is using the recommended profile": [
  null,
  "מערכת זו משתמשת בפרופיל המומלץ"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "יחידה זו לא תוכננה להפעלה באופן מפורש."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  ""
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  ""
 ],
 "Thursdays": [
  null,
  "ימי חמישי"
 ],
 "Time": [
  null,
  "שעה"
 ],
 "Time zone": [
  null,
  "אזור זמן"
 ],
 "Timer creation failed": [
  null,
  "יצירת קוצב הזמן נכשלה"
 ],
 "Timers": [
  null,
  "מתזמנים"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Total size: $0": [
  null,
  "גודל כולל: $0"
 ],
 "Tower": [
  null,
  "מארז גבוה"
 ],
 "Transient": [
  null,
  ""
 ],
 "Triggered by": [
  null,
  "מוקפץ על ידי"
 ],
 "Triggers": [
  null,
  "הקפצות"
 ],
 "Trying to synchronize with $0": [
  null,
  "מתבצע ניסיון להסתנכרן מול $0"
 ],
 "Tuesdays": [
  null,
  "ימי שלישי"
 ],
 "Tuned has failed to start": [
  null,
  "ההפעלה של Tuned נכשלה"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned הוא שירות שעוקב אחר המערכת שלך וממטב את הביצועים תחת עומסים מסוימים. הליבה של Tuned הם פרופילים, שמכוונים את המערכת שלך למגוון מקרי בוחן."
 ],
 "Tuned is not available": [
  null,
  "Tuned אינו זמין"
 ],
 "Tuned is not running": [
  null,
  "Tuned אינו מופעל"
 ],
 "Tuned is off": [
  null,
  "Tuned כבוי"
 ],
 "Turn on administrative access": [
  null,
  "הפעלת גישה ניהולית"
 ],
 "Type": [
  null,
  "סוג"
 ],
 "Type to filter": [
  null,
  "יש להקליד כדי לסנן"
 ],
 "Unit": [
  null,
  "יחידה"
 ],
 "Unit not found": [
  null,
  "היחידה לא נמצאה"
 ],
 "Unknown": [
  null,
  "לא ידוע"
 ],
 "Until": [
  null,
  ""
 ],
 "Updating status...": [
  null,
  "המצב מתעדכן…"
 ],
 "Uptime": [
  null,
  "זמן פעילות"
 ],
 "Usage": [
  null,
  "שימוש"
 ],
 "User": [
  null,
  "משתמש"
 ],
 "Validating address": [
  null,
  "הכתובת מתוקפת"
 ],
 "Vendor": [
  null,
  "ספק"
 ],
 "Version": [
  null,
  "גרסה"
 ],
 "View hardware details": [
  null,
  "הצגת פרטי חומרה"
 ],
 "View report": [
  null,
  "הצגת דוח"
 ],
 "Waiting for input…": [
  null,
  "בהמתנה לקלט…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "בהמתנה לסיום פעולות ניהול תכנה אחרות"
 ],
 "Waiting to start…": [
  null,
  "בהמתנה להפעלה…"
 ],
 "Wanted by": [
  null,
  "נדרש על ידי"
 ],
 "Wants": [
  null,
  "דורש"
 ],
 "Warning and above": [
  null,
  "אזהרה ומעלה"
 ],
 "Web console is running in limited access mode.": [
  null,
  "המסוף המקוון מופעל במצב גישה מוגבלת."
 ],
 "Wednesdays": [
  null,
  "ימי רביעי"
 ],
 "Weekly": [
  null,
  "שבועי"
 ],
 "Weeks": [
  null,
  "שבועות"
 ],
 "White": [
  null,
  "לבן"
 ],
 "Yearly": [
  null,
  "שנתי"
 ],
 "Yes": [
  null,
  "כן"
 ],
 "You may try to load older entries.": [
  null,
  "כדאי לך לנסות לטעון רשומות ישנות יותר."
 ],
 "You now have administrative access.": [
  null,
  "מעתה יש לך גישה ניהולית."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "הדפדפן שלך יזכור את רמת הגישה שלך בין הפעלות."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 בתים של נתונים בינריים]"
 ],
 "[binary data]": [
  null,
  "[נתונים בינריים]"
 ],
 "[no data]": [
  null,
  "[אין נתונים]"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "active": [
  null,
  "פעיל"
 ],
 "asset tag": [
  null,
  "תג נכס"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "עלייה"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "פקודה"
 ],
 "console": [
  null,
  "מסוף"
 ],
 "coredump": [
  null,
  "היטל ליבה"
 ],
 "cpu": [
  null,
  "מעבד"
 ],
 "crash": [
  null,
  "קריסה"
 ],
 "date": [
  null,
  "תאריך"
 ],
 "debug": [
  null,
  "ניפוי שגיאות"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "השבתה"
 ],
 "disks": [
  null,
  "כוננים"
 ],
 "domain": [
  null,
  "שם תחום"
 ],
 "edit": [
  null,
  "עריכה"
 ],
 "enable": [
  null,
  "הפעלה"
 ],
 "error": [
  null,
  "שגיאה"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "הצגת מפתחות ה־ssh של המארח נכשלה: $0"
 ],
 "graphs": [
  null,
  "תרשימים"
 ],
 "hardware": [
  null,
  "חומרה"
 ],
 "history": [
  null,
  "היסטוריה"
 ],
 "host": [
  null,
  "מארח"
 ],
 "journal": [
  null,
  "ז׳ורנל"
 ],
 "journalctl manpage": [
  null,
  "מדריך השימוש ב־journalctl"
 ],
 "machine": [
  null,
  "מכונה"
 ],
 "mask": [
  null,
  "מסכה"
 ],
 "memory": [
  null,
  "זיכרון"
 ],
 "metrics": [
  null,
  "מדדים"
 ],
 "mitigation": [
  null,
  "אפחות"
 ],
 "network": [
  null,
  "רשת"
 ],
 "none": [
  null,
  "אין"
 ],
 "of $0 CPU": [
  null,
  "מתוך מעבד אחד",
  "מתוך $0 מעבדים",
  "מתוך $0 מעבדים",
  "מתוך $0 מעבדים"
 ],
 "operating system": [
  null,
  "מערכת הפעלה"
 ],
 "os": [
  null,
  "מערכת הפעלה"
 ],
 "path": [
  null,
  "נתיב"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "power": [
  null,
  "חשמל"
 ],
 "ram": [
  null,
  "זיכרון"
 ],
 "recommended": [
  null,
  "מומלץ"
 ],
 "restart": [
  null,
  "הפעלה מחדש"
 ],
 "running $0": [
  null,
  "פועל $0"
 ],
 "serial": [
  null,
  "טורי"
 ],
 "service": [
  null,
  "שירות"
 ],
 "shell": [
  null,
  "מעטפת"
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ],
 "shut": [
  null,
  "לסגור"
 ],
 "socket": [
  null,
  "שקע"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "יעד"
 ],
 "time": [
  null,
  "זמן"
 ],
 "timer": [
  null,
  "קוצב זמן"
 ],
 "unit": [
  null,
  "יחידה"
 ],
 "unknown": [
  null,
  "לא ידוע"
 ],
 "unmask": [
  null,
  "הסרת מיסוך"
 ],
 "version": [
  null,
  "גרסה"
 ],
 "warning": [
  null,
  "אזהרה"
 ],
 "dialog-title\u0004Domain": [
  null,
  "שם תחום"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "הצטרפות לשם תחום"
 ]
});
