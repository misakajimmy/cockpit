cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 kritik sonuç",
  "$0 sonuç, kritik olanlar dahil"
 ],
 "$0 failed login attempt": [
  null,
  "$0 başarısız oturum açma girişimi",
  "$0 başarısız oturum açma girişimi"
 ],
 "$0 important hit": [
  null,
  "$0 önemli sonuç",
  "$0 sonuç, önemli olanlar dahil"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0, hiçbir depoda yok."
 ],
 "$0 low severity hit": [
  null,
  "$0 düşük önem derecesinde sonuç",
  "$0 düşük önem derecesinde sonuç"
 ],
 "$0 moderate hit": [
  null,
  "$0 orta dereceli sonuç",
  "$0 sonuç, orta dereceli olanlar dahil"
 ],
 "$0 service has failed": [
  null,
  "$0 hizmet başarısız oldu",
  "$0 hizmet başarısız oldu"
 ],
 "$0 will be installed.": [
  null,
  "$0 yüklenecektir."
 ],
 "$0: crash at $1": [
  null,
  "$0: $1 tarihinde çökme"
 ],
 "1 minute": [
  null,
  "1 dakika"
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "1st": [
  null,
  "1."
 ],
 "20 minutes": [
  null,
  "20 dakika"
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "2nd": [
  null,
  "2."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "3rd": [
  null,
  "3."
 ],
 "40 minutes": [
  null,
  "40 dakika"
 ],
 "4th": [
  null,
  "4."
 ],
 "5 minutes": [
  null,
  "5 dakika"
 ],
 "5th": [
  null,
  "5."
 ],
 "60 minutes": [
  null,
  "60 dakika"
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "Absent": [
  null,
  "Yok"
 ],
 "Active since ": [
  null,
  "Etkin olma başlangıcı "
 ],
 "Active state": [
  null,
  "Etkin durum"
 ],
 "Add": [
  null,
  "Ekle"
 ],
 "Additional actions": [
  null,
  "Ek eylemler"
 ],
 "Additional packages:": [
  null,
  "Ek paketler:"
 ],
 "Administrative access": [
  null,
  "Yönetimsel erişim"
 ],
 "Advanced TCA": [
  null,
  "Gelişmiş TCA"
 ],
 "After": [
  null,
  "Sonra"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Etki alanından ayrıldıktan sonra, sadece yerel kimlik bilgilerine sahip kullanıcılar bu makinede oturum açabilecektir. DNS çözümleme ayarları ve güvenilen CA'ların listesi değişebileceğinden, bu durum diğer hizmetleri de etkileyebilir."
 ],
 "After system boot": [
  null,
  "Sistem önyüklemesinden sonra"
 ],
 "Alert and above": [
  null,
  "Uyarı ve üstü"
 ],
 "Alias": [
  null,
  "Kod adı"
 ],
 "All": [
  null,
  "Tümü"
 ],
 "All-in-one": [
  null,
  "Hepsi-bir-arada"
 ],
 "Allow running (unmask)": [
  null,
  "Çalıştırmaya izin ver (maskelemeyi kaldır)"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Günlük iletilerindeki herhangi bir metin dizgisi süzülebilir. Dizgi ayrıca düzenli ifade biçiminde de olabilir. Ayrıca ileti günlük alanlarına göre süzmeyi de destekler. Bunlar, değerin olası değerlerin virgülle ayrılmış listesi olabilen, FIELD=VALUE biçimindeki boşlukla ayrılmış değerlerdir."
 ],
 "Appearance": [
  null,
  "Görünüm"
 ],
 "Apply and reboot": [
  null,
  "Uygula ve yeniden başlat"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Yeni ilke uygulanıyor... Bu işlem birkaç dakika sürebilir."
 ],
 "Asset tag": [
  null,
  "Demirbaş etiketi"
 ],
 "At minute": [
  null,
  "Dakikada"
 ],
 "At specific time": [
  null,
  "Belirli bir zamanda"
 ],
 "Authenticate": [
  null,
  "Kimlik doğrula"
 ],
 "Automatically starts": [
  null,
  "Otomatik olarak başlar"
 ],
 "Automatically using NTP": [
  null,
  "Otomatik olarak NTP kullanarak"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Otomatik olarak belirli NTP sunucularını kullanarak"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS tarihi"
 ],
 "BIOS version": [
  null,
  "BIOS sürümü"
 ],
 "Bad": [
  null,
  "Hatalı"
 ],
 "Bad setting": [
  null,
  "Hatalı ayar"
 ],
 "Before": [
  null,
  "Önce"
 ],
 "Binds to": [
  null,
  "Bağlanır"
 ],
 "Black": [
  null,
  "Siyah"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Blade kasası"
 ],
 "Boot": [
  null,
  "Önyükleme"
 ],
 "Bound by": [
  null,
  "Bağlayan"
 ],
 "Bus expansion chassis": [
  null,
  "Veri yolu genişletme kasası"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "CPU güvenliği"
 ],
 "CPU security toggles": [
  null,
  "CPU güvenlik geçişleri"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Şu anki süzgeçlerin birleşimi kullanılarak herhangi bir günlük bulunamıyor."
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Cancel poweroff": [
  null,
  "Kapatmayı iptal et"
 ],
 "Cancel reboot": [
  null,
  "Yeniden başlatmayı iptal et"
 ],
 "Cannot be enabled": [
  null,
  "Etkinleştirilemez"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Bu sistemde realmd mevcut olmadığından bir etki alanına katılamıyor"
 ],
 "Cannot schedule event in the past": [
  null,
  "Geçmişteki olay zamanlanamıyor"
 ],
 "Change": [
  null,
  "Değiştir"
 ],
 "Change crypto policy": [
  null,
  "Şifreleme ilkesini değiştir"
 ],
 "Change host name": [
  null,
  "Anamakine adını değiştir"
 ],
 "Change performance profile": [
  null,
  "Performans profilini değiştir"
 ],
 "Change profile": [
  null,
  "Profili değiştir"
 ],
 "Change system time": [
  null,
  "Sistem saatini değiştir"
 ],
 "Checking installed software": [
  null,
  "Yüklü yazılımlar denetleniyor"
 ],
 "Class": [
  null,
  "Sınıf"
 ],
 "Clear 'Failed to start'": [
  null,
  "'Başlatılamadı' hatasını temizle"
 ],
 "Clear all filters": [
  null,
  "Tüm süzgeçleri temizle"
 ],
 "Client software": [
  null,
  "İstemci yazılımı"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Command": [
  null,
  "Komut"
 ],
 "Command not found": [
  null,
  "Komut bulunamadı"
 ],
 "Communication with tuned has failed": [
  null,
  "tuned ile iletişim başarısız oldu"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "$0=$1 koşulu karşılanmadı"
 ],
 "Condition failed": [
  null,
  "Koşul başarısız oldu"
 ],
 "Configuration": [
  null,
  "Yapılandırma"
 ],
 "Configuring system settings": [
  null,
  "Sistem ayarlarını yapılandırma"
 ],
 "Confirm deletion of $0": [
  null,
  "$0 aygıtının silinmesini onayla"
 ],
 "Conflicted by": [
  null,
  "Çakışan"
 ],
 "Conflicts": [
  null,
  "Çakışanlar"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Dbus'a bağlanma başarısız oldu: $0"
 ],
 "Consists of": [
  null,
  "İçerir"
 ],
 "Contacted domain": [
  null,
  "İletişim kurulan etki alanı"
 ],
 "Controller": [
  null,
  "Denetleyici"
 ],
 "Convertible": [
  null,
  "Dönüştürülebilir"
 ],
 "Copy": [
  null,
  "Kopyala"
 ],
 "Copy to clipboard": [
  null,
  "Panoya kopyala"
 ],
 "Crash reporting": [
  null,
  "Çökme bildirimi"
 ],
 "Create timer": [
  null,
  "Zamanlayıcı oluştur"
 ],
 "Critical and above": [
  null,
  "Kritik ve üstü"
 ],
 "Crypto Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Şifreleme İlkeleri TLS, IPSec, SSH, DNSSec ve Kerberos protokollerini kapsayan temel şifreleme alt sistemlerini yapılandıran bir sistem bileşenidir."
 ],
 "Crypto policy": [
  null,
  "Şifreleme ilkesi"
 ],
 "Crypto policy is inconsistent": [
  null,
  "Şifreleme ilkesi tutarsız"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Şu anki önyükleme"
 ],
 "Custom crypto policy": [
  null,
  "Özel şifreleme ilkesi"
 ],
 "Daily": [
  null,
  "Günlük"
 ],
 "Dark": [
  null,
  "Koyu"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Tarih özellikleri, YYYY-MM-DD hh:mm:ss biçiminde olmalıdır. Alternatif olarak 'yesterday', 'today', 'tomorrow' dizgileri de anlaşılır. 'now' şu anki zamanı ifade eder. Son olarak, göreceli zamanlar '-' veya '+' önekleri ile belirtilebilir"
 ],
 "Debug and above": [
  null,
  "Hata ayıklama ve üstü"
 ],
 "Decrease by one": [
  null,
  "Bir azalt"
 ],
 "Delay": [
  null,
  "Gecikme"
 ],
 "Delay must be a number": [
  null,
  "Gecikme bir sayı olmak zorundadır"
 ],
 "Delete": [
  null,
  "Sil"
 ],
 "Deletion will remove the following files:": [
  null,
  "Silme işlemi aşağıdaki dosyaları kaldıracak:"
 ],
 "Description": [
  null,
  "Açıklama"
 ],
 "Desktop": [
  null,
  "Masaüstü"
 ],
 "Detachable": [
  null,
  "Ayrılabilir"
 ],
 "Details": [
  null,
  "Ayrıntılar"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Eşzamanlı çoklu kullanımı etkisizleştir"
 ],
 "Disable tuned": [
  null,
  "tuned'i etkisizleştir"
 ],
 "Disabled": [
  null,
  "Etkisizleştirildi"
 ],
 "Disallow running (mask)": [
  null,
  "Çalıştırmaya izin verme (maskele)"
 ],
 "Docking station": [
  null,
  "Kenetleme istasyonu"
 ],
 "Does not automatically start": [
  null,
  "Otomatik olarak başlamaz"
 ],
 "Domain": [
  null,
  "Etki alanı"
 ],
 "Domain address": [
  null,
  "Etki alanı adresi"
 ],
 "Domain administrator name": [
  null,
  "Etki alanı yöneticisi adı"
 ],
 "Domain administrator password": [
  null,
  "Etki alanı yöneticisi parolası"
 ],
 "Domain could not be contacted": [
  null,
  "Etki alanıyla iletişim kurulamadı"
 ],
 "Domain is not supported": [
  null,
  "Etki alanı desteklenmiyor"
 ],
 "Don't repeat": [
  null,
  "Tekrarlama"
 ],
 "Downloading $0": [
  null,
  "$0 indiriliyor"
 ],
 "Dual rank": [
  null,
  "Çift sıra"
 ],
 "Edit /etc/motd": [
  null,
  "/etc/motd'yi düzenle"
 ],
 "Edit motd": [
  null,
  "motd'yi düzenle"
 ],
 "Embedded PC": [
  null,
  "Gömülü PC"
 ],
 "Enabled": [
  null,
  "Etkinleştirildi"
 ],
 "Entry at $0": [
  null,
  "$0 tarihindeki giriş"
 ],
 "Error": [
  null,
  "Hata"
 ],
 "Error and above": [
  null,
  "Hata ve üstü"
 ],
 "Error message": [
  null,
  "Hata iletisi"
 ],
 "Expansion chassis": [
  null,
  "Genişletme kasası"
 ],
 "Extended information": [
  null,
  "Genişletilmiş bilgiler"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS düzgün şekilde etkinleştirilmedi"
 ],
 "Failed to disable tuned": [
  null,
  "tuned etkisizleştirme başarısız oldu"
 ],
 "Failed to disabled tuned profile": [
  null,
  "tuned profilini etkisizleştirmesi başarısız oldu"
 ],
 "Failed to enable tuned": [
  null,
  "tuned etkinleştirme başarısız oldu"
 ],
 "Failed to fetch logs": [
  null,
  "Günlükleri getirme başarısız oldu"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "/etc/motd içinde değişiklikleri kaydetme başarısız oldu"
 ],
 "Failed to start": [
  null,
  "Başlatılamadı"
 ],
 "Failed to switch profile": [
  null,
  "Profil değiştirme başarısız oldu"
 ],
 "File state": [
  null,
  "Dosya durumu"
 ],
 "Filter by name or description": [
  null,
  "Ada veya açıklamaya göre süz"
 ],
 "Filters": [
  null,
  "Süzgeçler"
 ],
 "Font size": [
  null,
  "Yazı tipi boyutu"
 ],
 "Forbidden from running": [
  null,
  "Çalıştırılması yasak"
 ],
 "Frame number": [
  null,
  "Çerçeve numarası"
 ],
 "Free-form search": [
  null,
  "Serbest biçimli arama"
 ],
 "Fridays": [
  null,
  "Cuma günleri"
 ],
 "General": [
  null,
  "Genel"
 ],
 "Generated": [
  null,
  "Oluşturuldu"
 ],
 "Go to $0": [
  null,
  "$0 hizmetine git"
 ],
 "Handheld": [
  null,
  "Elde taşınan"
 ],
 "Hardware information": [
  null,
  "Donanım bilgileri"
 ],
 "Health": [
  null,
  "Sağlık"
 ],
 "Help": [
  null,
  "Yardım"
 ],
 "Hierarchy ID": [
  null,
  "Hiyerarşi Kimliği"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Artan saldırı yüzeyi pahasına daha yüksek birlikte çalışabilirlik."
 ],
 "Hostname": [
  null,
  "Anamakine adı"
 ],
 "Hourly": [
  null,
  "Saatlik"
 ],
 "Hours": [
  null,
  "Saat"
 ],
 "ID": [
  null,
  "Kimlik"
 ],
 "Identifier": [
  null,
  "Tanımlayıcı"
 ],
 "Increase by one": [
  null,
  "Bir artır"
 ],
 "Indirect": [
  null,
  "Dolaylı"
 ],
 "Info and above": [
  null,
  "Bilgi ve üstü"
 ],
 "Insights: ": [
  null,
  "Insights: "
 ],
 "Install": [
  null,
  "Yükle"
 ],
 "Install software": [
  null,
  "Yazılım yükle"
 ],
 "Installing $0": [
  null,
  "$0 yükleniyor"
 ],
 "Invalid": [
  null,
  "Geçersiz"
 ],
 "Invalid date format": [
  null,
  "Geçersiz tarih biçimi"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Geçersiz tarih ve saat biçimi"
 ],
 "Invalid time format": [
  null,
  "Geçersiz saat biçimi"
 ],
 "Invalid timezone": [
  null,
  "Geçersiz saat dilimi"
 ],
 "IoT gateway": [
  null,
  "IoT ağ geçidi"
 ],
 "Join": [
  null,
  "Katıl"
 ],
 "Join domain": [
  null,
  "Etki alanına katıl"
 ],
 "Joining": [
  null,
  "Katılıyor"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Bir etki alanına katılmak, realmd kurulumu gerektirir"
 ],
 "Joining this domain is not supported": [
  null,
  "Bu etki alanına katılmak desteklenmiyor"
 ],
 "Joins namespace of": [
  null,
  "Katıldığı ait olduğu ad alanı"
 ],
 "Journal": [
  null,
  "Günlük"
 ],
 "Journal entry": [
  null,
  "Günlük girişi"
 ],
 "Journal entry not found": [
  null,
  "Günlük girişi bulunamadı"
 ],
 "Laptop": [
  null,
  "Dizüstü"
 ],
 "Last 24 hours": [
  null,
  "Son 24 saat"
 ],
 "Last 7 days": [
  null,
  "Son 7 gün"
 ],
 "Last successful login:": [
  null,
  "Son başarılı oturum açma:"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "Leave $0": [
  null,
  "$0'dan ayrıl"
 ],
 "Leave domain": [
  null,
  "Etki alanından ayrıl"
 ],
 "Light": [
  null,
  "Açık"
 ],
 "Limit access": [
  null,
  "Erişimi sınırla"
 ],
 "Limited access": [
  null,
  "Sınırlı erişim"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Sınırlı erişim kipi, yönetimsel yetkileri kısıtlar. Web konsolunun bazı kısımları sınırlı işlevselliğe sahip olacaktır."
 ],
 "Limits": [
  null,
  "Sınırlar"
 ],
 "Linked": [
  null,
  "Bağlantılı"
 ],
 "Listen": [
  null,
  "Dinle"
 ],
 "Listing unit files": [
  null,
  "Birim dosyalarını listeleme"
 ],
 "Listing unit files failed: $0": [
  null,
  "Birim dosyalarını listeleme başarısız oldu: $0"
 ],
 "Listing units": [
  null,
  "Birimleri listeleme"
 ],
 "Listing units failed: $0": [
  null,
  "Birimleri listeleme başarısız oldu: $0"
 ],
 "Load earlier entries": [
  null,
  "Daha önceki girişleri yükle"
 ],
 "Loading earlier entries": [
  null,
  "Daha önceki girişler yükleniyor"
 ],
 "Loading keys...": [
  null,
  "Anahtarlar yükleniyor..."
 ],
 "Loading of SSH keys failed": [
  null,
  "SSH anahtarlarını yükleme başarısız oldu"
 ],
 "Loading of units failed": [
  null,
  "Birimlerin yüklenmesi başarısız oldu"
 ],
 "Loading unit failed: $0": [
  null,
  "Birimin yüklenmesi başarısız oldu: $0"
 ],
 "Loading...": [
  null,
  "Yükleniyor..."
 ],
 "Log messages": [
  null,
  "Günlük iletileri"
 ],
 "Login format": [
  null,
  "Oturum açma biçimi"
 ],
 "Logs": [
  null,
  "Günlükler"
 ],
 "Low profile desktop": [
  null,
  "Düşük profilli masaüstü"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Machine ID": [
  null,
  "Makine kimliği"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Makine SSH anahtarı parmak izleri"
 ],
 "Main server chassis": [
  null,
  "Ana sunucu kasası"
 ],
 "Maintenance": [
  null,
  "Bakım"
 ],
 "Managing services": [
  null,
  "Hizmetleri yönetme"
 ],
 "Manually": [
  null,
  "El ile"
 ],
 "Mask service": [
  null,
  "Hizmeti maskele"
 ],
 "Masked": [
  null,
  "Maskelendi"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Hizmeti maskelemek, tüm bağımlı birimlerin çalışmasını engeller. Bunun beklenenden daha büyük etkisi olabilir. Lütfen bu birimi maskelemek istediğinizi onaylayın."
 ],
 "Memory": [
  null,
  "Bellek"
 ],
 "Memory technology": [
  null,
  "Bellek teknolojisi"
 ],
 "Merged": [
  null,
  "Birleştirildi"
 ],
 "Message to logged in users": [
  null,
  "Oturum açmış kullanıcılar için ileti"
 ],
 "Method": [
  null,
  "Yöntem"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Dakikanın 0 ile 59 arasında bir sayı olması gerekir"
 ],
 "Minutes": [
  null,
  "Dakika"
 ],
 "Mitigations": [
  null,
  "Risk azaltmaları"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Mondays": [
  null,
  "Pazartesi günleri"
 ],
 "Monthly": [
  null,
  "Aylık"
 ],
 "Multi-system chassis": [
  null,
  "Çok sistemli kasa"
 ],
 "NTP server": [
  null,
  "NTP sunucusu"
 ],
 "Name": [
  null,
  "Ad"
 ],
 "Need at least one NTP server": [
  null,
  "En az bir NTP sunucusu gerekli"
 ],
 "No": [
  null,
  "Hayır"
 ],
 "No delay": [
  null,
  "Gecikme yok"
 ],
 "No host keys found.": [
  null,
  "Bulunan anamakine anahtarları yok."
 ],
 "No log entries": [
  null,
  "Günlük girişleri yok"
 ],
 "No logs found": [
  null,
  "Bulunan günlükler yok"
 ],
 "No matching results": [
  null,
  "Eşleşen sonuçlar yok"
 ],
 "No results found": [
  null,
  "Bulunan sonuçlar yok"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Süzme ölçütüyle eşleşen sonuçlar yok. Sonuçları göstermek için tüm süzgeçleri temizleyin."
 ],
 "No rule hits": [
  null,
  "Kural sonuçları yok"
 ],
 "None": [
  null,
  "Yok"
 ],
 "Not connected to Insights": [
  null,
  "Insights'a bağlı değil"
 ],
 "Not found": [
  null,
  "Bulunamadı"
 ],
 "Not permitted to configure realms": [
  null,
  "Bölgeleri yapılandırmaya izin verilmiyor"
 ],
 "Not running": [
  null,
  "Çalışmıyor"
 ],
 "Not synchronized": [
  null,
  "Eşitlenmedi"
 ],
 "Note": [
  null,
  "Not"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Notice and above": [
  null,
  "Bildirim ve üstü"
 ],
 "Ok": [
  null,
  "Tamam"
 ],
 "On failure": [
  null,
  "Başarısızlık durumunda"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Sadece harfler, sayılar, : , _ , . , @ , - karakterlerine izin verilir"
 ],
 "Only emergency": [
  null,
  "Sadece acil durumlar"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "FIPS modunda önyükleme yaparken yalnızca onaylanmış ve izin verilen algoritmaları kullan."
 ],
 "Other": [
  null,
  "Diğer"
 ],
 "Overview": [
  null,
  "Genel Bakış"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit çöktü"
 ],
 "Part of": [
  null,
  "Parçası olduğu"
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Paste": [
  null,
  "Yapıştır"
 ],
 "Paste error": [
  null,
  "Yapıştırma hatası"
 ],
 "Path": [
  null,
  "Yol"
 ],
 "Paths": [
  null,
  "Yollar"
 ],
 "Pause": [
  null,
  "Duraklat"
 ],
 "Performance profile": [
  null,
  "Performans profili"
 ],
 "Peripheral chassis": [
  null,
  "Çevresel donanım kasası"
 ],
 "Pick date": [
  null,
  "Tarih seçin"
 ],
 "Pin unit": [
  null,
  "Birimi sabitle"
 ],
 "Pinned unit": [
  null,
  "Sabitlenmiş birim"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Lütfen yönetimsel erişim elde etmek için kimlik doğrulayın"
 ],
 "Portable": [
  null,
  "Taşınabilir"
 ],
 "Present": [
  null,
  "Mevcut"
 ],
 "Pretty host name": [
  null,
  "Okunaklı anamakine adı"
 ],
 "Previous boot": [
  null,
  "Önceki önyükleme"
 ],
 "Priority": [
  null,
  "Öncelik"
 ],
 "Problem becoming administrator": [
  null,
  "Yönetici olma sorunu"
 ],
 "Problem details": [
  null,
  "Sorun ayrıntıları"
 ],
 "Problem info": [
  null,
  "Sorun bilgileri"
 ],
 "Propagates reload to": [
  null,
  "Yeniden yüklemeyi şuna yayar"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Birlikte çalışabilirlik pahasına beklenen yakın vadeli gelecekteki saldırılara karşı korur."
 ],
 "RAID chassis": [
  null,
  "RAID kasası"
 ],
 "Rack mount chassis": [
  null,
  "Raf montajlı kasa"
 ],
 "Rank": [
  null,
  "Sıra"
 ],
 "Read more...": [
  null,
  "Daha fazlasını okuyun..."
 ],
 "Read-only": [
  null,
  "Salt-okunur"
 ],
 "Real host name": [
  null,
  "Gerçek anamakine adı"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Gerçek anamakine adı sadece küçük harf, rakam, kısa çizgi ve nokta karakterlerini (doldurulmuş alt etki alanlarıyla) içerebilir"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Gerçek anamakine adı 64 karakter veya daha kısa olmak zorundadır"
 ],
 "Reapply and reboot": [
  null,
  "Yeniden uygula ve yeniden başlat"
 ],
 "Reboot": [
  null,
  "Yeniden başlat"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Geçerli tehdit modelleri için tavsiye edilen, güvenli ayarlar."
 ],
 "Reload": [
  null,
  "Yeniden yükle"
 ],
 "Reload propagated from": [
  null,
  "Yeniden yükleme şuradan yayıldı"
 ],
 "Reloading": [
  null,
  "Yeniden yükleniyor"
 ],
 "Removals:": [
  null,
  "Kaldırılanlar:"
 ],
 "Remove": [
  null,
  "Kaldır"
 ],
 "Removing $0": [
  null,
  "$0 kaldırılıyor"
 ],
 "Repeat": [
  null,
  "Tekrarla"
 ],
 "Repeat monthly": [
  null,
  "Her ay tekrarla"
 ],
 "Repeat weekly": [
  null,
  "Her hafta tekrarla"
 ],
 "Report": [
  null,
  "Bildir"
 ],
 "Report to ABRT Analytics": [
  null,
  "ABRT Analytics'e bildir"
 ],
 "Reported; no links available": [
  null,
  "Bildirildi; mevcut bağlantılar yok"
 ],
 "Reporting failed": [
  null,
  "Bildirme başarısız oldu"
 ],
 "Reporting was canceled": [
  null,
  "Bildirme iptal edildi"
 ],
 "Reports:": [
  null,
  "Bildirmeler:"
 ],
 "Required by": [
  null,
  "Gerektiren"
 ],
 "Required by ": [
  null,
  "Gerektiren: "
 ],
 "Requires": [
  null,
  "Gerekliler"
 ],
 "Requires administration access to edit": [
  null,
  "Düzenlemek için yönetim erişimi gerektirir"
 ],
 "Requisite": [
  null,
  "Gereklilik"
 ],
 "Requisite of": [
  null,
  "Gerekliliği"
 ],
 "Reset": [
  null,
  "Sıfırla"
 ],
 "Restart": [
  null,
  "Yeniden başlat"
 ],
 "Resume": [
  null,
  "Devam"
 ],
 "Review crypto policy": [
  null,
  "Şifreleme ilkesini gözden geçir"
 ],
 "Reviewing logs": [
  null,
  "Günlükleri gözden geçirme"
 ],
 "Run at": [
  null,
  "Çalıştırma saati"
 ],
 "Run on": [
  null,
  "Çalıştırma tarihi"
 ],
 "Running": [
  null,
  "Çalışıyor"
 ],
 "Saturdays": [
  null,
  "Cumartesi günleri"
 ],
 "Save": [
  null,
  "Kaydet"
 ],
 "Save and reboot": [
  null,
  "Kaydet ve yeniden başlat"
 ],
 "Save changes": [
  null,
  "Değişiklikleri kaydet"
 ],
 "Scheduled poweroff at $0": [
  null,
  "$0 için kapatma zamanlandı"
 ],
 "Scheduled reboot at $0": [
  null,
  "$0 için yeniden başlatma zamanlandı"
 ],
 "Sealed-case PC": [
  null,
  "Mühürlü Kasa PC"
 ],
 "Search": [
  null,
  "Ara"
 ],
 "Seconds": [
  null,
  "Saniye"
 ],
 "Secure shell keys": [
  null,
  "Güvenli kabuk anahtarları"
 ],
 "Select a identifier": [
  null,
  "Bir tanımlayıcı seçin"
 ],
 "Send": [
  null,
  "Gönder"
 ],
 "Server software": [
  null,
  "Sunucu yazılımı"
 ],
 "Service logs": [
  null,
  "Hizmet günlükleri"
 ],
 "Services": [
  null,
  "Hizmetler"
 ],
 "Set hostname": [
  null,
  "Anamakine adını ayarla"
 ],
 "Set time": [
  null,
  "Saati ayarla"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "Tüm iş parçacıklarını göster"
 ],
 "Show fingerprints": [
  null,
  "Parmak izlerini göster"
 ],
 "Show messages containing given string.": [
  null,
  "Verilen dizgiyi içeren iletileri gösterin."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Belirtilen systemd birimi için iletileri gösterin."
 ],
 "Show messages from a specific boot.": [
  null,
  "Belirli bir önyüklemeden gelen iletileri gösterin."
 ],
 "Show more relationships": [
  null,
  "Daha fazla ilişki göster"
 ],
 "Show relationships": [
  null,
  "İlişkileri göster"
 ],
 "Shut down": [
  null,
  "Kapat"
 ],
 "Shutdown": [
  null,
  "Kapat"
 ],
 "Since": [
  null,
  "Başlangıç"
 ],
 "Single rank": [
  null,
  "Tek sıra"
 ],
 "Size": [
  null,
  "Boyut"
 ],
 "Slot": [
  null,
  "Yuva"
 ],
 "Sockets": [
  null,
  "Soketler"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Yazılım tabanlı geçici çözümler, CPU güvenlik sorunlarını önlemeye yardımcı olur. Bu risk azaltmaları, performansı düşürme yan etkisine sahiptir. Bu ayarları değiştirmekte sorumluluk size aittir."
 ],
 "Space-saving computer": [
  null,
  "Yerden kazandıran bilgisayar"
 ],
 "Specific time": [
  null,
  "Belirli bir zaman"
 ],
 "Speed": [
  null,
  "Hız"
 ],
 "Start": [
  null,
  "Başlat"
 ],
 "Start and enable": [
  null,
  "Başlat ve etkinleştir"
 ],
 "Start service": [
  null,
  "Hizmeti başlat"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Belirtilen tarihten daha yeni veya o tarihteki girişleri göstermeye başlayın."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Belirtilen tarihten daha eski veya o tarihteki girişleri göstermeye başlayın."
 ],
 "State": [
  null,
  "Durum"
 ],
 "Static": [
  null,
  "Sabit"
 ],
 "Status": [
  null,
  "Durum"
 ],
 "Stick PC": [
  null,
  "Çubuk PC"
 ],
 "Stop": [
  null,
  "Durdur"
 ],
 "Stop and disable": [
  null,
  "Durdur ve etkisizleştir"
 ],
 "Stub": [
  null,
  "Kalıntı"
 ],
 "Sub-Chassis": [
  null,
  "Alt Kasa"
 ],
 "Sub-Notebook": [
  null,
  "Alt Dizüstü"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "systemd sinyallerine abone olma başarısız oldu: $0"
 ],
 "Successfully copied to keyboard": [
  null,
  "Başarılı olarak klavyeye kopyalandı"
 ],
 "Sundays": [
  null,
  "Pazar günleri"
 ],
 "Switch to administrative access": [
  null,
  "Yönetimsel erişime geç"
 ],
 "Switch to limited access": [
  null,
  "Sınırlı erişime geç"
 ],
 "Synchronized": [
  null,
  "Eşitlendi"
 ],
 "Synchronized with $0": [
  null,
  "$0 ile eşitlendi"
 ],
 "Synchronizing": [
  null,
  "Eşitleniyor"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "System information": [
  null,
  "Sistem bilgileri"
 ],
 "System time": [
  null,
  "Sistem saati"
 ],
 "Systemd units": [
  null,
  "Systemd birimleri"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Targets": [
  null,
  "Hedefler"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "$0 kullanıcısının CPU güvenlik riski azaltmalarını değiştirmesine izin verilmiyor"
 ],
 "The user $0 is not permitted to change crypto policies": [
  null,
  "$0 kullanıcısının şifreleme ilkelerini değiştirmesine izin verilmiyor"
 ],
 "This field cannot be empty": [
  null,
  "Bu alan boş olamaz"
 ],
 "This may take a while": [
  null,
  "Bu biraz zaman alabilir"
 ],
 "This system is using a custom profile": [
  null,
  "Bu sistem özel bir profil kullanıyor"
 ],
 "This system is using the recommended profile": [
  null,
  "Bu sistem önerilen profili kullanıyor"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Bu birim açıkça etkinleştirilecek şekilde tasarlanmadı."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Bu, '_BOOT_ID=' için bir eşleşme ekleyecektir. Eğer belirtilmemişse, şu anki önyükleme için günlükler gösterilecektir. Eğer önyükleme kimliği atlanırsa, pozitif bir denkleştirme, günlüğün başından itibaren başlayarak önyüklemeleri arayacak ve eşit ya da sıfırdan az denkleştirme, günlüğün sonundan başlayarak önyüklemeleri arayacaktır. Böylece, 1, günlükte bulunan ilk önyükleme, 2, ikincisi ve bunun gibi; -0 son önyükleme ise, -1 sondan önceki önyükleme ve bunun gibi."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "Bu, belirli birim için olası tüm iletileri bulmak amacıyla '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' ve 'UNIT=' için eşleşme ekleyecek. Virgülle ayrılmış daha fazla birim içerebilir. "
 ],
 "Thursdays": [
  null,
  "Perşembe günleri"
 ],
 "Time": [
  null,
  "Zaman"
 ],
 "Time zone": [
  null,
  "Saat dilimi"
 ],
 "Timer creation failed": [
  null,
  "Zamanlayıcı oluşturma başarısız oldu"
 ],
 "Timer deletion failed": [
  null,
  "Zamanlayıcı silme başarısız oldu"
 ],
 "Timers": [
  null,
  "Zamanlayıcılar"
 ],
 "Toggle date picker": [
  null,
  "Tarihi seçiciyi aç/kapat"
 ],
 "Toggle filters": [
  null,
  "Süzgeçleri aç/kapat"
 ],
 "Total size: $0": [
  null,
  "Toplam boyut: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Transient": [
  null,
  "Geçici"
 ],
 "Trigger": [
  null,
  "Tetikleyici"
 ],
 "Triggered by": [
  null,
  "Tetikleyen"
 ],
 "Triggers": [
  null,
  "Tetikleyiciler"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 ile eşitlemeye çalışılıyor"
 ],
 "Tuesdays": [
  null,
  "Salı günleri"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned başlatılamadı"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned , sisteminizi izleyen ve belirli iş yükleri altında performansı en iyi hale getiren bir hizmettir. Tuned'ın çekirdeği, sisteminizi farklı kullanım durumları için ayarlayan profillerdir."
 ],
 "Tuned is not available": [
  null,
  "Tuned kullanılabilir değil"
 ],
 "Tuned is not running": [
  null,
  "Tuned çalışmıyor"
 ],
 "Tuned is off": [
  null,
  "Tuned kapalı"
 ],
 "Turn on administrative access": [
  null,
  "Yönetimsel erişimi aç"
 ],
 "Type": [
  null,
  "Tür"
 ],
 "Type to filter": [
  null,
  "Süzmek için yazın"
 ],
 "Unit": [
  null,
  "Birim"
 ],
 "Unit not found": [
  null,
  "Birim bulunamadı"
 ],
 "Unknown": [
  null,
  "Bilinmiyor"
 ],
 "Unpin unit": [
  null,
  "Birimi sabitlemeyi kaldır"
 ],
 "Until": [
  null,
  "Bitiş"
 ],
 "Updating status...": [
  null,
  "Durum güncelleniyor..."
 ],
 "Uptime": [
  null,
  "Çalışma süresi"
 ],
 "Usage": [
  null,
  "Kullanım"
 ],
 "User": [
  null,
  "Kullanıcı"
 ],
 "Validating address": [
  null,
  "Adres doğrulanıyor"
 ],
 "Vendor": [
  null,
  "Satıcı"
 ],
 "Version": [
  null,
  "Sürüm"
 ],
 "View all logs": [
  null,
  "Tüm günlükleri görüntüle"
 ],
 "View all services": [
  null,
  "Tüm hizmetleri görüntüle"
 ],
 "View hardware details": [
  null,
  "Donanım ayrıntılarını görüntüle"
 ],
 "View login history": [
  null,
  "Oturum açma geçmişini görüntüle"
 ],
 "View metrics and history": [
  null,
  "Ölçümleri ve geçmişi görüntüle"
 ],
 "View report": [
  null,
  "Raporu görüntüle"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Bellek bilgilerini görüntülemek için yönetimsel erişim gerekir."
 ],
 "Waiting for input…": [
  null,
  "Girdi bekleniyor…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Diğer yazılım yönetimi işlemlerinin bitmesi bekleniyor"
 ],
 "Waiting to start…": [
  null,
  "Başlatma bekleniyor…"
 ],
 "Wanted by": [
  null,
  "İsteyen"
 ],
 "Wants": [
  null,
  "İstenen"
 ],
 "Warning and above": [
  null,
  "Uyarı ve üstü"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Web konsolu sınırlı erişim kipinde çalışıyor."
 ],
 "Wednesdays": [
  null,
  "Çarşamba günleri"
 ],
 "Weekly": [
  null,
  "Haftalık"
 ],
 "Weeks": [
  null,
  "Haftalar"
 ],
 "White": [
  null,
  "Beyaz"
 ],
 "Yearly": [
  null,
  "Yıllık"
 ],
 "Yes": [
  null,
  "Evet"
 ],
 "You may try to load older entries.": [
  null,
  "Daha eski girişleri yüklemeyi deneyebilirsiniz."
 ],
 "You now have administrative access.": [
  null,
  "Artık yönetimsel erişiminiz var."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Tarayıcınız, bağlam menüsünden yapıştırmaya izin vermiyor. Shift+Insert kullanabilirsiniz."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Tarayıcınız, oturumlar arasında erişim seviyenizi hatırlayacaktır."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bayt ikili veri]"
 ],
 "[binary data]": [
  null,
  "[ikili veri]"
 ],
 "[no data]": [
  null,
  "[veri yok]"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "active": [
  null,
  "etkin"
 ],
 "asset tag": [
  null,
  "demirbaş etiketi"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "önyükleme"
 ],
 "cgroups": [
  null,
  "cgruplar"
 ],
 "command": [
  null,
  "komut"
 ],
 "console": [
  null,
  "konsol"
 ],
 "coredump": [
  null,
  "çekirdek dökümü"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "crash": [
  null,
  "çökme"
 ],
 "date": [
  null,
  "tarih"
 ],
 "debug": [
  null,
  "hata ayıklama"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "etkisizleştir"
 ],
 "disks": [
  null,
  "diskler"
 ],
 "domain": [
  null,
  "etki alanı"
 ],
 "edit": [
  null,
  "düzenle"
 ],
 "enable": [
  null,
  "etkinleştir"
 ],
 "error": [
  null,
  "hata"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "ssh anamakine anahtarlarını listeleme başarısız oldu: $0"
 ],
 "graphs": [
  null,
  "grafikler"
 ],
 "hardware": [
  null,
  "donanım"
 ],
 "history": [
  null,
  "geçmiş"
 ],
 "host": [
  null,
  "anamakine"
 ],
 "inconsistent": [
  null,
  "tutarsız"
 ],
 "journal": [
  null,
  "günlük"
 ],
 "journalctl manpage": [
  null,
  "journalctl kılavuz sayfası"
 ],
 "machine": [
  null,
  "makine"
 ],
 "mask": [
  null,
  "maskele"
 ],
 "memory": [
  null,
  "bellek"
 ],
 "metrics": [
  null,
  "ölçümler"
 ],
 "mitigation": [
  null,
  "risk azaltması"
 ],
 "network": [
  null,
  "ağ"
 ],
 "none": [
  null,
  "yok"
 ],
 "of $0 CPU": [
  null,
  "$0 CPU'nun",
  "$0 CPU'nun"
 ],
 "operating system": [
  null,
  "işletim sistemi"
 ],
 "os": [
  null,
  "is"
 ],
 "path": [
  null,
  "yol"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "performans"
 ],
 "power": [
  null,
  "güç"
 ],
 "ram": [
  null,
  "ram"
 ],
 "recommended": [
  null,
  "önerilir"
 ],
 "restart": [
  null,
  "yeniden başlat"
 ],
 "running $0": [
  null,
  "$0 çalışıyor"
 ],
 "serial": [
  null,
  "seri"
 ],
 "service": [
  null,
  "hizmet"
 ],
 "shell": [
  null,
  "kabuk"
 ],
 "show less": [
  null,
  "daha az göster"
 ],
 "show more": [
  null,
  "daha fazla göster"
 ],
 "shut": [
  null,
  "kapat"
 ],
 "socket": [
  null,
  "soket"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "hedef"
 ],
 "time": [
  null,
  "saat"
 ],
 "timer": [
  null,
  "zamanlayıcı"
 ],
 "unit": [
  null,
  "birim"
 ],
 "unknown": [
  null,
  "bilinmeyen"
 ],
 "unmask": [
  null,
  "maskelemeyi kaldır"
 ],
 "version": [
  null,
  "sürüm"
 ],
 "warning": [
  null,
  "uyarı"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Etki alanı"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Bir etki alanına katıl"
 ],
 "from <host>\u0004from $0": [
  null,
  "$0 anamakinesinden"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "$1 üzerinde $0 anamakinesinden"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "$0 üzerinde"
 ]
});
