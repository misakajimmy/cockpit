cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 kritický zásah",
  "$0 kritické zásahy",
  "$0 kritických zásahov"
 ],
 "$0 failed login attempt": [
  null,
  "",
  "",
  ""
 ],
 "$0 important hit": [
  null,
  "$0 dôležitý zásah",
  "$0 zásahy, vrátane dôležitých",
  "$0 zásahov, vrátane dôležitých"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie je k dispozícií v žiadom repozitári."
 ],
 "$0 low severity hit": [
  null,
  "$0 zásah s nízkou prioritou",
  "$0 zásahy s nízkou prioritou",
  "$0 zásahov s nízkou prioritou"
 ],
 "$0 moderate hit": [
  null,
  "$0 zásah strednej závažnosti",
  "$0 zásahy, vrátane strednej závažnosti",
  "$0 zásahov, vrátane strednej závažnosti"
 ],
 "$0 service has failed": [
  null,
  "$0 služba zhavarovala",
  "$0 služby zhavarovali",
  "$0 služieb zhavarovalo"
 ],
 "$0 will be installed.": [
  null,
  "$0 bude nainštalovaný."
 ],
 "$0: crash at $1": [
  null,
  "$0: pád v $1"
 ],
 "1 minute": [
  null,
  "1 minúta"
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "1st": [
  null,
  "1."
 ],
 "20 minutes": [
  null,
  "20 minút"
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  ""
 ],
 "22th": [
  null,
  ""
 ],
 "23th": [
  null,
  ""
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "2nd": [
  null,
  "2."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "3rd": [
  null,
  "3."
 ],
 "40 minutes": [
  null,
  "40 minút"
 ],
 "4th": [
  null,
  "4."
 ],
 "5 minutes": [
  null,
  "5 minút"
 ],
 "5th": [
  null,
  "5."
 ],
 "60 minutes": [
  null,
  "60 minút"
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "Absent": [
  null,
  "Chýba"
 ],
 "Active since ": [
  null,
  "Aktívny od "
 ],
 "Add": [
  null,
  "Pridať"
 ],
 "Additional actions": [
  null,
  "Ďalšie akcie"
 ],
 "Additional packages:": [
  null,
  "Ďalšie balíky:"
 ],
 "Administrative access": [
  null,
  "Prístup na úrovni správcu"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "After": [
  null,
  "Po"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Po opustení domény sa do tohto stroja budú môcť prihlásiť iba tí užívatelia, ktorý majú účet priamo na ňom. Môže to postihnúť aj ostatné služby, ako je nastavenie DNS prekladu a môže sa zmeniť zoznam dôveryhodných cert. autorít."
 ],
 "After system boot": [
  null,
  "Po štarte systému"
 ],
 "Alert and above": [
  null,
  "Výstraha a závažnejšie"
 ],
 "Alias": [
  null,
  ""
 ],
 "All": [
  null,
  "Všetko"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Allow running (unmask)": [
  null,
  "Povoliť spustenie (odmaskovať)"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  ""
 ],
 "Appearance": [
  null,
  "Vzhľad"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  ""
 ],
 "Asset tag": [
  null,
  "Inventárny štítok"
 ],
 "At specific time": [
  null,
  "V konkrétny čas"
 ],
 "Authenticate": [
  null,
  "Overiť sa"
 ],
 "Automatically starts": [
  null,
  "Spúšťa sa automaticky"
 ],
 "Automatically using NTP": [
  null,
  "Automaticky využitím NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticky využitím konkrétnych NTP serverov"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "Dátum vydania BIOSu"
 ],
 "BIOS version": [
  null,
  "Verzia BIOSu"
 ],
 "Before": [
  null,
  "Pred"
 ],
 "Binds to": [
  null,
  "Viaže sa na"
 ],
 "Black": [
  null,
  "Čierny"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Skriňa pre blade servery"
 ],
 "Boot": [
  null,
  "Zavádzanie"
 ],
 "Bound by": [
  null,
  "Viazaný"
 ],
 "Bus expansion chassis": [
  null,
  ""
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "Zabezpečenie procesoru"
 ],
 "CPU security toggles": [
  null,
  ""
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Nepodarilo sa nájsť žiadne záznamy pre danú kombináciu filtrov."
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Cancel poweroff": [
  null,
  ""
 ],
 "Cannot be enabled": [
  null,
  "Nie je možné povoliť"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Nie je možné pridanie do domény, pretože na tomto systéme chýba realmd"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie je možné plánovať udalosti do minulosti"
 ],
 "Change": [
  null,
  "Zmeniť"
 ],
 "Change crypto policy": [
  null,
  ""
 ],
 "Change host name": [
  null,
  "Zmeniť názov stroja"
 ],
 "Change performance profile": [
  null,
  "Zmeniť profil výkonu"
 ],
 "Change profile": [
  null,
  "Zmeniť profil"
 ],
 "Change system time": [
  null,
  "Zmeniť systémový čas"
 ],
 "Checking installed software": [
  null,
  "Zisťuje sa nainštalovaný software"
 ],
 "Class": [
  null,
  "Trieda"
 ],
 "Clear 'Failed to start'": [
  null,
  "Vyčistiť „Nepodarilo sa spustiť“"
 ],
 "Clear all filters": [
  null,
  "Vyčistiť všetky filtre"
 ],
 "Client software": [
  null,
  "Klientský software"
 ],
 "Close": [
  null,
  "Zavrieť"
 ],
 "Command": [
  null,
  "Príkaz"
 ],
 "Communication with tuned has failed": [
  null,
  "Komunikácia s tuned sa nepodarila"
 ],
 "Compact PCI": [
  null,
  "Kompaktné PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Podmienka $0=$1 nebola splnená"
 ],
 "Condition failed": [
  null,
  "Podmienka nesplnená"
 ],
 "Configuration": [
  null,
  "Konfigurácia"
 ],
 "Configuring system settings": [
  null,
  ""
 ],
 "Conflicted by": [
  null,
  "V konflikte"
 ],
 "Conflicts": [
  null,
  "V konflikte"
 ],
 "Consists of": [
  null,
  "Skladá sa z"
 ],
 "Contacted domain": [
  null,
  "Pripojená doména"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Copy": [
  null,
  "Kopírovať"
 ],
 "Copy to clipboard": [
  null,
  ""
 ],
 "Crash reporting": [
  null,
  "Nahlasovanie pádu"
 ],
 "Create timer": [
  null,
  "Vytvoriť časovač"
 ],
 "Critical and above": [
  null,
  "Kritické a závažnejšie"
 ],
 "Crypto Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  ""
 ],
 "Crypto policy": [
  null,
  ""
 ],
 "Crypto policy is inconsistent": [
  null,
  ""
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Od tohto spustenia"
 ],
 "Custom crypto policy": [
  null,
  ""
 ],
 "Daily": [
  null,
  ""
 ],
 "Dark": [
  null,
  "Tmavý"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  ""
 ],
 "Debug and above": [
  null,
  "Ladiace a závažnejšie"
 ],
 "Decrease by one": [
  null,
  ""
 ],
 "Delay": [
  null,
  "Omeškanie"
 ],
 "Delete": [
  null,
  "Zmazať"
 ],
 "Deletion will remove the following files:": [
  null,
  ""
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojiteľné"
 ],
 "Details": [
  null,
  "Detaily"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Vypnúť simultánny multithreading"
 ],
 "Disable tuned": [
  null,
  "Vypnúť tuned"
 ],
 "Disabled": [
  null,
  "Vypnutá"
 ],
 "Disallow running (mask)": [
  null,
  "Nepovoliť spustenie (maskovať)"
 ],
 "Docking station": [
  null,
  "Dokovacia stanica"
 ],
 "Does not automatically start": [
  null,
  "Nespúšťa sa automaticky"
 ],
 "Domain": [
  null,
  "Doména"
 ],
 "Domain address": [
  null,
  "Adresa domény"
 ],
 "Domain administrator name": [
  null,
  "Meno správcu domény"
 ],
 "Domain administrator password": [
  null,
  "Heslo správcu domény"
 ],
 "Domain could not be contacted": [
  null,
  "Doménu sa nepodarilo kontaktovať"
 ],
 "Domain is not supported": [
  null,
  "Doména nie je podporovaná"
 ],
 "Don't repeat": [
  null,
  "Neopakovať"
 ],
 "Downloading $0": [
  null,
  "Sťahuje sa $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit /etc/motd": [
  null,
  "Upraviť /etc/motd"
 ],
 "Edit motd": [
  null,
  "Upraviť motd"
 ],
 "Embedded PC": [
  null,
  ""
 ],
 "Enabled": [
  null,
  "Povolená"
 ],
 "Entry at $0": [
  null,
  "Položka z"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Error and above": [
  null,
  "Chyba a závažnejšie"
 ],
 "Error message": [
  null,
  "Chybové hlásenie"
 ],
 "Expansion chassis": [
  null,
  ""
 ],
 "Extended information": [
  null,
  "Rozšírené informácie"
 ],
 "FIPS is not properly enabled": [
  null,
  ""
 ],
 "Failed to disable tuned": [
  null,
  "Nepodarilo sa deaktivovať tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Nepodarilo sa aktivovať tuned"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Nepodarilo sa uložiť zmeny v /etc/motd"
 ],
 "Failed to start": [
  null,
  "Nepodarilo sa spustiť"
 ],
 "Failed to switch profile": [
  null,
  ""
 ],
 "Filter by name or description": [
  null,
  ""
 ],
 "Filters": [
  null,
  "Filtre"
 ],
 "Forbidden from running": [
  null,
  ""
 ],
 "Frame number": [
  null,
  ""
 ],
 "Fridays": [
  null,
  "Piatky"
 ],
 "General": [
  null,
  "Všeobecné"
 ],
 "Handheld": [
  null,
  "Pre držanie do ruky"
 ],
 "Hardware information": [
  null,
  "Informácie o hardware"
 ],
 "Health": [
  null,
  "Zdravie"
 ],
 "Help": [
  null,
  "Nápoveda"
 ],
 "Hierarchy ID": [
  null,
  ""
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  ""
 ],
 "Hostname": [
  null,
  "Názov stroja"
 ],
 "Hours": [
  null,
  "Hodiny"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "Identifikátor"
 ],
 "Increase by one": [
  null,
  ""
 ],
 "Indirect": [
  null,
  "Nepriame"
 ],
 "Info and above": [
  null,
  "Informácia a závažnejšie"
 ],
 "Insights: ": [
  null,
  "Insights: "
 ],
 "Install": [
  null,
  "Inštalovať"
 ],
 "Install software": [
  null,
  "Inštalovať software"
 ],
 "Installing $0": [
  null,
  "Inštaluje sa $0"
 ],
 "Invalid": [
  null,
  "Neplatné"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát dátumu"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát dátumu a času"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát čase"
 ],
 "Invalid timezone": [
  null,
  "Neplatná časová zóna"
 ],
 "IoT gateway": [
  null,
  ""
 ],
 "Join": [
  null,
  "Spojiť"
 ],
 "Join domain": [
  null,
  "Pripojiť sa k doméne"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Pripájanie sa do domény vyžaduje inštaláciu realmd"
 ],
 "Joining this domain is not supported": [
  null,
  ""
 ],
 "Joins namespace of": [
  null,
  ""
 ],
 "Journal": [
  null,
  "Žurnál"
 ],
 "Journal entry": [
  null,
  "Položka žurnálu"
 ],
 "Journal entry not found": [
  null,
  ""
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Last 24 hours": [
  null,
  "Posledných 24 hodín"
 ],
 "Last 7 days": [
  null,
  "Posledných 7 dní"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "Leave $0": [
  null,
  ""
 ],
 "Leave domain": [
  null,
  ""
 ],
 "Light": [
  null,
  "Svetlý"
 ],
 "Limit access": [
  null,
  ""
 ],
 "Limited access": [
  null,
  ""
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  ""
 ],
 "Limits": [
  null,
  ""
 ],
 "Linked": [
  null,
  ""
 ],
 "Listing unit files": [
  null,
  ""
 ],
 "Listing unit files failed: $0": [
  null,
  ""
 ],
 "Load earlier entries": [
  null,
  "Načítať skoršie položky"
 ],
 "Loading earlier entries": [
  null,
  "Načítajú sa skoršie položky"
 ],
 "Loading keys...": [
  null,
  "Načítavajú sa kľúče..."
 ],
 "Loading of SSH keys failed": [
  null,
  ""
 ],
 "Loading...": [
  null,
  "Načítavanie..."
 ],
 "Log messages": [
  null,
  "Záznamy udalostí"
 ],
 "Login format": [
  null,
  "Formát prihlasovania"
 ],
 "Logs": [
  null,
  "Záznamy udalostí"
 ],
 "Low profile desktop": [
  null,
  "Nízky desktop"
 ],
 "Lunch box": [
  null,
  "Kufríkový počítač"
 ],
 "Machine ID": [
  null,
  "Identifikátor stroja"
 ],
 "Machine SSH key fingerprints": [
  null,
  ""
 ],
 "Main server chassis": [
  null,
  "Hlavná skriňa serveru"
 ],
 "Managing services": [
  null,
  "Správa služieb"
 ],
 "Manually": [
  null,
  "Ručne"
 ],
 "Mask service": [
  null,
  "Maskovať službu"
 ],
 "Masked": [
  null,
  "Maskovaný"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Maskovanie služby zabráni spúšťaniu všetkých závislých jednotiek. Toto môže mať väčší dopad ako je zamýšľané. Prosím potvrďte, že chcete maskovať túto jednotku."
 ],
 "Memory": [
  null,
  "Pamäť"
 ],
 "Memory technology": [
  null,
  ""
 ],
 "Merged": [
  null,
  ""
 ],
 "Message to logged in users": [
  null,
  ""
 ],
 "Method": [
  null,
  "Metóda"
 ],
 "Mini PC": [
  null,
  ""
 ],
 "Mini tower": [
  null,
  ""
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minúta musí byť číslo medzi 0-59"
 ],
 "Minutes": [
  null,
  "Minúty"
 ],
 "Mitigations": [
  null,
  "Zmiernenia dopadu"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Mondays": [
  null,
  "Pondelky"
 ],
 "Monthly": [
  null,
  ""
 ],
 "Multi-system chassis": [
  null,
  ""
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Name": [
  null,
  "Názov"
 ],
 "Need at least one NTP server": [
  null,
  ""
 ],
 "No": [
  null,
  "Nie"
 ],
 "No delay": [
  null,
  ""
 ],
 "No host keys found.": [
  null,
  "Neboli nájdené žiadne kľúče stroja."
 ],
 "No log entries": [
  null,
  "Žiadne záznamy udalostí"
 ],
 "No logs found": [
  null,
  "Nenájdené žiadne záznamy udalostí"
 ],
 "No matching results": [
  null,
  "Žiadne vyhovujúce výsledky"
 ],
 "No results found": [
  null,
  "Neboli nájdené žiadne výsledky"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  ""
 ],
 "No rule hits": [
  null,
  "Žiadne zásahy pravidla"
 ],
 "None": [
  null,
  "Žiadny"
 ],
 "Not connected to Insights": [
  null,
  "Nepripojené k Insights"
 ],
 "Not found": [
  null,
  "Nenájdené"
 ],
 "Not running": [
  null,
  "Nespustená"
 ],
 "Not synchronized": [
  null,
  "Nezosynchronizované"
 ],
 "Note": [
  null,
  "Poznámka"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Notice and above": [
  null,
  "Oznámenie a závažnejšie"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "On failure": [
  null,
  "Pri chybe"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Sú povolené iba písmena, čísla a znaky :_.@-"
 ],
 "Only emergency": [
  null,
  "Iba núdzové"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  ""
 ],
 "Other": [
  null,
  "Iný"
 ],
 "Overview": [
  null,
  "Prehľad"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Part of": [
  null,
  "Súčasť"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Paste": [
  null,
  "Vložiť"
 ],
 "Path": [
  null,
  "Cesta"
 ],
 "Paths": [
  null,
  "Cesty"
 ],
 "Pause": [
  null,
  "Pozastaviť"
 ],
 "Performance profile": [
  null,
  ""
 ],
 "Peripheral chassis": [
  null,
  ""
 ],
 "Pick date": [
  null,
  "Vybrať dátum"
 ],
 "Pinned unit": [
  null,
  ""
 ],
 "Pizza box": [
  null,
  ""
 ],
 "Please authenticate to gain administrative access": [
  null,
  ""
 ],
 "Portable": [
  null,
  "Prenosný"
 ],
 "Present": [
  null,
  "Prítomné"
 ],
 "Pretty host name": [
  null,
  "Pekný názov stroja"
 ],
 "Previous boot": [
  null,
  ""
 ],
 "Priority": [
  null,
  "Priorita"
 ],
 "Problem details": [
  null,
  "Detaily o probléme"
 ],
 "Problem info": [
  null,
  ""
 ],
 "Propagates reload to": [
  null,
  ""
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  ""
 ],
 "RAID chassis": [
  null,
  "RAID skriňa"
 ],
 "Rack mount chassis": [
  null,
  ""
 ],
 "Rank": [
  null,
  "Rank"
 ],
 "Read more...": [
  null,
  ""
 ],
 "Read-only": [
  null,
  "Iba na čítanie"
 ],
 "Real host name": [
  null,
  "Skutočný názov stroja"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Skutočný názov stroja môže obsahovať iba malé písmená, číslice, pomlčky a bodky (pri použití subdomén)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Skutočný názov stroja musí byť 64 znakov alebo menej"
 ],
 "Reboot": [
  null,
  "Reštartovať"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  ""
 ],
 "Reload": [
  null,
  "Znova načítať"
 ],
 "Reload propagated from": [
  null,
  ""
 ],
 "Removals:": [
  null,
  "Odstránenia:"
 ],
 "Remove": [
  null,
  "Odobrať"
 ],
 "Removing $0": [
  null,
  "Odstraňuje sa $0"
 ],
 "Repeat": [
  null,
  "Opakovať"
 ],
 "Repeat monthly": [
  null,
  "Opakovať každý mesiac"
 ],
 "Repeat weekly": [
  null,
  "Opakovať každý týždeň"
 ],
 "Report": [
  null,
  "Nahlásiť"
 ],
 "Report to ABRT Analytics": [
  null,
  "Nahlásiť do ABRT Analytics"
 ],
 "Reported; no links available": [
  null,
  "Nahlásené; nie su dostupné žiadne odkazy"
 ],
 "Reporting failed": [
  null,
  "Nahlasovanie sa nepodarilo"
 ],
 "Reporting was canceled": [
  null,
  "Nahlasovanie bolo zrušené"
 ],
 "Reports:": [
  null,
  "Hlásenia:"
 ],
 "Required by": [
  null,
  "Vyžadované"
 ],
 "Required by ": [
  null,
  "Vyžadované "
 ],
 "Requires": [
  null,
  "Vyžaduje"
 ],
 "Requires administration access to edit": [
  null,
  "Pre úpravu sa vyžadujú administrátorské práva"
 ],
 "Requisite": [
  null,
  "Rekvizita"
 ],
 "Requisite of": [
  null,
  ""
 ],
 "Reset": [
  null,
  "Reset"
 ],
 "Restart": [
  null,
  "Reštart"
 ],
 "Resume": [
  null,
  "Obnoviť chod"
 ],
 "Review crypto policy": [
  null,
  ""
 ],
 "Reviewing logs": [
  null,
  "Vyhodnocovanie záznamov udalostí"
 ],
 "Run on": [
  null,
  ""
 ],
 "Running": [
  null,
  "Beží"
 ],
 "Saturdays": [
  null,
  "Soboty"
 ],
 "Save": [
  null,
  "Uložiť"
 ],
 "Save and reboot": [
  null,
  "Uložiť a reštartovať"
 ],
 "Save changes": [
  null,
  "Uložiť zmeny"
 ],
 "Scheduled poweroff at $0": [
  null,
  ""
 ],
 "Scheduled reboot at $0": [
  null,
  ""
 ],
 "Sealed-case PC": [
  null,
  "Počítač so zapäčatenou skriňou"
 ],
 "Search": [
  null,
  "Hľadať"
 ],
 "Seconds": [
  null,
  "Sekundy"
 ],
 "Secure shell keys": [
  null,
  "Kľúče zabezpečeného shellu"
 ],
 "Send": [
  null,
  "Poslať"
 ],
 "Server software": [
  null,
  ""
 ],
 "Service logs": [
  null,
  "Záznamy udalostí služby"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Set hostname": [
  null,
  "Nastaviť názov stroja"
 ],
 "Set time": [
  null,
  "Nastaviť čas"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "Ukázať všetky vlákna"
 ],
 "Show fingerprints": [
  null,
  "Zobraziť otlačky"
 ],
 "Show messages containing given string.": [
  null,
  ""
 ],
 "Show messages for the specified systemd unit.": [
  null,
  ""
 ],
 "Show messages from a specific boot.": [
  null,
  ""
 ],
 "Show more relationships": [
  null,
  ""
 ],
 "Show relationships": [
  null,
  ""
 ],
 "Shut down": [
  null,
  "Vypnúť"
 ],
 "Shutdown": [
  null,
  "Vypnúť"
 ],
 "Since": [
  null,
  ""
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Size": [
  null,
  "Veľkosť"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Sockets": [
  null,
  "Sokety"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  ""
 ],
 "Space-saving computer": [
  null,
  "Miesto-šetriaci počítač"
 ],
 "Specific time": [
  null,
  "Konkrétny čas"
 ],
 "Speed": [
  null,
  "Rýchlosť"
 ],
 "Start": [
  null,
  "Spustiť"
 ],
 "Start and enable": [
  null,
  "Spustiť a zapnúť"
 ],
 "Start service": [
  null,
  "Spustiť službu"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  ""
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  ""
 ],
 "State": [
  null,
  "Stav"
 ],
 "Static": [
  null,
  "Statická"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Stick PC": [
  null,
  ""
 ],
 "Stop": [
  null,
  "Zastaviť"
 ],
 "Stop and disable": [
  null,
  ""
 ],
 "Stub": [
  null,
  ""
 ],
 "Sub-Chassis": [
  null,
  "Podskriňa"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  ""
 ],
 "Successfully copied to keyboard": [
  null,
  ""
 ],
 "Sundays": [
  null,
  "Nedele"
 ],
 "Switch to limited access": [
  null,
  "Prepnúť na obmedzený prístup"
 ],
 "Synchronized": [
  null,
  "Synchronizované"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizované s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizuje sa"
 ],
 "System": [
  null,
  "Systém"
 ],
 "System information": [
  null,
  "Informácie o systéme"
 ],
 "System time": [
  null,
  "Systémový čas"
 ],
 "Systemd units": [
  null,
  "Systemd jednotky"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Targets": [
  null,
  "Ciele"
 ],
 "Terminal": [
  null,
  "Terminál"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  ""
 ],
 "The user $0 is not permitted to change crypto policies": [
  null,
  ""
 ],
 "This may take a while": [
  null,
  ""
 ],
 "This system is using a custom profile": [
  null,
  ""
 ],
 "This system is using the recommended profile": [
  null,
  ""
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  ""
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  ""
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  ""
 ],
 "Thursdays": [
  null,
  "štvrtky"
 ],
 "Time": [
  null,
  "Čas"
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "Timers": [
  null,
  "Časovače"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Total size: $0": [
  null,
  "Celková veľkosť: $0"
 ],
 "Tower": [
  null,
  "Veža"
 ],
 "Transient": [
  null,
  ""
 ],
 "Trigger": [
  null,
  "Spúšťač"
 ],
 "Triggered by": [
  null,
  ""
 ],
 "Triggers": [
  null,
  "Spúšťače"
 ],
 "Trying to synchronize with $0": [
  null,
  ""
 ],
 "Tuesdays": [
  null,
  "utorky"
 ],
 "Tuned has failed to start": [
  null,
  ""
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  ""
 ],
 "Tuned is not available": [
  null,
  ""
 ],
 "Tuned is not running": [
  null,
  ""
 ],
 "Tuned is off": [
  null,
  ""
 ],
 "Turn on administrative access": [
  null,
  ""
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type to filter": [
  null,
  ""
 ],
 "Unit": [
  null,
  "Jednotka"
 ],
 "Unknown": [
  null,
  "Neznáme"
 ],
 "Until": [
  null,
  ""
 ],
 "Updating status...": [
  null,
  "Aktualizuje sa stav..."
 ],
 "Uptime": [
  null,
  "Doba chodu"
 ],
 "Usage": [
  null,
  "Využitie"
 ],
 "User": [
  null,
  "Používateľ"
 ],
 "Validating address": [
  null,
  "Overuje sa adresa"
 ],
 "Vendor": [
  null,
  "Výrobca"
 ],
 "Version": [
  null,
  "Verzia"
 ],
 "View hardware details": [
  null,
  "Ukázať podrobnosti o hardware"
 ],
 "View report": [
  null,
  "Zobraziť hlásenie"
 ],
 "Waiting for input…": [
  null,
  "Čaká sa na vstup…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čaká sa na dokončenie ostatných operácií správy balíčkov"
 ],
 "Waiting to start…": [
  null,
  "Čaká sa na spustenie…"
 ],
 "Wanted by": [
  null,
  "Vyžadované"
 ],
 "Wants": [
  null,
  "Vyžaduje"
 ],
 "Warning and above": [
  null,
  "Varovanie a závažnejšie"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Webová konzola beží v režime obmedzeného prístupu."
 ],
 "Wednesdays": [
  null,
  "Stredy"
 ],
 "Weeks": [
  null,
  "Týždne"
 ],
 "White": [
  null,
  "Biely"
 ],
 "Yearly": [
  null,
  ""
 ],
 "Yes": [
  null,
  "Áno"
 ],
 "You may try to load older entries.": [
  null,
  "Môžte skúsiť načítať skoršie záznamy."
 ],
 "You now have administrative access.": [
  null,
  ""
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  ""
 ],
 "[$0 bytes of binary data]": [
  null,
  ""
 ],
 "[binary data]": [
  null,
  "[binárne dáta]"
 ],
 "[no data]": [
  null,
  "[žiadne dáta]"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "active": [
  null,
  "Aktívny"
 ],
 "asset tag": [
  null,
  "Inventárny štítok"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "boot"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "Príkaz"
 ],
 "console": [
  null,
  "konzola"
 ],
 "coredump": [
  null,
  "výpis jadra"
 ],
 "cpu": [
  null,
  "procesor"
 ],
 "crash": [
  null,
  "pád"
 ],
 "date": [
  null,
  "dátum"
 ],
 "debug": [
  null,
  "ladenie"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "vypnúť"
 ],
 "disks": [
  null,
  "disky"
 ],
 "domain": [
  null,
  "Doména"
 ],
 "edit": [
  null,
  "upraviť"
 ],
 "enable": [
  null,
  "povoliť"
 ],
 "error": [
  null,
  "Chyba"
 ],
 "failed to list ssh host keys: $0": [
  null,
  ""
 ],
 "graphs": [
  null,
  "grafy"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "history": [
  null,
  "história"
 ],
 "host": [
  null,
  "stroj"
 ],
 "journal": [
  null,
  "žurnál"
 ],
 "journalctl manpage": [
  null,
  "manuálové stránky k journalctl"
 ],
 "machine": [
  null,
  "stroj"
 ],
 "mask": [
  null,
  "maska"
 ],
 "memory": [
  null,
  "pamäť"
 ],
 "metrics": [
  null,
  "metriky"
 ],
 "mitigation": [
  null,
  "zmiernenie"
 ],
 "network": [
  null,
  "sieť"
 ],
 "none": [
  null,
  "žiaden"
 ],
 "of $0 CPU": [
  null,
  "z $0 procesoru",
  "z $0 procesorov",
  "z $0 procesorov"
 ],
 "operating system": [
  null,
  "Operačný systém"
 ],
 "os": [
  null,
  "os"
 ],
 "path": [
  null,
  "umiestnenie"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "výkon"
 ],
 "power": [
  null,
  "napájanie"
 ],
 "ram": [
  null,
  "ram"
 ],
 "recommended": [
  null,
  "odporúčaný"
 ],
 "restart": [
  null,
  "reštartovať"
 ],
 "running $0": [
  null,
  "beží na $0"
 ],
 "serial": [
  null,
  "sériové"
 ],
 "service": [
  null,
  "služba"
 ],
 "shell": [
  null,
  "shell"
 ],
 "show less": [
  null,
  "ukázať menej"
 ],
 "show more": [
  null,
  "ukázať viac"
 ],
 "shut": [
  null,
  "vypnúť"
 ],
 "socket": [
  null,
  "soket"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "cieľ"
 ],
 "time": [
  null,
  "čas"
 ],
 "timer": [
  null,
  "časovač"
 ],
 "unit": [
  null,
  "jednotka"
 ],
 "unknown": [
  null,
  "neznáme"
 ],
 "unmask": [
  null,
  "odmaskovať"
 ],
 "version": [
  null,
  "Verzia"
 ],
 "warning": [
  null,
  "varovanie"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Doména"
 ]
});
