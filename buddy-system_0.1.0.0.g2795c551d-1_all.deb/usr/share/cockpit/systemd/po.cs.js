cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 kritický zásah",
  "$0 kritické zásahy",
  "$0 kritických zásahů"
 ],
 "$0 failed login attempt": [
  null,
  "$0 nepodařený pokus o přihlášení",
  "$0 nepodařené pokusy o přihlášení",
  "$0 nepodařených pokusů o přihlášení"
 ],
 "$0 important hit": [
  null,
  "$0 důležitý zásah",
  "$0 zásahy, včetně důležitého",
  "$0 zásahů, včetně důležitého"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 není k dispozici z žádného z repozitářů."
 ],
 "$0 low severity hit": [
  null,
  "$0 zásah s nízkou prioritou",
  "$0 zásahy s nízkou prioritou",
  "$0 zásahů s nízkou prioritou"
 ],
 "$0 moderate hit": [
  null,
  "$0 zásah střední závažnosti",
  "$0 zásahy střední závažnosti",
  "$0 zásahů střední závažnosti"
 ],
 "$0 service has failed": [
  null,
  "$0 služba zhavarovala",
  "$0 služby zhavarovaly",
  "$0 služeb zhavarovalo"
 ],
 "$0 will be installed.": [
  null,
  "$0 bude nainstalováno."
 ],
 "$0: crash at $1": [
  null,
  "$0: pád v $1"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "1st": [
  null,
  "1."
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "2nd": [
  null,
  "2."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "3rd": [
  null,
  "3."
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "4th": [
  null,
  "4."
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "5th": [
  null,
  "5."
 ],
 "60 minutes": [
  null,
  "60 minut"
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "Absent": [
  null,
  "Chybí"
 ],
 "Active since ": [
  null,
  "Aktivní od "
 ],
 "Active state": [
  null,
  "Aktivní stav"
 ],
 "Add": [
  null,
  "Přidat"
 ],
 "Additional actions": [
  null,
  "Další akce"
 ],
 "Additional packages:": [
  null,
  "Další balíčky:"
 ],
 "Administrative access": [
  null,
  "Přístup na úrovni správce"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "After": [
  null,
  "Po"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Po opuštění domény se do tohoto stroje budou moci přihlásit jen ti uživatelé, kteří mají účet přímo na něm. Může to postihnout také ostatní služby, jako je nastavení DNS překladu a může se změnit seznam důvěryhodných cert. autorit."
 ],
 "After system boot": [
  null,
  "Po startu systému"
 ],
 "Alert and above": [
  null,
  "Výstraha a závažnější"
 ],
 "Alias": [
  null,
  "Alternativní název"
 ],
 "All": [
  null,
  "Vše"
 ],
 "All-in-one": [
  null,
  "Vše-v-jednom"
 ],
 "Allow running (unmask)": [
  null,
  "Umožnit spouštění (odmaskovat)"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "V hlášeních v záznamu událostí (log) je možné filtrovat podle libovolného textového řetězce. Řetězec také může mít podobu regulárního výrazu. Také je podporováno filtrování podle kolonek zprávy záznamu událostí. Zde se jedná o mezerami oddělované hodnoty v podobě KOLONKA=HODNOTA, kde hodnota může být čárkou oddělovaný seznam možných hodnot."
 ],
 "Appearance": [
  null,
  "Vzhled"
 ],
 "Apply and reboot": [
  null,
  "Použít a restartovat"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Uplatňuje se nová zásada… Toto může zabrat několik minut."
 ],
 "Asset tag": [
  null,
  "Inventární štítek"
 ],
 "At minute": [
  null,
  "V minutě"
 ],
 "At specific time": [
  null,
  "V uvedený čas"
 ],
 "Authenticate": [
  null,
  "Ověřit se"
 ],
 "Automatically starts": [
  null,
  "Spouští se automaticky"
 ],
 "Automatically using NTP": [
  null,
  "Automatické použití NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatické použití uvedených NTP serverů"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "Datum vydání BIOS"
 ],
 "BIOS version": [
  null,
  "Verze BIOS"
 ],
 "Bad": [
  null,
  "Chybné"
 ],
 "Bad setting": [
  null,
  "Chybné nastavení"
 ],
 "Before": [
  null,
  "Před"
 ],
 "Binds to": [
  null,
  "Spojuje k"
 ],
 "Black": [
  null,
  "Černá"
 ],
 "Blade": [
  null,
  "Blade server"
 ],
 "Blade enclosure": [
  null,
  "Skříň se šachtami pro blade servery"
 ],
 "Boot": [
  null,
  "Zavedení systému"
 ],
 "Bound by": [
  null,
  "Spojeno"
 ],
 "Bus expansion chassis": [
  null,
  "Skříň rozšíření sběrnice"
 ],
 "CPU": [
  null,
  "Procesor"
 ],
 "CPU security": [
  null,
  "Zabezpečení procesoru"
 ],
 "CPU security toggles": [
  null,
  "Přepínače zabezpečení procesoru"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Při použití stávající kombinace filtrů se nedaří nalézt žádné záznamy událostí."
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Cancel poweroff": [
  null,
  "Zrušit vypínání"
 ],
 "Cancel reboot": [
  null,
  "Zrušit restartování"
 ],
 "Cannot be enabled": [
  null,
  "Není možné zapnout"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Nelze přidat do domény, protože na tomto systému chybí nástroj realmd"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nelze naplánovat událost v minulosti"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Change crypto policy": [
  null,
  ""
 ],
 "Change host name": [
  null,
  "Změnit název počítače"
 ],
 "Change performance profile": [
  null,
  "Změnit profil výkonu"
 ],
 "Change profile": [
  null,
  "Změnit profil"
 ],
 "Change system time": [
  null,
  "Změnit systémový čas"
 ],
 "Checking installed software": [
  null,
  "Zjišťuje se nainstalovaný sofware"
 ],
 "Class": [
  null,
  "Třída"
 ],
 "Clear 'Failed to start'": [
  null,
  "Vyčistit „Nepodařilo se spustit“"
 ],
 "Clear all filters": [
  null,
  "Vyčistit všechny filtry"
 ],
 "Client software": [
  null,
  "Klientský software"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Command": [
  null,
  "Příkaz"
 ],
 "Communication with tuned has failed": [
  null,
  "Komunikace s procesem služby tuned se nezdařila"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Podmínka $0=$1 nebyla splněna"
 ],
 "Condition failed": [
  null,
  "Podmínka nebyla úspěšná"
 ],
 "Configuration": [
  null,
  "Nastavení"
 ],
 "Configuring system settings": [
  null,
  "Probíhá nastavení systému"
 ],
 "Conflicted by": [
  null,
  "V konfliktu s"
 ],
 "Conflicts": [
  null,
  "Konflikty"
 ],
 "Consists of": [
  null,
  "Sestává se z"
 ],
 "Contacted domain": [
  null,
  "Připojená doména"
 ],
 "Controller": [
  null,
  "Řadič"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Copy": [
  null,
  "Zkopírovat"
 ],
 "Copy to clipboard": [
  null,
  "Zkopírovat do schránky"
 ],
 "Crash reporting": [
  null,
  "Nahlašování pádů"
 ],
 "Create timer": [
  null,
  "Vytvořit časovač"
 ],
 "Critical and above": [
  null,
  "Kritické a závažnější"
 ],
 "Crypto Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  ""
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Od tohoto spuštění systému"
 ],
 "Daily": [
  null,
  "Denně"
 ],
 "Dark": [
  null,
  "Tmavý"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Zadání datumů by mělo být ve formátu RRRR-MM-DD hh:mm:ss. Alternativně je možné použít ještě řetězce „yesterday“ (včera), „today“ (dnes), „tomorrow“ (zítra). „now“ (nyní) odkazuje na aktuální dobu. Dále je možné zadávat vztažené (relativní) časy, předeslané předponou „-“ nebo „+“"
 ],
 "Debug and above": [
  null,
  "Ladící a závažnější"
 ],
 "Decrease by one": [
  null,
  "Snížit o jedno"
 ],
 "Delay": [
  null,
  "Prodleva"
 ],
 "Delay must be a number": [
  null,
  "Je třeba, aby prodleva byla číslo"
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Deletion will remove the following files:": [
  null,
  ""
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojitelné"
 ],
 "Details": [
  null,
  "Podrobnosti"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Vypnout souběžné vícevláknové zpracovávání"
 ],
 "Disable tuned": [
  null,
  "Vypnout proces služby tuned"
 ],
 "Disabled": [
  null,
  "Vypnuto"
 ],
 "Disallow running (mask)": [
  null,
  "Nepovolit spuštění (maskovat)"
 ],
 "Docking station": [
  null,
  "Dokovací stanice"
 ],
 "Does not automatically start": [
  null,
  "Nespouštět automaticky"
 ],
 "Domain": [
  null,
  "Doména"
 ],
 "Domain address": [
  null,
  "Adresa domény"
 ],
 "Domain administrator name": [
  null,
  "Uživatelské jméno správce domény"
 ],
 "Domain administrator password": [
  null,
  "Heslo správce domény"
 ],
 "Don't repeat": [
  null,
  "Neopakovat"
 ],
 "Downloading $0": [
  null,
  "Stahuje se $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit /etc/motd": [
  null,
  "Upravit soubor /etc/motd"
 ],
 "Edit motd": [
  null,
  "Upravit hostitele"
 ],
 "Embedded PC": [
  null,
  "Jednodeskový počítač"
 ],
 "Enabled": [
  null,
  "Povoleno"
 ],
 "Entry at $0": [
  null,
  "Položka na $0"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Error and above": [
  null,
  "Chyba a závažnější"
 ],
 "Error message": [
  null,
  "Chybové hlášení"
 ],
 "Expansion chassis": [
  null,
  "Rozšiřující šasi"
 ],
 "Extended information": [
  null,
  "Rozšířené informace"
 ],
 "FIPS is not properly enabled": [
  null,
  ""
 ],
 "Failed to disable tuned": [
  null,
  "Nepodařilo se zakázat proces služby tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Nepodařilo se zapnout tuned"
 ],
 "Failed to fetch logs": [
  null,
  "Nepodařilo se získat záznamy událostí"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Nepodařilo se uložit změny v /etc/motd"
 ],
 "Failed to start": [
  null,
  "Nepodařilo se spustit"
 ],
 "Failed to switch profile": [
  null,
  "Nepodařilo se přepnout profil"
 ],
 "File state": [
  null,
  "Stav souboru"
 ],
 "Filter by name or description": [
  null,
  "Filtrovat podle názvu nebo popisu"
 ],
 "Filters": [
  null,
  "Filtry"
 ],
 "Font size": [
  null,
  "Velikost písmen"
 ],
 "Forbidden from running": [
  null,
  "Spuštění zakázáno"
 ],
 "Frame number": [
  null,
  "Číslo snímku"
 ],
 "Free-form search": [
  null,
  "Vyhledávání volnou formou"
 ],
 "Fridays": [
  null,
  "Pátky"
 ],
 "General": [
  null,
  "Obecné"
 ],
 "Generated": [
  null,
  "Vytvořeno"
 ],
 "Go to $0": [
  null,
  "Jít na $0"
 ],
 "Handheld": [
  null,
  "Pro držení v rukou"
 ],
 "Hardware information": [
  null,
  "Informace o hardware"
 ],
 "Health": [
  null,
  "Celkový stav"
 ],
 "Help": [
  null,
  "Nápověda"
 ],
 "Hierarchy ID": [
  null,
  "Identifikátor hierarchie"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  ""
 ],
 "Hostname": [
  null,
  "Název stroje"
 ],
 "Hourly": [
  null,
  "Každou hodinu"
 ],
 "Hours": [
  null,
  "Hodin"
 ],
 "ID": [
  null,
  "Identif."
 ],
 "Identifier": [
  null,
  "Identifikátor"
 ],
 "Increase by one": [
  null,
  "Navýšit o jednu"
 ],
 "Indirect": [
  null,
  "Nepřímé"
 ],
 "Info and above": [
  null,
  "Informace a závažnější"
 ],
 "Insights: ": [
  null,
  "Vhledy: "
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Install software": [
  null,
  "Nainstalovat software"
 ],
 "Installing $0": [
  null,
  "Instaluje se $0"
 ],
 "Invalid": [
  null,
  "Neplatné"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát data"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát data a času"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát času"
 ],
 "Invalid timezone": [
  null,
  "Neplatné časové pásmo"
 ],
 "IoT gateway": [
  null,
  "Brána Internetu věcí (IoT)"
 ],
 "Join": [
  null,
  "Spojit"
 ],
 "Join domain": [
  null,
  "Připojit se k doméně"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Připojení se do domény vyžaduje instalaci nástroje realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "Připojení se do této domény není podporováno"
 ],
 "Joins namespace of": [
  null,
  "Připojuje jmenný prostor od"
 ],
 "Journal": [
  null,
  "Žurnál"
 ],
 "Journal entry": [
  null,
  "Položka žurnálu"
 ],
 "Journal entry not found": [
  null,
  "Položka žurnálu nenalezena"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Last 24 hours": [
  null,
  "Uplynulých 24 hodin"
 ],
 "Last 7 days": [
  null,
  "Uplynulých 7 dnů"
 ],
 "Learn more": [
  null,
  "Další informace naleznete"
 ],
 "Leave domain": [
  null,
  "Opustit doménu"
 ],
 "Light": [
  null,
  "Světlý"
 ],
 "Limit access": [
  null,
  "Omezit přístup"
 ],
 "Limited access": [
  null,
  "Omezený přístup"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Režim omezeného přístupu omezuje oprávnění pro správu. Některé části webové konzole budou poskytovat méně funkcí."
 ],
 "Linked": [
  null,
  "Odkazováno"
 ],
 "Listen": [
  null,
  "Očekávat spojení"
 ],
 "Listing unit files": [
  null,
  ""
 ],
 "Listing unit files failed: $0": [
  null,
  ""
 ],
 "Load earlier entries": [
  null,
  "Načíst dřívější položky"
 ],
 "Loading earlier entries": [
  null,
  "Načítají se dřívější položky"
 ],
 "Loading keys...": [
  null,
  "Načítání klíčů…"
 ],
 "Loading of SSH keys failed": [
  null,
  "Načítání SSH klíčů se nezdařilo"
 ],
 "Loading...": [
  null,
  "Načítání…"
 ],
 "Log messages": [
  null,
  "Zprávy záznamu událostí"
 ],
 "Login format": [
  null,
  "Formát přihlašování"
 ],
 "Logs": [
  null,
  "Záznamy událostí"
 ],
 "Low profile desktop": [
  null,
  "Nízký desktop"
 ],
 "Lunch box": [
  null,
  "Kufříkový počítač"
 ],
 "Machine ID": [
  null,
  "Identif. stroje"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Otisky SSH klíče stroje"
 ],
 "Main server chassis": [
  null,
  "Hlavní skříň serveru"
 ],
 "Managing services": [
  null,
  "Správa služeb"
 ],
 "Manually": [
  null,
  "Ručně"
 ],
 "Mask service": [
  null,
  "Maskovat službu"
 ],
 "Masked": [
  null,
  "Maskováno"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Maskování služby zabrání všem závislým jednotkám ve spouštění. To může mít větší dopad, než zamýšleno. Potvrďte, že chcete tuto jednotku maskovat."
 ],
 "Memory": [
  null,
  "Paměť"
 ],
 "Memory technology": [
  null,
  "Technologie paměti"
 ],
 "Merged": [
  null,
  "Sloučeno"
 ],
 "Message to logged in users": [
  null,
  "Zpráva přihlášeným uživatelům"
 ],
 "Method": [
  null,
  "Metoda"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini věž"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Je třeba, aby minuta bylo číslo z rozmezí 0-59"
 ],
 "Minutes": [
  null,
  "Minut"
 ],
 "Mitigations": [
  null,
  "Zmírnění dopadu"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Mondays": [
  null,
  "Pondělky"
 ],
 "Monthly": [
  null,
  "Každý měsíc"
 ],
 "Multi-system chassis": [
  null,
  "Skříň pro více systémů"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Need at least one NTP server": [
  null,
  "Je třeba alespoň jeden NTP server"
 ],
 "No": [
  null,
  "Ne"
 ],
 "No delay": [
  null,
  "Bez prodlevy"
 ],
 "No host keys found.": [
  null,
  "Nenalezeny žádné klíče stroje."
 ],
 "No log entries": [
  null,
  "Žádné položky záznamu událostí"
 ],
 "No logs found": [
  null,
  "Nenalezeny žádné záznamy událostí"
 ],
 "No matching results": [
  null,
  "Žádné shodující se výsledky"
 ],
 "No results found": [
  null,
  "Nenalezeny žádné výsledky"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Kritériím filtru neodpovídají žádné výsledky. Pro zobrazení výsledků vyčistěte veškeré filtry."
 ],
 "No rule hits": [
  null,
  "Žádné zásahy pravidla"
 ],
 "None": [
  null,
  "Žádný"
 ],
 "Not connected to Insights": [
  null,
  "Nepřipojeno k Insights"
 ],
 "Not found": [
  null,
  "Nenalezeno"
 ],
 "Not running": [
  null,
  "Není spuštěné"
 ],
 "Not synchronized": [
  null,
  "Nesynchronizováno"
 ],
 "Note": [
  null,
  "Poznámka"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Notice and above": [
  null,
  "Oznámení a závažnější"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "On failure": [
  null,
  "Při nezdaru"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Dovolena jsou pouze písmena a číslice, dále ještě znaky : , _ , . , @ , -"
 ],
 "Only emergency": [
  null,
  "Pouze nouzové"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  ""
 ],
 "Other": [
  null,
  "Ostatní"
 ],
 "Overview": [
  null,
  "Přehled"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Part of": [
  null,
  "Součástí"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Paste": [
  null,
  "Vložit"
 ],
 "Paste error": [
  null,
  "Chyba vkládání"
 ],
 "Path": [
  null,
  "Popis umístění"
 ],
 "Paths": [
  null,
  "Popisy umístění"
 ],
 "Pause": [
  null,
  "Pozastavit"
 ],
 "Performance profile": [
  null,
  "Profil výkonnosti"
 ],
 "Peripheral chassis": [
  null,
  "Skříň periferií"
 ],
 "Pick date": [
  null,
  "Vyberte datum"
 ],
 "Pinned unit": [
  null,
  ""
 ],
 "Pizza box": [
  null,
  "Velikost „krabice od pizzy“"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Pro získání přístupu na úrovni správce se prosím ověřte"
 ],
 "Portable": [
  null,
  "Přenosný"
 ],
 "Present": [
  null,
  "Přítomno"
 ],
 "Pretty host name": [
  null,
  "Hezký název stroje"
 ],
 "Previous boot": [
  null,
  "Předchozí zavedení"
 ],
 "Priority": [
  null,
  "Priorita"
 ],
 "Problem becoming administrator": [
  null,
  "Problém s tím, stát se správcem"
 ],
 "Problem details": [
  null,
  "Podrobnosti o problému"
 ],
 "Problem info": [
  null,
  "Informace o problému"
 ],
 "Propagates reload to": [
  null,
  "Propaguje načíst znovu k"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  ""
 ],
 "RAID chassis": [
  null,
  "RAID skříň"
 ],
 "Rack mount chassis": [
  null,
  "Skříň do stojanu"
 ],
 "Rank": [
  null,
  "Rank"
 ],
 "Read more...": [
  null,
  "Zjistit více…"
 ],
 "Read-only": [
  null,
  "Pouze pro čtení"
 ],
 "Real host name": [
  null,
  "Skutečný název stroje"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Skutečný název stroje může obsahovat pouze malá písmena (bez diakritiky), číslice, spojovníky a tečky (u použitých subdomén)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Je třeba, aby skutečný název stroje byl nanejvýš 64 znaků dlouhý"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  ""
 ],
 "Reload": [
  null,
  "Načíst znovu"
 ],
 "Reload propagated from": [
  null,
  "Znovu načíst propagováno z"
 ],
 "Reloading": [
  null,
  "Opětovné načítání"
 ],
 "Removals:": [
  null,
  "Odebrání:"
 ],
 "Remove": [
  null,
  "Odebrat"
 ],
 "Removing $0": [
  null,
  "Odebírá se $0"
 ],
 "Repeat": [
  null,
  "Opakovat"
 ],
 "Repeat monthly": [
  null,
  "Opakovat každý měsíc"
 ],
 "Repeat weekly": [
  null,
  "Opakovat každý týden"
 ],
 "Report": [
  null,
  "Nahlásit"
 ],
 "Report to ABRT Analytics": [
  null,
  "Hlásit do ABRT analýzy"
 ],
 "Reported; no links available": [
  null,
  "Nahlášeno; nejsou k dispozici žádné odkazy"
 ],
 "Reporting failed": [
  null,
  "Nahlašování se nezdařilo"
 ],
 "Reporting was canceled": [
  null,
  "Nahlašování bylo zrušeno"
 ],
 "Reports:": [
  null,
  "Hlášení:"
 ],
 "Required by": [
  null,
  "Vyžadováno"
 ],
 "Required by ": [
  null,
  "Vyžadováno "
 ],
 "Requires": [
  null,
  "Vyžaduje"
 ],
 "Requires administration access to edit": [
  null,
  "Pro úpravu jsou vyžadována oprávnění správce systému"
 ],
 "Requisite": [
  null,
  "Závislost"
 ],
 "Requisite of": [
  null,
  "Závislost pro"
 ],
 "Reset": [
  null,
  "Reset"
 ],
 "Restart": [
  null,
  "Restartovat"
 ],
 "Resume": [
  null,
  "Obnovit chod"
 ],
 "Reviewing logs": [
  null,
  "Vyhodnocování záznamu událostí"
 ],
 "Run at": [
  null,
  "Spustit v"
 ],
 "Run on": [
  null,
  "Spustit na"
 ],
 "Running": [
  null,
  "Spuštěné"
 ],
 "Saturdays": [
  null,
  "Soboty"
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "Save and reboot": [
  null,
  "Uložit a restartovat"
 ],
 "Save changes": [
  null,
  "Uložit změny"
 ],
 "Scheduled poweroff at $0": [
  null,
  ""
 ],
 "Scheduled reboot at $0": [
  null,
  ""
 ],
 "Sealed-case PC": [
  null,
  "Počítač se zapečetěnou skříní"
 ],
 "Search": [
  null,
  "Hledat"
 ],
 "Seconds": [
  null,
  "Sekund"
 ],
 "Secure shell keys": [
  null,
  "Klíče zabezpečeného shellu"
 ],
 "Select a identifier": [
  null,
  "Vybrat identifikátor"
 ],
 "Send": [
  null,
  "Odeslat"
 ],
 "Server software": [
  null,
  "Serverový software"
 ],
 "Service logs": [
  null,
  "Záznamy událostí služby"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Set hostname": [
  null,
  "Nastavit název stroje"
 ],
 "Set time": [
  null,
  "Nastavit čas"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "Zobrazit všechna vlákna"
 ],
 "Show fingerprints": [
  null,
  "Zobrazit otisky"
 ],
 "Show messages containing given string.": [
  null,
  "Zobrazit zprávy obsahující daný řetězec."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Zobrazit zprávy pro zadanou systemd jednotku."
 ],
 "Show messages from a specific boot.": [
  null,
  "Zobrazit zprávy z konkrétního startu systému."
 ],
 "Show more relationships": [
  null,
  "Zobrazit další vztahy"
 ],
 "Show relationships": [
  null,
  "Zobrazit vztahy"
 ],
 "Shut down": [
  null,
  "Vypnout"
 ],
 "Shutdown": [
  null,
  "Vypnout"
 ],
 "Since": [
  null,
  "Od"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Size": [
  null,
  "Velikost"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Sockets": [
  null,
  "Sokety"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Softwarová ošetření problémů zabezpečení procesoru, snižující riziko jejich zneužití. Mají negativní dopad na výkonnost. Nastavení měníte na vlastní nebezpeční."
 ],
 "Space-saving computer": [
  null,
  "Prostorově úsporný počítač"
 ],
 "Specific time": [
  null,
  "Konkrétní čas"
 ],
 "Speed": [
  null,
  "Rychlost"
 ],
 "Start": [
  null,
  "Spustit"
 ],
 "Start and enable": [
  null,
  "Spustit a zapnout"
 ],
 "Start service": [
  null,
  "Spustit službu"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Začít zobrazovat položky od zadaného data výše."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Začít zobrazovat položky od zadaného data dál do minulosti."
 ],
 "State": [
  null,
  "Stav"
 ],
 "Static": [
  null,
  "Statické"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Stick PC": [
  null,
  "Počítač v klíčence"
 ],
 "Stop": [
  null,
  "Zastavit"
 ],
 "Stop and disable": [
  null,
  "Zastavit a vypnout"
 ],
 "Stub": [
  null,
  "Pahýl"
 ],
 "Sub-Chassis": [
  null,
  "Dílčí skříň"
 ],
 "Sub-Notebook": [
  null,
  "Zmenšený notebook"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  ""
 ],
 "Successfully copied to keyboard": [
  null,
  "Úspěšně zkopírováno do klávesnice"
 ],
 "Sundays": [
  null,
  "Neděle"
 ],
 "Switch to administrative access": [
  null,
  "Přepnout na přístup správce"
 ],
 "Switch to limited access": [
  null,
  "Přepnout na omezený přístup"
 ],
 "Synchronized": [
  null,
  "Synchronizováno"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizováno s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizuje se"
 ],
 "System": [
  null,
  "Systém"
 ],
 "System information": [
  null,
  "Informace o systému"
 ],
 "System time": [
  null,
  "Systémový čas"
 ],
 "Systemd units": [
  null,
  "Systemd jednotky"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Targets": [
  null,
  "Cíle"
 ],
 "Terminal": [
  null,
  "Terminál"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Uživatel $0 není oprávněn měnit zmírňování dopadu chyb zabezpečení procesoru"
 ],
 "This field cannot be empty": [
  null,
  "Tuto kolonku je třeba vyplnit"
 ],
 "This may take a while": [
  null,
  "Toto může chvíli trvat"
 ],
 "This system is using a custom profile": [
  null,
  "Tento systém používá uživatelsky určený profil"
 ],
 "This system is using the recommended profile": [
  null,
  "Tento systém používá doporučený profil"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Tato jednotka není navržena k tomu, aby byla výslovně zapnuta."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Toto přidá shodu pro „_BOOT_ID=“. Pokud není určeno, budou zobrazeny záznamy událostí pro stávající start systému. Pokud je identifikátor startu vynechán, kladný posun prohledá starty počínaje od začátku žurnálu a posun rovný nebo menší než nula prohledá starty počínaje od konce žurnálu. Proto 1 znamená první start, nalezený v žurnálu v chronologickém pořadí, 2 druhé a tak dále; zatímco -0 je poslední start, -1 start před tím posledním, a tak dále."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "Toto přidá shodu pro „_SYSTEMD_UNIT=“, „COREDUMP_UNIT=“ a „UNIT=“ a pomůže tak nalezení všech případných zpráv pro danou jednotku. Může obsahovat vícero jednotek, oddělovaných čárkou. "
 ],
 "Thursdays": [
  null,
  "Čtvrtky"
 ],
 "Time": [
  null,
  "Čas"
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "Timer creation failed": [
  null,
  "Vytvoření časovače se nezdařilo"
 ],
 "Timers": [
  null,
  "Časovače"
 ],
 "Toggle date picker": [
  null,
  "Přepnout volič datumů"
 ],
 "Toggle filters": [
  null,
  "Přepnout filtry"
 ],
 "Total size: $0": [
  null,
  "Celková velikost: $0"
 ],
 "Tower": [
  null,
  "Věž"
 ],
 "Transient": [
  null,
  "Přechodné"
 ],
 "Trigger": [
  null,
  "Spouštěč"
 ],
 "Triggered by": [
  null,
  "Spuštěno na základě"
 ],
 "Triggers": [
  null,
  "Spouštěče"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizaci se $0"
 ],
 "Tuesdays": [
  null,
  "Úterky"
 ],
 "Tuned has failed to start": [
  null,
  "Spuštění procesu služby tuned se nezdařilo"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned je služba která monitoruje váš systém a optimalizuje jeho výkon pod určitými zátěžemi. Jádrem Tuned jsou profily, který ladí váš systém pro různé případy použití."
 ],
 "Tuned is not available": [
  null,
  "Tuned není k dispozici"
 ],
 "Tuned is not running": [
  null,
  "Tuned není spuštěné"
 ],
 "Tuned is off": [
  null,
  "Tuned je vypnuté"
 ],
 "Turn on administrative access": [
  null,
  "Zapnout přístup na úrovni správce"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type to filter": [
  null,
  "Filtrujte psaním"
 ],
 "Unit": [
  null,
  "Jednotka"
 ],
 "Unit not found": [
  null,
  "Jednotka nenalezena"
 ],
 "Unknown": [
  null,
  "Neznámé"
 ],
 "Until": [
  null,
  "Dokud"
 ],
 "Updating status...": [
  null,
  "Aktualizace stavu…"
 ],
 "Uptime": [
  null,
  "Doba chodu od spuštění"
 ],
 "Usage": [
  null,
  "Použití"
 ],
 "User": [
  null,
  "Uživatel"
 ],
 "Validating address": [
  null,
  "Ověřuje se adresa"
 ],
 "Vendor": [
  null,
  "Výrobce"
 ],
 "Version": [
  null,
  "Verze"
 ],
 "View all logs": [
  null,
  "Zobrazit všechny záznamy událostí"
 ],
 "View hardware details": [
  null,
  "Zobrazit podrobnosti o hardware"
 ],
 "View report": [
  null,
  "Zobrazit hlášení"
 ],
 "Waiting for input…": [
  null,
  "Čeká se na vstup…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čeká se na dokončení ostatních operací správy balíčků"
 ],
 "Waiting to start…": [
  null,
  "Čeká se na spuštění…"
 ],
 "Wanted by": [
  null,
  "Vyžadováno"
 ],
 "Wants": [
  null,
  "Vyžaduje"
 ],
 "Warning and above": [
  null,
  "Varování a závažnější"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Webová konzole je spuštěná v režimu omezeného přístupu."
 ],
 "Wednesdays": [
  null,
  "Středy"
 ],
 "Weekly": [
  null,
  "Každý týden"
 ],
 "Weeks": [
  null,
  "Týdny"
 ],
 "White": [
  null,
  "Bílá"
 ],
 "Yearly": [
  null,
  "Každý rok"
 ],
 "Yes": [
  null,
  "Ano"
 ],
 "You may try to load older entries.": [
  null,
  "Můžete zkusit načíst starší položky."
 ],
 "You now have administrative access.": [
  null,
  "Nyní máte přístup na úrovni správy systému."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Vámi využívaný prohlížeč neumožňuje vkládání z kontextové nabídky. Náhradně je možné použít Shift+Insert."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Váš prohlížeč si bude úroveň přístupu pamatovat i pro příště."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bajtů binárních dat]"
 ],
 "[binary data]": [
  null,
  "[binarní data]"
 ],
 "[no data]": [
  null,
  "[žádná data]"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "active": [
  null,
  "aktivní"
 ],
 "asset tag": [
  null,
  "inventární štítek"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "boot"
 ],
 "cgroups": [
  null,
  "řídící skupiny"
 ],
 "command": [
  null,
  "příkaz"
 ],
 "console": [
  null,
  "konzole"
 ],
 "coredump": [
  null,
  "výpis paměti"
 ],
 "cpu": [
  null,
  "procesor"
 ],
 "crash": [
  null,
  "pád"
 ],
 "date": [
  null,
  "datum"
 ],
 "debug": [
  null,
  "ladění"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "vypnout"
 ],
 "disks": [
  null,
  "disky"
 ],
 "domain": [
  null,
  "doména"
 ],
 "edit": [
  null,
  "upravit"
 ],
 "enable": [
  null,
  "zapnout"
 ],
 "error": [
  null,
  "chyba"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "nepodařilo se vypsat ssh klíče stroje: $0"
 ],
 "graphs": [
  null,
  "grafy"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "history": [
  null,
  "historie"
 ],
 "host": [
  null,
  "stroj"
 ],
 "journal": [
  null,
  "žurnál"
 ],
 "journalctl manpage": [
  null,
  "manuálová stránka ke journalctl"
 ],
 "machine": [
  null,
  "stroj"
 ],
 "mask": [
  null,
  "maska"
 ],
 "memory": [
  null,
  "paměť"
 ],
 "metrics": [
  null,
  "metriky"
 ],
 "mitigation": [
  null,
  "omezení vlivu"
 ],
 "network": [
  null,
  "síť"
 ],
 "none": [
  null,
  "nic"
 ],
 "of $0 CPU": [
  null,
  "z $0 procesoru",
  "ze $0 procesorů",
  "z $0 procesorů"
 ],
 "operating system": [
  null,
  "operační systém"
 ],
 "os": [
  null,
  "os"
 ],
 "path": [
  null,
  "popis umístění"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "power": [
  null,
  "napájení"
 ],
 "ram": [
  null,
  "operační paměť"
 ],
 "recommended": [
  null,
  "doporučeno"
 ],
 "restart": [
  null,
  "restartovat"
 ],
 "running $0": [
  null,
  "spuštěné $0"
 ],
 "serial": [
  null,
  "sériové"
 ],
 "service": [
  null,
  "služba"
 ],
 "shell": [
  null,
  "shell"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "shut": [
  null,
  "vyp"
 ],
 "socket": [
  null,
  "patice"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "cíl"
 ],
 "time": [
  null,
  "čas"
 ],
 "timer": [
  null,
  "časovač"
 ],
 "unit": [
  null,
  "jednotka"
 ],
 "unknown": [
  null,
  "neznámý"
 ],
 "unmask": [
  null,
  "zrušit maskování"
 ],
 "version": [
  null,
  "verze"
 ],
 "warning": [
  null,
  "varování"
 ]
});
