cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 kritische Treffer",
  "$0 Treffer, darunter kritische"
 ],
 "$0 failed login attempt": [
  null,
  "$0 fehlgeschlagene Anmeldung",
  "$0 fehlgeschlagene Anmeldungen"
 ],
 "$0 important hit": [
  null,
  "$0 wichtiger Treffer",
  "$0 Treffer, darunter wichtige"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ist in keinem Repository verfügbar."
 ],
 "$0 low severity hit": [
  null,
  "$0 wenig wichtiger Treffer",
  "$0 wenig unwichtige Treffer"
 ],
 "$0 moderate hit": [
  null,
  "$0 Treffer",
  "$0 Treffer, darunter moderate"
 ],
 "$0 service has failed": [
  null,
  "$0 Dienst ist fehlerhaft",
  "$0 Dienste sind fehlerhaft"
 ],
 "$0 will be installed.": [
  null,
  "$0 wird installiert."
 ],
 "$0: crash at $1": [
  null,
  "$0: Absturz bei $1"
 ],
 "1 minute": [
  null,
  "1 Minute"
 ],
 "10th": [
  null,
  "10."
 ],
 "11th": [
  null,
  "11."
 ],
 "12th": [
  null,
  "12."
 ],
 "13th": [
  null,
  "13."
 ],
 "14th": [
  null,
  "14."
 ],
 "15th": [
  null,
  "15."
 ],
 "16th": [
  null,
  "16."
 ],
 "17th": [
  null,
  "17."
 ],
 "18th": [
  null,
  "18."
 ],
 "19th": [
  null,
  "19."
 ],
 "1st": [
  null,
  "1."
 ],
 "20 minutes": [
  null,
  "20 Minuten"
 ],
 "20th": [
  null,
  "20."
 ],
 "21th": [
  null,
  "21."
 ],
 "22th": [
  null,
  "22."
 ],
 "23th": [
  null,
  "23."
 ],
 "24th": [
  null,
  "24."
 ],
 "25th": [
  null,
  "25."
 ],
 "26th": [
  null,
  "26."
 ],
 "27th": [
  null,
  "27."
 ],
 "28th": [
  null,
  "28."
 ],
 "29th": [
  null,
  "29."
 ],
 "2nd": [
  null,
  "2."
 ],
 "30th": [
  null,
  "30."
 ],
 "31st": [
  null,
  "31."
 ],
 "3rd": [
  null,
  "3."
 ],
 "40 minutes": [
  null,
  "40 Minuten"
 ],
 "4th": [
  null,
  "4."
 ],
 "5 minutes": [
  null,
  "5 Minuten"
 ],
 "5th": [
  null,
  "5."
 ],
 "60 minutes": [
  null,
  "60 Minuten"
 ],
 "6th": [
  null,
  "6."
 ],
 "7th": [
  null,
  "7."
 ],
 "8th": [
  null,
  "8."
 ],
 "9th": [
  null,
  "9."
 ],
 "Absent": [
  null,
  "Abwesend"
 ],
 "Active since ": [
  null,
  "Aktiviert seit "
 ],
 "Active state": [
  null,
  "Aktiver Status"
 ],
 "Add": [
  null,
  "Hinzufügen"
 ],
 "Additional actions": [
  null,
  "Weitere Aktionen"
 ],
 "Additional packages:": [
  null,
  "Zusatzpakete:"
 ],
 "Administrative access": [
  null,
  "Administrativer Zugang"
 ],
 "Advanced TCA": [
  null,
  "Fortgeschrittenes TCA"
 ],
 "After": [
  null,
  "Nach"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Nach dem Verlassen der Domain können sich nur noch Nutzer mit lokalen Zugängen an dieser Maschine anmelden. Dies betrifft auch andere Dienste wie z.B. die DNS Auflösungs Einstellungen und die Liste der vertrauenswürdigen CAs könnte sich ändern."
 ],
 "After system boot": [
  null,
  "Nach dem Systemstart"
 ],
 "Alert and above": [
  null,
  "Alarm und oben"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "All": [
  null,
  "Alle"
 ],
 "All-in-one": [
  null,
  "Alles-in-einem"
 ],
 "Allow running (unmask)": [
  null,
  "Ausführung zulassen (unmask)"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Jede Zeichenkette in den log Nachrichten kann gefiltert werden. Die Zeichenkette kann auch die Form eines herkömmlichen Ausdrucks haben. Filtern nach log Nachrichtenfeldern wird ebenfalls unterstützt. Dies sind durch Leerzeichen getrennte Werte in der Form FELD=WERT, wobei WERT eine durch Kommata getrennte Liste von möglichen Werten sein kann."
 ],
 "Appearance": [
  null,
  "Erscheinungsbild"
 ],
 "Apply and reboot": [
  null,
  "Anwenden und Neustarten"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Neue Policy wird angewendet... Dies kann ein paar Minuten dauern."
 ],
 "Asset tag": [
  null,
  "Asset-Tag"
 ],
 "At minute": [
  null,
  "Bei Minute"
 ],
 "At specific time": [
  null,
  "Zu einer bestimmten Zeit"
 ],
 "Authenticate": [
  null,
  "Authentifiziere"
 ],
 "Automatically starts": [
  null,
  "Startet automatisch"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch (NTP)"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch (spezifische NTP-Server)"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS-Datum"
 ],
 "BIOS version": [
  null,
  "BIOS-Version"
 ],
 "Bad": [
  null,
  "Falsch"
 ],
 "Bad setting": [
  null,
  "Falsche Einstellung"
 ],
 "Before": [
  null,
  "Bevor"
 ],
 "Binds to": [
  null,
  "Bindet an"
 ],
 "Black": [
  null,
  "Schwarz"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Bladegehäuse"
 ],
 "Boot": [
  null,
  "Booten"
 ],
 "Bound by": [
  null,
  "Gebunden"
 ],
 "Bus expansion chassis": [
  null,
  "Bus-Erweiterungsgehäuse"
 ],
 "CPU": [
  null,
  "Prozessor"
 ],
 "CPU security": [
  null,
  "Prozessor-Sicherheit"
 ],
 "CPU security toggles": [
  null,
  "Prozessor-Sicherheits-Schalter"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Es konnten keine Logeinträge für die aktuellen Filtereinstellungen gefunden werden"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Cancel poweroff": [
  null,
  "Herunterfahren abbrechen"
 ],
 "Cancel reboot": [
  null,
  "Neustart abbrechen"
 ],
 "Cannot be enabled": [
  null,
  "Kann nicht aktiviert werden"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Kann keiner Domäne beitreten, da realmd auf diesem System nicht installiert ist."
 ],
 "Cannot schedule event in the past": [
  null,
  "Vorgang kann nicht für die Vergangenheit geplant werden"
 ],
 "Change": [
  null,
  "Ändern"
 ],
 "Change crypto policy": [
  null,
  "Cryptopolicy ändern"
 ],
 "Change host name": [
  null,
  "Rechnernamen ändern"
 ],
 "Change performance profile": [
  null,
  "Leistungsprofil ändern"
 ],
 "Change profile": [
  null,
  "Profil ändern"
 ],
 "Change system time": [
  null,
  "Systemzeit ändern"
 ],
 "Checking installed software": [
  null,
  "Installierte Software wird überprüft"
 ],
 "Class": [
  null,
  "Klasse"
 ],
 "Clear 'Failed to start'": [
  null,
  "'Starten Fehlgeschlagen' zurücksetzen"
 ],
 "Clear all filters": [
  null,
  "Alle Filter entfernen"
 ],
 "Client software": [
  null,
  "Client software"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Command": [
  null,
  "Befehl"
 ],
 "Command not found": [
  null,
  "Befehl nicht gefunden"
 ],
 "Communication with tuned has failed": [
  null,
  "Kommunikation mit tuned schlug fehl"
 ],
 "Compact PCI": [
  null,
  "Kompakte PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Bedingung $0=$1 wurde nicht erfüllt"
 ],
 "Condition failed": [
  null,
  "Bedingung fehlgeschlagen"
 ],
 "Configuration": [
  null,
  "Konfiguration"
 ],
 "Configuring system settings": [
  null,
  "Konfiguriere System-Einstellungen"
 ],
 "Confirm deletion of $0": [
  null,
  "Löschen von $0 bestätigen"
 ],
 "Conflicted by": [
  null,
  "Konflikt von"
 ],
 "Conflicts": [
  null,
  "Konflikte"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Verbindung zum dbus fehlgeschlagen: $0"
 ],
 "Consists of": [
  null,
  "Besteht aus"
 ],
 "Contacted domain": [
  null,
  "Kontaktierte Domain"
 ],
 "Controller": [
  null,
  "Controller"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Copy": [
  null,
  "Kopieren"
 ],
 "Copy to clipboard": [
  null,
  "In Zwischenablage kopieren"
 ],
 "Crash reporting": [
  null,
  "Absturz melden"
 ],
 "Create timer": [
  null,
  "Timer erstellen"
 ],
 "Critical and above": [
  null,
  "Kritisch und höher"
 ],
 "Crypto Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Crypto Policies ist ein Systembestandteil, der die kryptografischen Kern-Subsysteme konfiguriert. Dabei deckt er das TLS, IPSec, SSH, DNSSec und Kerberos Protokoll ab."
 ],
 "Crypto policy": [
  null,
  "Crypto Policy"
 ],
 "Crypto policy is inconsistent": [
  null,
  "Die Crypto Policy ist inkonsistent"
 ],
 "Ctrl+Insert": [
  null,
  "Strg+Einfügen"
 ],
 "Current boot": [
  null,
  "Aktueller Boot"
 ],
 "Custom crypto policy": [
  null,
  "Benutzerdefinierte Verschlüsselungsrichtlinie"
 ],
 "Daily": [
  null,
  "Täglich"
 ],
 "Dark": [
  null,
  "Dunkel"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Datumsangaben sollten im Format JJJJ-MM-TT hh:mm:ss sein. Alternativ werden auch die Begriffe 'gestern', 'heute', 'morgen' verstanden. 'Now' bezieht sich auf die aktuelle Zeit. Es können auch relative Zeiten angegeben werden mit den Vorzeichen '-' oder '+'"
 ],
 "Debug and above": [
  null,
  "Debug und höher"
 ],
 "Decrease by one": [
  null,
  "Um eins verringern"
 ],
 "Delay": [
  null,
  "Verzögerung"
 ],
 "Delay must be a number": [
  null,
  "Verzögerung muss eine Zahl sein"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Deletion will remove the following files:": [
  null,
  "Beim Löschen werden die folgenden Dateien entfernt:"
 ],
 "Description": [
  null,
  "Beschreibung"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Abnehmbar"
 ],
 "Details": [
  null,
  "Details"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Simultanes Multithreading deaktivieren"
 ],
 "Disable tuned": [
  null,
  "Tuned deaktivieren"
 ],
 "Disabled": [
  null,
  "Deaktiviert"
 ],
 "Disallow running (mask)": [
  null,
  "Verbiete die Ausführung (mask)"
 ],
 "Docking station": [
  null,
  "Dockingstation"
 ],
 "Does not automatically start": [
  null,
  "Nicht automatisch starten"
 ],
 "Domain": [
  null,
  "Domain"
 ],
 "Domain address": [
  null,
  "Domänenadressen"
 ],
 "Domain administrator name": [
  null,
  "Name des Domain-Administrators"
 ],
 "Domain administrator password": [
  null,
  "Passwort des Domain-Administrators"
 ],
 "Domain could not be contacted": [
  null,
  "Die Domäne konnte nicht kontaktiert werden"
 ],
 "Domain is not supported": [
  null,
  "Domäne wird nicht unterstützt"
 ],
 "Don't repeat": [
  null,
  "Nicht wiederholen"
 ],
 "Downloading $0": [
  null,
  "wird heruntergeladen $0"
 ],
 "Dual rank": [
  null,
  "Doppelter Rang"
 ],
 "Edit /etc/motd": [
  null,
  "/etc/motd bearbeiten"
 ],
 "Edit motd": [
  null,
  "motd bearbeiten"
 ],
 "Embedded PC": [
  null,
  "Embedded PC"
 ],
 "Enabled": [
  null,
  "Aktiviert"
 ],
 "Entry at $0": [
  null,
  "Eintrag bei $0"
 ],
 "Error": [
  null,
  "Fehler"
 ],
 "Error and above": [
  null,
  "Fehler und höher"
 ],
 "Error message": [
  null,
  "Fehlermeldung"
 ],
 "Expansion chassis": [
  null,
  "Erweiterungsgehäuse"
 ],
 "Extended information": [
  null,
  "Erweiterte Informationen"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS wurde nicht richtig aktiviert"
 ],
 "Failed to disable tuned": [
  null,
  "Fehler beim Deaktivieren"
 ],
 "Failed to disabled tuned profile": [
  null,
  "Deaktivierung des tuned-Profils ist fehlgeschlagen"
 ],
 "Failed to enable tuned": [
  null,
  "Tuned konnte nicht aktiviert werden"
 ],
 "Failed to fetch logs": [
  null,
  "Protokolle konnten nicht abgerufen werden"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Änderungen in /etc/motd konnten nicht gespeichert werden"
 ],
 "Failed to start": [
  null,
  "Starten fehlgeschlagen"
 ],
 "Failed to switch profile": [
  null,
  "Profil konnte nicht gewechselt werden"
 ],
 "File state": [
  null,
  "Dateistatus"
 ],
 "Filter by name or description": [
  null,
  "Filtere nach Name oder Beschreibung"
 ],
 "Filters": [
  null,
  "Filter"
 ],
 "Font size": [
  null,
  "Schriftgröße"
 ],
 "Forbidden from running": [
  null,
  "Ausführen verboten"
 ],
 "Frame number": [
  null,
  "Framezahl"
 ],
 "Free-form search": [
  null,
  "Freitext-Suche"
 ],
 "Fridays": [
  null,
  "Freitags"
 ],
 "General": [
  null,
  "Allgemein"
 ],
 "Generated": [
  null,
  "Generiert"
 ],
 "Go to $0": [
  null,
  "Gehe zu $0"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "Hardware information": [
  null,
  "Hardware-Informationen"
 ],
 "Health": [
  null,
  "Meldungen"
 ],
 "Help": [
  null,
  "Hilfe"
 ],
 "Hierarchy ID": [
  null,
  "Hierachie ID"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Höhere Interoperabilität auf Kosten einer größeren Angriffsfläche."
 ],
 "Hostname": [
  null,
  "Hostname"
 ],
 "Hourly": [
  null,
  "Stündlich"
 ],
 "Hours": [
  null,
  "Stunde"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "Kennung"
 ],
 "Increase by one": [
  null,
  "Um eins erhöhen"
 ],
 "Indirect": [
  null,
  "Indirekt"
 ],
 "Info and above": [
  null,
  "Info und höher"
 ],
 "Insights: ": [
  null,
  "Einblicke: "
 ],
 "Install": [
  null,
  "Installation"
 ],
 "Install software": [
  null,
  "Software installieren"
 ],
 "Installing $0": [
  null,
  "$0 wird installiert"
 ],
 "Invalid": [
  null,
  "Ungültig"
 ],
 "Invalid date format": [
  null,
  "Ungültiges Datumsformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ungültiges Datumsformat und ungültiges Zeitformat"
 ],
 "Invalid time format": [
  null,
  "Ungültiges Zeitformat"
 ],
 "Invalid timezone": [
  null,
  "Ungültige Zeitzone"
 ],
 "IoT gateway": [
  null,
  "IoT-Gateway"
 ],
 "Join": [
  null,
  "Beitreten"
 ],
 "Join domain": [
  null,
  "Einer Domain beitreten"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "Zum Beitritt einer Domäne wird realmd benötigt"
 ],
 "Joining this domain is not supported": [
  null,
  "Der Beitritt zu dieser Domain wird nicht unterstützt"
 ],
 "Joins namespace of": [
  null,
  "Tritt dem Namespace Of bei"
 ],
 "Journal": [
  null,
  "Tagebuch"
 ],
 "Journal entry": [
  null,
  "Journal-Eintrag"
 ],
 "Journal entry not found": [
  null,
  "Journal-Eintrag nicht gefunden"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Last 24 hours": [
  null,
  "Letzte 24 Stunden"
 ],
 "Last 7 days": [
  null,
  "Letzte 7 Tage"
 ],
 "Last successful login:": [
  null,
  "Letzte erfolgreiche Anmeldung:"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "Leave $0": [
  null,
  "$0 verlassen"
 ],
 "Leave domain": [
  null,
  "Domäne verlassen"
 ],
 "Light": [
  null,
  "Leicht"
 ],
 "Limit access": [
  null,
  "Zugang einschränken"
 ],
 "Limited access": [
  null,
  "Eingeschränkter Zugang"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Der eingeschränkte Zugriffsmodus schränkt die administrativen Rechte ein. Einige Teile der Web-Konsole sind in ihrer Funktionalität eingeschränkt."
 ],
 "Limits": [
  null,
  "Einschränkungen"
 ],
 "Linked": [
  null,
  "Verbunden"
 ],
 "Listen": [
  null,
  "Lauschen"
 ],
 "Listing unit files": [
  null,
  "Unit-Dateien werden aufgelistet"
 ],
 "Listing unit files failed: $0": [
  null,
  "Auflisten von Unit-Dateien fehlgeschlagen: $0"
 ],
 "Listing units": [
  null,
  ""
 ],
 "Listing units failed: $0": [
  null,
  ""
 ],
 "Load earlier entries": [
  null,
  "Frühere Einträge laden"
 ],
 "Loading earlier entries": [
  null,
  "Frühere Einträge werden geladen"
 ],
 "Loading keys...": [
  null,
  "Schlüssel werden geladen ..."
 ],
 "Loading of SSH keys failed": [
  null,
  "Laden von SSH-Schlüsseln fehlgeschlagen"
 ],
 "Loading of units failed": [
  null,
  ""
 ],
 "Loading unit failed: $0": [
  null,
  ""
 ],
 "Loading...": [
  null,
  "Lade..."
 ],
 "Log messages": [
  null,
  "Nachrichten protokollieren"
 ],
 "Login format": [
  null,
  "Login format"
 ],
 "Logs": [
  null,
  "Protokolle"
 ],
 "Low profile desktop": [
  null,
  "Low-Profile-Desktop"
 ],
 "Lunch box": [
  null,
  "Brotdose"
 ],
 "Machine ID": [
  null,
  "Maschinen-ID"
 ],
 "Machine SSH key fingerprints": [
  null,
  "SSH-Fingerabdrücke auf diesem Rechner"
 ],
 "Main server chassis": [
  null,
  "Hauptservergehäuse"
 ],
 "Maintenance": [
  null,
  "Wartung"
 ],
 "Managing services": [
  null,
  "Dienste verwalten"
 ],
 "Manually": [
  null,
  "Manuell"
 ],
 "Mask service": [
  null,
  "Dienst maskieren"
 ],
 "Masked": [
  null,
  "Maskiert"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  ""
 ],
 "Memory": [
  null,
  "Speicher"
 ],
 "Memory technology": [
  null,
  "Speicher-Technologie"
 ],
 "Merged": [
  null,
  "Zusammengeführt"
 ],
 "Message to logged in users": [
  null,
  "Nachricht an angemeldete Benutzer"
 ],
 "Method": [
  null,
  "Methode"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini-Tower"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Minute muss eine Zahl zwischen 0 und 59 sein"
 ],
 "Minutes": [
  null,
  "Minuten"
 ],
 "Mitigations": [
  null,
  "Milderungen"
 ],
 "Model": [
  null,
  "Modell"
 ],
 "Mondays": [
  null,
  "Montags"
 ],
 "Monthly": [
  null,
  "Monatlich"
 ],
 "Multi-system chassis": [
  null,
  "Multi-System-Chassis"
 ],
 "NTP server": [
  null,
  "NTP-Server"
 ],
 "Name": [
  null,
  "Name"
 ],
 "Need at least one NTP server": [
  null,
  "Benötigen Sie mindestens einen NTP-Server"
 ],
 "No": [
  null,
  "Nein"
 ],
 "No delay": [
  null,
  "Keine Verzögerung"
 ],
 "No host keys found.": [
  null,
  "Es wurden keine Host-Schlüssel gefunden."
 ],
 "No log entries": [
  null,
  "Keine Protokolleinträge"
 ],
 "No logs found": [
  null,
  "Keine Protokolle gefunden"
 ],
 "No matching results": [
  null,
  "Keine passenden Ergebnisse"
 ],
 "No results found": [
  null,
  "Keine Ergebnisse gefunden"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Keine Ergebnisse entsprechen den Filterkriterien. Löschen Sie alle Filter, um die Ergebnisse anzuzeigen."
 ],
 "No rule hits": [
  null,
  "Keine Treffer in Regelwerk"
 ],
 "None": [
  null,
  "Kein"
 ],
 "Not connected to Insights": [
  null,
  "Nicht mit Insights verbunden"
 ],
 "Not found": [
  null,
  "Nicht gefunden"
 ],
 "Not permitted to configure realms": [
  null,
  ""
 ],
 "Not running": [
  null,
  "Läuft nicht"
 ],
 "Not synchronized": [
  null,
  "Nicht synchronisiert"
 ],
 "Note": [
  null,
  "Hinweis"
 ],
 "Notebook": [
  null,
  "Notizbuch"
 ],
 "Notice and above": [
  null,
  "Hinweis und höher"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "On failure": [
  null,
  "Bei einem Ausfall"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "Nur Alphabete, Zahlen,:, _,. , @ , - sind erlaubt"
 ],
 "Only emergency": [
  null,
  "Nur Notfall"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Beim Booten im FIPS-Modus nur zugelassene und erlaubte Algorithmen verwenden."
 ],
 "Other": [
  null,
  "Weitere"
 ],
 "Overview": [
  null,
  "Überblick"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ist abgestürzt"
 ],
 "Part of": [
  null,
  "Teil von"
 ],
 "Password": [
  null,
  "Passwort"
 ],
 "Paste": [
  null,
  "Einfügen"
 ],
 "Paste error": [
  null,
  "Fehler beim Einfügen"
 ],
 "Path": [
  null,
  "Pfad"
 ],
 "Paths": [
  null,
  "Pfade"
 ],
 "Pause": [
  null,
  "Pause"
 ],
 "Performance profile": [
  null,
  "Leistungsprofil"
 ],
 "Peripheral chassis": [
  null,
  "Peripheriechassis"
 ],
 "Pick date": [
  null,
  "Datum auswählen"
 ],
 "Pin unit": [
  null,
  ""
 ],
 "Pinned unit": [
  null,
  ""
 ],
 "Pizza box": [
  null,
  "Pizza-Box"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Bitte authentifizieren Sie sich, um administrativen Zugriff zu erhalten"
 ],
 "Portable": [
  null,
  "tragbar"
 ],
 "Present": [
  null,
  "Derzeit"
 ],
 "Pretty host name": [
  null,
  "Anzeige-Rechnername"
 ],
 "Previous boot": [
  null,
  ""
 ],
 "Priority": [
  null,
  "Priorität"
 ],
 "Problem becoming administrator": [
  null,
  "Problem beim Administrator werden"
 ],
 "Problem details": [
  null,
  "Problemdetails"
 ],
 "Problem info": [
  null,
  "Problem Info"
 ],
 "Propagates reload to": [
  null,
  "Propagiert reload to"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Schützt vor kurzfristig zu erwartenden Angriffen auf Kosten der Interoperabilität."
 ],
 "RAID chassis": [
  null,
  "RAID-Chassis"
 ],
 "Rack mount chassis": [
  null,
  "Rack-Einbaugehäuse"
 ],
 "Rank": [
  null,
  "Rang"
 ],
 "Read more...": [
  null,
  "Mehr lesen..."
 ],
 "Read-only": [
  null,
  "Nur-lesen"
 ],
 "Real host name": [
  null,
  "Echter Rechnername"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Ein echter Hostname darf nur Kleinbuchstaben, Ziffern, Bindestriche und Punkte enthalten (mit ausgefüllten Unterdomänen)."
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Der tatsächliche Hostname darf höchstens 64 Zeichen umfassen"
 ],
 "Reapply and reboot": [
  null,
  "Erneut anwenden und neu starten"
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Empfohlene, sichere Einstellungen für aktuelle Bedrohungsmodelle."
 ],
 "Reload": [
  null,
  "Neu Laden"
 ],
 "Reload propagated from": [
  null,
  "Propagiert von neu laden"
 ],
 "Reloading": [
  null,
  "Wird neu geladen"
 ],
 "Removals:": [
  null,
  "Umzüge:"
 ],
 "Remove": [
  null,
  "Entfernen"
 ],
 "Removing $0": [
  null,
  "Entfernen $0"
 ],
 "Repeat": [
  null,
  "Wiederholen"
 ],
 "Repeat monthly": [
  null,
  "Monatlich wiederholen"
 ],
 "Repeat weekly": [
  null,
  "Wöchentlich wiederholen"
 ],
 "Report": [
  null,
  "Melden"
 ],
 "Report to ABRT Analytics": [
  null,
  "Zu ABRT Analytics senden"
 ],
 "Reported; no links available": [
  null,
  "Gemeldet; keine Links verfügbar"
 ],
 "Reporting failed": [
  null,
  "Meldung fehlgeschlagen"
 ],
 "Reporting was canceled": [
  null,
  "Meldung wurde abgebrochen"
 ],
 "Reports:": [
  null,
  "Berichte:"
 ],
 "Required by": [
  null,
  "Benötigt von"
 ],
 "Required by ": [
  null,
  "Benötigt von "
 ],
 "Requires": [
  null,
  "Erfordert"
 ],
 "Requires administration access to edit": [
  null,
  "Benötigt Administrator-Zugriff zum bearbeiten"
 ],
 "Requisite": [
  null,
  "Requisit"
 ],
 "Requisite of": [
  null,
  "Erfordernis von"
 ],
 "Reset": [
  null,
  "Zurücksetzen"
 ],
 "Restart": [
  null,
  "Neustarten"
 ],
 "Resume": [
  null,
  "Fortfahren"
 ],
 "Review crypto policy": [
  null,
  "Kryptorichtlinie begutachten"
 ],
 "Reviewing logs": [
  null,
  "Protokolle bewerten"
 ],
 "Run at": [
  null,
  "Ausführen um"
 ],
 "Run on": [
  null,
  "Ausführen auf"
 ],
 "Running": [
  null,
  "Läuft"
 ],
 "Saturdays": [
  null,
  "Samstags"
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "Save and reboot": [
  null,
  "Sichern und Neustarten"
 ],
 "Save changes": [
  null,
  "Änderungen speichern"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Planmäßiges Ausschalten um $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "Planmäßiger Neustart um $0"
 ],
 "Sealed-case PC": [
  null,
  "PC mit versiegeltem Gehäuse"
 ],
 "Search": [
  null,
  "Suche"
 ],
 "Seconds": [
  null,
  "Sekunden"
 ],
 "Secure shell keys": [
  null,
  "SSH-Schlüssel"
 ],
 "Select a identifier": [
  null,
  "Einen Bezeichner auswählen"
 ],
 "Send": [
  null,
  "Senden"
 ],
 "Server software": [
  null,
  "Server-Software"
 ],
 "Service logs": [
  null,
  "Serviceprotokolle"
 ],
 "Services": [
  null,
  "Dienste"
 ],
 "Set hostname": [
  null,
  "Hostname setzen"
 ],
 "Set time": [
  null,
  "Zeit setzen"
 ],
 "Shift+Insert": [
  null,
  "Shift+Einfügen"
 ],
 "Show all threads": [
  null,
  "Alle Threads anzeigen"
 ],
 "Show fingerprints": [
  null,
  "Fingerabdrücke anzeigen"
 ],
 "Show messages containing given string.": [
  null,
  "Meldungen mit der angegebenen Zeichenkette anzeigen."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Meldungen für die angegebene systemd-Einheit anzeigen."
 ],
 "Show messages from a specific boot.": [
  null,
  ""
 ],
 "Show more relationships": [
  null,
  "Weitere Beziehungen anzeigen"
 ],
 "Show relationships": [
  null,
  "Beziehungen anzeigen"
 ],
 "Shut down": [
  null,
  "Herunterfahren"
 ],
 "Shutdown": [
  null,
  "Herunterfahren"
 ],
 "Since": [
  null,
  "Seit"
 ],
 "Single rank": [
  null,
  "Einzelner Rang"
 ],
 "Size": [
  null,
  "Größe"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Sockets": [
  null,
  "Sockets"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Softwarebasierte Umgehungen helfen, CPU-Sicherheitsprobleme zu vermeiden. Diese Abhilfemaßnahmen haben den Nebeneffekt, dass sie die Leistung verringern. Das Ändern dieser Einstellungen erfolgt auf eigene Gefahr."
 ],
 "Space-saving computer": [
  null,
  "Platzsparender Computer"
 ],
 "Specific time": [
  null,
  "Bestimmte Zeit"
 ],
 "Speed": [
  null,
  "Geschwindigkeit"
 ],
 "Start": [
  null,
  "Starten"
 ],
 "Start and enable": [
  null,
  "Starten und aktivieren"
 ],
 "Start service": [
  null,
  "Dienst starten"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Start der Anzeige von Einträgen, die am oder nach dem angegebenen Datum liegen."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Start der Anzeige von Einträgen, die am oder vor dem angegebenen Datum liegen."
 ],
 "State": [
  null,
  "Status"
 ],
 "Static": [
  null,
  "Statisch"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Stoppen"
 ],
 "Stop and disable": [
  null,
  "Anhalten und deaktivieren"
 ],
 "Stub": [
  null,
  ""
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "Das Abonnieren von systemd-Signalen ist fehlgeschlagen: $0"
 ],
 "Successfully copied to keyboard": [
  null,
  "Erfolgreich auf die Tastatur kopiert"
 ],
 "Sundays": [
  null,
  "Sonntags"
 ],
 "Switch to administrative access": [
  null,
  "Auf administrativen Zugang umschalten"
 ],
 "Switch to limited access": [
  null,
  "Auf eingeschränkten Zugang umschalten"
 ],
 "Synchronized": [
  null,
  "Synchronisiert"
 ],
 "Synchronized with $0": [
  null,
  "Mit $0 synchronisiert"
 ],
 "Synchronizing": [
  null,
  "Wird synchronisiert"
 ],
 "System": [
  null,
  "System"
 ],
 "System information": [
  null,
  "Systeminformationen"
 ],
 "System time": [
  null,
  "Systemzeit"
 ],
 "Systemd units": [
  null,
  "Systemd Unit"
 ],
 "Tablet": [
  null,
  "Tablett"
 ],
 "Targets": [
  null,
  "Ziele"
 ],
 "Terminal": [
  null,
  "Terminal"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "Der Benutzer $0 ist nicht berechtigt, die CPU-Sicherheitsmaßnahmen zu ändern"
 ],
 "The user $0 is not permitted to change crypto policies": [
  null,
  "Der Benutzer $0 ist nicht berechtigt, Kryptorichtlinien zu ändern"
 ],
 "This field cannot be empty": [
  null,
  "Dieses Feld darf nicht leer sein"
 ],
 "This may take a while": [
  null,
  "Dies kann eine Weile dauern"
 ],
 "This system is using a custom profile": [
  null,
  "Dieses System benutzt ein benutzerdefiniertes Profil"
 ],
 "This system is using the recommended profile": [
  null,
  "Dieses System benutzt das empfohlene Profil"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Dieses Gerät kann nicht explizit aktiviert werden."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  ""
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  ""
 ],
 "Thursdays": [
  null,
  "Donnerstags"
 ],
 "Time": [
  null,
  "Zeit"
 ],
 "Time zone": [
  null,
  "Zeitzone"
 ],
 "Timer creation failed": [
  null,
  "Timer-Erstellung fehlgeschlagen"
 ],
 "Timer deletion failed": [
  null,
  "Timer-Löschung fehlgeschlagen"
 ],
 "Timers": [
  null,
  "Timer"
 ],
 "Toggle date picker": [
  null,
  "Datumsauswahl umschalten"
 ],
 "Toggle filters": [
  null,
  "Filter umschalten"
 ],
 "Total size: $0": [
  null,
  "Gesamtgröße: $0"
 ],
 "Tower": [
  null,
  "Turm"
 ],
 "Transient": [
  null,
  "Vorübergehend"
 ],
 "Trigger": [
  null,
  "Auslöser"
 ],
 "Triggered by": [
  null,
  "Ausgelöst durch"
 ],
 "Triggers": [
  null,
  "Löst aus"
 ],
 "Trying to synchronize with $0": [
  null,
  "Versuche mit {{Server}} zu synchronisieren"
 ],
 "Tuesdays": [
  null,
  "Dienstags"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned konnte nicht gestartet werden"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned ist ein Dienst, der Ihr System überwacht und die Leistung unter bestimmten Arbeitsbelastungen optimiert. Das Herzstück von Tuned sind Profile, die Ihr System für verschiedene Anwendungsfälle abstimmen."
 ],
 "Tuned is not available": [
  null,
  "Tuned ist nicht verfügbar"
 ],
 "Tuned is not running": [
  null,
  "Tuned läuft nicht"
 ],
 "Tuned is off": [
  null,
  "Tuned ist ausgeschaltet"
 ],
 "Turn on administrative access": [
  null,
  "Administrator-Zugriff aktivieren"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type to filter": [
  null,
  "Zum Filtern tippen"
 ],
 "Unit": [
  null,
  "Einheit"
 ],
 "Unit not found": [
  null,
  "Einheit nicht gefunden"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ],
 "Unpin unit": [
  null,
  ""
 ],
 "Until": [
  null,
  "Bis"
 ],
 "Updating status...": [
  null,
  "Update Status..."
 ],
 "Uptime": [
  null,
  "Betriebszeit"
 ],
 "Usage": [
  null,
  "Nutzung"
 ],
 "User": [
  null,
  "Benutzer"
 ],
 "Validating address": [
  null,
  "Validiere Adresse"
 ],
 "Vendor": [
  null,
  "Anbieter"
 ],
 "Version": [
  null,
  "Version"
 ],
 "View all logs": [
  null,
  "Alle Protokolle ansehen"
 ],
 "View all services": [
  null,
  "Alle Dienste ansehen"
 ],
 "View hardware details": [
  null,
  "Hardware-Details anzeigen"
 ],
 "View login history": [
  null,
  "Anmeldeverlauf ansehen"
 ],
 "View metrics and history": [
  null,
  "Metriken und Verlauf ansehen"
 ],
 "View report": [
  null,
  "Bericht anzeigen"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "Zum Ansehen der Speicherinformationen ist ein administrativer Zugriff erforderlich."
 ],
 "Waiting for input…": [
  null,
  "Warte auf Eingabe…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Warten, bis andere Software-Verwaltungsvorgänge abgeschlossen sind"
 ],
 "Waiting to start…": [
  null,
  "Warte auf den Start. . ."
 ],
 "Wanted by": [
  null,
  "Gesucht von"
 ],
 "Wants": [
  null,
  "Will"
 ],
 "Warning and above": [
  null,
  "Warnung und höher"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Die Webkonsole läuft mit limitierten Berechtigungen."
 ],
 "Wednesdays": [
  null,
  "Mittwochs"
 ],
 "Weekly": [
  null,
  "Wöchentlich"
 ],
 "Weeks": [
  null,
  "Wochen"
 ],
 "White": [
  null,
  "Weiß"
 ],
 "Yearly": [
  null,
  "Jährlich"
 ],
 "Yes": [
  null,
  "Ja"
 ],
 "You may try to load older entries.": [
  null,
  "Wollen sie probieren alte Einträge zu laden."
 ],
 "You now have administrative access.": [
  null,
  "Sie haben nun Administrator Zugriff."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Ihr Browser lässt das Einfügen über das Kontextmenü nicht zu. Sie können Umschalt+Einfügen verwenden."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Ihr Browser speichert Ihre Zugriffsstufe über mehrere Sitzungen hinweg."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bytes Binäredaten]"
 ],
 "[binary data]": [
  null,
  "[Binärdaten]"
 ],
 "[no data]": [
  null,
  "[keine Daten]"
 ],
 "abrt": [
  null,
  ""
 ],
 "active": [
  null,
  "Aktiv"
 ],
 "asset tag": [
  null,
  "Asset-Tag"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "Starten"
 ],
 "cgroups": [
  null,
  ""
 ],
 "command": [
  null,
  "Kommando"
 ],
 "console": [
  null,
  "Konsole"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "CPU"
 ],
 "crash": [
  null,
  "Absturz"
 ],
 "date": [
  null,
  "Datum"
 ],
 "debug": [
  null,
  "Debug"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "deaktivieren"
 ],
 "disks": [
  null,
  "Datenträger"
 ],
 "domain": [
  null,
  "Domain"
 ],
 "edit": [
  null,
  "bearbeiten"
 ],
 "enable": [
  null,
  "aktivieren"
 ],
 "error": [
  null,
  "Fehler"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "Kann SSH-Hostschlüssel nicht anzeigen: $0"
 ],
 "graphs": [
  null,
  "Kurven"
 ],
 "hardware": [
  null,
  "Hardware"
 ],
 "history": [
  null,
  "Verlauf"
 ],
 "host": [
  null,
  "host"
 ],
 "inconsistent": [
  null,
  "inkonsistent"
 ],
 "journal": [
  null,
  "Journal"
 ],
 "journalctl manpage": [
  null,
  "journalctl manpage"
 ],
 "machine": [
  null,
  "Maschine"
 ],
 "mask": [
  null,
  "Maske"
 ],
 "memory": [
  null,
  "Speicher"
 ],
 "metrics": [
  null,
  "Kennzahlen"
 ],
 "mitigation": [
  null,
  "Milderung"
 ],
 "network": [
  null,
  "Netzwerk"
 ],
 "none": [
  null,
  "kein"
 ],
 "of $0 CPU": [
  null,
  "von $0 CPU",
  "von $0 CPUs"
 ],
 "operating system": [
  null,
  "Betriebssystem"
 ],
 "os": [
  null,
  "os"
 ],
 "path": [
  null,
  "Pfad"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "Leistung"
 ],
 "power": [
  null,
  "Leistung"
 ],
 "ram": [
  null,
  "Arbeitsspeicher"
 ],
 "recommended": [
  null,
  "empfohlen"
 ],
 "restart": [
  null,
  "Neustart"
 ],
 "running $0": [
  null,
  "$0 wird ausgeführt"
 ],
 "serial": [
  null,
  "Seriell"
 ],
 "service": [
  null,
  "Dienst"
 ],
 "shell": [
  null,
  "Shell"
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ],
 "shut": [
  null,
  ""
 ],
 "socket": [
  null,
  "Socket"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "Ziel"
 ],
 "time": [
  null,
  "Zeit"
 ],
 "timer": [
  null,
  "Timer"
 ],
 "unit": [
  null,
  "Einheit"
 ],
 "unknown": [
  null,
  "unbekannt"
 ],
 "unmask": [
  null,
  "Freigeben"
 ],
 "version": [
  null,
  "Version"
 ],
 "warning": [
  null,
  "Warnung"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Einer Domäne beitreten"
 ],
 "from <host>\u0004from $0": [
  null,
  "von $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "von $0 auf $1"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "auf $0"
 ]
});
