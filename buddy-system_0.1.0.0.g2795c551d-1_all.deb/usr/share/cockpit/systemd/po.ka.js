cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 გიბ"
 ],
 "$0 critical hit": [
  null,
  "$0 კრიტიკული დარტყმა",
  "$0 დარტყმა, კრიტიკულის ჩათვლით"
 ],
 "$0 failed login attempt": [
  null,
  "შესვლის $0 წარუმატებელი მცდელობა",
  "შესვლის $0 ცალი წარუმატებელი მცდელობა"
 ],
 "$0 important hit": [
  null,
  "$0 მნიშვნელოვანი მოხვედრა",
  "$0 მოხვედრა, მნიშვნელოვნის ჩათვლით"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ხელმიუწვდომელია ყველა რეპოზიტორიიდან."
 ],
 "$0 low severity hit": [
  null,
  "$0 დაბალი სერიოზულობის მოხვედრა",
  "$0 ცალი დაბალი სერიოზულობის მოხვედრა"
 ],
 "$0 moderate hit": [
  null,
  "$0 საშუალო მოხვედრა",
  "$0 მოხვედრა, საშუალოს ჩათვლით"
 ],
 "$0 service has failed": [
  null,
  "$0 სერვისის შეცდომა",
  "$0 ცალი სერვისის შეცდომა"
 ],
 "$0 will be installed.": [
  null,
  "დაყენდება $0."
 ],
 "$0: crash at $1": [
  null,
  "$0: ავარია $1-თან"
 ],
 "1 minute": [
  null,
  "1 წთ"
 ],
 "10th": [
  null,
  "მეათე"
 ],
 "11th": [
  null,
  "მეთერთმეტე"
 ],
 "12th": [
  null,
  "მეთორმეტე"
 ],
 "13th": [
  null,
  "13-ე"
 ],
 "14th": [
  null,
  "14-ე"
 ],
 "15th": [
  null,
  "15-ე"
 ],
 "16th": [
  null,
  "16-ე"
 ],
 "17th": [
  null,
  "17-ე"
 ],
 "18th": [
  null,
  "18-ე"
 ],
 "19th": [
  null,
  "19-ე"
 ],
 "1st": [
  null,
  "პირველი"
 ],
 "20 minutes": [
  null,
  "20 წთ"
 ],
 "20th": [
  null,
  "20-ე"
 ],
 "21th": [
  null,
  "21-ე"
 ],
 "22th": [
  null,
  "22-ე"
 ],
 "23th": [
  null,
  "23-ე"
 ],
 "24th": [
  null,
  "24-ე"
 ],
 "25th": [
  null,
  "25-ე"
 ],
 "26th": [
  null,
  "26-ე"
 ],
 "27th": [
  null,
  "27-ე"
 ],
 "28th": [
  null,
  "28-ე"
 ],
 "29th": [
  null,
  "29-ე"
 ],
 "2nd": [
  null,
  "მეორე"
 ],
 "30th": [
  null,
  "30-ე"
 ],
 "31st": [
  null,
  "31-ე"
 ],
 "3rd": [
  null,
  "მესამე"
 ],
 "40 minutes": [
  null,
  "40 წთ"
 ],
 "4th": [
  null,
  "მეოთხე"
 ],
 "5 minutes": [
  null,
  "5 წთ"
 ],
 "5th": [
  null,
  "მეხუთე"
 ],
 "60 minutes": [
  null,
  "60 წთ"
 ],
 "6th": [
  null,
  "მეექვსე"
 ],
 "7th": [
  null,
  "მეშვიდე"
 ],
 "8th": [
  null,
  "მერვე"
 ],
 "9th": [
  null,
  "მეცხრე"
 ],
 "Absent": [
  null,
  "აკლია"
 ],
 "Active since ": [
  null,
  "აქტიურია "
 ],
 "Active state": [
  null,
  "აქტიური მდგომარეობა"
 ],
 "Add": [
  null,
  "დამატება"
 ],
 "Additional actions": [
  null,
  "დამატებითი ქმედებები"
 ],
 "Additional packages:": [
  null,
  "დამატებითი პაკეტები:"
 ],
 "Administrative access": [
  null,
  "ადმინისტრატიული წვდომა"
 ],
 "Advanced TCA": [
  null,
  "დამატებითი TCA"
 ],
 "After": [
  null,
  "შემდეგ"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "დომენიდან გამოსვლის შემდეგ ამ მანქანაზე შესვლა შეეძლებათ მხოლოდ ლოკალური ანგარიშების მქონე მომხმარებლებს. ასევე შეიძლება შეფერხებით იმუშაოს სხვა ისეთმა სერვისებმა, როგორიცაა მაგალითად DNS და შეიცვლება სანდო CA-ები."
 ],
 "After system boot": [
  null,
  "სისტემის ჩატვირთვის შემდეგ"
 ],
 "Alert and above": [
  null,
  "გაფრთხილება და უარესები"
 ],
 "Alias": [
  null,
  "მეტსახელი"
 ],
 "All": [
  null,
  "ყველა"
 ],
 "All-in-one": [
  null,
  "ყველა-ერთში"
 ],
 "Allow running (unmask)": [
  null,
  "გაშვების ნების დართვა (ნიღბის მოხსნა)"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "ჟურნალის შეტყობინებებში შესაძლებელია ნებისმიერი სტრიქონის გაფიტვრა. სტრიქონი ასევე შეიძლება მოიძებნოს რეგულარული გამოსახულებებითაც. ასევე არსებობს ჟურნალის ველების მიხედვით გაფილტვრის მხარდაჭერა. წარმოადგენენ ჰარეთი გაყოფილ მნისვნელობებს FIELD=VALUE ფორმაში, სადაც მნიშვნელობები შეიძლება წარმოადგენდეს მძიმით გამოყოფილ შესაძლო მნიშვნელობების სიას."
 ],
 "Appearance": [
  null,
  "გარეგნობა"
 ],
 "Apply and reboot": [
  null,
  "გადატარება და გადატვირთვა"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "ახალი წესების გადატარება... შეიძლება რამდენიმე წუთი დასჭირდეს."
 ],
 "Asset tag": [
  null,
  "აქტივის ჭდე"
 ],
 "At minute": [
  null,
  "1 წთ"
 ],
 "At specific time": [
  null,
  "მითითებულ დროს"
 ],
 "Authenticate": [
  null,
  "ავთენტიკაცია"
 ],
 "Automatically starts": [
  null,
  "ავტომატურად გაეშვება"
 ],
 "Automatically using NTP": [
  null,
  "ავტომატურად, NTP-ით"
 ],
 "Automatically using specific NTP servers": [
  null,
  "მითითებული NTP სერვერების ავტომატური გამოყენება"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS-ის თარიღი"
 ],
 "BIOS version": [
  null,
  "BIOS-ის ვერსია"
 ],
 "Bad": [
  null,
  "ცუდი"
 ],
 "Bad setting": [
  null,
  "ცუდი პარამეტრი"
 ],
 "Before": [
  null,
  "წინ"
 ],
 "Binds to": [
  null,
  "ებმება"
 ],
 "Black": [
  null,
  "შავი"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "კალათი"
 ],
 "Boot": [
  null,
  "ჩატვირთვა"
 ],
 "Bound by": [
  null,
  "მიბმულია"
 ],
 "Bus expansion chassis": [
  null,
  "მატარებლის გაფართოების შასი"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "CPU უსაფრთხოება"
 ],
 "CPU security toggles": [
  null,
  "CPU-ის უსაფრთხოების გადამრთველები"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "მიმდინარე ფილტრების კომბინაციის ჟურნალში ჩანაწერების მოძებნა შეუძლებელია."
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Cancel poweroff": [
  null,
  "გამორთვის გაუქმება"
 ],
 "Cancel reboot": [
  null,
  "გადატვირთვის გაუქმება"
 ],
 "Cannot be enabled": [
  null,
  "ვერ ჩაირთვება"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "ამ სისტემაზე realmd-ს არარსებობის გამო დომენში ჩართვა შეუძლებელია"
 ],
 "Cannot schedule event in the past": [
  null,
  "მოვლენის წარსულ დროში დანიშვნა შეუძლებელია"
 ],
 "Change": [
  null,
  "შეცვლა"
 ],
 "Change crypto policy": [
  null,
  "შიფრაციის წესების შეცვლა"
 ],
 "Change host name": [
  null,
  "ჰოსტის სახელის შეცვლა"
 ],
 "Change performance profile": [
  null,
  "წარმადობის პროფილის შეცვლა"
 ],
 "Change profile": [
  null,
  "პროფილის შეცვლა"
 ],
 "Change system time": [
  null,
  "სისტემური დროის შეცვლა"
 ],
 "Checking installed software": [
  null,
  "დაყენებული პროგრამული უზრუნველყოფის შემოწმება"
 ],
 "Class": [
  null,
  "კლასი"
 ],
 "Clear 'Failed to start'": [
  null,
  "'გაშვების შეცდომა'-ის გასუფთავება"
 ],
 "Clear all filters": [
  null,
  "ყველა ფილტრის გასუფთავება"
 ],
 "Client software": [
  null,
  "კლიენტი პროგრამა"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Command": [
  null,
  "ბრძანება"
 ],
 "Command not found": [
  null,
  "ბრძანება ნაპოვნი არაა"
 ],
 "Communication with tuned has failed": [
  null,
  "tuned-თან კავშირის შეცდომა"
 ],
 "Compact PCI": [
  null,
  "კომპაქტური PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "პირობა $0=$1 არ შესრულდა"
 ],
 "Condition failed": [
  null,
  "პირობის შეცდომა"
 ],
 "Configuration": [
  null,
  "მორგება"
 ],
 "Configuring system settings": [
  null,
  "სისტემის პარამეტრების მორგება"
 ],
 "Confirm deletion of $0": [
  null,
  "დაადასტურეთ $0-ის წაშლა"
 ],
 "Conflicted by": [
  null,
  "კონფლიქტშია"
 ],
 "Conflicts": [
  null,
  "კონფლიქტები"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "dbus-თან დაკავშირების შეცდომა: $0"
 ],
 "Consists of": [
  null,
  "შედგება"
 ],
 "Contacted domain": [
  null,
  "დომენთან კავშირი წარმატებულია"
 ],
 "Controller": [
  null,
  "კონტროლერი"
 ],
 "Convertible": [
  null,
  "გარდაქმნადი"
 ],
 "Copy": [
  null,
  "კოპირება"
 ],
 "Copy to clipboard": [
  null,
  "ბაფერში კოპირება"
 ],
 "Crash reporting": [
  null,
  "ავარიის ანგარიში"
 ],
 "Create timer": [
  null,
  "ტაიმერის შექმნა"
 ],
 "Critical and above": [
  null,
  "კრიტიკული და ზემოთ"
 ],
 "Crypto Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "შიფრაციის წესები წარმოადგენს სისტემურ კომპონენტს, რომელიც ძირითადი კრიპტოგრაფიული ქვესისტემების, TLS/IPSec/SSH/DNNSEC და kerberos-ის კონფიგურაციას უზრუნველყოფს."
 ],
 "Crypto policy": [
  null,
  "შიფრაციის წესები"
 ],
 "Crypto policy is inconsistent": [
  null,
  "შიფრაციის წესები არამდგრადია"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "მიმდინარე ჩატვირთვა"
 ],
 "Custom crypto policy": [
  null,
  "სიფრაციის წესების მორგება"
 ],
 "Daily": [
  null,
  "დღიურად"
 ],
 "Dark": [
  null,
  "ბლენი"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "თარიღის სპეციფიკაციები უნდა იყოს YYYY-MM-DD ფორმატის სთ:მთ:წ.წ. ალტერნატიულად გაგებულია სტრიქონები \"გუშინ\", \"დღეს\", \"ხვალ\". \"ახლა\" ეხება მიმდინარე დროს. და ბოლოს, შედარებითი დრო შეიძლება იყოს მითითებული, პრეფიქსით '-' ან '+'"
 ],
 "Debug and above": [
  null,
  "გამართვა და ზემოთ"
 ],
 "Decrease by one": [
  null,
  "ერთით შემცირება"
 ],
 "Delay": [
  null,
  "დაყოვნება"
 ],
 "Delay must be a number": [
  null,
  "დაყოვნება რიცხვი უნდა იყოს"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Deletion will remove the following files:": [
  null,
  "ასევე წაიშლება შემდეგი ფაილები:"
 ],
 "Description": [
  null,
  "აღწერა"
 ],
 "Desktop": [
  null,
  "სამუშაო მაგიდა"
 ],
 "Detachable": [
  null,
  "მოძრობადი"
 ],
 "Details": [
  null,
  "დეტალები"
 ],
 "Disable simultaneous multithreading": [
  null,
  "მრავალნაკადიანობის გამორთვა"
 ],
 "Disable tuned": [
  null,
  "tuned-ის გამორთვა"
 ],
 "Disabled": [
  null,
  "გათიშულია"
 ],
 "Disallow running (mask)": [
  null,
  "გაშვების აკრძალვა (შენიღბვა)"
 ],
 "Docking station": [
  null,
  "სამაგრი დაფა"
 ],
 "Does not automatically start": [
  null,
  "არ გაეშვება ავტომატურად"
 ],
 "Domain": [
  null,
  "დომენი"
 ],
 "Domain address": [
  null,
  "დომენის მისამართი"
 ],
 "Domain administrator name": [
  null,
  "დომენის ადმინისტრატორის სახელი"
 ],
 "Domain administrator password": [
  null,
  "დომენის ადმინისტრატორის პაროლი"
 ],
 "Domain could not be contacted": [
  null,
  "დომენთან კავშირის შეცდომა"
 ],
 "Domain is not supported": [
  null,
  "დომენის მხარდაჭერა არ არსებობს"
 ],
 "Don't repeat": [
  null,
  "არ გაიმეორო"
 ],
 "Downloading $0": [
  null,
  "$0-ის გადმოწერა"
 ],
 "Dual rank": [
  null,
  "ორმაგი რანგი"
 ],
 "Edit /etc/motd": [
  null,
  "/etc/motd-ის ჩასწორება"
 ],
 "Edit motd": [
  null,
  "motd ფაილის ჩასწორება"
 ],
 "Embedded PC": [
  null,
  "ჩაშენებული PC"
 ],
 "Enabled": [
  null,
  "ჩართულია"
 ],
 "Entry at $0": [
  null,
  "$0-ში ჩაწერა"
 ],
 "Error": [
  null,
  "შეცდომა"
 ],
 "Error and above": [
  null,
  "შეცდომა და ზემოთ"
 ],
 "Error message": [
  null,
  "შეცდომის შეტყობინება"
 ],
 "Expansion chassis": [
  null,
  "გაფართოების კორპუსი"
 ],
 "Extended information": [
  null,
  "გაფართოებული ინფორმაცია"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS-ი სწორად არაა ჩართული"
 ],
 "Failed to disable tuned": [
  null,
  "tuned-ის გამორთვის შეცდომა"
 ],
 "Failed to disabled tuned profile": [
  null,
  "tuned-ის პროფილის გამორთვის შეცდომა"
 ],
 "Failed to enable tuned": [
  null,
  "tuned-ის ჩართვის შეცდომა"
 ],
 "Failed to fetch logs": [
  null,
  "ჟურნალის გამოთხოვნის შეცდომა"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "/etc/motd-ში ცვლილებების შეტანის შეცდომა"
 ],
 "Failed to start": [
  null,
  "გაშვების შეცდომა"
 ],
 "Failed to switch profile": [
  null,
  "პროფილის გადართვის შეცდომა"
 ],
 "File state": [
  null,
  "ფაილის მდგომარეობა"
 ],
 "Filter by name or description": [
  null,
  "სახელით ან აღწერით გაფილტვრა"
 ],
 "Filters": [
  null,
  "ფილტრები"
 ],
 "Font size": [
  null,
  "ფონტის ზომა"
 ],
 "Forbidden from running": [
  null,
  "გაშვება აკრძალულია"
 ],
 "Frame number": [
  null,
  "სერიული ნომერი"
 ],
 "Free-form search": [
  null,
  "ძებნის თავისუფალი ფორმა"
 ],
 "Fridays": [
  null,
  "კვირაობით"
 ],
 "General": [
  null,
  "საერთო"
 ],
 "Generated": [
  null,
  "გენერირებული"
 ],
 "Go to $0": [
  null,
  "$0-ზე გადასვლა"
 ],
 "Handheld": [
  null,
  "ჯიბის"
 ],
 "Hardware information": [
  null,
  "ინფორმაცია აპარატურის შესახებ"
 ],
 "Health": [
  null,
  "ჯანმრთელობა"
 ],
 "Help": [
  null,
  "დახმარება"
 ],
 "Hierarchy ID": [
  null,
  "იერარქიის ID"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "მაღალი ურთიერთკავშირი შეტევის გაზრდილი ზედაპირის ხარჯზე."
 ],
 "Hostname": [
  null,
  "ჰოსტის სახელი"
 ],
 "Hourly": [
  null,
  "საათობრივ"
 ],
 "Hours": [
  null,
  "საათი"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "იდენტიფიკატორი"
 ],
 "Increase by one": [
  null,
  "ერთით გაზრდა"
 ],
 "Indirect": [
  null,
  "არაპირდაპირი"
 ],
 "Info and above": [
  null,
  "ინფორმაცია და ზემოთ"
 ],
 "Insights: ": [
  null,
  "Insights: "
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Install software": [
  null,
  "პროგრამების დაყენება"
 ],
 "Installing $0": [
  null,
  "$0-ის დაყენება"
 ],
 "Invalid": [
  null,
  "არასწორი"
 ],
 "Invalid date format": [
  null,
  "თარიღის არასწორი ფორმატი"
 ],
 "Invalid date format and invalid time format": [
  null,
  "თარიღისა და დროის არასწორი ფორმატი"
 ],
 "Invalid time format": [
  null,
  "დროის არასწორი ფორმატი"
 ],
 "Invalid timezone": [
  null,
  "დროის არასწორი სარტყელი"
 ],
 "IoT gateway": [
  null,
  "IoT gateway"
 ],
 "Join": [
  null,
  "შეერთება"
 ],
 "Join domain": [
  null,
  "დომენზე დაერთება"
 ],
 "Joining": [
  null,
  "შეერთება"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "დომენში შესასვლელად საჭიროა realmd-ის დაყენება"
 ],
 "Joining this domain is not supported": [
  null,
  "დომენში შესვლის მხარდაჭერა არ არსებობს"
 ],
 "Joins namespace of": [
  null,
  "ზონაში შეერთება"
 ],
 "Journal": [
  null,
  "ჟურნალი"
 ],
 "Journal entry": [
  null,
  "ჟურნალის ელემენტი"
 ],
 "Journal entry not found": [
  null,
  "ჟურნალის ერთეული ნაპოვნი არაა"
 ],
 "Laptop": [
  null,
  "ლეპტოპი"
 ],
 "Last 24 hours": [
  null,
  "ბოლო 24 საათი"
 ],
 "Last 7 days": [
  null,
  "ბოლო 7 დღე"
 ],
 "Last successful login:": [
  null,
  "ბოლო წარმატებული შესვლა:"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "Leave $0": [
  null,
  "$0-დან გასვლა"
 ],
 "Leave domain": [
  null,
  "დომენიდან გასვლა"
 ],
 "Light": [
  null,
  "ღია"
 ],
 "Limit access": [
  null,
  "წვდომის შეზღუდვა"
 ],
 "Limited access": [
  null,
  "შეზღუდული წვდომა"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "შეზღუდული წვდომა გისაზღვრავთ ადმინისტრატიულ პრივილეგიებს. ვებ კონსოლის ზოგიერთი ნაწილი შეზღუდული იქნება."
 ],
 "Limits": [
  null,
  "ლიმიტები"
 ],
 "Linked": [
  null,
  "მიბმული"
 ],
 "Listen": [
  null,
  "მოსმენა"
 ],
 "Listing unit files": [
  null,
  "სერვისის ფაილების სია"
 ],
 "Listing unit files failed: $0": [
  null,
  "მწყობრიდან გამოსული სერვისების სია: $0"
 ],
 "Listing units": [
  null,
  "სერვისების სია"
 ],
 "Listing units failed: $0": [
  null,
  "სერვისების სიის გამოტანის შეცდომა: $0"
 ],
 "Load earlier entries": [
  null,
  "ადრინდელი ელემენტების ჩატვირთვა"
 ],
 "Loading earlier entries": [
  null,
  "ადრინდელი ელემენტების ჩატვირთვა"
 ],
 "Loading keys...": [
  null,
  "გასაღებების ჩატვირთვა..."
 ],
 "Loading of SSH keys failed": [
  null,
  "SSH გასაღებების ჩატვირთვის შეცდომა"
 ],
 "Loading of units failed": [
  null,
  "სერვისების ჩატვირთვის შეცდომა"
 ],
 "Loading unit failed: $0": [
  null,
  "სერვისების ჩატვირთვის შეცდომა: $0"
 ],
 "Loading...": [
  null,
  "ჩატვირთვა..."
 ],
 "Log messages": [
  null,
  "ჟურნალის შეტყობინებები"
 ],
 "Login format": [
  null,
  "შესვლის ფორმატი"
 ],
 "Logs": [
  null,
  "ჟურნალი"
 ],
 "Low profile desktop": [
  null,
  "დაბალი პროფილის სამუშაო მაგიდა"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Machine ID": [
  null,
  "მანქანის ID"
 ],
 "Machine SSH key fingerprints": [
  null,
  "მანქანის SSH გასაღების ანაბეჭდები"
 ],
 "Main server chassis": [
  null,
  "სერვერის მთავარი შასი"
 ],
 "Maintenance": [
  null,
  "სარემონტო"
 ],
 "Managing services": [
  null,
  "სერვისების მართვა"
 ],
 "Manually": [
  null,
  "ხელით მითითებული"
 ],
 "Mask service": [
  null,
  "სერვისის დამალვა"
 ],
 "Masked": [
  null,
  "შენიღბული"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "სერვისის შენიღბვა კრძალავს მასზე დამოკიდებული ყველა სერვისის გაშვებას. ამას იმაზე მეტი ეფექტი შეიძლება ჰქონეს, ვიდრე თქვენ გგონიათ. გთხოვთ დაადასტუროთ, რომ გნებავთ ამის გაკეთება."
 ],
 "Memory": [
  null,
  "მეხსიერება"
 ],
 "Memory technology": [
  null,
  "მეხსიერების ტექნოლოგია"
 ],
 "Merged": [
  null,
  "შერწყმული"
 ],
 "Message to logged in users": [
  null,
  "შესული მომხმარებლებისთვის შეტყობინების გაგზავნა"
 ],
 "Method": [
  null,
  "მეთოდი"
 ],
 "Mini PC": [
  null,
  "მინი PC"
 ],
 "Mini tower": [
  null,
  "კომპიუტერი პატარა ყუთით"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "წუთი უნდა იყოს რიცხვი შუალედში 0-59"
 ],
 "Minutes": [
  null,
  "წუთი"
 ],
 "Mitigations": [
  null,
  "დაცვის გეგმები"
 ],
 "Model": [
  null,
  "მოდელი"
 ],
 "Mondays": [
  null,
  "ორშაბათობით"
 ],
 "Monthly": [
  null,
  "თვეში ერთხელ"
 ],
 "Multi-system chassis": [
  null,
  "მრავალსისტემიანი ყუთი"
 ],
 "NTP server": [
  null,
  "NTP სერვერი"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Need at least one NTP server": [
  null,
  "საჭიროა ერთი NTP სერვერი მაინც"
 ],
 "No": [
  null,
  "არა"
 ],
 "No delay": [
  null,
  "დაყოვნების გარეშე"
 ],
 "No host keys found.": [
  null,
  "ჰოსტის გასაღებები ნაპოვნი არაა."
 ],
 "No log entries": [
  null,
  "ჟურნალის ცარიელია"
 ],
 "No logs found": [
  null,
  "ჟურნალი ცარიელია"
 ],
 "No matching results": [
  null,
  "პასუხები არაა"
 ],
 "No results found": [
  null,
  "შედეგები ნაპოვნი არაა"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "თქვენს ფილტრს შედეგები არ აქვს. შედეგების საჩვენებლად გაასუფთავეთ ფილტრები."
 ],
 "No rule hits": [
  null,
  "არ მოხვდა წესებში"
 ],
 "None": [
  null,
  "არცერთი"
 ],
 "Not connected to Insights": [
  null,
  "არაა მიერთებული Insights-თან"
 ],
 "Not found": [
  null,
  "ნაპოვნი არაა"
 ],
 "Not permitted to configure realms": [
  null,
  "realm-ების მორგების წვდომა აკრძალულია"
 ],
 "Not running": [
  null,
  "გაშვებული არაა"
 ],
 "Not synchronized": [
  null,
  "სინქრონიზებული არაა"
 ],
 "Note": [
  null,
  "არცერთი"
 ],
 "Notebook": [
  null,
  "ნოუთბუქი"
 ],
 "Notice and above": [
  null,
  "გაფრთხილება და ზემოთ"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "On failure": [
  null,
  "შეცდომის შემთხვევაში"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "დაშვებულია მხოლოდ ლათინური ანბანი, ციფრები, :, _ და @"
 ],
 "Only emergency": [
  null,
  "მხოლოდ გადაუდებელ შემთხვევაში"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "FIPS რეჟიმში ჩატვირთვისას მხოლოდ დადასტურებული ალგორითმების გამოყენება."
 ],
 "Other": [
  null,
  "სხვა"
 ],
 "Overview": [
  null,
  "გადახედვა"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit-ის ავარია"
 ],
 "Part of": [
  null,
  "წარმოადგენს ნაწილს"
 ],
 "Password": [
  null,
  "პაროლი"
 ],
 "Paste": [
  null,
  "ჩასმა"
 ],
 "Paste error": [
  null,
  "ჩასმის შეცდომა"
 ],
 "Path": [
  null,
  "ბილიკი"
 ],
 "Paths": [
  null,
  "ბილიკი"
 ],
 "Pause": [
  null,
  "პაუზა"
 ],
 "Performance profile": [
  null,
  "წარმადობის პროფილი"
 ],
 "Peripheral chassis": [
  null,
  "გარე კორპუსი"
 ],
 "Pick date": [
  null,
  "აირჩიეთ თარიღი"
 ],
 "Pin unit": [
  null,
  "მიჭიკარტება"
 ],
 "Pinned unit": [
  null,
  "მიჭიკარტებული"
 ],
 "Pizza box": [
  null,
  "პიცისყუთი"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "ადმინისტრატორი წვდომის მისაღებად გთხოვთ გაიაროთ ავთენტიკაცია"
 ],
 "Portable": [
  null,
  "გადატანადი"
 ],
 "Present": [
  null,
  "წარმოდგენილია"
 ],
 "Pretty host name": [
  null,
  "ჰოსტის ლამაზი სახელი"
 ],
 "Previous boot": [
  null,
  "წინა ჩატვირთვა"
 ],
 "Priority": [
  null,
  "პრიორიტეტი"
 ],
 "Problem becoming administrator": [
  null,
  "ადმინისტრატორად გახდომის შეცდომა"
 ],
 "Problem details": [
  null,
  "პრობლემის დეტალები"
 ],
 "Problem info": [
  null,
  "ინფორმაცია პრობლემის შესახებ"
 ],
 "Propagates reload to": [
  null,
  "გადატვირთვა გავრცელდება"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "იცავს მოსალოდნელი უახლოესი მომავალი თავდასხმებისგან თავსებადობის ხარჯზე."
 ],
 "RAID chassis": [
  null,
  "RAID კალათი"
 ],
 "Rack mount chassis": [
  null,
  "რეკში ჩასადგმელი შასი"
 ],
 "Rank": [
  null,
  "რანგი"
 ],
 "Read more...": [
  null,
  "მეტის წაკითხვა..."
 ],
 "Read-only": [
  null,
  "მხოლოდ წასაკითხად"
 ],
 "Real host name": [
  null,
  "ჰოსტის რეალური სახელი"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "ჰოსტის რეალური სახელი შეიძლება მხოლოდ შეიცავდეს პატარა სიმბოლოებს, ციფრებს, ტირეებს და ჰარეებს"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "ჯოსტის რეალური სახელი 64 სიმბოლოზე დიდი არ უნდა იყოს"
 ],
 "Reapply and reboot": [
  null,
  "თავიდან გადატარება და გადატვირთვა"
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "რეკომენდებული, დაცული პარამეტრები მიმდინარე დაცვის მოდელისთვის."
 ],
 "Reload": [
  null,
  "თავიდან ჩატვირთვა"
 ],
 "Reload propagated from": [
  null,
  "გადატვირთვის წყარო"
 ],
 "Reloading": [
  null,
  "თავიდან ჩატვირთვა"
 ],
 "Removals:": [
  null,
  "წაიშლება:"
 ],
 "Remove": [
  null,
  "წაშლა"
 ],
 "Removing $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Repeat": [
  null,
  "გამეორება"
 ],
 "Repeat monthly": [
  null,
  "თვეში ერთხელ გამეორება"
 ],
 "Repeat weekly": [
  null,
  "კვირაში ერთხელ გამეორება"
 ],
 "Report": [
  null,
  "ანგარიში"
 ],
 "Report to ABRT Analytics": [
  null,
  "ABRT ანალიტიკისთვის გადაცემა"
 ],
 "Reported; no links available": [
  null,
  "ანგარიში გაგზავნილია; ბმულები მიუწვდომელია"
 ],
 "Reporting failed": [
  null,
  "ანგარიშის გადაგზავნის შეცდომა"
 ],
 "Reporting was canceled": [
  null,
  "ანგარიში გაუქმდა"
 ],
 "Reports:": [
  null,
  "ანგარიშები:"
 ],
 "Required by": [
  null,
  "სჭირდება"
 ],
 "Required by ": [
  null,
  "სჭირდება "
 ],
 "Requires": [
  null,
  "სჭირდება"
 ],
 "Requires administration access to edit": [
  null,
  "ჩასასწორებლად საჭიროა ადმინისტრატორის წვდომა"
 ],
 "Requisite": [
  null,
  "მოთხოვნა"
 ],
 "Requisite of": [
  null,
  "ვის საჭიროებასა წარმოადგენს"
 ],
 "Reset": [
  null,
  "საწყის მნიშვნელობებზე დაბრუნება"
 ],
 "Restart": [
  null,
  "გადატვირთვა"
 ],
 "Resume": [
  null,
  "გაგრძელება"
 ],
 "Review crypto policy": [
  null,
  "შიფრაციის წესების გადახედვა"
 ],
 "Reviewing logs": [
  null,
  "ჟურნალის გადახედვა"
 ],
 "Run at": [
  null,
  "გაშვების დრო"
 ],
 "Run on": [
  null,
  "გასაშვები პლატფორმა"
 ],
 "Running": [
  null,
  "გაშვებული"
 ],
 "Saturdays": [
  null,
  "შაბათობით"
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "Save and reboot": [
  null,
  "შენახვა და გადატვირთვა"
 ],
 "Save changes": [
  null,
  "ცვლილებების შენახვა"
 ],
 "Scheduled poweroff at $0": [
  null,
  "გათიშვის დროა $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "გადატვირთვის დროა $0"
 ],
 "Sealed-case PC": [
  null,
  "დალუქული PC"
 ],
 "Search": [
  null,
  "ძებნა"
 ],
 "Seconds": [
  null,
  "წამი"
 ],
 "Secure shell keys": [
  null,
  "SSH-ის გასაღებები"
 ],
 "Select a identifier": [
  null,
  "აირჩიეთ იდენტიფიკატორი"
 ],
 "Send": [
  null,
  "გაგზავნა"
 ],
 "Server software": [
  null,
  "სერვერული პროგრამები"
 ],
 "Service logs": [
  null,
  "სერვერის ჟურნალი"
 ],
 "Services": [
  null,
  "სერვისები"
 ],
 "Set hostname": [
  null,
  "ჰოსტის სახელის დაყენება"
 ],
 "Set time": [
  null,
  "დროის დაყენება"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "ყველა ნაკადის ჩვენება"
 ],
 "Show fingerprints": [
  null,
  "ანაბეჭდების ჩვენება"
 ],
 "Show messages containing given string.": [
  null,
  "იმ შეტყობინებების ჩვენება, რომლებიც მითითებულ სტრიქონს შეიცავენ."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "system-ის მითითებული სერვისის შეტყობინებების ჩვენება."
 ],
 "Show messages from a specific boot.": [
  null,
  "შეტყობინებების მითითებული ჩატვირთვიდან ჩვენება."
 ],
 "Show more relationships": [
  null,
  "მეტი ნათესაობის ჩვენება"
 ],
 "Show relationships": [
  null,
  "ურთიერთობების ჩვენება"
 ],
 "Shut down": [
  null,
  "გამორთვა"
 ],
 "Shutdown": [
  null,
  "გამორთვა"
 ],
 "Since": [
  null,
  "საწყისი დრო"
 ],
 "Single rank": [
  null,
  "ერთრანგიანი"
 ],
 "Size": [
  null,
  "ზომა"
 ],
 "Slot": [
  null,
  "სლოტი"
 ],
 "Sockets": [
  null,
  "სოკეტები"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "პროცესორის შეცდომების პროგრამულ გასწორებას შეუძლია თავიდან აგარიდოთ მასთან დაკავშირებული პრობლემები. მაგრამ ამ პაჩებს აქვთ გვერდითი ეფექტი - ისინი აგდებენ წარმადობას. ამ პარამეტრის ცვლილების შედეგებზე პასუხს თქვენ აგებთ."
 ],
 "Space-saving computer": [
  null,
  "პატარა ზომის კომპიუტერი"
 ],
 "Specific time": [
  null,
  "მითითებული დრო"
 ],
 "Speed": [
  null,
  "სიჩქარე"
 ],
 "Start": [
  null,
  "დაწყება"
 ],
 "Start and enable": [
  null,
  "ჩართვა და გაშვება"
 ],
 "Start service": [
  null,
  "სერვისის გაშვება"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "მხოლოდ მითითებული თარიღის შემდეგი შეტყობინებების ჩვენება."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "მხოლოდ მითითებულ თარიღზე ძველი შეტყობინებების ჩვენება."
 ],
 "State": [
  null,
  "მდგომარეობა"
 ],
 "Static": [
  null,
  "სტატიკური"
 ],
 "Status": [
  null,
  "მდგომარეობა"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "გაჩერება"
 ],
 "Stop and disable": [
  null,
  "გაჩერება და გამორთვა"
 ],
 "Stub": [
  null,
  "Stub"
 ],
 "Sub-Chassis": [
  null,
  "ქვე-კორპუსი"
 ],
 "Sub-Notebook": [
  null,
  "ქვე-ნოუთბუქი"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "systemd-ის სიგნალების გამოწერის შეცდომა: $0"
 ],
 "Successfully copied to keyboard": [
  null,
  "წარმატებით დაკოპირდა ბუფერში"
 ],
 "Sundays": [
  null,
  "კვირაობით"
 ],
 "Switch to administrative access": [
  null,
  "ადმინისტრატორის წვდომაზე გადართვა"
 ],
 "Switch to limited access": [
  null,
  "შეზღუდულ წვდომებზე გადართვა"
 ],
 "Synchronized": [
  null,
  "სინქრონიზებულია"
 ],
 "Synchronized with $0": [
  null,
  "სინქრონიზებულია $0-თან"
 ],
 "Synchronizing": [
  null,
  "სინქრონიზაცია"
 ],
 "System": [
  null,
  "სისტემა"
 ],
 "System information": [
  null,
  "ინფორმაცია სისტემის შესახებ"
 ],
 "System time": [
  null,
  "სისტემური დრო"
 ],
 "Systemd units": [
  null,
  "Systemd unit-ები"
 ],
 "Tablet": [
  null,
  "ტაბლეტი"
 ],
 "Targets": [
  null,
  "სამიზნეები"
 ],
 "Terminal": [
  null,
  "ტერმინალი"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "მომხმარებელს '$0' არ აქვს უფლება შეცვალოს პროცესორის უსაფრთხოების პროგრამული გადაწყვეტილების პარამეტრები"
 ],
 "The user $0 is not permitted to change crypto policies": [
  null,
  "მომხმარებელს '$0' შიფრაციის წესების შეცვლის უფლება არ აქვს"
 ],
 "This field cannot be empty": [
  null,
  "ველი არ შეიძლება ცარიელი იყოს"
 ],
 "This may take a while": [
  null,
  "საკმაო დრო დასჭირდება"
 ],
 "This system is using a custom profile": [
  null,
  "ეს სისტემა მორგებულ პროფილს იყენებს"
 ],
 "This system is using the recommended profile": [
  null,
  "ეს სისტემა რეკომენდებულ პროფილს იყენებს"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "ერთეული პირდაპირი ჩართვისთვის განკუთვნილი არაა."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "დაამატებს თანხვედრას '_BOOT_IID='-თვის. თუ მითითებული არაა, გამოყენებყლი იქნება მიმდინარე ჩატვრთვა. თუ ჩატვირთვის ID გამოტოვებულია, გამოყენებული იქნება დადებითი წანაცვლება ჟურნალის დასაწყისიდან და გამოტანილი იქნება პირველი რამდენიმე ჩანაწერი. ამიტომ, 1 ნიშნავს პირველ ჩატვირთვას, 2 მეორეს და ა.შ. მაგრამ -0 ბოლო ჩატვირთვაა, -1 ბოლოს წინა და ა.შ."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "დაამატებს თანხვედრას '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' და 'UNIT='-თან მითითებული ერთეულის ჟურნალის შეტყობინებებში საძებნად. შეიძლება შეიცავდეს მეტ ერთეულსაც, გამოყოფილს მძიმეებით. "
 ],
 "Thursdays": [
  null,
  "ხუთშაბათობით"
 ],
 "Time": [
  null,
  "დრო"
 ],
 "Time zone": [
  null,
  "დროის სარტყელი"
 ],
 "Timer creation failed": [
  null,
  "ტაიმერის შექმნის შეცდომა"
 ],
 "Timer deletion failed": [
  null,
  "ტაიმერის წაშლის შეცდომა"
 ],
 "Timers": [
  null,
  "ტაიმერები"
 ],
 "Toggle date picker": [
  null,
  "თარიღის ამრჩევის გადართვა"
 ],
 "Toggle filters": [
  null,
  "ფილტრების ჩართ/გამორთ"
 ],
 "Total size: $0": [
  null,
  "ჯამური ზომა: $0"
 ],
 "Tower": [
  null,
  "კომპიუტერის კორპუსი"
 ],
 "Transient": [
  null,
  "შუალედური"
 ],
 "Trigger": [
  null,
  "ტრიგერი"
 ],
 "Triggered by": [
  null,
  "დამტრიგერებელი"
 ],
 "Triggers": [
  null,
  "ტრიგერები"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0-თან სინქრონიზაციის მცდელობა"
 ],
 "Tuesdays": [
  null,
  "სამშაბათობით"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned-ის გაშვების შეცდომა"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned წარმოადგენს სერვისს, რომელიც უთვალთვალებს თქვენს სისტემას და აოპტიმიზირებს მას ზოგიერთიდატვირთვისთვის. Tuned-ის ბირთვის წარმოადგენს მისი პროფილები, რომლებიც სისტემას სხვადასხვა დატვირთვას ავტომატურად მოარგებს."
 ],
 "Tuned is not available": [
  null,
  "Tuned-ი ხელმიუწვდომელია"
 ],
 "Tuned is not running": [
  null,
  "Tuned-ი გაშვებული არაა"
 ],
 "Tuned is off": [
  null,
  "Tuned გამორთულია"
 ],
 "Turn on administrative access": [
  null,
  "ადმინისტრატორის წვდომების ჩართვა"
 ],
 "Type": [
  null,
  "ტიპი"
 ],
 "Type to filter": [
  null,
  "გასაფილტრად აკრიფეთ"
 ],
 "Unit": [
  null,
  "მოწყობილობა"
 ],
 "Unit not found": [
  null,
  "ვერ ვიპოვე"
 ],
 "Unknown": [
  null,
  "უცნობი"
 ],
 "Unpin unit": [
  null,
  "განჭიკარტება"
 ],
 "Until": [
  null,
  "დასასრულის დრო"
 ],
 "Updating status...": [
  null,
  "სტატუსის განახლება..."
 ],
 "Uptime": [
  null,
  "ჩართულია"
 ],
 "Usage": [
  null,
  "გამოყენება"
 ],
 "User": [
  null,
  "მომხმარებელი"
 ],
 "Validating address": [
  null,
  "მისამართის დადასტურება"
 ],
 "Vendor": [
  null,
  "მომწოდებელი"
 ],
 "Version": [
  null,
  "ვერსია"
 ],
 "View all logs": [
  null,
  "ყველა ჟურნალის ნახვა"
 ],
 "View all services": [
  null,
  "ყველა სერვისის ნახვა"
 ],
 "View hardware details": [
  null,
  "აპარატურის დეტალების ნახვა"
 ],
 "View login history": [
  null,
  "შესვლების ისტორიის ნახვა"
 ],
 "View metrics and history": [
  null,
  "გრაფიკებისა და ისტორიის ნახვა"
 ],
 "View report": [
  null,
  "ანგარიშის ნახვა"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "მეხსიერების ინფორმაციის ნახვას ადმინისტრირების წვდომა სჭირდება."
 ],
 "Waiting for input…": [
  null,
  "შეყვანის მოლოდინი…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "პროგრამების მართვის სხვა ოპერაციების დასრულების მოლოდინი"
 ],
 "Waiting to start…": [
  null,
  "გაშვების მოლოდინი…"
 ],
 "Wanted by": [
  null,
  "სჭირდება"
 ],
 "Wants": [
  null,
  "უნდა"
 ],
 "Warning and above": [
  null,
  "წინასწარი გაფრთხილებები და ზემოთ"
 ],
 "Web console is running in limited access mode.": [
  null,
  "ვებ კონსოლი გაშვებულია შეზღუდული წვდომის რეჟიმში."
 ],
 "Wednesdays": [
  null,
  "ოთხშაბათობით"
 ],
 "Weekly": [
  null,
  "კვირაში ერთხელ"
 ],
 "Weeks": [
  null,
  "კვირა"
 ],
 "White": [
  null,
  "თეთრი"
 ],
 "Yearly": [
  null,
  "წლიურად"
 ],
 "Yes": [
  null,
  "დიახ"
 ],
 "You may try to load older entries.": [
  null,
  "სცადეთ ჩატვირთოთ ძველი ელემენტები."
 ],
 "You now have administrative access.": [
  null,
  "ახლა გაქვთ ადმინისტრატორის წვდომა."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "თქვენს ბრაუზერს არ გააჩნია კონტექსტური მენიუდან ჩასმის მხარდაჭერა. სცადეთ დააჭიროთ Shift+Insert-ს."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "თქვენი ბრაუზერი თქვენი წვდომის დონეებს სესიებს შორისაც დაიმახსოვრებს."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[ბინარული მონაცემების $0 ბაიტი]"
 ],
 "[binary data]": [
  null,
  "[ბინარული მონაცემები]"
 ],
 "[no data]": [
  null,
  "[მონაცემების გარეშე]"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "active": [
  null,
  "აქტიური"
 ],
 "asset tag": [
  null,
  "აქტივის ჭდე"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "ჩატვირთვა"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "ბრძანება"
 ],
 "console": [
  null,
  "კონსოლი"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "პროცესორი"
 ],
 "crash": [
  null,
  "ავარია"
 ],
 "date": [
  null,
  "თარიღი"
 ],
 "debug": [
  null,
  "შეცდომების მოძებნა"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "გამორთვა"
 ],
 "disks": [
  null,
  "დისკები"
 ],
 "domain": [
  null,
  "დომენი"
 ],
 "edit": [
  null,
  "ჩასწორება"
 ],
 "enable": [
  null,
  "ჩართვა"
 ],
 "error": [
  null,
  "შეცდომა"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "ssh-ის ჰოსტის გასაღებების სიის გამოტანის შეცდომა: $0"
 ],
 "graphs": [
  null,
  "გრაფიკები"
 ],
 "hardware": [
  null,
  "აპარატურა"
 ],
 "history": [
  null,
  "ისტორია"
 ],
 "host": [
  null,
  "ჰოსტი"
 ],
 "inconsistent": [
  null,
  "არამდგრადი"
 ],
 "journal": [
  null,
  "ჟურნალი"
 ],
 "journalctl manpage": [
  null,
  "journalctl-ის მინი-დოკუმენტაცია"
 ],
 "machine": [
  null,
  "მანქანა"
 ],
 "mask": [
  null,
  "ნიღაბი"
 ],
 "memory": [
  null,
  "მეხსიერება"
 ],
 "metrics": [
  null,
  "მეტრიკები"
 ],
 "mitigation": [
  null,
  "შემოვლა"
 ],
 "network": [
  null,
  "ქსელი"
 ],
 "none": [
  null,
  "არცერთი"
 ],
 "of $0 CPU": [
  null,
  "$0 CPU-დან",
  "$0 ცალი CPU-დან"
 ],
 "operating system": [
  null,
  "ოპერაციული სისტემა"
 ],
 "os": [
  null,
  "ოპერაციული სისტემა"
 ],
 "path": [
  null,
  "ბილიკი"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "წარმადობა"
 ],
 "power": [
  null,
  "კვება"
 ],
 "ram": [
  null,
  "ram"
 ],
 "recommended": [
  null,
  "რეკომენდებულია"
 ],
 "restart": [
  null,
  "რესტარტი"
 ],
 "running $0": [
  null,
  "$0-ის გაშვება"
 ],
 "serial": [
  null,
  "მიმდევრობითი"
 ],
 "service": [
  null,
  "სერვისი"
 ],
 "shell": [
  null,
  "გარსი"
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ],
 "shut": [
  null,
  "გათიშვა"
 ],
 "socket": [
  null,
  "სოკეტი"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "მიზანი"
 ],
 "time": [
  null,
  "დრო"
 ],
 "timer": [
  null,
  "ტაიმერი"
 ],
 "unit": [
  null,
  "მოდული"
 ],
 "unknown": [
  null,
  "უცნობი"
 ],
 "unmask": [
  null,
  "unmask"
 ],
 "version": [
  null,
  "ვერსია"
 ],
 "warning": [
  null,
  "გაფრთხილება"
 ],
 "dialog-title\u0004Domain": [
  null,
  "დომენი"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "დომენში შესვლა"
 ],
 "from <host>\u0004from $0": [
  null,
  "$0-დან"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "$0დან $1-ზე"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "$0-ზე"
 ]
});
