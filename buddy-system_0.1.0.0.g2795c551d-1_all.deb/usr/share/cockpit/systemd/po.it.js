cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 risultato critico",
  "$0 risultati, inclusi critici"
 ],
 "$0 failed login attempt": [
  null,
  "$0 tentativo di accesso fallito",
  "$0 tentativi di accesso falliti"
 ],
 "$0 important hit": [
  null,
  "$0 risultato importante",
  "$0 risultati, inclusi importanti"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 non è disponibile in nessun archivio web."
 ],
 "$0 low severity hit": [
  null,
  "$0 risultato di bassa severità",
  "$0 risultati, inclusi bassa gravità"
 ],
 "$0 moderate hit": [
  null,
  "$0 risultato moderato",
  "$0 risultati, inclusi moderati"
 ],
 "$0 service has failed": [
  null,
  "$0 servizio ha fallito",
  "$0 servizi hanno fallito"
 ],
 "$0 will be installed.": [
  null,
  "$0 sarà installato."
 ],
 "$0: crash at $1": [
  null,
  "$0: crash a $1"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "10th": [
  null,
  "10°"
 ],
 "11th": [
  null,
  "11°"
 ],
 "12th": [
  null,
  "12°"
 ],
 "13th": [
  null,
  "13°"
 ],
 "14th": [
  null,
  "14°"
 ],
 "15th": [
  null,
  "15°"
 ],
 "16th": [
  null,
  "16°"
 ],
 "17th": [
  null,
  "17°"
 ],
 "18th": [
  null,
  "18°"
 ],
 "19th": [
  null,
  "19°"
 ],
 "1st": [
  null,
  "1°"
 ],
 "20 minutes": [
  null,
  "20 minuti"
 ],
 "20th": [
  null,
  "20°"
 ],
 "21th": [
  null,
  "21esimo"
 ],
 "22th": [
  null,
  "22esimo"
 ],
 "23th": [
  null,
  "23esimo"
 ],
 "24th": [
  null,
  "24°"
 ],
 "25th": [
  null,
  "25°"
 ],
 "26th": [
  null,
  "26°"
 ],
 "27th": [
  null,
  "27°"
 ],
 "28th": [
  null,
  "28°"
 ],
 "29th": [
  null,
  "29°"
 ],
 "2nd": [
  null,
  "2°"
 ],
 "30th": [
  null,
  "30°"
 ],
 "31st": [
  null,
  "31°"
 ],
 "3rd": [
  null,
  "3°"
 ],
 "40 minutes": [
  null,
  "40 minuti"
 ],
 "4th": [
  null,
  "4°"
 ],
 "5 minutes": [
  null,
  "5 minuti"
 ],
 "5th": [
  null,
  "5°"
 ],
 "60 minutes": [
  null,
  "60 minuti"
 ],
 "6th": [
  null,
  "6°"
 ],
 "7th": [
  null,
  "7°"
 ],
 "8th": [
  null,
  "8°"
 ],
 "9th": [
  null,
  "9°"
 ],
 "Absent": [
  null,
  "Assente"
 ],
 "Active since ": [
  null,
  "Attivo dal "
 ],
 "Active state": [
  null,
  "Stato attivo"
 ],
 "Add": [
  null,
  "Aggiungi"
 ],
 "Additional actions": [
  null,
  "Azioni aggiuntive"
 ],
 "Additional packages:": [
  null,
  "Pacchetti aggiuntivi:"
 ],
 "Administrative access": [
  null,
  "Accesso amministrativo"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzato"
 ],
 "After": [
  null,
  "Dopo"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "Dopo aver lasciato il dominio, solo gli utenti con credenziali locali potranno accedere a questa macchina. Ciò può influire anche su altri servizi poiché le impostazioni della risoluzione DNS e l'elenco delle CA affidabili potrebbero cambiare."
 ],
 "After system boot": [
  null,
  "Dopo l'avvio del sistema"
 ],
 "Alert and above": [
  null,
  "Allarme e oltre"
 ],
 "Alias": [
  null,
  "Alias"
 ],
 "All": [
  null,
  "Tutti"
 ],
 "All-in-one": [
  null,
  "Tutto in una volta"
 ],
 "Allow running (unmask)": [
  null,
  "Consenti esecuzione (unmask)"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "Qualsiasi stringa di testo nei messaggi di registro può essere filtrata. La stringa può anche essere sotto forma di un'espressione regolare. Supporta anche il filtraggio in base ai campi del registro dei messaggi. Questi sono valori separati da spazi, nella forma CAMPO=VALORE, dove il valore può essere un elenco di valori possibili separati da virgole."
 ],
 "Appearance": [
  null,
  "Aspetto"
 ],
 "Apply and reboot": [
  null,
  "Applica e riavvia"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "Applicazione di una nuova politica... L'operazione potrebbe richiedere alcuni minuti."
 ],
 "Asset tag": [
  null,
  "Tag asset"
 ],
 "At minute": [
  null,
  "Al minuto"
 ],
 "At specific time": [
  null,
  "In un momento specifico"
 ],
 "Authenticate": [
  null,
  "Autenticare"
 ],
 "Automatically starts": [
  null,
  "Si avvia automaticamente"
 ],
 "Automatically using NTP": [
  null,
  "Automaticamente utilizzando NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticamente utilizzando server NTP specifici"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "Data del BIOS"
 ],
 "BIOS version": [
  null,
  "Versione del BIOS"
 ],
 "Bad": [
  null,
  "Male"
 ],
 "Bad setting": [
  null,
  "Impostazione errata"
 ],
 "Before": [
  null,
  "Prima"
 ],
 "Binds to": [
  null,
  "Si lega a"
 ],
 "Black": [
  null,
  "Nero"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chassis del blade"
 ],
 "Boot": [
  null,
  "Boot"
 ],
 "Bound by": [
  null,
  "Legato da"
 ],
 "Bus expansion chassis": [
  null,
  "Bus di espansione chassis"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "Sicurezza CPU"
 ],
 "CPU security toggles": [
  null,
  "Impostazioni di Sicurezza della CPU"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "Non è possibile trovare alcun log utilizzando l'attuale combinazione di filtri."
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Cancel poweroff": [
  null,
  "Annulla spegnimento"
 ],
 "Cancel reboot": [
  null,
  "Annulla il riavvio"
 ],
 "Cannot be enabled": [
  null,
  "Non può essere abilitato"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "Impossibile accedere a un dominio perché realmd non è disponibile su questo sistema"
 ],
 "Cannot schedule event in the past": [
  null,
  "Non è possibile programmare eventi del passato"
 ],
 "Change": [
  null,
  "Cambia"
 ],
 "Change crypto policy": [
  null,
  "Cambia la politica di crittografia"
 ],
 "Change host name": [
  null,
  "Cambia nome host"
 ],
 "Change performance profile": [
  null,
  "Modifica del profilo performance"
 ],
 "Change profile": [
  null,
  "Cambia profilo"
 ],
 "Change system time": [
  null,
  "Modifica dell'ora di sistema"
 ],
 "Checking installed software": [
  null,
  "Verifica del software installato"
 ],
 "Class": [
  null,
  "Classe"
 ],
 "Clear 'Failed to start'": [
  null,
  "Cancella 'Impossibile avviare'"
 ],
 "Clear all filters": [
  null,
  "Cancella tutti i filtri"
 ],
 "Client software": [
  null,
  "Software Client"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Command not found": [
  null,
  "Comando non trovato"
 ],
 "Communication with tuned has failed": [
  null,
  "Comunicazione con tuned non riuscita"
 ],
 "Compact PCI": [
  null,
  "PCI compatto"
 ],
 "Condition $0=$1 was not met": [
  null,
  "Condizione $0=$1 non soddisfatta"
 ],
 "Condition failed": [
  null,
  "Condizione non riuscita"
 ],
 "Configuration": [
  null,
  "Configurazione"
 ],
 "Configuring system settings": [
  null,
  "Configurazione delle impostazioni di sistema"
 ],
 "Confirm deletion of $0": [
  null,
  "Conferma la cancellazione di $0"
 ],
 "Conflicted by": [
  null,
  "Conflitto da"
 ],
 "Conflicts": [
  null,
  "Conflitti"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "Connessione a dbus non riuscita: $0"
 ],
 "Consists of": [
  null,
  "Consiste di"
 ],
 "Contacted domain": [
  null,
  "Dominio contattato"
 ],
 "Controller": [
  null,
  "Controllo"
 ],
 "Convertible": [
  null,
  "Convertibile"
 ],
 "Copy": [
  null,
  "Copia"
 ],
 "Copy to clipboard": [
  null,
  "Copia negli appunti"
 ],
 "Crash reporting": [
  null,
  "Segnalazione di arresti anomali"
 ],
 "Create timer": [
  null,
  "Creare timer"
 ],
 "Critical and above": [
  null,
  "Critico e superiore"
 ],
 "Crypto Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "Crypto Policies è un componente di sistema che configura i sottosistemi crittografici di base, coprendo i protocolli TLS, IPSec, SSH, DNSSec e Kerberos."
 ],
 "Crypto policy": [
  null,
  "Politica di crittografia"
 ],
 "Crypto policy is inconsistent": [
  null,
  "La politica delle crittografia è incoerente"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "Boot corrente"
 ],
 "Custom crypto policy": [
  null,
  "Politica di crittografia personalizzata"
 ],
 "Daily": [
  null,
  "Giornaliero"
 ],
 "Dark": [
  null,
  "Scuro"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "Le specifiche della data devono essere nel formato AAAA-MM-GG hh:mm:ss. In alternativa si intendono le stringhe 'yesterday', 'today', 'tomorrow'. 'now' si riferisce all'ora corrente. Infine, possono essere specificati tempi relativi, preceduti da '-' o '+'"
 ],
 "Debug and above": [
  null,
  "Debug e superiore"
 ],
 "Decrease by one": [
  null,
  "Diminuisci di uno"
 ],
 "Delay": [
  null,
  "Ritardo"
 ],
 "Delay must be a number": [
  null,
  "Il ritardo deve essere un numero"
 ],
 "Delete": [
  null,
  "Cancella"
 ],
 "Deletion will remove the following files:": [
  null,
  "L'eliminazione rimuoverà i seguenti file:"
 ],
 "Description": [
  null,
  "Descrizione"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Rimovibile"
 ],
 "Details": [
  null,
  "Dettagli"
 ],
 "Disable simultaneous multithreading": [
  null,
  "Disabilita il multithreading simultaneo"
 ],
 "Disable tuned": [
  null,
  "Disabilita tuned"
 ],
 "Disabled": [
  null,
  "Disabilitato"
 ],
 "Disallow running (mask)": [
  null,
  "Non consentire l'esecuzione (mask)"
 ],
 "Docking station": [
  null,
  "Stazione di docking"
 ],
 "Does not automatically start": [
  null,
  "Non si avvia automaticamente"
 ],
 "Domain": [
  null,
  "Dominio"
 ],
 "Domain address": [
  null,
  "Indirizzo del dominio"
 ],
 "Domain administrator name": [
  null,
  "Nome dell'amministratore di dominio"
 ],
 "Domain administrator password": [
  null,
  "Password dell'amministratore di dominio"
 ],
 "Domain could not be contacted": [
  null,
  "Il dominio non può essere contattato"
 ],
 "Domain is not supported": [
  null,
  "Il dominio non è supportato"
 ],
 "Don't repeat": [
  null,
  "Non ripetere"
 ],
 "Downloading $0": [
  null,
  "Download di $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Edit /etc/motd": [
  null,
  "Modifica /etc/motd"
 ],
 "Edit motd": [
  null,
  "Modifica motd"
 ],
 "Embedded PC": [
  null,
  "PC integrato"
 ],
 "Enabled": [
  null,
  "Attivato"
 ],
 "Entry at $0": [
  null,
  "Voce a $0"
 ],
 "Error": [
  null,
  "Errore"
 ],
 "Error and above": [
  null,
  "Errore e superiore"
 ],
 "Error message": [
  null,
  "Messaggio di errore"
 ],
 "Expansion chassis": [
  null,
  "Chassis di espansione"
 ],
 "Extended information": [
  null,
  "Informazioni estese"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS non è abilitato correttamente"
 ],
 "Failed to disable tuned": [
  null,
  "Impossibile disabilitare tuned"
 ],
 "Failed to disabled tuned profile": [
  null,
  "Impossibile disabilitare il profilo tuned"
 ],
 "Failed to enable tuned": [
  null,
  "Impossibile abilitare tuned"
 ],
 "Failed to fetch logs": [
  null,
  "Impossibile recuperare i logs"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "Impossibile salvare le modifiche in /etc/motd"
 ],
 "Failed to start": [
  null,
  "Impossibile avviare"
 ],
 "Failed to switch profile": [
  null,
  "Impossibile cambiare profilo"
 ],
 "File state": [
  null,
  "Stato file"
 ],
 "Filter by name or description": [
  null,
  "Filtra per nome o descrizione"
 ],
 "Filters": [
  null,
  "Filtri"
 ],
 "Font size": [
  null,
  "Dimensione font"
 ],
 "Forbidden from running": [
  null,
  "Esecuzione non autorizzata"
 ],
 "Frame number": [
  null,
  "Numero del frame"
 ],
 "Free-form search": [
  null,
  "Ricerca libera"
 ],
 "Fridays": [
  null,
  "Venerdì"
 ],
 "General": [
  null,
  "Generale"
 ],
 "Generated": [
  null,
  "Generato"
 ],
 "Go to $0": [
  null,
  "Vai a $0"
 ],
 "Handheld": [
  null,
  "Palmare"
 ],
 "Hardware information": [
  null,
  "Informazioni hardware"
 ],
 "Health": [
  null,
  "Salute"
 ],
 "Help": [
  null,
  "Aiuto"
 ],
 "Hierarchy ID": [
  null,
  "ID gerarchico"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "Maggiore interoperabilità a scapito di una maggiore superficie di attacco."
 ],
 "Hostname": [
  null,
  "Nome host"
 ],
 "Hourly": [
  null,
  "Orario"
 ],
 "Hours": [
  null,
  "Ore"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "Identificativo"
 ],
 "Increase by one": [
  null,
  "Aumenta di uno"
 ],
 "Indirect": [
  null,
  "Indiretto"
 ],
 "Info and above": [
  null,
  "Info e superiore"
 ],
 "Insights: ": [
  null,
  "Approfondimenti: "
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Install software": [
  null,
  "Installa il software"
 ],
 "Installing $0": [
  null,
  "Installazione di $0"
 ],
 "Invalid": [
  null,
  "Non valido"
 ],
 "Invalid date format": [
  null,
  "Formato data non valido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato data non valido e formato ora non valido"
 ],
 "Invalid time format": [
  null,
  "Formato ora non valido"
 ],
 "Invalid timezone": [
  null,
  "Fuso orario non valido"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Join": [
  null,
  "Associa"
 ],
 "Join domain": [
  null,
  "Associa al dominio"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "L'associazione a un dominio richiede l'installazione di realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "L'associane a questo dominio non è supportata"
 ],
 "Joins namespace of": [
  null,
  "Associa al namespace di"
 ],
 "Journal": [
  null,
  "Registro"
 ],
 "Journal entry": [
  null,
  "Voce del registro"
 ],
 "Journal entry not found": [
  null,
  "Voce del registro non trovata"
 ],
 "Laptop": [
  null,
  "Portatile"
 ],
 "Last 24 hours": [
  null,
  "Ultime 24 ore"
 ],
 "Last 7 days": [
  null,
  "Ultimi 7 giorni"
 ],
 "Last successful login:": [
  null,
  "Ultimo accesso riuscito:"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "Leave $0": [
  null,
  "Lasciare $0"
 ],
 "Leave domain": [
  null,
  "Abbandona dominio"
 ],
 "Light": [
  null,
  "Chiaro"
 ],
 "Limit access": [
  null,
  "Limitare l'accesso"
 ],
 "Limited access": [
  null,
  "Accesso limitato"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "La modalità di accesso limitato limita i privilegi di amministratore. Alcune parti della Web Console avranno funzionalità ridotte."
 ],
 "Limits": [
  null,
  "Limiti"
 ],
 "Linked": [
  null,
  "Collegato"
 ],
 "Listen": [
  null,
  "Ascolta"
 ],
 "Listing unit files": [
  null,
  "Elenco dei file di unità"
 ],
 "Listing unit files failed: $0": [
  null,
  "Elenco dei file dell'unità non riuscito: $0"
 ],
 "Listing units": [
  null,
  "Elencando unità"
 ],
 "Listing units failed: $0": [
  null,
  "Unità elencate fallite: $0"
 ],
 "Load earlier entries": [
  null,
  "Carica voci precedenti"
 ],
 "Loading keys...": [
  null,
  "Caricamento delle chiavi..."
 ],
 "Loading of SSH keys failed": [
  null,
  "Caricamento delle chiavi SSH non riuscito"
 ],
 "Loading of units failed": [
  null,
  "Caricamento delle unità fallito"
 ],
 "Loading unit failed: $0": [
  null,
  "Unità caricate fallite: $0"
 ],
 "Loading...": [
  null,
  "Caricamento in corso..."
 ],
 "Log messages": [
  null,
  "Messaggi di log"
 ],
 "Login format": [
  null,
  "Formato di accesso"
 ],
 "Logs": [
  null,
  "Log"
 ],
 "Low profile desktop": [
  null,
  "Desktop a basso profilo"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Machine ID": [
  null,
  "ID macchina"
 ],
 "Machine SSH key fingerprints": [
  null,
  "Impronte digitali delle chiavi SSH della macchina"
 ],
 "Main server chassis": [
  null,
  "Chassis del server principale"
 ],
 "Maintenance": [
  null,
  "Manutenzione"
 ],
 "Managing services": [
  null,
  "Gestione dei servizi"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Mask service": [
  null,
  "Maschera servizio"
 ],
 "Masked": [
  null,
  "Mascherato"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "Il mascheramento del servizio impedisce l'avvio di tutte le unità da esso dipendenti. Questo può avere un impatto maggiore del previsto. Conferma di voler mascherare questa unità."
 ],
 "Memory": [
  null,
  "Memoria"
 ],
 "Memory technology": [
  null,
  "Tecnologia di memoria"
 ],
 "Merged": [
  null,
  "Fuso"
 ],
 "Message to logged in users": [
  null,
  "Messaggio agli utenti autenticati"
 ],
 "Method": [
  null,
  "Metodo"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "Il minuto deve essere un numero compreso tra 0-59"
 ],
 "Minutes": [
  null,
  "Minuti"
 ],
 "Mitigations": [
  null,
  "Mitigazioni"
 ],
 "Model": [
  null,
  "Modello"
 ],
 "Mondays": [
  null,
  "Lunedì"
 ],
 "Monthly": [
  null,
  "Mensilmente"
 ],
 "Multi-system chassis": [
  null,
  "Chassis multisistema"
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Need at least one NTP server": [
  null,
  "E' necessario almeno un server NTP"
 ],
 "No": [
  null,
  "No"
 ],
 "No delay": [
  null,
  "Nessun ritardo"
 ],
 "No host keys found.": [
  null,
  "Non sono state trovate chiavi host."
 ],
 "No log entries": [
  null,
  "Nessuna voce nel log"
 ],
 "No logs found": [
  null,
  "Nessun log trovato"
 ],
 "No matching results": [
  null,
  "Nessun risultato corrispondente"
 ],
 "No results found": [
  null,
  "nessun risultato trovato"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "Nessun risultato corrisponde ai criteri del filtro. Cancella tutti i filtri per mostrare i risultati."
 ],
 "No rule hits": [
  null,
  "Nessuna regola trovata"
 ],
 "None": [
  null,
  "Nessuno"
 ],
 "Not connected to Insights": [
  null,
  "Non connesso a Insights"
 ],
 "Not found": [
  null,
  "Non trovato"
 ],
 "Not running": [
  null,
  "Non in esecuzione"
 ],
 "Not synchronized": [
  null,
  "Non sincronizzato"
 ],
 "Note": [
  null,
  "Note"
 ],
 "Notebook": [
  null,
  "Portatile"
 ],
 "Notice and above": [
  null,
  "Notice e oltre"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "On failure": [
  null,
  "In caso di guasto"
 ],
 "Only emergency": [
  null,
  "Solo emergenza"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "Utilizzare solo algoritmi approvati e consentiti durante l'avvio in modalità FIPS."
 ],
 "Other": [
  null,
  "Altro"
 ],
 "Overview": [
  null,
  "Panoramica"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit si è interrotto"
 ],
 "Part of": [
  null,
  "Parte di"
 ],
 "Password": [
  null,
  "Password"
 ],
 "Paste": [
  null,
  "Incolla"
 ],
 "Path": [
  null,
  "Percorso"
 ],
 "Paths": [
  null,
  "Percorsi"
 ],
 "Pause": [
  null,
  "Pausa"
 ],
 "Performance profile": [
  null,
  "Profilo delle prestazioni"
 ],
 "Peripheral chassis": [
  null,
  "Chassis periferico"
 ],
 "Pick date": [
  null,
  "Scegli una data"
 ],
 "Pinned unit": [
  null,
  ""
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autenticarsi per ottenere l'accesso amministrativo"
 ],
 "Portable": [
  null,
  "Portatile"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "Pretty host name": [
  null,
  "Nome dell'host grazioso"
 ],
 "Previous boot": [
  null,
  "Avvio precedente"
 ],
 "Priority": [
  null,
  "Priorità"
 ],
 "Problem details": [
  null,
  "Dettagli del problema"
 ],
 "Problem info": [
  null,
  "Informazioni sul problema"
 ],
 "Propagates reload to": [
  null,
  "Propagati ricarica su"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "Protegge dagli attacchi futuri previsti a breve termine a scapito dell'interoperabilità."
 ],
 "RAID chassis": [
  null,
  "Chassis RAID"
 ],
 "Rack mount chassis": [
  null,
  "Chassis a rack"
 ],
 "Rank": [
  null,
  "Posizione"
 ],
 "Read more...": [
  null,
  "Leggi di più..."
 ],
 "Read-only": [
  null,
  "Sola lettura"
 ],
 "Real host name": [
  null,
  "Nome dell'host reale"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "Il nome host reale può contenere solo caratteri minuscoli, cifre, trattini e punti (con sottodomini popolati)"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "Il nome host reale deve essere di 64 caratteri o meno"
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "Impostazioni consigliate e sicure per gli attuali modelli di minaccia."
 ],
 "Reload": [
  null,
  "Ricarica"
 ],
 "Reload propagated from": [
  null,
  "Ricarica propagato da"
 ],
 "Removals:": [
  null,
  "Rimozioni:"
 ],
 "Remove": [
  null,
  "Elimina"
 ],
 "Removing $0": [
  null,
  "Rimozione $0"
 ],
 "Repeat weekly": [
  null,
  "Ripeti ogni settimana"
 ],
 "Report": [
  null,
  "Notifica"
 ],
 "Report to ABRT Analytics": [
  null,
  "Segnala ad ABRT Analytics"
 ],
 "Reported; no links available": [
  null,
  "Segnalato; nessun collegamento disponibile"
 ],
 "Reporting failed": [
  null,
  "Segnalazione fallita"
 ],
 "Reporting was canceled": [
  null,
  "La segnalazione è stata annullata"
 ],
 "Reports:": [
  null,
  "Rapporti:"
 ],
 "Required by": [
  null,
  "Richiesto da"
 ],
 "Required by ": [
  null,
  "Richiesto da "
 ],
 "Requires": [
  null,
  "Ha bisogno di"
 ],
 "Requires administration access to edit": [
  null,
  "Richiede accesso amministrativo per la modifica"
 ],
 "Requisite": [
  null,
  "Requisito"
 ],
 "Requisite of": [
  null,
  "Requisito di"
 ],
 "Reset": [
  null,
  "Azzera"
 ],
 "Restart": [
  null,
  "Riavvia"
 ],
 "Resume": [
  null,
  "Riprendi"
 ],
 "Reviewing logs": [
  null,
  "Revisione dei log"
 ],
 "Run on": [
  null,
  "Eseguire in"
 ],
 "Running": [
  null,
  "In esecuzione"
 ],
 "Saturdays": [
  null,
  "Sabati"
 ],
 "Save": [
  null,
  "Salva"
 ],
 "Save and reboot": [
  null,
  "Salva e riavvia"
 ],
 "Save changes": [
  null,
  "Salva modifiche"
 ],
 "Scheduled poweroff at $0": [
  null,
  "Spegnimento programmato alle $0"
 ],
 "Scheduled reboot at $0": [
  null,
  "Riavvio programmato alle $0"
 ],
 "Sealed-case PC": [
  null,
  "PC sigillato"
 ],
 "Search": [
  null,
  "Ricerca"
 ],
 "Seconds": [
  null,
  "Secondi"
 ],
 "Secure shell keys": [
  null,
  "Chiavi secure shell"
 ],
 "Send": [
  null,
  "Invia"
 ],
 "Server software": [
  null,
  "Software Server"
 ],
 "Service logs": [
  null,
  "Log servizi"
 ],
 "Services": [
  null,
  "Servizi"
 ],
 "Set hostname": [
  null,
  "Imposta il nome host"
 ],
 "Set time": [
  null,
  "Imposta tempo"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "Mostra tutti i threads"
 ],
 "Show fingerprints": [
  null,
  "Mostra le impronte digitali"
 ],
 "Show messages containing given string.": [
  null,
  "Mostra i messaggi contenenti una determinata stringa."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "Mostra i messaggi per l'unità systemd specificata."
 ],
 "Show messages from a specific boot.": [
  null,
  "Mostra i messaggi da un avvio specifico."
 ],
 "Show more relationships": [
  null,
  "Mostra più relazioni"
 ],
 "Show relationships": [
  null,
  "Mostra relazioni"
 ],
 "Shut down": [
  null,
  "Arresto"
 ],
 "Shutdown": [
  null,
  "Spegni"
 ],
 "Since": [
  null,
  "Da"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Size": [
  null,
  "Dimensione"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Sockets": [
  null,
  "Socket"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "Soluzioni alternative basate su software aiutano a prevenire problemi di sicurezza della CPU. Queste mitigazioni hanno l'effetto collaterale di ridurre le prestazioni. Modificare queste impostazioni a proprio rischio."
 ],
 "Space-saving computer": [
  null,
  "Computer space-saving"
 ],
 "Specific time": [
  null,
  "Tempo specifico"
 ],
 "Speed": [
  null,
  "Velocità"
 ],
 "Start": [
  null,
  "Avvia"
 ],
 "Start and enable": [
  null,
  "Avvia e Abilita"
 ],
 "Start service": [
  null,
  "Avvia il servizio"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "Inizia a mostrare le voci a partire dalla data specificata o da una data successiva."
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "Inizia a mostrare le voci entro e non oltre la data specificata."
 ],
 "State": [
  null,
  "Stato"
 ],
 "Static": [
  null,
  "Statico"
 ],
 "Status": [
  null,
  "Stato"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Stop": [
  null,
  "Ferma"
 ],
 "Stop and disable": [
  null,
  "Ferma e Disabilita"
 ],
 "Stub": [
  null,
  "urtare"
 ],
 "Sub-Chassis": [
  null,
  "Sub-Chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "La sottoscrizione alle segnalazioni di sistemd è fallita"
 ],
 "Sundays": [
  null,
  "Domeniche"
 ],
 "Switch to limited access": [
  null,
  "Passa ad accesso limitato"
 ],
 "Synchronized": [
  null,
  "Sincronizzato"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizzato con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizzazione"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "System information": [
  null,
  "Informazioni di sistema"
 ],
 "System time": [
  null,
  "Ora di sistema"
 ],
 "Systemd units": [
  null,
  "Unità systemd"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Targets": [
  null,
  "Destinazioni"
 ],
 "Terminal": [
  null,
  "Terminale"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "L'utente $0 non è autorizzato a modificare le mitigazioni di sicurezza della CPU"
 ],
 "This may take a while": [
  null,
  "L'operazione potrebbe richiedere del tempo"
 ],
 "This system is using a custom profile": [
  null,
  "Questo sistema utilizza un profilo personalizzato"
 ],
 "This system is using the recommended profile": [
  null,
  "Questo sistema utilizza il profilo raccomandato"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "Questa unità non è stata progettata per essere abilitata esplicitamente."
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "Questo aggiungerà una corrispondenza per '_BOOT_ID='. Se non specificato verranno mostrati i log per l'avvio corrente. Se l'ID di avvio viene omesso, un offset positivo cercherà gli avvii a partire dall'inizio del journal e un offset uguale o inferiore a zero cercherà gli avvioi a partire dalla fine del journal. Pertanto, 1 indica il primo avvio trovato nel journal in ordine cronologico, 2 il secondo e così via; mentre -0 è l'ultimo avvio, -1 l'avvio prima dell'ultimo e così via."
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "Questo aggiungerà una corrispondenza per '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' e 'UNIT=' per trovare tutti i messaggi possibili per l'unità data. Può contenere più unità separate da virgola. "
 ],
 "Thursdays": [
  null,
  "Giovedì"
 ],
 "Time": [
  null,
  "Ora"
 ],
 "Time zone": [
  null,
  "Fuso Orario"
 ],
 "Timers": [
  null,
  "Timer"
 ],
 "Toggle date picker": [
  null,
  "Attiva/disattiva la selezione della data"
 ],
 "Toggle filters": [
  null,
  "Attiva/disattiva i filtri"
 ],
 "Total size: $0": [
  null,
  "Dimensione totale: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Transient": [
  null,
  "Transitorio"
 ],
 "Triggered by": [
  null,
  "Attivato da"
 ],
 "Triggers": [
  null,
  "Trigger"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentativo di sincronizzazione con $0"
 ],
 "Tuesdays": [
  null,
  "Martedì"
 ],
 "Tuned has failed to start": [
  null,
  "Impossibile avviare tuned"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "tuned è un servizio che monitora il tuo sistema e ottimizza le prestazioni sotto alcuni carichi di lavoro. il cuore di tuned sono i profili, che ottimizzano il tuo sistema in casi differenti."
 ],
 "Tuned is not available": [
  null,
  "Tuned non è disponibile"
 ],
 "Tuned is not running": [
  null,
  "Tuned non è in esecuzione"
 ],
 "Tuned is off": [
  null,
  "Tuned è disattivato"
 ],
 "Turn on administrative access": [
  null,
  "Attiva l'accesso amministrativo"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Type to filter": [
  null,
  "Tipo da filtrare"
 ],
 "Unit": [
  null,
  "Unità"
 ],
 "Unknown": [
  null,
  "Sconosciuto"
 ],
 "Until": [
  null,
  "Fino a"
 ],
 "Updating status...": [
  null,
  "Aggiornamento dello stato..."
 ],
 "Usage": [
  null,
  "Utilizzo"
 ],
 "User": [
  null,
  "Utente"
 ],
 "Validating address": [
  null,
  "Convalida dell'indirizzo"
 ],
 "Vendor": [
  null,
  "Rivenditore"
 ],
 "Version": [
  null,
  "Versione"
 ],
 "View hardware details": [
  null,
  "Visualizza i dettagli hardware"
 ],
 "View report": [
  null,
  "Visualizza rapporto"
 ],
 "Waiting for input…": [
  null,
  "In attesa di input…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "In attesa che finiscano le altre operazioni di gestione del software"
 ],
 "Waiting to start…": [
  null,
  "In attesa di avvio…"
 ],
 "Wanted by": [
  null,
  "Ricercato da"
 ],
 "Wants": [
  null,
  "Vuole"
 ],
 "Warning and above": [
  null,
  "Avvertenza e superiore"
 ],
 "Web console is running in limited access mode.": [
  null,
  "La Web Console è in esecuzione in modalità di accesso limitato."
 ],
 "Wednesdays": [
  null,
  "Mercoledì"
 ],
 "Weeks": [
  null,
  "Settimane"
 ],
 "White": [
  null,
  "Bianco"
 ],
 "Yearly": [
  null,
  "Annuale"
 ],
 "Yes": [
  null,
  "Sì"
 ],
 "You may try to load older entries.": [
  null,
  "Puoi provare a caricare voci precedenti."
 ],
 "You now have administrative access.": [
  null,
  "Ora hai accesso amministrativo."
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "Il tuo browser non consente l'incolla dal menu contestuale. Puoi usare Maiusc+Ins."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Il tuo browser ricorderà il tuo livello di accesso tra le sessioni."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0byte di dati binari]"
 ],
 "[binary data]": [
  null,
  "[dati binari]"
 ],
 "[no data]": [
  null,
  "[nessun dato]"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "active": [
  null,
  "attivo"
 ],
 "asset tag": [
  null,
  "asset tag"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "avvio"
 ],
 "cgroups": [
  null,
  "cgroups"
 ],
 "command": [
  null,
  "comando"
 ],
 "console": [
  null,
  "console"
 ],
 "coredump": [
  null,
  "coredump"
 ],
 "cpu": [
  null,
  "cpu"
 ],
 "crash": [
  null,
  "crash"
 ],
 "date": [
  null,
  "data"
 ],
 "debug": [
  null,
  "debug"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "disabilita"
 ],
 "disks": [
  null,
  "dischi"
 ],
 "domain": [
  null,
  "dominio"
 ],
 "edit": [
  null,
  "modifica"
 ],
 "enable": [
  null,
  "abilita"
 ],
 "error": [
  null,
  "errore"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "impossibile elencare le chiavi host ssh: $0"
 ],
 "graphs": [
  null,
  "grafici"
 ],
 "hardware": [
  null,
  "hardware"
 ],
 "history": [
  null,
  "cronologia"
 ],
 "host": [
  null,
  "host"
 ],
 "journal": [
  null,
  "registro"
 ],
 "journalctl manpage": [
  null,
  "pagina man di journalctl"
 ],
 "machine": [
  null,
  "macchina"
 ],
 "mask": [
  null,
  "maschera"
 ],
 "memory": [
  null,
  "memoria"
 ],
 "metrics": [
  null,
  "metriche"
 ],
 "mitigation": [
  null,
  "mitigazione"
 ],
 "network": [
  null,
  "rete"
 ],
 "none": [
  null,
  "nessuno"
 ],
 "of $0 CPU": [
  null,
  "di $0 CPU",
  "di $0 CPU"
 ],
 "operating system": [
  null,
  "sistema operativo"
 ],
 "os": [
  null,
  "os"
 ],
 "path": [
  null,
  "percorso"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "power": [
  null,
  "alimentazione"
 ],
 "ram": [
  null,
  "ram"
 ],
 "recommended": [
  null,
  "raccomandato"
 ],
 "restart": [
  null,
  "riavvia"
 ],
 "running $0": [
  null,
  "$0 in esecuzione"
 ],
 "serial": [
  null,
  "seriale"
 ],
 "service": [
  null,
  "servizio"
 ],
 "shell": [
  null,
  "shell"
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ],
 "shut": [
  null,
  "shut"
 ],
 "socket": [
  null,
  "socket"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "destinazione"
 ],
 "time": [
  null,
  "ora"
 ],
 "timer": [
  null,
  "timer"
 ],
 "unit": [
  null,
  "unità"
 ],
 "unknown": [
  null,
  "sconosciuto"
 ],
 "version": [
  null,
  "versione"
 ],
 "warning": [
  null,
  "avviso"
 ],
 "dialog-title\u0004Domain": [
  null,
  "Dominio"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "Entra in un dominio"
 ]
});
