cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 critical hit": [
  null,
  "$0 关键命中"
 ],
 "$0 failed login attempt": [
  null,
  "$0 失败的登录尝试"
 ],
 "$0 important hit": [
  null,
  "$0 重要的命中"
 ],
 "$0 is not available from any repository.": [
  null,
  "所有仓库都不提供 $0。"
 ],
 "$0 low severity hit": [
  null,
  "$0 低度 hit"
 ],
 "$0 moderate hit": [
  null,
  "$0 中度 hit"
 ],
 "$0 service has failed": [
  null,
  "$0 个服务失败"
 ],
 "$0 will be installed.": [
  null,
  "将安装 $0。"
 ],
 "$0: crash at $1": [
  null,
  "$0: 崩溃于 $1"
 ],
 "1 minute": [
  null,
  "1 分钟"
 ],
 "10th": [
  null,
  "10号"
 ],
 "11th": [
  null,
  "11号"
 ],
 "12th": [
  null,
  "12号"
 ],
 "13th": [
  null,
  "13号"
 ],
 "14th": [
  null,
  "14号"
 ],
 "15th": [
  null,
  "15号"
 ],
 "16th": [
  null,
  "16号"
 ],
 "17th": [
  null,
  "第17"
 ],
 "18th": [
  null,
  "第18"
 ],
 "19th": [
  null,
  "第19"
 ],
 "1st": [
  null,
  "第1"
 ],
 "20 minutes": [
  null,
  "20 分钟"
 ],
 "20th": [
  null,
  "第20"
 ],
 "21th": [
  null,
  "第21"
 ],
 "22th": [
  null,
  "第22"
 ],
 "23th": [
  null,
  "第23"
 ],
 "24th": [
  null,
  "第24"
 ],
 "25th": [
  null,
  "第25"
 ],
 "26th": [
  null,
  "第26"
 ],
 "27th": [
  null,
  "第27"
 ],
 "28th": [
  null,
  "第28"
 ],
 "29th": [
  null,
  "第29"
 ],
 "2nd": [
  null,
  "第2"
 ],
 "30th": [
  null,
  "第30"
 ],
 "31st": [
  null,
  "第31"
 ],
 "3rd": [
  null,
  "第3"
 ],
 "40 minutes": [
  null,
  "40 分钟"
 ],
 "4th": [
  null,
  "第4"
 ],
 "5 minutes": [
  null,
  "5 分钟"
 ],
 "5th": [
  null,
  "第5"
 ],
 "60 minutes": [
  null,
  "60 分钟"
 ],
 "6th": [
  null,
  "第6"
 ],
 "7th": [
  null,
  "第7"
 ],
 "8th": [
  null,
  "第8"
 ],
 "9th": [
  null,
  "第9"
 ],
 "Absent": [
  null,
  "缺席"
 ],
 "Active since ": [
  null,
  "活跃自 "
 ],
 "Active state": [
  null,
  "活跃状态"
 ],
 "Add": [
  null,
  "添加"
 ],
 "Additional actions": [
  null,
  "额外操作"
 ],
 "Additional packages:": [
  null,
  "额外的软件包："
 ],
 "Administrative access": [
  null,
  "管理员权限"
 ],
 "Advanced TCA": [
  null,
  "高级 TCA"
 ],
 "After": [
  null,
  "后于"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  "从域离开后，仅有使用本地凭据的用户可以登录到该主机。这也可能影响到包括DNS解析设置以及信任的CA在内的一系列设置。"
 ],
 "After system boot": [
  null,
  "系统启动后"
 ],
 "Alert and above": [
  null,
  "Alert 及更高级别"
 ],
 "Alias": [
  null,
  "别名"
 ],
 "All": [
  null,
  "所有"
 ],
 "All-in-one": [
  null,
  "一体化"
 ],
 "Allow running (unmask)": [
  null,
  "允许运行 (取消屏蔽)"
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  "可以对日志信息中的文本字符串进行过滤。字符串也可以是正则表达式的形式。另外，还支持按消息日志字段进行过滤。它们是空格分隔的值，格式为 FIELD=VALUE，其中的值可以是逗号分隔的可能的值的列表。"
 ],
 "Appearance": [
  null,
  "外观"
 ],
 "Apply and reboot": [
  null,
  "应用并重启"
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  "应用新策略...可能需要几分钟时间。"
 ],
 "Asset tag": [
  null,
  "资产标签"
 ],
 "At minute": [
  null,
  "分钟"
 ],
 "At specific time": [
  null,
  "在指定时间"
 ],
 "Authenticate": [
  null,
  "认证"
 ],
 "Automatically starts": [
  null,
  "自动启动"
 ],
 "Automatically using NTP": [
  null,
  "自动使用 NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "自动使用指定的 NTP 服务器"
 ],
 "BIOS": [
  null,
  "BIOS"
 ],
 "BIOS date": [
  null,
  "BIOS 日期"
 ],
 "BIOS version": [
  null,
  "BIOS 版本"
 ],
 "Bad": [
  null,
  "错误"
 ],
 "Bad setting": [
  null,
  "错误设置"
 ],
 "Before": [
  null,
  "前于"
 ],
 "Binds to": [
  null,
  "绑定到"
 ],
 "Black": [
  null,
  "黑色"
 ],
 "Blade": [
  null,
  "刀片"
 ],
 "Blade enclosure": [
  null,
  "刀片机箱"
 ],
 "Boot": [
  null,
  "引导"
 ],
 "Bound by": [
  null,
  "边界为"
 ],
 "Bus expansion chassis": [
  null,
  "总线扩展机箱"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU security": [
  null,
  "CPU安全性"
 ],
 "CPU security toggles": [
  null,
  "CPU安全性开关"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  "使用当前的过滤器组合找不到任何日志。"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Cancel poweroff": [
  null,
  "取消关机"
 ],
 "Cancel reboot": [
  null,
  "取消重启"
 ],
 "Cannot be enabled": [
  null,
  "无法被启用"
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  "无法加入域，因为 realmd 在此系统上不可用"
 ],
 "Cannot schedule event in the past": [
  null,
  "无法调度以前的事件"
 ],
 "Change": [
  null,
  "变更"
 ],
 "Change crypto policy": [
  null,
  "更改加密策略"
 ],
 "Change host name": [
  null,
  "修改主机名"
 ],
 "Change performance profile": [
  null,
  "变更性能配置"
 ],
 "Change profile": [
  null,
  "变更配置"
 ],
 "Change system time": [
  null,
  "修改系统时间"
 ],
 "Checking installed software": [
  null,
  "检查安装的软件"
 ],
 "Class": [
  null,
  "等级"
 ],
 "Clear 'Failed to start'": [
  null,
  "清除 'Failed to start'"
 ],
 "Clear all filters": [
  null,
  "清除所有过滤规则"
 ],
 "Client software": [
  null,
  "客户端软件"
 ],
 "Close": [
  null,
  "关闭"
 ],
 "Command": [
  null,
  "命令"
 ],
 "Command not found": [
  null,
  "未找到命令"
 ],
 "Communication with tuned has failed": [
  null,
  "与 tuned 通信失败"
 ],
 "Compact PCI": [
  null,
  "紧凑型 PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "条件 $0=$1 不满足"
 ],
 "Condition failed": [
  null,
  "条件失败"
 ],
 "Configuration": [
  null,
  "配置"
 ],
 "Configuring system settings": [
  null,
  "配置系统设置"
 ],
 "Confirm deletion of $0": [
  null,
  "确认删除 $0"
 ],
 "Conflicted by": [
  null,
  "冲突"
 ],
 "Conflicts": [
  null,
  "冲突"
 ],
 "Connecting to dbus failed: $0": [
  null,
  "连接到 dbus 失败：$0"
 ],
 "Consists of": [
  null,
  "组成"
 ],
 "Contacted domain": [
  null,
  "联系的域"
 ],
 "Controller": [
  null,
  "控制器"
 ],
 "Convertible": [
  null,
  "可转换"
 ],
 "Copy": [
  null,
  "复制"
 ],
 "Copy to clipboard": [
  null,
  "复制到剪贴板"
 ],
 "Crash reporting": [
  null,
  "崩溃报告"
 ],
 "Create timer": [
  null,
  "创建定时器"
 ],
 "Critical and above": [
  null,
  "Critical 及更高级别"
 ],
 "Crypto Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  "加密策略是一个系统组件，它配置内核加密子系统，覆盖 TLS、IPSec、SSH、DNSSec 和 Kerberos 协议。"
 ],
 "Crypto policy": [
  null,
  "加密策略"
 ],
 "Crypto policy is inconsistent": [
  null,
  "加密策略不一致"
 ],
 "Ctrl+Insert": [
  null,
  "Ctrl+Insert"
 ],
 "Current boot": [
  null,
  "当前启动"
 ],
 "Custom crypto policy": [
  null,
  "自定义加密策略"
 ],
 "Daily": [
  null,
  "每日"
 ],
 "Dark": [
  null,
  "暗色"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  "日期规格应为 YYYY-MM-DD hh:mm:ss 格式。另外，也可以使用字符串 'yesterday', 'today', 'tomorrow'。'now' 代表当前时间。另外，还可以指定相对时间，前缀为 '-' 或 '+'"
 ],
 "Debug and above": [
  null,
  "Debug 及更高级别"
 ],
 "Decrease by one": [
  null,
  "减一"
 ],
 "Delay": [
  null,
  "延时"
 ],
 "Delay must be a number": [
  null,
  "延迟必须是一个数字"
 ],
 "Delete": [
  null,
  "删除"
 ],
 "Deletion will remove the following files:": [
  null,
  "删除操作会删除以下文件："
 ],
 "Description": [
  null,
  "描述"
 ],
 "Desktop": [
  null,
  "桌面"
 ],
 "Detachable": [
  null,
  "可拆开"
 ],
 "Details": [
  null,
  "详情"
 ],
 "Disable simultaneous multithreading": [
  null,
  "禁用同步多线程"
 ],
 "Disable tuned": [
  null,
  "禁用 tuned"
 ],
 "Disabled": [
  null,
  "禁用"
 ],
 "Disallow running (mask)": [
  null,
  "不允许运行 (屏蔽)"
 ],
 "Docking station": [
  null,
  "扩展坞"
 ],
 "Does not automatically start": [
  null,
  "不自动启动"
 ],
 "Domain": [
  null,
  "域"
 ],
 "Domain address": [
  null,
  "域地址"
 ],
 "Domain administrator name": [
  null,
  "域管理员用户名"
 ],
 "Domain administrator password": [
  null,
  "域管理员密码"
 ],
 "Domain could not be contacted": [
  null,
  "无法联系到域"
 ],
 "Domain is not supported": [
  null,
  "不支持域"
 ],
 "Don't repeat": [
  null,
  "不要重复"
 ],
 "Downloading $0": [
  null,
  "正在下载 $0"
 ],
 "Dual rank": [
  null,
  "双通道"
 ],
 "Edit /etc/motd": [
  null,
  "编辑 /etc/motd"
 ],
 "Edit motd": [
  null,
  "编辑 motd"
 ],
 "Embedded PC": [
  null,
  "嵌入式 PC"
 ],
 "Enabled": [
  null,
  "启用"
 ],
 "Entry at $0": [
  null,
  "于 $0 的条目"
 ],
 "Error": [
  null,
  "错误"
 ],
 "Error and above": [
  null,
  "Error 及更高级别"
 ],
 "Error message": [
  null,
  "错误信息"
 ],
 "Expansion chassis": [
  null,
  "扩展机箱"
 ],
 "Extended information": [
  null,
  "扩展的信息"
 ],
 "FIPS is not properly enabled": [
  null,
  "FIPS 没有被正确启用"
 ],
 "Failed to disable tuned": [
  null,
  "禁用 tuned 失败"
 ],
 "Failed to disabled tuned profile": [
  null,
  "禁用调优的配置文件失败"
 ],
 "Failed to enable tuned": [
  null,
  "启用 tuned 失败"
 ],
 "Failed to fetch logs": [
  null,
  "获取日志失败"
 ],
 "Failed to save changes in /etc/motd": [
  null,
  "保存 /etc/motd 中的更改失败"
 ],
 "Failed to start": [
  null,
  "启动失败"
 ],
 "Failed to switch profile": [
  null,
  "切换配置集失败"
 ],
 "File state": [
  null,
  "文件状态"
 ],
 "Filter by name or description": [
  null,
  "根据名称或描述进行过滤"
 ],
 "Filters": [
  null,
  "过滤"
 ],
 "Font size": [
  null,
  "字体大小"
 ],
 "Forbidden from running": [
  null,
  "禁止运行"
 ],
 "Frame number": [
  null,
  "帧号"
 ],
 "Free-form search": [
  null,
  "自由形式搜索"
 ],
 "Fridays": [
  null,
  "周五"
 ],
 "General": [
  null,
  "通用"
 ],
 "Generated": [
  null,
  "生成的"
 ],
 "Go to $0": [
  null,
  "前往 $0"
 ],
 "Handheld": [
  null,
  "手持式"
 ],
 "Hardware information": [
  null,
  "硬件信息"
 ],
 "Health": [
  null,
  "健康"
 ],
 "Help": [
  null,
  "帮助"
 ],
 "Hierarchy ID": [
  null,
  "层次结构 ID"
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  "更高的互操作性会增加被安全攻击的面积。"
 ],
 "Hostname": [
  null,
  "主机名"
 ],
 "Hourly": [
  null,
  "每小时"
 ],
 "Hours": [
  null,
  "小时"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Identifier": [
  null,
  "标识符"
 ],
 "Increase by one": [
  null,
  "加一"
 ],
 "Indirect": [
  null,
  "间接的"
 ],
 "Info and above": [
  null,
  "Info 及更高级别"
 ],
 "Insights: ": [
  null,
  "Insights: "
 ],
 "Install": [
  null,
  "安装"
 ],
 "Install software": [
  null,
  "安装软件"
 ],
 "Installing $0": [
  null,
  "正在安装 $0"
 ],
 "Invalid": [
  null,
  "无效"
 ],
 "Invalid date format": [
  null,
  "无效的日期格式"
 ],
 "Invalid date format and invalid time format": [
  null,
  "无效的日期格式和时间格式"
 ],
 "Invalid time format": [
  null,
  "无效的时间格式"
 ],
 "Invalid timezone": [
  null,
  "无效的时区"
 ],
 "IoT gateway": [
  null,
  "IoT 网关"
 ],
 "Join": [
  null,
  "加入"
 ],
 "Join domain": [
  null,
  "加入域"
 ],
 "Joining": [
  null,
  "加入"
 ],
 "Joining a domain requires installation of realmd": [
  null,
  "加入域需要安装 realmd"
 ],
 "Joining this domain is not supported": [
  null,
  "不支持加入该域"
 ],
 "Joins namespace of": [
  null,
  "加入命名空间"
 ],
 "Journal": [
  null,
  "日志"
 ],
 "Journal entry": [
  null,
  "日志条目"
 ],
 "Journal entry not found": [
  null,
  "未找到日志条目"
 ],
 "Laptop": [
  null,
  "笔记本电脑"
 ],
 "Last 24 hours": [
  null,
  "最近 24 小时"
 ],
 "Last 7 days": [
  null,
  "最近 7 天"
 ],
 "Last successful login:": [
  null,
  "最后成功的登录："
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "Leave $0": [
  null,
  "离开 $0"
 ],
 "Leave domain": [
  null,
  "离开域"
 ],
 "Light": [
  null,
  "亮色"
 ],
 "Limit access": [
  null,
  "限制访问"
 ],
 "Limited access": [
  null,
  "被限制的访问"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "限制访问模式会限制管理员权限。Web 控制台部分功能将会减少。"
 ],
 "Limits": [
  null,
  "限制"
 ],
 "Linked": [
  null,
  "连接"
 ],
 "Listen": [
  null,
  "监听"
 ],
 "Listing unit files": [
  null,
  "列出单元文件"
 ],
 "Listing unit files failed: $0": [
  null,
  "列出单元文件失败：$0"
 ],
 "Listing units": [
  null,
  "列出单元"
 ],
 "Listing units failed: $0": [
  null,
  "列出单元失败：$0"
 ],
 "Load earlier entries": [
  null,
  "载入更早条目"
 ],
 "Loading earlier entries": [
  null,
  "载入更早的条目"
 ],
 "Loading keys...": [
  null,
  "正在加载密钥 ......"
 ],
 "Loading of SSH keys failed": [
  null,
  "加载 SSH 密钥失败"
 ],
 "Loading of units failed": [
  null,
  "单元加载失败"
 ],
 "Loading unit failed: $0": [
  null,
  "登录单元失败：$0"
 ],
 "Loading...": [
  null,
  "载入中..."
 ],
 "Log messages": [
  null,
  "日志消息"
 ],
 "Login format": [
  null,
  "登陆格式"
 ],
 "Logs": [
  null,
  "日志"
 ],
 "Low profile desktop": [
  null,
  "低调桌面"
 ],
 "Lunch box": [
  null,
  "主机类型"
 ],
 "Machine ID": [
  null,
  "机器编号"
 ],
 "Machine SSH key fingerprints": [
  null,
  "主机 SSH 密钥指纹"
 ],
 "Main server chassis": [
  null,
  "主服务器机箱"
 ],
 "Maintenance": [
  null,
  "维护"
 ],
 "Managing services": [
  null,
  "管理服务"
 ],
 "Manually": [
  null,
  "手动的"
 ],
 "Mask service": [
  null,
  "屏蔽服务"
 ],
 "Masked": [
  null,
  "已屏蔽"
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  "屏蔽服务会阻止所有依赖的单元被运行。这所造成的影响可能会比预期的大。请确认您需要屏蔽这个单元。"
 ],
 "Memory": [
  null,
  "内存"
 ],
 "Memory technology": [
  null,
  "内存拓扑"
 ],
 "Merged": [
  null,
  "合并"
 ],
 "Message to logged in users": [
  null,
  "发送给已登录用户的信息"
 ],
 "Method": [
  null,
  "模式"
 ],
 "Mini PC": [
  null,
  "迷你电脑"
 ],
 "Mini tower": [
  null,
  "迷你塔式主机"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "分钟需要是 0-59 间的数字"
 ],
 "Minutes": [
  null,
  "分钟"
 ],
 "Mitigations": [
  null,
  "缓解"
 ],
 "Model": [
  null,
  "型号"
 ],
 "Mondays": [
  null,
  "周一"
 ],
 "Monthly": [
  null,
  "每月"
 ],
 "Multi-system chassis": [
  null,
  "多系统机箱"
 ],
 "NTP server": [
  null,
  "NTP 服务器"
 ],
 "Name": [
  null,
  "名称"
 ],
 "Need at least one NTP server": [
  null,
  "至少需要一个 NTP 服务器"
 ],
 "No": [
  null,
  "否"
 ],
 "No delay": [
  null,
  "无延时"
 ],
 "No host keys found.": [
  null,
  "没有找到主机密钥。"
 ],
 "No log entries": [
  null,
  "无日志条目"
 ],
 "No logs found": [
  null,
  "没有找到日志"
 ],
 "No matching results": [
  null,
  "没有找到匹配的结果"
 ],
 "No results found": [
  null,
  "没有找到结果"
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  "没有结果符合过滤条件。清除所有过滤器以显示结果。"
 ],
 "No rule hits": [
  null,
  "无规则命中"
 ],
 "None": [
  null,
  "无"
 ],
 "Not connected to Insights": [
  null,
  "没有连接到 Insights"
 ],
 "Not found": [
  null,
  "未找到"
 ],
 "Not permitted to configure realms": [
  null,
  "不允许配置域"
 ],
 "Not running": [
  null,
  "未运行"
 ],
 "Not synchronized": [
  null,
  "未同步"
 ],
 "Note": [
  null,
  "注意"
 ],
 "Notebook": [
  null,
  "笔记本"
 ],
 "Notice and above": [
  null,
  "Notice 及更高级别"
 ],
 "Ok": [
  null,
  "确认"
 ],
 "On failure": [
  null,
  "失败时"
 ],
 "Only alphabets, numbers, : , _ , . , @ , - are allowed": [
  null,
  "只允许使用字母, 数字, : , _ , . , @ , -"
 ],
 "Only emergency": [
  null,
  "只限紧急情况"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  "仅在使用 FIPS 模式引导时才使用已批准和允许的算法。"
 ],
 "Other": [
  null,
  "其他"
 ],
 "Overview": [
  null,
  "概览"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit 已崩溃"
 ],
 "Part of": [
  null,
  "部分"
 ],
 "Password": [
  null,
  "密码"
 ],
 "Paste": [
  null,
  "粘贴"
 ],
 "Paste error": [
  null,
  "粘贴错误"
 ],
 "Path": [
  null,
  "路径"
 ],
 "Paths": [
  null,
  "路径"
 ],
 "Pause": [
  null,
  "暂停"
 ],
 "Performance profile": [
  null,
  "性能配置集"
 ],
 "Peripheral chassis": [
  null,
  "外设机箱"
 ],
 "Pick date": [
  null,
  "选择日期"
 ],
 "Pin unit": [
  null,
  "固定单元"
 ],
 "Pinned unit": [
  null,
  "固定单元"
 ],
 "Pizza box": [
  null,
  "披萨盒"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "请认证以获得管理员权限"
 ],
 "Portable": [
  null,
  "手提"
 ],
 "Present": [
  null,
  "当前"
 ],
 "Pretty host name": [
  null,
  "易读主机名"
 ],
 "Previous boot": [
  null,
  "以前启动"
 ],
 "Priority": [
  null,
  "优先级"
 ],
 "Problem becoming administrator": [
  null,
  "成为管理员时出现问题"
 ],
 "Problem details": [
  null,
  "问题详情"
 ],
 "Problem info": [
  null,
  "问题信息"
 ],
 "Propagates reload to": [
  null,
  "传播重新加载到"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  "防止近期被安全攻击会降低互操作性。"
 ],
 "RAID chassis": [
  null,
  "RAID 机箱"
 ],
 "Rack mount chassis": [
  null,
  "机架式机箱"
 ],
 "Rank": [
  null,
  "Rank"
 ],
 "Read more...": [
  null,
  "了解更多..."
 ],
 "Read-only": [
  null,
  "只读"
 ],
 "Real host name": [
  null,
  "实际主机名"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "实际主机名仅包含小写字母、数字、破折号和句号（包括填充的子域）"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "实际主机名必须小于等于64个字符"
 ],
 "Reapply and reboot": [
  null,
  "重新应用并重启"
 ],
 "Reboot": [
  null,
  "重启"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  "建议的，当前威胁模型的安全设置。"
 ],
 "Reload": [
  null,
  "重载"
 ],
 "Reload propagated from": [
  null,
  "重新加载的传播来自"
 ],
 "Reloading": [
  null,
  "重新加载中"
 ],
 "Removals:": [
  null,
  "移除："
 ],
 "Remove": [
  null,
  "删除"
 ],
 "Removing $0": [
  null,
  "正在删除 $0"
 ],
 "Repeat": [
  null,
  "重复"
 ],
 "Repeat monthly": [
  null,
  "每月重复"
 ],
 "Repeat weekly": [
  null,
  "每周重复"
 ],
 "Report": [
  null,
  "报告"
 ],
 "Report to ABRT Analytics": [
  null,
  "向ABRT Analytics 报告"
 ],
 "Reported; no links available": [
  null,
  "已报告；没有可用的链接"
 ],
 "Reporting failed": [
  null,
  "报告失败"
 ],
 "Reporting was canceled": [
  null,
  "报告已取消"
 ],
 "Reports:": [
  null,
  "报告："
 ],
 "Required by": [
  null,
  "要求的"
 ],
 "Required by ": [
  null,
  "要求自 "
 ],
 "Requires": [
  null,
  "要求"
 ],
 "Requires administration access to edit": [
  null,
  "需要管理访问权限进行编辑"
 ],
 "Requisite": [
  null,
  "必要"
 ],
 "Requisite of": [
  null,
  "必备的"
 ],
 "Reset": [
  null,
  "重置"
 ],
 "Restart": [
  null,
  "重启"
 ],
 "Resume": [
  null,
  "恢复"
 ],
 "Review crypto policy": [
  null,
  "检查加密策略"
 ],
 "Reviewing logs": [
  null,
  "回顾日志"
 ],
 "Run at": [
  null,
  "运行于"
 ],
 "Run on": [
  null,
  "运行于"
 ],
 "Running": [
  null,
  "运行中"
 ],
 "Saturdays": [
  null,
  "周六"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Save and reboot": [
  null,
  "保存并重启"
 ],
 "Save changes": [
  null,
  "保存更改"
 ],
 "Scheduled poweroff at $0": [
  null,
  "计划在 $0 关闭电源"
 ],
 "Scheduled reboot at $0": [
  null,
  "计划在 $0 重启"
 ],
 "Sealed-case PC": [
  null,
  "密封式 PC"
 ],
 "Search": [
  null,
  "搜索"
 ],
 "Seconds": [
  null,
  "秒"
 ],
 "Secure shell keys": [
  null,
  "安全 shell 密钥"
 ],
 "Select a identifier": [
  null,
  "选择标识符"
 ],
 "Send": [
  null,
  "发送"
 ],
 "Server software": [
  null,
  "服务器软件"
 ],
 "Service logs": [
  null,
  "服务日志"
 ],
 "Services": [
  null,
  "服务"
 ],
 "Set hostname": [
  null,
  "设置主机名"
 ],
 "Set time": [
  null,
  "设置时间"
 ],
 "Shift+Insert": [
  null,
  "Shift+Insert"
 ],
 "Show all threads": [
  null,
  "显示所有线程"
 ],
 "Show fingerprints": [
  null,
  "显示指纹"
 ],
 "Show messages containing given string.": [
  null,
  "显示包含给定字符串的消息."
 ],
 "Show messages for the specified systemd unit.": [
  null,
  "显示指定 systemd 单元的消息。"
 ],
 "Show messages from a specific boot.": [
  null,
  "显示来自特定引导的消息."
 ],
 "Show more relationships": [
  null,
  "显示更多关系"
 ],
 "Show relationships": [
  null,
  "显示关系"
 ],
 "Shut down": [
  null,
  "关机"
 ],
 "Shutdown": [
  null,
  "关机"
 ],
 "Since": [
  null,
  "自从"
 ],
 "Single rank": [
  null,
  "单 rank"
 ],
 "Size": [
  null,
  "大小"
 ],
 "Slot": [
  null,
  "插槽"
 ],
 "Sockets": [
  null,
  "套接字"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  "基于软件的临时解决方案可以帮助防止 CPU 安全问题。这些缓解方案会对性能有一定影响。改变这些设置可能会存在风险。"
 ],
 "Space-saving computer": [
  null,
  "节省空间的计算机"
 ],
 "Specific time": [
  null,
  "指定时间"
 ],
 "Speed": [
  null,
  "速度"
 ],
 "Start": [
  null,
  "启动"
 ],
 "Start and enable": [
  null,
  "开始并启用"
 ],
 "Start service": [
  null,
  "启动服务"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  "显示指定日期及以后的条目。"
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  "显示指定日期及以前的条目。"
 ],
 "State": [
  null,
  "状态"
 ],
 "Static": [
  null,
  "静态"
 ],
 "Status": [
  null,
  "状态"
 ],
 "Stick PC": [
  null,
  "PC 棒"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Stop and disable": [
  null,
  "停止并禁用"
 ],
 "Stub": [
  null,
  "Stub"
 ],
 "Sub-Chassis": [
  null,
  "子机箱"
 ],
 "Sub-Notebook": [
  null,
  "子笔记本"
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  "订阅 systemd 信号失败：$0"
 ],
 "Successfully copied to keyboard": [
  null,
  "成功复制到键盘"
 ],
 "Sundays": [
  null,
  "周日"
 ],
 "Switch to administrative access": [
  null,
  "切换到管理权限"
 ],
 "Switch to limited access": [
  null,
  "切换到限制权限"
 ],
 "Synchronized": [
  null,
  "已同步"
 ],
 "Synchronized with $0": [
  null,
  "与 $0 同步"
 ],
 "Synchronizing": [
  null,
  "同步"
 ],
 "System": [
  null,
  "系统"
 ],
 "System information": [
  null,
  "系统信息"
 ],
 "System time": [
  null,
  "系统时间"
 ],
 "Systemd units": [
  null,
  "Systemd 单元"
 ],
 "Tablet": [
  null,
  "平板"
 ],
 "Targets": [
  null,
  "目标"
 ],
 "Terminal": [
  null,
  "终端"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  "用户 $0 没有权限修改 cpu 安全缓解方案设置"
 ],
 "The user $0 is not permitted to change crypto policies": [
  null,
  "用户 $0 不允许修改加密策略"
 ],
 "This field cannot be empty": [
  null,
  "该字段不能为空"
 ],
 "This may take a while": [
  null,
  "这可能需要一些时间"
 ],
 "This system is using a custom profile": [
  null,
  "该系统正在使用自定义的配置集"
 ],
 "This system is using the recommended profile": [
  null,
  "该系统正在使用推荐的配置集"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "该单元没有设计为需要明确启用。"
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  "这将添加一个 '_BOOT_ID=' 匹配项。 如果未指定，则将显示来自当前引导的日志。 在没有指定 ID 时，正偏移将从日志开始查找启动，而等于或小于零的偏移将从日志末尾开始查找启动。因此，1 表示日志中第一次引导（按时间顺序排列），2 为第二个，以此类推；-0 是最后一次引导，-1 是最后一次引导前的一个，以此类推。"
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  "这将添加 '_SYSTEMD_UNIT='、'COREDUMP_UNIT=' 和 'UNIT=' 匹配项，以查找给定单元的所有可能消息。可以包含以逗号分隔的多个单元。 "
 ],
 "Thursdays": [
  null,
  "周四"
 ],
 "Time": [
  null,
  "时间"
 ],
 "Time zone": [
  null,
  "时区"
 ],
 "Timer creation failed": [
  null,
  "计时器创建失败"
 ],
 "Timer deletion failed": [
  null,
  "计时器删除失败"
 ],
 "Timers": [
  null,
  "计时器"
 ],
 "Toggle date picker": [
  null,
  "切换日期选择器"
 ],
 "Toggle filters": [
  null,
  "切换过滤器"
 ],
 "Total size: $0": [
  null,
  "总大小：$0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Transient": [
  null,
  "短暂的"
 ],
 "Trigger": [
  null,
  "触发器"
 ],
 "Triggered by": [
  null,
  "触发于"
 ],
 "Triggers": [
  null,
  "触发器"
 ],
 "Trying to synchronize with $0": [
  null,
  "正在尝试与 $0 同步"
 ],
 "Tuesdays": [
  null,
  "周二"
 ],
 "Tuned has failed to start": [
  null,
  "Tuned 启动失败"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  "Tuned 是一个监控您的系统并优化某些工作负载性能的服务。Tuned 的核心是配置集（profile），使用它为不同的用例调整您的系统。"
 ],
 "Tuned is not available": [
  null,
  "Tuned 不可用"
 ],
 "Tuned is not running": [
  null,
  "Tuned 未运行"
 ],
 "Tuned is off": [
  null,
  "Tuned 已关闭"
 ],
 "Turn on administrative access": [
  null,
  "开启管理员权限"
 ],
 "Type": [
  null,
  "类型"
 ],
 "Type to filter": [
  null,
  "输入内容来过滤"
 ],
 "Unit": [
  null,
  "单位"
 ],
 "Unit not found": [
  null,
  "未找到单位"
 ],
 "Unknown": [
  null,
  "未知"
 ],
 "Unpin unit": [
  null,
  "取消固定单元"
 ],
 "Until": [
  null,
  "直到"
 ],
 "Updating status...": [
  null,
  "更新状态 ..."
 ],
 "Uptime": [
  null,
  "运行时间"
 ],
 "Usage": [
  null,
  "用法"
 ],
 "User": [
  null,
  "用户"
 ],
 "Validating address": [
  null,
  "验证地址"
 ],
 "Vendor": [
  null,
  "厂商"
 ],
 "Version": [
  null,
  "版本"
 ],
 "View all logs": [
  null,
  "查看所有日志"
 ],
 "View all services": [
  null,
  "查看所有服务"
 ],
 "View hardware details": [
  null,
  "查看硬件详细信息"
 ],
 "View login history": [
  null,
  "查看登录历史记录"
 ],
 "View metrics and history": [
  null,
  "查看指标和历史记录"
 ],
 "View report": [
  null,
  "查看报告"
 ],
 "Viewing memory information requires administrative access.": [
  null,
  "查看内存信息需要管理访问权限。"
 ],
 "Waiting for input…": [
  null,
  "等待输入…"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他软件管理操作完成"
 ],
 "Waiting to start…": [
  null,
  "等待开始…"
 ],
 "Wanted by": [
  null,
  "需要于"
 ],
 "Wants": [
  null,
  "需要"
 ],
 "Warning and above": [
  null,
  "Warning 及更高级别"
 ],
 "Web console is running in limited access mode.": [
  null,
  "Web 控制台正运行于限制访问模式。"
 ],
 "Wednesdays": [
  null,
  "周三"
 ],
 "Weekly": [
  null,
  "每周"
 ],
 "Weeks": [
  null,
  "周"
 ],
 "White": [
  null,
  "白"
 ],
 "Yearly": [
  null,
  "每年"
 ],
 "Yes": [
  null,
  "是"
 ],
 "You may try to load older entries.": [
  null,
  "您可以尝试加载较早的条目。"
 ],
 "You now have administrative access.": [
  null,
  "您已经获取了管理员权限。"
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  "您的浏览器不允许从上下文菜单中进行粘贴，您可以使用 Shift+Insert。"
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "您的浏览器将会在不同会话之间记住您的访问级别。"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 字节二进制数据]"
 ],
 "[binary data]": [
  null,
  "[二进制数据]"
 ],
 "[no data]": [
  null,
  "[没有数据]"
 ],
 "abrt": [
  null,
  "abrt"
 ],
 "active": [
  null,
  "激活"
 ],
 "asset tag": [
  null,
  "资产标签"
 ],
 "bash": [
  null,
  "bash"
 ],
 "bios": [
  null,
  "bios"
 ],
 "boot": [
  null,
  "引导"
 ],
 "cgroups": [
  null,
  "用户组"
 ],
 "command": [
  null,
  "命令"
 ],
 "console": [
  null,
  "控制台"
 ],
 "coredump": [
  null,
  "核心转储"
 ],
 "cpu": [
  null,
  "中央处理器"
 ],
 "crash": [
  null,
  "崩溃"
 ],
 "date": [
  null,
  "日期"
 ],
 "debug": [
  null,
  "故障调试"
 ],
 "dimm": [
  null,
  "dimm"
 ],
 "disable": [
  null,
  "禁用"
 ],
 "disks": [
  null,
  "磁盘"
 ],
 "domain": [
  null,
  "域"
 ],
 "edit": [
  null,
  "编辑"
 ],
 "enable": [
  null,
  "启用"
 ],
 "error": [
  null,
  "错误"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "列出 SSH 主机密钥失败: $0"
 ],
 "graphs": [
  null,
  "图表"
 ],
 "hardware": [
  null,
  "硬件"
 ],
 "history": [
  null,
  "历史"
 ],
 "host": [
  null,
  "主机"
 ],
 "inconsistent": [
  null,
  "不一致"
 ],
 "journal": [
  null,
  "日志"
 ],
 "journalctl manpage": [
  null,
  "journalctl 手册页"
 ],
 "machine": [
  null,
  "机器"
 ],
 "mask": [
  null,
  "屏蔽"
 ],
 "memory": [
  null,
  "内存"
 ],
 "metrics": [
  null,
  "指标"
 ],
 "mitigation": [
  null,
  "缓解方案"
 ],
 "network": [
  null,
  "网络"
 ],
 "none": [
  null,
  "空"
 ],
 "of $0 CPU": [
  null,
  "$0 CPU"
 ],
 "operating system": [
  null,
  "操作系统"
 ],
 "os": [
  null,
  "操作系统"
 ],
 "path": [
  null,
  "路径"
 ],
 "pci": [
  null,
  "pci"
 ],
 "pcp": [
  null,
  "pcp"
 ],
 "performance": [
  null,
  "性能"
 ],
 "power": [
  null,
  "电源"
 ],
 "ram": [
  null,
  "ram"
 ],
 "recommended": [
  null,
  "推荐"
 ],
 "restart": [
  null,
  "重启"
 ],
 "running $0": [
  null,
  "运行中 $0"
 ],
 "serial": [
  null,
  "序列"
 ],
 "service": [
  null,
  "服务"
 ],
 "shell": [
  null,
  "shell"
 ],
 "show less": [
  null,
  "显示更少"
 ],
 "show more": [
  null,
  "显示更多"
 ],
 "shut": [
  null,
  "关闭"
 ],
 "socket": [
  null,
  "套接口"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "systemctl": [
  null,
  "systemctl"
 ],
 "systemd": [
  null,
  "systemd"
 ],
 "target": [
  null,
  "目标"
 ],
 "time": [
  null,
  "时间"
 ],
 "timer": [
  null,
  "计时器"
 ],
 "unit": [
  null,
  "单位"
 ],
 "unknown": [
  null,
  "未知"
 ],
 "unmask": [
  null,
  "取消屏蔽"
 ],
 "version": [
  null,
  "版本"
 ],
 "warning": [
  null,
  "警告"
 ],
 "dialog-title\u0004Domain": [
  null,
  "域"
 ],
 "dialog-title\u0004Join a domain": [
  null,
  "加入域"
 ],
 "from <host>\u0004from $0": [
  null,
  "来自 $0"
 ],
 "from <host> on <terminal>\u0004from $0 on $1": [
  null,
  "来自 $1 上的 $0"
 ],
 "on <terminal>\u0004on $0": [
  null,
  "在 $0 上"
 ]
});
