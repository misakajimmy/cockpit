cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  ""
 ],
 "$0 critical hit": [
  null,
  ""
 ],
 "$0 important hit": [
  null,
  ""
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 在任何存儲庫中都不可用。"
 ],
 "$0 low severity hit": [
  null,
  ""
 ],
 "$0 service has failed": [
  null,
  "$0 服務發生錯誤"
 ],
 "$0 will be installed.": [
  null,
  "$0 將會被安裝。"
 ],
 "$0: crash at $1": [
  null,
  ""
 ],
 "1 minute": [
  null,
  "1分鐘"
 ],
 "10th": [
  null,
  "第10"
 ],
 "11th": [
  null,
  "第11"
 ],
 "12th": [
  null,
  "第12"
 ],
 "13th": [
  null,
  "第13"
 ],
 "14th": [
  null,
  "第14"
 ],
 "15th": [
  null,
  "第15"
 ],
 "16th": [
  null,
  "第16"
 ],
 "17th": [
  null,
  "第17"
 ],
 "18th": [
  null,
  "第18"
 ],
 "19th": [
  null,
  "第19"
 ],
 "1st": [
  null,
  "第1"
 ],
 "20 minutes": [
  null,
  "20分鐘"
 ],
 "20th": [
  null,
  "第20"
 ],
 "21th": [
  null,
  ""
 ],
 "22th": [
  null,
  ""
 ],
 "23th": [
  null,
  ""
 ],
 "24th": [
  null,
  "第24"
 ],
 "25th": [
  null,
  "第25"
 ],
 "26th": [
  null,
  "第26"
 ],
 "27th": [
  null,
  "第27"
 ],
 "28th": [
  null,
  "第28"
 ],
 "29th": [
  null,
  "第29"
 ],
 "2nd": [
  null,
  "第2"
 ],
 "30th": [
  null,
  "第30"
 ],
 "31st": [
  null,
  "第31"
 ],
 "3rd": [
  null,
  "第3"
 ],
 "40 minutes": [
  null,
  "40分鐘"
 ],
 "4th": [
  null,
  "第4"
 ],
 "5 minutes": [
  null,
  "5分鐘"
 ],
 "5th": [
  null,
  "第5"
 ],
 "60 minutes": [
  null,
  "60分鐘"
 ],
 "6th": [
  null,
  "第6"
 ],
 "7th": [
  null,
  "第7"
 ],
 "8th": [
  null,
  "第8"
 ],
 "9th": [
  null,
  "第9"
 ],
 "Absent": [
  null,
  ""
 ],
 "Active since ": [
  null,
  ""
 ],
 "Add": [
  null,
  "加入"
 ],
 "Additional actions": [
  null,
  ""
 ],
 "Additional packages:": [
  null,
  "附加包："
 ],
 "Advanced TCA": [
  null,
  "高級TCA"
 ],
 "After": [
  null,
  "封底"
 ],
 "After leaving the domain, only users with local credentials will be able to log into this machine. This may also affect other services as DNS resolution settings and the list of trusted CAs may change.": [
  null,
  ""
 ],
 "After system boot": [
  null,
  "系統啟動後"
 ],
 "Alert and above": [
  null,
  "警報及以上"
 ],
 "All": [
  null,
  "全部"
 ],
 "All-in-one": [
  null,
  ""
 ],
 "Allow running (unmask)": [
  null,
  ""
 ],
 "Any text string in the logs messages can be filtered. The string can also be in the form of a regular expression. Also supports filtering by message log fields. These are space separated values, in form FIELD=VALUE, where value can be comma separated list of possible values.": [
  null,
  ""
 ],
 "Applying new policy... This may take a few minutes.": [
  null,
  ""
 ],
 "Asset tag": [
  null,
  "標籤"
 ],
 "At specific time": [
  null,
  "在特定時間"
 ],
 "Automatically starts": [
  null,
  ""
 ],
 "Automatically using NTP": [
  null,
  "自動使用NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "自動使用特定的NTP伺服器"
 ],
 "BIOS": [
  null,
  "BIOS 廠牌"
 ],
 "BIOS date": [
  null,
  "BIOS 日期"
 ],
 "BIOS version": [
  null,
  "BIOS 版本"
 ],
 "Before": [
  null,
  "之前"
 ],
 "Binds to": [
  null,
  "綁定到"
 ],
 "Black": [
  null,
  "黑色"
 ],
 "Blade": [
  null,
  "刀鋒"
 ],
 "Blade enclosure": [
  null,
  "刀鋒機箱"
 ],
 "Boot": [
  null,
  ""
 ],
 "Bound by": [
  null,
  "以......為界"
 ],
 "Bus expansion chassis": [
  null,
  "總線擴展機箱"
 ],
 "CPU": [
  null,
  "處理器"
 ],
 "CPU security": [
  null,
  "處理器安全"
 ],
 "CPU security toggles": [
  null,
  "處理器安全開關"
 ],
 "Can not find any logs using the current combination of filters.": [
  null,
  ""
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Cancel poweroff": [
  null,
  ""
 ],
 "Cannot join a domain because realmd is not available on this system": [
  null,
  ""
 ],
 "Cannot schedule event in the past": [
  null,
  "無法安排過去的活動"
 ],
 "Change": [
  null,
  "改變"
 ],
 "Change crypto policy": [
  null,
  ""
 ],
 "Change host name": [
  null,
  "更改主機名"
 ],
 "Change performance profile": [
  null,
  "更改績效檔案"
 ],
 "Change profile": [
  null,
  "改變檔案"
 ],
 "Change system time": [
  null,
  "改變系統時間"
 ],
 "Checking installed software": [
  null,
  "檢查已安裝的軟件"
 ],
 "Class": [
  null,
  "類別"
 ],
 "Clear 'Failed to start'": [
  null,
  ""
 ],
 "Clear all filters": [
  null,
  ""
 ],
 "Client software": [
  null,
  ""
 ],
 "Close": [
  null,
  "關閉"
 ],
 "Command": [
  null,
  "指令"
 ],
 "Communication with tuned has failed": [
  null,
  "與tuned的通信失敗了"
 ],
 "Compact PCI": [
  null,
  "緊湊型PCI"
 ],
 "Condition $0=$1 was not met": [
  null,
  "條件 $0=$1 沒有得到滿足"
 ],
 "Condition failed": [
  null,
  "條件失敗"
 ],
 "Configuration": [
  null,
  "組態"
 ],
 "Conflicted by": [
  null,
  "衝突的"
 ],
 "Conflicts": [
  null,
  "衝突"
 ],
 "Consists of": [
  null,
  "由組成"
 ],
 "Contacted domain": [
  null,
  ""
 ],
 "Convertible": [
  null,
  "可兌換"
 ],
 "Copy": [
  null,
  ""
 ],
 "Copy to clipboard": [
  null,
  ""
 ],
 "Crash reporting": [
  null,
  ""
 ],
 "Create timer": [
  null,
  "建立計時器"
 ],
 "Critical and above": [
  null,
  "關鍵及以上"
 ],
 "Crypto Policies is a system component that configures the core cryptographic subsystems, covering the TLS, IPSec, SSH, DNSSec, and Kerberos protocols.": [
  null,
  ""
 ],
 "Ctrl+Insert": [
  null,
  ""
 ],
 "Current boot": [
  null,
  "當前啟動"
 ],
 "Daily": [
  null,
  ""
 ],
 "Dark": [
  null,
  "深色"
 ],
 "Date specifications should be of the format YYYY-MM-DD hh:mm:ss. Alternatively the strings 'yesterday', 'today', 'tomorrow' are understood. 'now' refers to the current time. Finally, relative times may be specified, prefixed with '-' or '+'": [
  null,
  ""
 ],
 "Debug and above": [
  null,
  "調試及以上"
 ],
 "Decrease by one": [
  null,
  ""
 ],
 "Delay": [
  null,
  "延遲"
 ],
 "Delete": [
  null,
  "刪除"
 ],
 "Deletion will remove the following files:": [
  null,
  ""
 ],
 "Description": [
  null,
  "說明"
 ],
 "Desktop": [
  null,
  "桌面環境"
 ],
 "Detachable": [
  null,
  "可拆開"
 ],
 "Details": [
  null,
  "詳情"
 ],
 "Disable simultaneous multithreading": [
  null,
  ""
 ],
 "Disable tuned": [
  null,
  "禁用調整"
 ],
 "Disabled": [
  null,
  "已停用"
 ],
 "Disallow running (mask)": [
  null,
  ""
 ],
 "Docking station": [
  null,
  "停靠站"
 ],
 "Domain": [
  null,
  "網域名稱"
 ],
 "Domain address": [
  null,
  "域名地址"
 ],
 "Domain administrator name": [
  null,
  "域管理員名稱"
 ],
 "Domain administrator password": [
  null,
  "域管理員密碼"
 ],
 "Don't repeat": [
  null,
  "不要重複"
 ],
 "Downloading $0": [
  null,
  "下載 $0"
 ],
 "Dual rank": [
  null,
  ""
 ],
 "Embedded PC": [
  null,
  "嵌入式PC"
 ],
 "Enabled": [
  null,
  "已啟用"
 ],
 "Entry at $0": [
  null,
  ""
 ],
 "Error": [
  null,
  "錯誤"
 ],
 "Error and above": [
  null,
  "錯誤及以上"
 ],
 "Expansion chassis": [
  null,
  "擴展機箱"
 ],
 "Extended information": [
  null,
  ""
 ],
 "FIPS is not properly enabled": [
  null,
  ""
 ],
 "Failed to disable tuned": [
  null,
  "無法禁用已調整"
 ],
 "Failed to enable tuned": [
  null,
  "無法啟用調整"
 ],
 "Failed to start": [
  null,
  ""
 ],
 "Failed to switch profile": [
  null,
  "無法切換配置文件"
 ],
 "Forbidden from running": [
  null,
  ""
 ],
 "Frame number": [
  null,
  ""
 ],
 "Fridays": [
  null,
  ""
 ],
 "General": [
  null,
  "一般"
 ],
 "Hardware information": [
  null,
  "硬體訊息"
 ],
 "Health": [
  null,
  "系統摘要"
 ],
 "Help": [
  null,
  "說明"
 ],
 "Hierarchy ID": [
  null,
  ""
 ],
 "Higher interoperability at the cost of an increased attack surface.": [
  null,
  ""
 ],
 "Hostname": [
  null,
  "主機名稱"
 ],
 "Hours": [
  null,
  "時"
 ],
 "ID": [
  null,
  ""
 ],
 "Identifier": [
  null,
  ""
 ],
 "Increase by one": [
  null,
  ""
 ],
 "Info and above": [
  null,
  "訊息及以上"
 ],
 "Insights: ": [
  null,
  ""
 ],
 "Install": [
  null,
  "安裝"
 ],
 "Install software": [
  null,
  "安裝軟件"
 ],
 "Installing $0": [
  null,
  "正在安裝 $0"
 ],
 "Invalid date format": [
  null,
  "日期格式無效"
 ],
 "Invalid date format and invalid time format": [
  null,
  "日期格式無效，時間格式無效"
 ],
 "Invalid time format": [
  null,
  "時間格式無效"
 ],
 "IoT gateway": [
  null,
  "物聯網網關"
 ],
 "Join": [
  null,
  "加入"
 ],
 "Join domain": [
  null,
  "網域設定"
 ],
 "Joining this domain is not supported": [
  null,
  "不支持加入此域"
 ],
 "Joins namespace of": [
  null,
  "加入命名空間"
 ],
 "Journal": [
  null,
  "日誌"
 ],
 "Journal entry": [
  null,
  "期刊錄入"
 ],
 "Journal entry not found": [
  null,
  "期刊條目未找到"
 ],
 "Laptop": [
  null,
  "筆記本電腦"
 ],
 "Last 24 hours": [
  null,
  "過去24小時"
 ],
 "Last 7 days": [
  null,
  "過去7天"
 ],
 "Leave domain": [
  null,
  "離開域名"
 ],
 "Light": [
  null,
  "淺色"
 ],
 "Limit access": [
  null,
  ""
 ],
 "Limited access": [
  null,
  ""
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  ""
 ],
 "Limits": [
  null,
  ""
 ],
 "Listen": [
  null,
  ""
 ],
 "Listing unit files": [
  null,
  ""
 ],
 "Listing unit files failed: $0": [
  null,
  ""
 ],
 "Load earlier entries": [
  null,
  "加載較早的條目"
 ],
 "Loading...": [
  null,
  "正在載入..."
 ],
 "Log messages": [
  null,
  "記錄消息"
 ],
 "Login format": [
  null,
  ""
 ],
 "Logs": [
  null,
  "系統日誌"
 ],
 "Low profile desktop": [
  null,
  "低調桌面"
 ],
 "Lunch box": [
  null,
  "午餐盒"
 ],
 "Machine ID": [
  null,
  "編號"
 ],
 "Machine SSH key fingerprints": [
  null,
  "機器SSH密鑰指紋"
 ],
 "Main server chassis": [
  null,
  "主伺服器機箱"
 ],
 "Manually": [
  null,
  "手動"
 ],
 "Mask service": [
  null,
  ""
 ],
 "Masked": [
  null,
  ""
 ],
 "Masking service prevents all dependent units from running. This can have bigger impact than anticipated. Please confirm that you want to mask this unit.": [
  null,
  ""
 ],
 "Memory": [
  null,
  "記憶體"
 ],
 "Memory technology": [
  null,
  ""
 ],
 "Merged": [
  null,
  ""
 ],
 "Message to logged in users": [
  null,
  "登錄用戶的消息"
 ],
 "Method": [
  null,
  ""
 ],
 "Mini PC": [
  null,
  "迷你電腦"
 ],
 "Mini tower": [
  null,
  "迷你塔"
 ],
 "Minute needs to be a number between 0-59": [
  null,
  "分鐘需要是0-59之間的數字"
 ],
 "Minutes": [
  null,
  "分"
 ],
 "Mitigations": [
  null,
  ""
 ],
 "Model": [
  null,
  "型號"
 ],
 "Mondays": [
  null,
  ""
 ],
 "Monthly": [
  null,
  ""
 ],
 "Multi-system chassis": [
  null,
  "多系統機箱"
 ],
 "NTP server": [
  null,
  "NTP伺服器"
 ],
 "Name": [
  null,
  "名稱"
 ],
 "Need at least one NTP server": [
  null,
  "至少需要一台NTP伺服器"
 ],
 "No": [
  null,
  "否"
 ],
 "No delay": [
  null,
  "沒有延遲"
 ],
 "No host keys found.": [
  null,
  "找不到主機密鑰。"
 ],
 "No logs found": [
  null,
  ""
 ],
 "No matching results": [
  null,
  ""
 ],
 "No results found": [
  null,
  ""
 ],
 "No results match the filter criteria. Clear all filters to show results.": [
  null,
  ""
 ],
 "No rule hits": [
  null,
  ""
 ],
 "None": [
  null,
  "無"
 ],
 "Not connected to Insights": [
  null,
  ""
 ],
 "Not found": [
  null,
  "未找到"
 ],
 "Not running": [
  null,
  "沒跑"
 ],
 "Not synchronized": [
  null,
  "不同步"
 ],
 "Note": [
  null,
  "備註"
 ],
 "Notebook": [
  null,
  "筆記本"
 ],
 "Notice and above": [
  null,
  "注意及以上"
 ],
 "Ok": [
  null,
  "確定"
 ],
 "On failure": [
  null,
  "失敗"
 ],
 "Only emergency": [
  null,
  "只有緊急情況"
 ],
 "Only use approved and allowed algorithms when booting in FIPS mode.": [
  null,
  ""
 ],
 "Other": [
  null,
  "其它"
 ],
 "Overview": [
  null,
  "主機狀態"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit崩潰了"
 ],
 "Part of": [
  null,
  "部分"
 ],
 "Password": [
  null,
  "密碼"
 ],
 "Paste": [
  null,
  ""
 ],
 "Path": [
  null,
  "路徑"
 ],
 "Paths": [
  null,
  "路徑"
 ],
 "Pause": [
  null,
  ""
 ],
 "Performance profile": [
  null,
  "效能配置"
 ],
 "Peripheral chassis": [
  null,
  "外圍機箱"
 ],
 "Pick date": [
  null,
  ""
 ],
 "Pinned unit": [
  null,
  ""
 ],
 "Pizza box": [
  null,
  "披薩盒"
 ],
 "Please authenticate to gain administrative access": [
  null,
  ""
 ],
 "Portable": [
  null,
  "手提"
 ],
 "Present": [
  null,
  ""
 ],
 "Pretty host name": [
  null,
  "漂亮的主機名"
 ],
 "Previous boot": [
  null,
  ""
 ],
 "Priority": [
  null,
  "優先等級"
 ],
 "Problem details": [
  null,
  "問題詳情"
 ],
 "Problem info": [
  null,
  "問題訊息"
 ],
 "Propagates reload to": [
  null,
  "宣傳重新加載"
 ],
 "Protects from anticipated near-term future attacks at the expense of interoperability.": [
  null,
  ""
 ],
 "RAID chassis": [
  null,
  "RAID機箱"
 ],
 "Rack mount chassis": [
  null,
  "機架式機箱"
 ],
 "Rank": [
  null,
  ""
 ],
 "Read more...": [
  null,
  ""
 ],
 "Read-only": [
  null,
  ""
 ],
 "Real host name": [
  null,
  "真實主機名"
 ],
 "Real host name can only contain lower-case characters, digits, dashes, and periods (with populated subdomains)": [
  null,
  "真實主機名只能包含小寫字符，數字，短劃線和句點（帶有填充的子域）"
 ],
 "Real host name must be 64 characters or less": [
  null,
  "實際主機名必須為64個字符或更少"
 ],
 "Reapply and reboot": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "重新開機"
 ],
 "Recommended, secure settings for current threat models.": [
  null,
  ""
 ],
 "Reload": [
  null,
  "重新載入"
 ],
 "Reload propagated from": [
  null,
  "重新傳播來自"
 ],
 "Removals:": [
  null,
  "清除："
 ],
 "Remove": [
  null,
  "移除"
 ],
 "Removing $0": [
  null,
  "刪除 $0"
 ],
 "Repeat weekly": [
  null,
  "重複每週"
 ],
 "Report": [
  null,
  "回報"
 ],
 "Report to ABRT Analytics": [
  null,
  ""
 ],
 "Reported; no links available": [
  null,
  ""
 ],
 "Reporting failed": [
  null,
  ""
 ],
 "Reporting was canceled": [
  null,
  ""
 ],
 "Reports:": [
  null,
  ""
 ],
 "Required by": [
  null,
  "要求的"
 ],
 "Required by ": [
  null,
  ""
 ],
 "Requires": [
  null,
  "需要"
 ],
 "Requires administration access to edit": [
  null,
  ""
 ],
 "Requisite": [
  null,
  "必要"
 ],
 "Requisite of": [
  null,
  "必備的"
 ],
 "Reset": [
  null,
  "重置"
 ],
 "Restart": [
  null,
  "重新啟動"
 ],
 "Resume": [
  null,
  ""
 ],
 "Run on": [
  null,
  ""
 ],
 "Running": [
  null,
  "執行中"
 ],
 "Saturdays": [
  null,
  ""
 ],
 "Save": [
  null,
  "儲存"
 ],
 "Save and reboot": [
  null,
  ""
 ],
 "Scheduled poweroff at $0": [
  null,
  ""
 ],
 "Scheduled reboot at $0": [
  null,
  ""
 ],
 "Sealed-case PC": [
  null,
  "密封式PC"
 ],
 "Search": [
  null,
  ""
 ],
 "Seconds": [
  null,
  "秒"
 ],
 "Secure shell keys": [
  null,
  "安全資料"
 ],
 "Send": [
  null,
  ""
 ],
 "Server software": [
  null,
  ""
 ],
 "Service logs": [
  null,
  "服務日誌"
 ],
 "Services": [
  null,
  "服務"
 ],
 "Set hostname": [
  null,
  ""
 ],
 "Set time": [
  null,
  "設置時間"
 ],
 "Shift+Insert": [
  null,
  ""
 ],
 "Show fingerprints": [
  null,
  "顯示指紋"
 ],
 "Show messages containing given string.": [
  null,
  ""
 ],
 "Show messages for the specified systemd unit.": [
  null,
  ""
 ],
 "Show messages from a specific boot.": [
  null,
  ""
 ],
 "Show more relationships": [
  null,
  ""
 ],
 "Show relationships": [
  null,
  ""
 ],
 "Shut down": [
  null,
  "關機"
 ],
 "Shutdown": [
  null,
  "關機"
 ],
 "Since": [
  null,
  ""
 ],
 "Single rank": [
  null,
  ""
 ],
 "Size": [
  null,
  "大小"
 ],
 "Slot": [
  null,
  "插槽"
 ],
 "Sockets": [
  null,
  "插槽"
 ],
 "Software-based workarounds help prevent CPU security issues. These mitigations have the side effect of reducing performance. Change these settings at your own risk.": [
  null,
  ""
 ],
 "Space-saving computer": [
  null,
  "節省空間的計算機"
 ],
 "Specific time": [
  null,
  "特定的時間"
 ],
 "Speed": [
  null,
  ""
 ],
 "Start": [
  null,
  "開始"
 ],
 "Start and enable": [
  null,
  ""
 ],
 "Start service": [
  null,
  "開始服務"
 ],
 "Start showing entries on or newer than the specified date.": [
  null,
  ""
 ],
 "Start showing entries on or older than the specified date.": [
  null,
  ""
 ],
 "State": [
  null,
  "狀態"
 ],
 "Static": [
  null,
  "靜態"
 ],
 "Status": [
  null,
  "狀態"
 ],
 "Stick PC": [
  null,
  "堅持使用PC"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Stop and disable": [
  null,
  ""
 ],
 "Stub": [
  null,
  ""
 ],
 "Subscribing to systemd signals failed: $0": [
  null,
  ""
 ],
 "Successfully copied to keyboard": [
  null,
  ""
 ],
 "Sundays": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  ""
 ],
 "Synchronized": [
  null,
  "同步"
 ],
 "System": [
  null,
  "系統"
 ],
 "System time": [
  null,
  "系統時間"
 ],
 "Tablet": [
  null,
  "面板"
 ],
 "Targets": [
  null,
  "目標"
 ],
 "Terminal": [
  null,
  "終端機"
 ],
 "The user $0 is not permitted to change cpu security mitigations": [
  null,
  ""
 ],
 "This may take a while": [
  null,
  "可能還要等一下"
 ],
 "This system is using a custom profile": [
  null,
  "該系統使用自定義配置文件"
 ],
 "This system is using the recommended profile": [
  null,
  "該系統使用推薦的配置文件"
 ],
 "This unit is not designed to be enabled explicitly.": [
  null,
  "此單元未設計為顯式啟用。"
 ],
 "This will add a match for '_BOOT_ID='. If not specified the logs for the current boot will be shown. If the boot ID is omitted, a positive offset will look up the boots starting from the beginning of the journal, and an equal-or-less-than zero offset will look up boots starting from the end of the journal. Thus, 1 means the first boot found in the journal in chronological order, 2 the second and so on; while -0 is the last boot, -1 the boot before last, and so on.": [
  null,
  ""
 ],
 "This will add match for '_SYSTEMD_UNIT=', 'COREDUMP_UNIT=' and 'UNIT=' to find all possible messages for the given unit. Can contain more units separated by comma. ": [
  null,
  ""
 ],
 "Thursdays": [
  null,
  ""
 ],
 "Time zone": [
  null,
  "時區"
 ],
 "Timers": [
  null,
  "計時器"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Total size: $0": [
  null,
  "總大小： $0"
 ],
 "Tower": [
  null,
  "塔"
 ],
 "Transient": [
  null,
  ""
 ],
 "Triggered by": [
  null,
  "觸發"
 ],
 "Triggers": [
  null,
  "觸發器"
 ],
 "Tuesdays": [
  null,
  ""
 ],
 "Tuned has failed to start": [
  null,
  "Tuned未能開始"
 ],
 "Tuned is a service that monitors your system and optimizes the performance under certain workloads. The core of Tuned are profiles, which tune your system for different use cases.": [
  null,
  ""
 ],
 "Tuned is not available": [
  null,
  "調諧不可用"
 ],
 "Tuned is not running": [
  null,
  "Tuned沒有運行"
 ],
 "Tuned is off": [
  null,
  "Tuned已關閉"
 ],
 "Turn on administrative access": [
  null,
  ""
 ],
 "Type": [
  null,
  "類型"
 ],
 "Unit": [
  null,
  "單位"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Until": [
  null,
  ""
 ],
 "Updating status...": [
  null,
  ""
 ],
 "Uptime": [
  null,
  ""
 ],
 "Usage": [
  null,
  "效能狀態"
 ],
 "User": [
  null,
  "使用者"
 ],
 "Validating address": [
  null,
  ""
 ],
 "Vendor": [
  null,
  "供應商"
 ],
 "Version": [
  null,
  "版本"
 ],
 "View all logs": [
  null,
  ""
 ],
 "View hardware details": [
  null,
  "詳細資料"
 ],
 "View login history": [
  null,
  ""
 ],
 "View metrics and history": [
  null,
  ""
 ],
 "View report": [
  null,
  ""
 ],
 "Waiting for input…": [
  null,
  ""
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他軟件管理操作完成"
 ],
 "Waiting to start…": [
  null,
  ""
 ],
 "Wanted by": [
  null,
  "通緝"
 ],
 "Wants": [
  null,
  "希望"
 ],
 "Warning and above": [
  null,
  "警告及以上"
 ],
 "Web console is running in limited access mode.": [
  null,
  ""
 ],
 "Wednesdays": [
  null,
  ""
 ],
 "Weeks": [
  null,
  "週"
 ],
 "White": [
  null,
  "白色"
 ],
 "Yearly": [
  null,
  ""
 ],
 "Yes": [
  null,
  "是"
 ],
 "You may try to load older entries.": [
  null,
  ""
 ],
 "You now have administrative access.": [
  null,
  ""
 ],
 "Your browser does not allow paste from the context menu. You can use Shift+Insert.": [
  null,
  ""
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  ""
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 二進制數據的字節]"
 ],
 "[binary data]": [
  null,
  "[二進制數據]"
 ],
 "[no data]": [
  null,
  "[沒有數據]"
 ],
 "abrt": [
  null,
  ""
 ],
 "active": [
  null,
  "活性"
 ],
 "asset tag": [
  null,
  "標籤"
 ],
 "bash": [
  null,
  ""
 ],
 "bios": [
  null,
  ""
 ],
 "boot": [
  null,
  ""
 ],
 "cgroups": [
  null,
  ""
 ],
 "command": [
  null,
  ""
 ],
 "console": [
  null,
  ""
 ],
 "coredump": [
  null,
  ""
 ],
 "cpu": [
  null,
  "處理器"
 ],
 "crash": [
  null,
  "崩潰"
 ],
 "date": [
  null,
  ""
 ],
 "debug": [
  null,
  ""
 ],
 "dimm": [
  null,
  ""
 ],
 "disable": [
  null,
  ""
 ],
 "domain": [
  null,
  ""
 ],
 "edit": [
  null,
  "編輯"
 ],
 "enable": [
  null,
  "啟用"
 ],
 "error": [
  null,
  "錯誤"
 ],
 "failed to list ssh host keys: $0": [
  null,
  "無法列出ssh​​主機密鑰： $0"
 ],
 "graphs": [
  null,
  ""
 ],
 "hardware": [
  null,
  ""
 ],
 "host": [
  null,
  "主機"
 ],
 "journal": [
  null,
  ""
 ],
 "journalctl manpage": [
  null,
  ""
 ],
 "machine": [
  null,
  ""
 ],
 "mask": [
  null,
  ""
 ],
 "memory": [
  null,
  ""
 ],
 "mitigation": [
  null,
  ""
 ],
 "network": [
  null,
  "網絡"
 ],
 "none": [
  null,
  "無"
 ],
 "operating system": [
  null,
  ""
 ],
 "os": [
  null,
  ""
 ],
 "path": [
  null,
  ""
 ],
 "pci": [
  null,
  ""
 ],
 "power": [
  null,
  ""
 ],
 "ram": [
  null,
  ""
 ],
 "recommended": [
  null,
  "推薦的"
 ],
 "restart": [
  null,
  ""
 ],
 "running $0": [
  null,
  ""
 ],
 "serial": [
  null,
  ""
 ],
 "service": [
  null,
  ""
 ],
 "shell": [
  null,
  ""
 ],
 "show less": [
  null,
  "顯示較少"
 ],
 "show more": [
  null,
  "顯示更多"
 ],
 "shut": [
  null,
  ""
 ],
 "socket": [
  null,
  ""
 ],
 "ssh": [
  null,
  ""
 ],
 "systemctl": [
  null,
  ""
 ],
 "systemd": [
  null,
  ""
 ],
 "target": [
  null,
  ""
 ],
 "time": [
  null,
  ""
 ],
 "timer": [
  null,
  ""
 ],
 "unit": [
  null,
  ""
 ],
 "unknown": [
  null,
  "不明"
 ],
 "unmask": [
  null,
  ""
 ],
 "version": [
  null,
  ""
 ],
 "warning": [
  null,
  ""
 ],
 "from <host>\u0004from $0": [
  null,
  ""
 ]
});
