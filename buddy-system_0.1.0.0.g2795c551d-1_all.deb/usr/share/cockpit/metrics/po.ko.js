cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 CPU"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 available": [
  null,
  "$0 사용 가능"
 ],
 "$0 free": [
  null,
  "$0 공간"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0는 저장소에서 사용 할 수 없습니다."
 ],
 "$0 page": [
  null,
  "$0 페이지"
 ],
 "$0 total": [
  null,
  "총 $0"
 ],
 "$0 will be installed.": [
  null,
  "$0가 설치됩니다."
 ],
 "1 min": [
  null,
  "1 분"
 ],
 "15 min": [
  null,
  "15 분"
 ],
 "5 min": [
  null,
  "5분"
 ],
 "Absent": [
  null,
  "부재"
 ],
 "Add $0": [
  null,
  "$0 추가"
 ],
 "Additional packages:": [
  null,
  "추가 꾸러미 :"
 ],
 "Advanced TCA": [
  null,
  "고급 TCA"
 ],
 "All-in-one": [
  null,
  "일체형"
 ],
 "Blade": [
  null,
  "블레이드"
 ],
 "Blade enclosure": [
  null,
  "블레이드 인클로저"
 ],
 "Bus expansion chassis": [
  null,
  "버스 확장 섀시"
 ],
 "CPU": [
  null,
  "중앙처리장치"
 ],
 "CPU spike": [
  null,
  "중앙처리장치 순간 사용량"
 ],
 "CPU usage": [
  null,
  "중앙처리장치 사용량"
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Checking installed software": [
  null,
  "설치된 소프트웨어 확인 중"
 ],
 "Collect metrics": [
  null,
  "메트릭 수집"
 ],
 "Compact PCI": [
  null,
  "PCI 압축"
 ],
 "Convertible": [
  null,
  "변환 가능"
 ],
 "Core $0": [
  null,
  "코어 $0"
 ],
 "Current top CPU usage": [
  null,
  "현재 최대 CPU 사용량"
 ],
 "Desktop": [
  null,
  "데스크탑"
 ],
 "Detachable": [
  null,
  "분리 가능"
 ],
 "Device": [
  null,
  "장치"
 ],
 "Disk I/O": [
  null,
  "디스크 I/O"
 ],
 "Disk I/O spike": [
  null,
  "디스크 I/O 순간 사용량"
 ],
 "Disks": [
  null,
  "디스크"
 ],
 "Disks usage": [
  null,
  "디스크 사용량"
 ],
 "Docking station": [
  null,
  "도킹 스테이션"
 ],
 "Downloading $0": [
  null,
  "$0 내려받기 중"
 ],
 "Dual rank": [
  null,
  "듀얼 랭크"
 ],
 "Embedded PC": [
  null,
  "임베디드 PC"
 ],
 "Error has occurred": [
  null,
  "오류가 발생했습니다"
 ],
 "Event": [
  null,
  "사건"
 ],
 "Event logs": [
  null,
  "사건 기록"
 ],
 "Expansion chassis": [
  null,
  "확장 섀시"
 ],
 "Export to network": [
  null,
  "네트워크로 내보내기"
 ],
 "Failed to configure PCP": [
  null,
  "PCP 구성에 실패하였습니다"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "방화벽에서 $0 활성화에 실패"
 ],
 "Handheld": [
  null,
  "휴대용"
 ],
 "In": [
  null,
  "입력"
 ],
 "Install": [
  null,
  "설치"
 ],
 "Install cockpit-pcp": [
  null,
  "cockpit-pcp 설치"
 ],
 "Install software": [
  null,
  "소프트웨어 설치"
 ],
 "Installing $0": [
  null,
  "$0 설치 중"
 ],
 "Interface": [
  null,
  "연결장치"
 ],
 "IoT gateway": [
  null,
  "IoT 게이트웨이"
 ],
 "Jump to": [
  null,
  "다음으로 이동"
 ],
 "Laptop": [
  null,
  "랩탑"
 ],
 "Learn more": [
  null,
  "더 알아보기"
 ],
 "Load": [
  null,
  "적재"
 ],
 "Load earlier data": [
  null,
  "이전 자료 적재"
 ],
 "Load spike": [
  null,
  "적재 순간 사용량"
 ],
 "Loading...": [
  null,
  "적재 중..."
 ],
 "Log out": [
  null,
  "로그아웃"
 ],
 "Low profile desktop": [
  null,
  "낮은 프로파일 데스크탑"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "Main server chassis": [
  null,
  "메인 서버 섀시"
 ],
 "Memory": [
  null,
  "메모리"
 ],
 "Memory spike": [
  null,
  "메모리 순간 사용량"
 ],
 "Memory usage": [
  null,
  "메모리 사용량"
 ],
 "Metrics and history": [
  null,
  "측정 항목과 내역 보기"
 ],
 "Metrics history could not be loaded": [
  null,
  "메트릭 내역을 로드할 수 없습니다"
 ],
 "Metrics settings": [
  null,
  "메트릭 설정"
 ],
 "Mini PC": [
  null,
  "미니 PC"
 ],
 "Mini tower": [
  null,
  "미니 타워"
 ],
 "Multi-system chassis": [
  null,
  "멀티 시스템 섀시"
 ],
 "Network": [
  null,
  "네트워크"
 ],
 "Network I/O": [
  null,
  "네트워크 I/O"
 ],
 "Network I/O spike": [
  null,
  "네트워크 I/O 순간 사용량"
 ],
 "Network usage": [
  null,
  "네트워크 사용량"
 ],
 "No data available": [
  null,
  "사용 가능한 데이터 없음"
 ],
 "No data available between $0 and $1": [
  null,
  "$0 ~ $1 사이에 사용 가능한 데이터 없음"
 ],
 "No logs found": [
  null,
  "기록을 찾을 수 없음"
 ],
 "Notebook": [
  null,
  "노트북"
 ],
 "Ok": [
  null,
  "확인"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "메트릭을 공유하는 방화벽에서 pmproxy 서비스를 엽니다."
 ],
 "Other": [
  null,
  "기타"
 ],
 "Out": [
  null,
  "출력"
 ],
 "Overview": [
  null,
  "개요"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "메트릭 내역에 꾸러미 cockpit-pcp가 누락되어 있습니다"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit가 충돌했습니다"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "Performance Co-Pilot는 당신의 시스템에서 성능 메트릭을 수집하고 분석합니다."
 ],
 "Peripheral chassis": [
  null,
  "주변 장치 섀시"
 ],
 "Pizza box": [
  null,
  "피자 박스"
 ],
 "Portable": [
  null,
  "이동식"
 ],
 "Present": [
  null,
  "존재"
 ],
 "RAID chassis": [
  null,
  "레이드 섀시"
 ],
 "RAM": [
  null,
  "램"
 ],
 "Rack mount chassis": [
  null,
  "랙 마운트 섀시"
 ],
 "Read": [
  null,
  "읽기"
 ],
 "Read more...": [
  null,
  "더 알아보기..."
 ],
 "Reboot": [
  null,
  "재시작"
 ],
 "Removals:": [
  null,
  "삭제:"
 ],
 "Removing $0": [
  null,
  "$0 삭제 중"
 ],
 "Save": [
  null,
  "저장"
 ],
 "Sealed-case PC": [
  null,
  "쉴드 케이스 PC"
 ],
 "Service": [
  null,
  "서비스"
 ],
 "Single rank": [
  null,
  "단일 등급"
 ],
 "Space-saving computer": [
  null,
  "공간-절약형 컴퓨터"
 ],
 "Stick PC": [
  null,
  "스틱 PC"
 ],
 "Sub-Chassis": [
  null,
  "서브 섀시"
 ],
 "Sub-Notebook": [
  null,
  "서브 노트북"
 ],
 "Swap": [
  null,
  "스왑"
 ],
 "Swap out": [
  null,
  "스왑 아웃"
 ],
 "Tablet": [
  null,
  "테블릿"
 ],
 "Today": [
  null,
  "오늘"
 ],
 "Top 5 CPU services": [
  null,
  "상위 5개의 CPU 서비스"
 ],
 "Top 5 memory services": [
  null,
  "상위 5개의 메모리 서비스"
 ],
 "Total size: $0": [
  null,
  "전체 크기: $0"
 ],
 "Tower": [
  null,
  "타워"
 ],
 "Troubleshoot": [
  null,
  "문제 해결"
 ],
 "Unknown": [
  null,
  "알 수 없음"
 ],
 "Usage": [
  null,
  "사용량"
 ],
 "Used": [
  null,
  "사용됨"
 ],
 "View all CPUs": [
  null,
  "모든 CPU 보기"
 ],
 "View all disks": [
  null,
  "모든 디스크 보기"
 ],
 "View all logs": [
  null,
  "모든 기록 보기"
 ],
 "View detailed logs": [
  null,
  "상세한 기록 보기"
 ],
 "View per-disk throughput": [
  null,
  "디스크-당 처리량 보기"
 ],
 "Visit firewall": [
  null,
  "방화벽 방문"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "다른 소프트웨어 관리 작업이 완료될 때 까지 대기 중"
 ],
 "Write": [
  null,
  "쓰기"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  "메트릭을 기록을 보려면 다시 로그인해야 합니다"
 ],
 "Zone": [
  null,
  "영역"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[바이너리 데이터의 $0 바이트]"
 ],
 "[binary data]": [
  null,
  "[바이너리 데이터]"
 ],
 "[no data]": [
  null,
  "[데이터 없음]"
 ],
 "average: $0%": [
  null,
  "평균: $0%"
 ],
 "cockpit-podman is not installed": [
  null,
  "Cockpit-podman이 설치되어 있지 않습니다"
 ],
 "max: $0%": [
  null,
  "최대: $0%"
 ],
 "nice": [
  null,
  "nice"
 ],
 "pmlogger.service has failed": [
  null,
  "pmlogger.service가 실패했습니다"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "pmlogger.service는 자료 수집에 실패하였습니다"
 ],
 "pmlogger.service is not running": [
  null,
  "pmlogger.service가 동작 하지 않습니다"
 ],
 "pod": [
  null,
  "pod"
 ],
 "show less": [
  null,
  "덜 보기"
 ],
 "show more": [
  null,
  "더 보기"
 ],
 "sys": [
  null,
  "sys"
 ],
 "user": [
  null,
  "사용자"
 ]
});
