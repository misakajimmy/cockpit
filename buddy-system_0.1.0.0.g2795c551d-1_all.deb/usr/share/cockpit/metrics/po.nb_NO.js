cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 CPU",
  "$0 CPUer"
 ],
 "$0 free": [
  null,
  "$0 ledig"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 er ikke tilgjengelig fra noe depot."
 ],
 "$0 page": [
  null,
  "$0 side",
  "$0 sider"
 ],
 "$0 total": [
  null,
  "$0 totalt"
 ],
 "$0 will be installed.": [
  null,
  "$0 vil bli installert."
 ],
 "1 min": [
  null,
  "1 min"
 ],
 "15 min": [
  null,
  "15 min"
 ],
 "5 min": [
  null,
  "5 min"
 ],
 "Absent": [
  null,
  "Fraværende"
 ],
 "Add $0": [
  null,
  "Legg til $0"
 ],
 "Additional packages:": [
  null,
  "Ekstra pakker:"
 ],
 "Advanced TCA": [
  null,
  "Avansert TCA"
 ],
 "All-in-one": [
  null,
  "Alt i ett"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Blad-kabinett"
 ],
 "Bus expansion chassis": [
  null,
  ""
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU spike": [
  null,
  "CPU-topp"
 ],
 "CPU usage": [
  null,
  "CPU-bruk"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Checking installed software": [
  null,
  "Kontrollerer installert programvare"
 ],
 "Compact PCI": [
  null,
  ""
 ],
 "Convertible": [
  null,
  "Konverterbar"
 ],
 "Core $0": [
  null,
  "Kjerne $0"
 ],
 "Desktop": [
  null,
  ""
 ],
 "Detachable": [
  null,
  ""
 ],
 "Device": [
  null,
  "Enhet"
 ],
 "Disk I/O": [
  null,
  "Disk I/U"
 ],
 "Disk I/O spike": [
  null,
  "Disk I/O-topp"
 ],
 "Disks": [
  null,
  "Disker"
 ],
 "Docking station": [
  null,
  "Dokkingstasjon"
 ],
 "Downloading $0": [
  null,
  "Laster ned $0"
 ],
 "Dual rank": [
  null,
  "Dobbel rangering"
 ],
 "Embedded PC": [
  null,
  "Innebygd PC"
 ],
 "Error has occurred": [
  null,
  "Det har oppstått en feil"
 ],
 "Event": [
  null,
  "Hendelse"
 ],
 "Event logs": [
  null,
  "Hendelseslogger"
 ],
 "Expansion chassis": [
  null,
  ""
 ],
 "Handheld": [
  null,
  "Håndholdt"
 ],
 "In": [
  null,
  "Inn"
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install cockpit-pcp": [
  null,
  "Installer cockpit-pcp"
 ],
 "Install software": [
  null,
  "Installer programvare"
 ],
 "Installing $0": [
  null,
  "Installerer $0"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Jump to": [
  null,
  "Gå til"
 ],
 "Laptop": [
  null,
  ""
 ],
 "Learn more": [
  null,
  "Lær mer"
 ],
 "Load": [
  null,
  "Last"
 ],
 "Load earlier data": [
  null,
  "Last tidligere data"
 ],
 "Load spike": [
  null,
  "Last-topp"
 ],
 "Loading...": [
  null,
  "Laster..."
 ],
 "Log out": [
  null,
  "Logg ut"
 ],
 "Low profile desktop": [
  null,
  ""
 ],
 "Lunch box": [
  null,
  "Lunsjboks"
 ],
 "Main server chassis": [
  null,
  ""
 ],
 "Memory": [
  null,
  "Minne"
 ],
 "Memory spike": [
  null,
  "Minne topp"
 ],
 "Memory usage": [
  null,
  "Minnebruk"
 ],
 "Metrics history could not be loaded": [
  null,
  ""
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Mini tower": [
  null,
  ""
 ],
 "Multi-system chassis": [
  null,
  ""
 ],
 "Network": [
  null,
  "Nettverk"
 ],
 "Network I/O": [
  null,
  "Nettverk I/U"
 ],
 "Network I/O spike": [
  null,
  "Nettverk I/O topp"
 ],
 "Network usage": [
  null,
  "Nettverksbruk"
 ],
 "No data available": [
  null,
  "Ingen data tilgjengelig"
 ],
 "No data available between $0 and $1": [
  null,
  "Ingen data tilgjengelig mellom $0 og $1"
 ],
 "No logs found": [
  null,
  "Ingen logger funnet"
 ],
 "Notebook": [
  null,
  ""
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  ""
 ],
 "Other": [
  null,
  "Annen"
 ],
 "Out": [
  null,
  "Ut"
 ],
 "Overview": [
  null,
  "Oversikt"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "Pakke cockpit-pcp mangler i metrikk-historikken"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit krasjet"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  ""
 ],
 "Peripheral chassis": [
  null,
  "Perifert chassis"
 ],
 "Pizza box": [
  null,
  "Pizzaboks"
 ],
 "Portable": [
  null,
  "Bærbar"
 ],
 "Present": [
  null,
  "Til stede"
 ],
 "RAID chassis": [
  null,
  "RAID chassis"
 ],
 "RAM": [
  null,
  "RAM"
 ],
 "Rack mount chassis": [
  null,
  ""
 ],
 "Read": [
  null,
  "Les"
 ],
 "Read more...": [
  null,
  "Les mer…"
 ],
 "Reboot": [
  null,
  "Omstart"
 ],
 "Removals:": [
  null,
  ""
 ],
 "Removing $0": [
  null,
  "Fjerner $0"
 ],
 "Save": [
  null,
  "Lagre"
 ],
 "Sealed-case PC": [
  null,
  ""
 ],
 "Service": [
  null,
  "Tjeneste"
 ],
 "Single rank": [
  null,
  ""
 ],
 "Space-saving computer": [
  null,
  "Plassbesparende datamaskin"
 ],
 "Stick PC": [
  null,
  ""
 ],
 "Sub-Chassis": [
  null,
  ""
 ],
 "Sub-Notebook": [
  null,
  ""
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Swap out": [
  null,
  "Swap ut"
 ],
 "Tablet": [
  null,
  "Nettbrett"
 ],
 "Today": [
  null,
  "I dag"
 ],
 "Top 5 CPU services": [
  null,
  "Topp 5 CPU-tjenester"
 ],
 "Top 5 memory services": [
  null,
  "Topp 5 minnetjenester"
 ],
 "Total size: $0": [
  null,
  "Total størrelse: $0"
 ],
 "Tower": [
  null,
  ""
 ],
 "Troubleshoot": [
  null,
  "Feilsøk"
 ],
 "Unknown": [
  null,
  "Ukjent"
 ],
 "Usage": [
  null,
  "Bruk"
 ],
 "Used": [
  null,
  "Brukt"
 ],
 "View per-disk throughput": [
  null,
  ""
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Venter på at andre programvareadministrasjons-operasjoner skal fullføres"
 ],
 "Write": [
  null,
  "Skriv"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  ""
 ],
 "Zone": [
  null,
  ""
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bytes med binære data]"
 ],
 "[binary data]": [
  null,
  "[binære data]"
 ],
 "[no data]": [
  null,
  "[ingen data]"
 ],
 "average: $0%": [
  null,
  ""
 ],
 "max: $0%": [
  null,
  ""
 ],
 "nice": [
  null,
  ""
 ],
 "pmlogger.service is failing to collect data": [
  null,
  ""
 ],
 "pod": [
  null,
  ""
 ],
 "show less": [
  null,
  "vis mindre"
 ],
 "show more": [
  null,
  "vis mer"
 ],
 "sys": [
  null,
  "sys"
 ],
 "user": [
  null,
  "bruker"
 ]
});
