cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 CPU-kärna",
  "$0 CPU-kärnor"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 available": [
  null,
  "$0 tillgängligt"
 ],
 "$0 free": [
  null,
  "$0 fritt"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 är inte tillgängligt från något förråd."
 ],
 "$0 page": [
  null,
  "$0 sida",
  "$0 sidor"
 ],
 "$0 total": [
  null,
  "$0 totalt"
 ],
 "$0 will be installed.": [
  null,
  "$0 kommer att installeras."
 ],
 "1 min": [
  null,
  "1 min"
 ],
 "15 min": [
  null,
  "15 min"
 ],
 "5 min": [
  null,
  "5 min"
 ],
 "Absent": [
  null,
  "Frånvarande"
 ],
 "Add $0": [
  null,
  "Lägg till $0"
 ],
 "Additional packages:": [
  null,
  "Ytterligare paket:"
 ],
 "Advanced TCA": [
  null,
  "Avancerad TCA"
 ],
 "All-in-one": [
  null,
  "Allt i ett"
 ],
 "Blade": [
  null,
  "Blad"
 ],
 "Blade enclosure": [
  null,
  "Bladhölje"
 ],
 "Bus expansion chassis": [
  null,
  "Bussexpansionschassi"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU spike": [
  null,
  "CPU-topp"
 ],
 "CPU usage": [
  null,
  "CPU-användning"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Checking installed software": [
  null,
  "Kontrollerar installerad programvara"
 ],
 "Collect metrics": [
  null,
  "Samla in mätvärden"
 ],
 "Compact PCI": [
  null,
  "Kompakt PCI"
 ],
 "Convertible": [
  null,
  "Konvertibel"
 ],
 "Core $0": [
  null,
  "Kärna $0"
 ],
 "Current top CPU usage": [
  null,
  "Aktuell högsta CPU-användning"
 ],
 "Desktop": [
  null,
  "Skrivbord"
 ],
 "Detachable": [
  null,
  "Frånkopplingsbar"
 ],
 "Device": [
  null,
  "Enhet"
 ],
 "Disk I/O": [
  null,
  "Disk-I/O"
 ],
 "Disk I/O spike": [
  null,
  "Disk-I/O-topp"
 ],
 "Disks": [
  null,
  "Diskar"
 ],
 "Disks usage": [
  null,
  "Diskanvändning"
 ],
 "Docking station": [
  null,
  "Dockningsstation"
 ],
 "Downloading $0": [
  null,
  "Hämtar $0"
 ],
 "Dual rank": [
  null,
  "Dubbelrad"
 ],
 "Embedded PC": [
  null,
  "Inbäddad PC"
 ],
 "Error has occurred": [
  null,
  "Fel har uppstått"
 ],
 "Event": [
  null,
  "Händelser"
 ],
 "Event logs": [
  null,
  "Händelseloggar"
 ],
 "Expansion chassis": [
  null,
  "Expansionschassin"
 ],
 "Export to network": [
  null,
  "Exportera till nätverk"
 ],
 "Failed to configure PCP": [
  null,
  "Misslyckades att konfigurera PCP"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Misslyckades med att aktivera $0 i firewalld"
 ],
 "Handheld": [
  null,
  "Handhållen"
 ],
 "In": [
  null,
  "In"
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Install cockpit-pcp": [
  null,
  "Installera cockpit-pcp"
 ],
 "Install software": [
  null,
  "Installera programvara"
 ],
 "Installing $0": [
  null,
  "Installerar $0"
 ],
 "Interface": [
  null,
  "Gränssnitt",
  "Gränssnitt"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Jump to": [
  null,
  "Hoppa till"
 ],
 "Laptop": [
  null,
  "Bärbar dator"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "Load": [
  null,
  "Ladda"
 ],
 "Load earlier data": [
  null,
  "Läs in tidigare data"
 ],
 "Load spike": [
  null,
  "Belastningstopp"
 ],
 "Loading...": [
  null,
  "Läser in …"
 ],
 "Log out": [
  null,
  "Logga ut"
 ],
 "Low profile desktop": [
  null,
  "Lågprofilskrivbord"
 ],
 "Lunch box": [
  null,
  "Lunchlåda"
 ],
 "Main server chassis": [
  null,
  "Huvudserverchassi"
 ],
 "Memory": [
  null,
  "Minne"
 ],
 "Memory spike": [
  null,
  "Minnestopp"
 ],
 "Memory usage": [
  null,
  "Minnesanvändning"
 ],
 "Metrics and history": [
  null,
  "Mått och historik"
 ],
 "Metrics history could not be loaded": [
  null,
  "Metrikhistoriken kunde inte läsas in"
 ],
 "Metrics settings": [
  null,
  "Måttinställningar"
 ],
 "Mini PC": [
  null,
  "Mini-PC"
 ],
 "Mini tower": [
  null,
  "Minitorn"
 ],
 "Multi-system chassis": [
  null,
  "Multisystemschassi"
 ],
 "Network": [
  null,
  "Nätverk"
 ],
 "Network I/O": [
  null,
  "Nätverks-I/O"
 ],
 "Network I/O spike": [
  null,
  "Nätverks-I/O-topp"
 ],
 "Network usage": [
  null,
  "Nätverksanvändning"
 ],
 "No data available": [
  null,
  "Ingen data tillgänglig"
 ],
 "No data available between $0 and $1": [
  null,
  "Ingen data tillgänglig mellan $0 och $1"
 ],
 "No logs found": [
  null,
  "Inga loggar hittades"
 ],
 "Notebook": [
  null,
  "Bärbar (notebook)"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "Öppna pmproxy-tjänsten i brandväggen för att dela mätvärden."
 ],
 "Other": [
  null,
  "Annan"
 ],
 "Out": [
  null,
  "Ut"
 ],
 "Overview": [
  null,
  "Översikt"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "Paketet cockpit-pcp saknas för statistikhistorik"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kraschade"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "Performance Co-Pilot samlar in och analyserar prestandamått från ditt system."
 ],
 "Peripheral chassis": [
  null,
  "Periferichassi"
 ],
 "Pizza box": [
  null,
  "Pizzalåda"
 ],
 "Portable": [
  null,
  "Bärbar"
 ],
 "Present": [
  null,
  "Närvarande"
 ],
 "RAID chassis": [
  null,
  "RAID-chassi"
 ],
 "RAM": [
  null,
  "RAM"
 ],
 "Rack mount chassis": [
  null,
  "Rackmonteringschassi"
 ],
 "Read": [
  null,
  "Läs"
 ],
 "Read more...": [
  null,
  "Läs mer..."
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Removals:": [
  null,
  "Borttagningar:"
 ],
 "Removing $0": [
  null,
  "Tar bort $0"
 ],
 "Save": [
  null,
  "Spara"
 ],
 "Sealed-case PC": [
  null,
  "PC med slutet hölje"
 ],
 "Service": [
  null,
  "Tjänst"
 ],
 "Single rank": [
  null,
  "Ensam ordning"
 ],
 "Space-saving computer": [
  null,
  "Utrymmessparande dator"
 ],
 "Stick PC": [
  null,
  "Pinndator"
 ],
 "Sub-Chassis": [
  null,
  "Under-chassi"
 ],
 "Sub-Notebook": [
  null,
  "ULPC"
 ],
 "Swap": [
  null,
  "Växlingsutrymme"
 ],
 "Swap out": [
  null,
  "Växla ut"
 ],
 "Tablet": [
  null,
  "Platta"
 ],
 "Today": [
  null,
  "Idag"
 ],
 "Top 5 CPU services": [
  null,
  "Topp 5 CPU-tjänster"
 ],
 "Top 5 memory services": [
  null,
  "Topp 5 minnestjänster"
 ],
 "Total size: $0": [
  null,
  "Total storlek: $0"
 ],
 "Tower": [
  null,
  "Torn"
 ],
 "Troubleshoot": [
  null,
  "Felsök"
 ],
 "Unknown": [
  null,
  "Okänd"
 ],
 "Usage": [
  null,
  "Användning"
 ],
 "Used": [
  null,
  "Använt"
 ],
 "View all CPUs": [
  null,
  "Visa alla processorer"
 ],
 "View all disks": [
  null,
  "Visa alla diskar"
 ],
 "View all logs": [
  null,
  "Visa alla loggar"
 ],
 "View detailed logs": [
  null,
  "Visa detaljerade loggar"
 ],
 "View per-disk throughput": [
  null,
  "Visa per disk genomströmning"
 ],
 "Visit firewall": [
  null,
  "Besök brandvägg"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Väntar på att andra programvaruhanteringsåtgärder skall bli klara"
 ],
 "Write": [
  null,
  "Skriv"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  "Man behöver logga in igen för att kunna se mätvärdeshistoriken"
 ],
 "Zone": [
  null,
  "Zon"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 byte med binärdata]"
 ],
 "[binary data]": [
  null,
  "[binärdata]"
 ],
 "[no data]": [
  null,
  "[inga data]"
 ],
 "average: $0%": [
  null,
  "genomsnitt: $0%"
 ],
 "cockpit-podman is not installed": [
  null,
  "cockpit-podman är inte installerat"
 ],
 "max: $0%": [
  null,
  "max: $0%"
 ],
 "nice": [
  null,
  "nice"
 ],
 "pmlogger.service has failed": [
  null,
  "pmlogger.service har misslyckats"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "pmlogger.service misslyckas att samla in data"
 ],
 "pmlogger.service is not running": [
  null,
  "pmlogger.service körs inte"
 ],
 "pod": [
  null,
  "kapsel"
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ],
 "sys": [
  null,
  "sys"
 ],
 "user": [
  null,
  "användare"
 ]
});
