cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 процесор",
  "$0 процесори",
  "$0 процесорів"
 ],
 "$0 GiB": [
  null,
  "$0 ГіБ"
 ],
 "$0 available": [
  null,
  "Доступно $0"
 ],
 "$0 free": [
  null,
  "Вільно $0"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 немає у жодному зі сховищ."
 ],
 "$0 page": [
  null,
  "$0 сторінка",
  "$0 сторінки",
  "$0 сторінок"
 ],
 "$0 total": [
  null,
  "Загалом $0"
 ],
 "$0 will be installed.": [
  null,
  "Буде встановлено $0."
 ],
 "1 min": [
  null,
  "1 хв."
 ],
 "15 min": [
  null,
  "15 хв."
 ],
 "5 min": [
  null,
  "5 хв."
 ],
 "Absent": [
  null,
  "Відсутній"
 ],
 "Add $0": [
  null,
  "Додати $0"
 ],
 "Additional packages:": [
  null,
  "Додаткові пакунки:"
 ],
 "Advanced TCA": [
  null,
  "Розширене TCA"
 ],
 "All-in-one": [
  null,
  "Усе в одному"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Обгортка Blade"
 ],
 "Bus expansion chassis": [
  null,
  "Апаратний блок розширення каналу"
 ],
 "CPU": [
  null,
  "Процесор"
 ],
 "CPU spike": [
  null,
  "Пік процесора"
 ],
 "CPU usage": [
  null,
  "Використання процесора"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Checking installed software": [
  null,
  "Перевіряємо встановлене програмне забезпечення"
 ],
 "Collect metrics": [
  null,
  "Зібрати метрику"
 ],
 "Compact PCI": [
  null,
  "Компактний PCI"
 ],
 "Convertible": [
  null,
  "Змінюваний"
 ],
 "Core $0": [
  null,
  "Ядро $0"
 ],
 "Current top CPU usage": [
  null,
  "Поточний рейтинг використання процесора"
 ],
 "Desktop": [
  null,
  "Робоча станція"
 ],
 "Detachable": [
  null,
  "Змінний"
 ],
 "Device": [
  null,
  "Пристрій"
 ],
 "Disk I/O": [
  null,
  "Дисковий ввід/вивід"
 ],
 "Disk I/O spike": [
  null,
  "Пік дискового введення-виведення"
 ],
 "Disks": [
  null,
  "Диски"
 ],
 "Disks usage": [
  null,
  "Використання дисків"
 ],
 "Docking station": [
  null,
  "Станція заряджання"
 ],
 "Downloading $0": [
  null,
  "Отримуємо $0"
 ],
 "Dual rank": [
  null,
  "Подвійний ранг"
 ],
 "Embedded PC": [
  null,
  "Вбудований ПК"
 ],
 "Error has occurred": [
  null,
  "Сталася помилка"
 ],
 "Event": [
  null,
  "Подія"
 ],
 "Event logs": [
  null,
  "Журнал подій"
 ],
 "Expansion chassis": [
  null,
  "Апаратний блок розширення"
 ],
 "Export to network": [
  null,
  "Експортувати до мережі"
 ],
 "Failed to configure PCP": [
  null,
  "Не вдалося налаштувати PCP"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Не вдалося увімкнути $0 у firewalld"
 ],
 "Handheld": [
  null,
  "Кишеньковий пристрій"
 ],
 "In": [
  null,
  "Вхід"
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Install cockpit-pcp": [
  null,
  "Встановити cockpit-pcp"
 ],
 "Install software": [
  null,
  "Встановити програмне забезпечення"
 ],
 "Installing $0": [
  null,
  "Встановлюємо $0"
 ],
 "Interface": [
  null,
  "Інтерфейс",
  "Інтерфейси",
  "Інтерфейси"
 ],
 "IoT gateway": [
  null,
  "Шлюз IoT"
 ],
 "Jump to": [
  null,
  "Перейти"
 ],
 "Laptop": [
  null,
  "Переносний ПК"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "Load": [
  null,
  "Завантажити"
 ],
 "Load earlier data": [
  null,
  "Завантажити попередні дані"
 ],
 "Load spike": [
  null,
  "Завантажити пік"
 ],
 "Loading...": [
  null,
  "Завантаження…"
 ],
 "Log out": [
  null,
  "Вийти"
 ],
 "Low profile desktop": [
  null,
  "Низькопрофільна робоча станція"
 ],
 "Lunch box": [
  null,
  "Пусковий комп'ютер"
 ],
 "Main server chassis": [
  null,
  "Апаратний блок основного сервера"
 ],
 "Memory": [
  null,
  "Пам'ять"
 ],
 "Memory spike": [
  null,
  "Пік пам'яті"
 ],
 "Memory usage": [
  null,
  "Використання пам'яті"
 ],
 "Metrics and history": [
  null,
  "Метрика і журнал"
 ],
 "Metrics history could not be loaded": [
  null,
  "Не вдалося завантажити журнал метрики"
 ],
 "Metrics settings": [
  null,
  "Параметри метрики"
 ],
 "Mini PC": [
  null,
  "Міні-ПК"
 ],
 "Mini tower": [
  null,
  "Міні-башточка"
 ],
 "Multi-system chassis": [
  null,
  "Багатосистемний апаратний блок"
 ],
 "Network": [
  null,
  "Мережа"
 ],
 "Network I/O": [
  null,
  "Вхід-вихід мережі"
 ],
 "Network I/O spike": [
  null,
  "Пік входу-виходу мережі"
 ],
 "Network usage": [
  null,
  "Використання мережі"
 ],
 "No data available": [
  null,
  "Немає доступним даних"
 ],
 "No data available between $0 and $1": [
  null,
  "Немає доступних даних між $0 і $1"
 ],
 "No logs found": [
  null,
  "Журналів не знайдено"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "Відкрити службу pmproxy у брандмауері для надання метрики у спільне користування."
 ],
 "Other": [
  null,
  "Інше"
 ],
 "Out": [
  null,
  "Вихід"
 ],
 "Overview": [
  null,
  "Огляд"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "Не вистачає пакунка cockpit-pcp для журналу метрики"
 ],
 "PackageKit crashed": [
  null,
  "Аварійне завершення роботи PackageKit"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "Co-Pilot швидкодіії збирає та аналізує метрику швидкодії вашої системи."
 ],
 "Peripheral chassis": [
  null,
  "Периферійний апаратний блок"
 ],
 "Pizza box": [
  null,
  "З коробку для піци"
 ],
 "Portable": [
  null,
  "Портативний"
 ],
 "Present": [
  null,
  "Поточна"
 ],
 "RAID chassis": [
  null,
  "Апаратний блок RAID"
 ],
 "RAM": [
  null,
  "Пам'ять"
 ],
 "Rack mount chassis": [
  null,
  "Апаратний блок монтування стійок"
 ],
 "Read": [
  null,
  "Читання"
 ],
 "Read more...": [
  null,
  "Докладніше…"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Removals:": [
  null,
  "Вилучення:"
 ],
 "Removing $0": [
  null,
  "Вилучаємо $0"
 ],
 "Save": [
  null,
  "Зберегти"
 ],
 "Sealed-case PC": [
  null,
  "ПК з опломбованим корпусом"
 ],
 "Service": [
  null,
  "Служба"
 ],
 "Single rank": [
  null,
  "Єдиний ранг"
 ],
 "Space-saving computer": [
  null,
  "Компактний комп'ютер"
 ],
 "Stick PC": [
  null,
  "Паличковий ПК"
 ],
 "Sub-Chassis": [
  null,
  "Підблок"
 ],
 "Sub-Notebook": [
  null,
  "Підноутбук"
 ],
 "Swap": [
  null,
  "Свопінґ"
 ],
 "Swap out": [
  null,
  "Резервування"
 ],
 "Tablet": [
  null,
  "Планшет"
 ],
 "Today": [
  null,
  "Сьогодні"
 ],
 "Top 5 CPU services": [
  null,
  "Основні 5 служб процесора"
 ],
 "Top 5 memory services": [
  null,
  "Основні 5 служб пам'яті"
 ],
 "Total size: $0": [
  null,
  "Загальний розмір: $0"
 ],
 "Tower": [
  null,
  "Башточка"
 ],
 "Troubleshoot": [
  null,
  "Діагностика проблем"
 ],
 "Unknown": [
  null,
  "Невідомий"
 ],
 "Usage": [
  null,
  "Використання"
 ],
 "Used": [
  null,
  "Використано"
 ],
 "View all CPUs": [
  null,
  "Переглянути усі процесори"
 ],
 "View all disks": [
  null,
  "Переглянути усі диски"
 ],
 "View all logs": [
  null,
  "Переглянути усі журнали"
 ],
 "View detailed logs": [
  null,
  "Переглянути докладні журнали"
 ],
 "View per-disk throughput": [
  null,
  "Переглянути пропускну здатність за дисками"
 ],
 "Visit firewall": [
  null,
  "Відвідати брандмауер"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Очікуємо на завершення інших дій із програмним забезпеченням"
 ],
 "Write": [
  null,
  "Запис"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  "Вам слід повторно увійти до системи, щоб мати змогу переглядати журнал метрики"
 ],
 "Zone": [
  null,
  "Зона"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 байтів двійкових даних]"
 ],
 "[binary data]": [
  null,
  "[двійкові дані]"
 ],
 "[no data]": [
  null,
  "[немає даних]"
 ],
 "average: $0%": [
  null,
  "середнє: $0%"
 ],
 "cockpit-podman is not installed": [
  null,
  "cockpit-podman не встановлено"
 ],
 "max: $0%": [
  null,
  "макс.: $0%"
 ],
 "nice": [
  null,
  "пріоритетність"
 ],
 "pmlogger.service has failed": [
  null,
  "помилка pmlogger.service"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "pmlogger.service не вдалося зібрати дані"
 ],
 "pmlogger.service is not running": [
  null,
  "pmlogger.service не запущено"
 ],
 "pod": [
  null,
  "кокон"
 ],
 "show less": [
  null,
  "показати менше"
 ],
 "show more": [
  null,
  "показати більше"
 ],
 "sys": [
  null,
  "sys"
 ],
 "user": [
  null,
  "користувач"
 ]
});
