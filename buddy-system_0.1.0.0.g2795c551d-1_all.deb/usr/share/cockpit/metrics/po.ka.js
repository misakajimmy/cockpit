cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 CPU",
  "$0 ცალი CPU"
 ],
 "$0 GiB": [
  null,
  "$0 გიბ"
 ],
 "$0 available": [
  null,
  "ხელმისაწვდომია $0"
 ],
 "$0 free": [
  null,
  "$0 თავისუფალი"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ხელმიუწვდომელია ყველა რეპოზიტორიიდან."
 ],
 "$0 page": [
  null,
  "$0 გვერდი",
  "$0 ცალი გვერდი"
 ],
 "$0 total": [
  null,
  "ჯამში $0"
 ],
 "$0 will be installed.": [
  null,
  "დაყენდება $0."
 ],
 "1 min": [
  null,
  "1 წთ"
 ],
 "15 min": [
  null,
  "15 წთ"
 ],
 "5 min": [
  null,
  "5 წთ"
 ],
 "Absent": [
  null,
  "აკლია"
 ],
 "Add $0": [
  null,
  "$0-ის დამატება"
 ],
 "Additional packages:": [
  null,
  "დამატებითი პაკეტები:"
 ],
 "Advanced TCA": [
  null,
  "დამატებითი TCA"
 ],
 "All-in-one": [
  null,
  "ყველა-ერთში"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "კალათი"
 ],
 "Bus expansion chassis": [
  null,
  "მატარებლის გაფართოების შასი"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU spike": [
  null,
  "CPU-ის პიკი"
 ],
 "CPU usage": [
  null,
  "CPU-ის გამოყენება"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Checking installed software": [
  null,
  "დაყენებული პროგრამული უზრუნველყოფის შემოწმება"
 ],
 "Collect metrics": [
  null,
  "მეტრიკების შეგროვება"
 ],
 "Compact PCI": [
  null,
  "კომპაქტური PCI"
 ],
 "Convertible": [
  null,
  "გარდაქმნადი"
 ],
 "Core $0": [
  null,
  "ბირთვი $0"
 ],
 "Current top CPU usage": [
  null,
  "CPU-ის მიმდინარე დატვირთვა"
 ],
 "Desktop": [
  null,
  "სამუშაო მაგიდა"
 ],
 "Detachable": [
  null,
  "მოძრობადი"
 ],
 "Device": [
  null,
  "მოწყობილობა"
 ],
 "Disk I/O": [
  null,
  "დისკის I/O"
 ],
 "Disk I/O spike": [
  null,
  "დისკის I/O-ის პიკი"
 ],
 "Disks": [
  null,
  "დისკები"
 ],
 "Disks usage": [
  null,
  "დისკების გამოყენება"
 ],
 "Docking station": [
  null,
  "სამაგრი დაფა"
 ],
 "Downloading $0": [
  null,
  "$0-ის გადმოწერა"
 ],
 "Dual rank": [
  null,
  "ორმაგი რანგი"
 ],
 "Embedded PC": [
  null,
  "ჩაშენებული PC"
 ],
 "Error has occurred": [
  null,
  "შეცდომა"
 ],
 "Event": [
  null,
  "მოვლენა"
 ],
 "Event logs": [
  null,
  "მოვლენების ჟურნალი"
 ],
 "Expansion chassis": [
  null,
  "გაფართოების კორპუსი"
 ],
 "Export to network": [
  null,
  "ქსელში გატანა"
 ],
 "Failed to configure PCP": [
  null,
  "PCP-ის მორგების შეცდომა"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld-ში $0-ის ჩართვის შეცდომა"
 ],
 "Handheld": [
  null,
  "ჯიბის"
 ],
 "In": [
  null,
  "შიგნით"
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Install cockpit-pcp": [
  null,
  "cockpt-pcp-ის დაყენება"
 ],
 "Install software": [
  null,
  "პროგრამების დაყენება"
 ],
 "Installing $0": [
  null,
  "$0-ის დაყენება"
 ],
 "Interface": [
  null,
  "ცალი ინტერფეისი",
  "ინტერფეისი"
 ],
 "IoT gateway": [
  null,
  "IoT gateway"
 ],
 "Jump to": [
  null,
  "გადასვლა"
 ],
 "Laptop": [
  null,
  "ლეპტოპი"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "Load": [
  null,
  "ჩატვირთვა"
 ],
 "Load earlier data": [
  null,
  "ადრინდელი მონაცემების ჩატვირთვა"
 ],
 "Load spike": [
  null,
  "დატვირთვის პიკი"
 ],
 "Loading...": [
  null,
  "ჩატვირთვა..."
 ],
 "Log out": [
  null,
  "გასვლა"
 ],
 "Low profile desktop": [
  null,
  "დაბალი პროფილის სამუშაო მაგიდა"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "სერვერის მთავარი შასი"
 ],
 "Memory": [
  null,
  "მეხსიერება"
 ],
 "Memory spike": [
  null,
  "მეხსიერების პიკი"
 ],
 "Memory usage": [
  null,
  "მეხსიერების გამოყენება"
 ],
 "Metrics and history": [
  null,
  "გრაფიკების და ისტორიის ნახვა"
 ],
 "Metrics history could not be loaded": [
  null,
  "მეტრიკების ისტორიის ჩატვირთვის შეცდომა"
 ],
 "Metrics settings": [
  null,
  "მეტრიკების მორგება"
 ],
 "Mini PC": [
  null,
  "მინი PC"
 ],
 "Mini tower": [
  null,
  "კომპიუტერი პატარა ყუთით"
 ],
 "Multi-system chassis": [
  null,
  "მრავალსისტემიანი ყუთი"
 ],
 "Network": [
  null,
  "ქსელი"
 ],
 "Network I/O": [
  null,
  "ქსელური I/O"
 ],
 "Network I/O spike": [
  null,
  "ქსელის I/O პიკი"
 ],
 "Network usage": [
  null,
  "ქსელის გამოყენება"
 ],
 "No data available": [
  null,
  "მონაცემები ხელმიუწვდომელია"
 ],
 "No data available between $0 and $1": [
  null,
  "$0-დან $1-მდე მონაცემები ნაპოვნი არაა"
 ],
 "No logs found": [
  null,
  "ჟურნალი ცარიელია"
 ],
 "Notebook": [
  null,
  "ნოუთბუქი"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "მეტრიკების გასაზიარებლად ბრანდმაუერში გახსენით pmproxy-ის სერვისი."
 ],
 "Other": [
  null,
  "სხვა"
 ],
 "Out": [
  null,
  "გარე"
 ],
 "Overview": [
  null,
  "გადახედვა"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "მეტრიკების ისტორიაში პაკეტი cockpit-pcp არ არსებობს"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit-ის ავარია"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "წარმადობის Co-Pilot-ი აგროვებს და აანალიზებს თქვენი სისტემის წარმადობის მეტრიკებს."
 ],
 "Peripheral chassis": [
  null,
  "გარე კორპუსი"
 ],
 "Pizza box": [
  null,
  "პიცისყუთი"
 ],
 "Portable": [
  null,
  "გადატანადი"
 ],
 "Present": [
  null,
  "წარმოდგენილია"
 ],
 "RAID chassis": [
  null,
  "RAID კალათი"
 ],
 "RAM": [
  null,
  "RAM"
 ],
 "Rack mount chassis": [
  null,
  "რეკში ჩასადგმელი შასი"
 ],
 "Read": [
  null,
  "წაკითხვა"
 ],
 "Read more...": [
  null,
  "მეტის წაკითხვა..."
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Removals:": [
  null,
  "წაიშლება:"
 ],
 "Removing $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "Sealed-case PC": [
  null,
  "დალუქული PC"
 ],
 "Service": [
  null,
  "სერვისი"
 ],
 "Single rank": [
  null,
  "ერთრანგიანი"
 ],
 "Space-saving computer": [
  null,
  "პატარა ზომის კომპიუტერი"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Sub-Chassis": [
  null,
  "ქვე-კორპუსი"
 ],
 "Sub-Notebook": [
  null,
  "ქვე-ნოუთბუქი"
 ],
 "Swap": [
  null,
  "სვაპი"
 ],
 "Swap out": [
  null,
  "გამოყენებული სვაპი"
 ],
 "Tablet": [
  null,
  "ტაბლეტი"
 ],
 "Today": [
  null,
  "დღეს"
 ],
 "Top 5 CPU services": [
  null,
  "ყველაზე მეტი CPU-ის მხარჯავი 5 სერვისი"
 ],
 "Top 5 memory services": [
  null,
  "ყველაზე მეტი მეხსიერების მხარჯავი 5 სერვისი"
 ],
 "Total size: $0": [
  null,
  "ჯამური ზომა: $0"
 ],
 "Tower": [
  null,
  "კომპიუტერის კორპუსი"
 ],
 "Troubleshoot": [
  null,
  "პრობლემების გადაწყვეტა"
 ],
 "Unknown": [
  null,
  "უცნობი"
 ],
 "Usage": [
  null,
  "გამოყენება"
 ],
 "Used": [
  null,
  "გამოყენებულია"
 ],
 "View all CPUs": [
  null,
  "ყველა პროცესორის ნახვა"
 ],
 "View all disks": [
  null,
  "ყველა დისკის ნახვა"
 ],
 "View all logs": [
  null,
  "ყველა ჟურნალის ნახვა"
 ],
 "View detailed logs": [
  null,
  "დეტალური ჟურნალის ნახვა"
 ],
 "View per-disk throughput": [
  null,
  "დისკების მიმოცვლის სათითაოდ ნახვა"
 ],
 "Visit firewall": [
  null,
  "ბრანდმაუერზე გადასვლა"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "პროგრამების მართვის სხვა ოპერაციების დასრულების მოლოდინი"
 ],
 "Write": [
  null,
  "ჩაწერა"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  "მეტრიკის ისტორიის სანახავად საჭიროა ავტორიზაცია"
 ],
 "Zone": [
  null,
  "ზონა"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[ბინარული მონაცემების $0 ბაიტი]"
 ],
 "[binary data]": [
  null,
  "[ბინარული მონაცემები]"
 ],
 "[no data]": [
  null,
  "[მონაცემების გარეშე]"
 ],
 "average: $0%": [
  null,
  "საშუალო: $0%"
 ],
 "cockpit-podman is not installed": [
  null,
  "Cockpit-podman-ი დაყენებული არაა"
 ],
 "max: $0%": [
  null,
  "მაქს: $0%"
 ],
 "nice": [
  null,
  "პრიორიტეტი"
 ],
 "pmlogger.service has failed": [
  null,
  "pmlogger.service-ის შეცდომა"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "pmlogger.service-ის შეცდომა მონაცემების შეგროვებისას"
 ],
 "pmlogger.service is not running": [
  null,
  "pmlogger.service გაშვებული არაა"
 ],
 "pod": [
  null,
  "pod"
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ],
 "sys": [
  null,
  "sys"
 ],
 "user": [
  null,
  "მომხმარებელი"
 ]
});
