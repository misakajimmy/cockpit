cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 CPU"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 available": [
  null,
  "$0 利用可能"
 ],
 "$0 free": [
  null,
  "$0 空き"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 は、あらゆるリポジトリーから利用できません。"
 ],
 "$0 page": [
  null,
  "$0 ページ"
 ],
 "$0 total": [
  null,
  "$0 合計"
 ],
 "$0 will be installed.": [
  null,
  "$0 がインストールされます。"
 ],
 "1 min": [
  null,
  "1 分"
 ],
 "15 min": [
  null,
  "15 分"
 ],
 "5 min": [
  null,
  "5 分"
 ],
 "Absent": [
  null,
  "不在"
 ],
 "Add $0": [
  null,
  "$0 を追加する"
 ],
 "Additional packages:": [
  null,
  "追加のパッケージ:"
 ],
 "Advanced TCA": [
  null,
  "高度な TCA"
 ],
 "All-in-one": [
  null,
  "オールインワン"
 ],
 "Blade": [
  null,
  "ブレード"
 ],
 "Blade enclosure": [
  null,
  "ブレードエンクロージャー"
 ],
 "Bus expansion chassis": [
  null,
  "バス拡張シャーシ"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU spike": [
  null,
  "cpu スパイク"
 ],
 "CPU usage": [
  null,
  "CPU 使用率"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Checking installed software": [
  null,
  "インストールされたソフトウェアの確認中"
 ],
 "Collect metrics": [
  null,
  "メトリックスの収集"
 ],
 "Compact PCI": [
  null,
  "PCI の圧縮"
 ],
 "Convertible": [
  null,
  "変換可能"
 ],
 "Core $0": [
  null,
  "コア $0"
 ],
 "Current top CPU usage": [
  null,
  "現在の CPU 使用率のトップ"
 ],
 "Desktop": [
  null,
  "デスクトップ"
 ],
 "Detachable": [
  null,
  "割り当て解除可能"
 ],
 "Device": [
  null,
  "デバイス"
 ],
 "Disk I/O": [
  null,
  "ディスク I/O"
 ],
 "Disk I/O spike": [
  null,
  "ディスク I/O スパイク"
 ],
 "Disks": [
  null,
  "ディスク"
 ],
 "Docking station": [
  null,
  "ドッキングステーション"
 ],
 "Downloading $0": [
  null,
  "$0 をダウンロード中"
 ],
 "Dual rank": [
  null,
  "デュアルランク"
 ],
 "Embedded PC": [
  null,
  "組み込み PC"
 ],
 "Error has occurred": [
  null,
  "エラーが発生しました"
 ],
 "Event": [
  null,
  "イベント"
 ],
 "Event logs": [
  null,
  "イベントログ"
 ],
 "Expansion chassis": [
  null,
  "拡張シャーシ"
 ],
 "Export to network": [
  null,
  "ネットワークへエクスポート"
 ],
 "Failed to configure PCP": [
  null,
  "PCP の設定に失敗しました"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "firewalld での $0 の有効化に失敗しました"
 ],
 "Handheld": [
  null,
  "ハンドヘルド"
 ],
 "In": [
  null,
  "内"
 ],
 "Install": [
  null,
  "インストール"
 ],
 "Install cockpit-pcp": [
  null,
  "cockpit-pcp をインストールする"
 ],
 "Install software": [
  null,
  "ソフトウェアをインストール"
 ],
 "Installing $0": [
  null,
  "$0 をインストール中"
 ],
 "Interface": [
  null,
  "インターフェース"
 ],
 "IoT gateway": [
  null,
  "IoT ゲートウェイ"
 ],
 "Jump to": [
  null,
  "次にジャンプ"
 ],
 "Laptop": [
  null,
  "ラップトップ"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "Load": [
  null,
  "ロード"
 ],
 "Load earlier data": [
  null,
  "以前のデータのロード"
 ],
 "Load spike": [
  null,
  "スパイクのロード"
 ],
 "Loading...": [
  null,
  "ロード中..."
 ],
 "Log out": [
  null,
  "ログアウト"
 ],
 "Low profile desktop": [
  null,
  "低プロファイルデスクトップ"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "メインサーバーシャーシ"
 ],
 "Memory": [
  null,
  "メモリ"
 ],
 "Memory spike": [
  null,
  "メモリーのスパイク"
 ],
 "Memory usage": [
  null,
  "メモリー使用状況"
 ],
 "Metrics and history": [
  null,
  "メトリックスおよび履歴"
 ],
 "Metrics history could not be loaded": [
  null,
  "メトリックス履歴をロードできませんでした"
 ],
 "Metrics settings": [
  null,
  "メトリックス設定"
 ],
 "Mini PC": [
  null,
  "ミニ PC"
 ],
 "Mini tower": [
  null,
  "ミニタワー"
 ],
 "Multi-system chassis": [
  null,
  "マルチシステムシャーシ"
 ],
 "Network": [
  null,
  "ネットワーク"
 ],
 "Network I/O": [
  null,
  "ネットワーク I/O"
 ],
 "Network I/O spike": [
  null,
  "ネットワーク I/O スパイク"
 ],
 "Network usage": [
  null,
  "ネットワーク使用量"
 ],
 "No data available": [
  null,
  "利用可能なデータなし"
 ],
 "No data available between $0 and $1": [
  null,
  "$0 と $1 間で利用できるデータなし"
 ],
 "No logs found": [
  null,
  "ログが見つかりません"
 ],
 "Notebook": [
  null,
  "ノートブック"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "ファイアウォールで pmproxy サービスを開き、メトリックを共有します。"
 ],
 "Other": [
  null,
  "その他"
 ],
 "Out": [
  null,
  "外"
 ],
 "Overview": [
  null,
  "概要"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "メトリックス履歴に、パッケージ cockpit-pcp がありません"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit がクラッシュしました"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "パフォーマンス Co-Pilot は、お使いのシステムからパフォーマンスメトリックスを収集して分析します。"
 ],
 "Peripheral chassis": [
  null,
  "周辺機器シャーシ"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Portable": [
  null,
  "ポータブル"
 ],
 "Present": [
  null,
  "存在"
 ],
 "RAID chassis": [
  null,
  "RAID シャーシ"
 ],
 "RAM": [
  null,
  "RAM"
 ],
 "Rack mount chassis": [
  null,
  "ラックマウントシャーシ"
 ],
 "Read": [
  null,
  "読み取り"
 ],
 "Read more...": [
  null,
  "さらに読む..."
 ],
 "Reboot": [
  null,
  "再起動"
 ],
 "Removals:": [
  null,
  "削除:"
 ],
 "Removing $0": [
  null,
  "$0 を削除中"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Sealed-case PC": [
  null,
  "シールドケース PC"
 ],
 "Service": [
  null,
  "サービス"
 ],
 "Single rank": [
  null,
  "シングルランク"
 ],
 "Space-saving computer": [
  null,
  "省スペースコンピューター"
 ],
 "Stick PC": [
  null,
  "スティッキー PC"
 ],
 "Sub-Chassis": [
  null,
  "サブシャーシ"
 ],
 "Sub-Notebook": [
  null,
  "サブノート"
 ],
 "Swap": [
  null,
  "スワップ"
 ],
 "Swap out": [
  null,
  "スワップアウト"
 ],
 "Tablet": [
  null,
  "タブレット"
 ],
 "Today": [
  null,
  "今日"
 ],
 "Top 5 CPU services": [
  null,
  "上位 5 CPU サービス"
 ],
 "Top 5 memory services": [
  null,
  "上位 5 メモリーサービス"
 ],
 "Total size: $0": [
  null,
  "合計サイズ: $0"
 ],
 "Tower": [
  null,
  "タワー"
 ],
 "Troubleshoot": [
  null,
  "トラブルシュート"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Usage": [
  null,
  "使用率"
 ],
 "Used": [
  null,
  "使用済み"
 ],
 "View all CPUs": [
  null,
  "すべての CPU を表示する"
 ],
 "View all logs": [
  null,
  "すべてのログの表示"
 ],
 "View detailed logs": [
  null,
  "詳細なログを表示する"
 ],
 "View per-disk throughput": [
  null,
  ""
 ],
 "Visit firewall": [
  null,
  "ファイアウォールへのアクセス"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "他のソフトウェア管理オペレーションが終了するまで待機中"
 ],
 "Write": [
  null,
  "書き込み"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  "メトリックス履歴を表示するには、ログインし直す必要があります"
 ],
 "Zone": [
  null,
  "ゾーン"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[バイナリーデータの $0 バイト]"
 ],
 "[binary data]": [
  null,
  "[バイナリーデータ]"
 ],
 "[no data]": [
  null,
  "[データなし]"
 ],
 "average: $0%": [
  null,
  "平均: $0%"
 ],
 "cockpit-podman is not installed": [
  null,
  "cockpit-podman がインストールされていません"
 ],
 "max: $0%": [
  null,
  "最大: $0%"
 ],
 "nice": [
  null,
  "Nice 値"
 ],
 "pmlogger.service has failed": [
  null,
  "pmlogger.service が失敗しました"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "pmlogger.service がデータの収集に失敗しました"
 ],
 "pmlogger.service is not running": [
  null,
  "pmlogger.service サービスが実行されていません"
 ],
 "pod": [
  null,
  "Pod"
 ],
 "show less": [
  null,
  "簡易表示"
 ],
 "show more": [
  null,
  "詳細表示"
 ],
 "sys": [
  null,
  "sys"
 ],
 "user": [
  null,
  "ユーザー"
 ]
});
