cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 procesor",
  "$0 procesory",
  "$0 procesorów"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 available": [
  null,
  "$0 dostępne"
 ],
 "$0 free": [
  null,
  "$0 wolne"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie jest dostępne w żadnym repozytorium."
 ],
 "$0 page": [
  null,
  "$0 strona",
  "$0 strony",
  "$0 stron"
 ],
 "$0 total": [
  null,
  "$0 razem"
 ],
 "$0 will be installed.": [
  null,
  "$0 zostanie zainstalowane."
 ],
 "1 min": [
  null,
  "1 minuta"
 ],
 "15 min": [
  null,
  "15 minut"
 ],
 "5 min": [
  null,
  "5 minut"
 ],
 "Absent": [
  null,
  "Nieobecne"
 ],
 "Add $0": [
  null,
  "Dodaj $0"
 ],
 "Additional packages:": [
  null,
  "Dodatkowe pakiety:"
 ],
 "Advanced TCA": [
  null,
  "Zaawansowane TCA"
 ],
 "All-in-one": [
  null,
  "Wszystko w jednym"
 ],
 "Blade": [
  null,
  "Kasetowy"
 ],
 "Blade enclosure": [
  null,
  "Obudowa kasetowa"
 ],
 "Bus expansion chassis": [
  null,
  "Obudowa rozszerzenia magistrali"
 ],
 "CPU": [
  null,
  "Procesor"
 ],
 "CPU spike": [
  null,
  "Szczyt procesora"
 ],
 "CPU usage": [
  null,
  "Użycie procesora"
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Checking installed software": [
  null,
  "Sprawdzanie zainstalowanego oprogramowania"
 ],
 "Collect metrics": [
  null,
  "Zbieraj statystyki"
 ],
 "Compact PCI": [
  null,
  "Kompaktowe PCI"
 ],
 "Convertible": [
  null,
  "2 w jednym"
 ],
 "Core $0": [
  null,
  "$0. rdzeń"
 ],
 "Current top CPU usage": [
  null,
  "Obecnie najwyższe użycie procesora"
 ],
 "Desktop": [
  null,
  "Komputer stacjonarny"
 ],
 "Detachable": [
  null,
  "Odłączalny"
 ],
 "Device": [
  null,
  "Urządzenie"
 ],
 "Disk I/O": [
  null,
  "Wejście/wyjście dysku"
 ],
 "Disk I/O spike": [
  null,
  "Szczyt wejścia/wyjścia dysku"
 ],
 "Disks": [
  null,
  "Dyski"
 ],
 "Disks usage": [
  null,
  "Użycie dysków"
 ],
 "Docking station": [
  null,
  "Stacja dokująca"
 ],
 "Downloading $0": [
  null,
  "Pobieranie $0"
 ],
 "Dual rank": [
  null,
  "Podwójny stopień"
 ],
 "Embedded PC": [
  null,
  "Komputer osadzony"
 ],
 "Error has occurred": [
  null,
  "Wystąpił błąd"
 ],
 "Event": [
  null,
  "Zdarzenie"
 ],
 "Event logs": [
  null,
  "Dzienniki zdarzeń"
 ],
 "Expansion chassis": [
  null,
  "Obudowa rozszerzenia"
 ],
 "Export to network": [
  null,
  "Eksport do sieci"
 ],
 "Failed to configure PCP": [
  null,
  "Skonfigurowanie PCP się nie powiodło"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Włączenie $0 w usłudze firewalld się nie powiodło"
 ],
 "Handheld": [
  null,
  "Przenośny"
 ],
 "In": [
  null,
  "Wejście"
 ],
 "Install": [
  null,
  "Zainstaluj"
 ],
 "Install cockpit-pcp": [
  null,
  "Zainstaluj cockpit-pcp"
 ],
 "Install software": [
  null,
  "Zainstaluj oprogramowanie"
 ],
 "Installing $0": [
  null,
  "Instalowanie $0"
 ],
 "Interface": [
  null,
  "Interfejs",
  "Interfejsy",
  "Interfejsy"
 ],
 "IoT gateway": [
  null,
  "Brama IoT"
 ],
 "Jump to": [
  null,
  "Przejdź do"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Learn more": [
  null,
  "Więcej informacji"
 ],
 "Load": [
  null,
  "Obciążenie"
 ],
 "Load earlier data": [
  null,
  "Wczytaj wcześniejsze dane"
 ],
 "Load spike": [
  null,
  "Szczyt obciążenia"
 ],
 "Loading...": [
  null,
  "Wczytywanie…"
 ],
 "Log out": [
  null,
  "Wyloguj"
 ],
 "Low profile desktop": [
  null,
  "Komputer stacjonarny o mniejszym rozmiarze"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Główna obudowa serwera"
 ],
 "Memory": [
  null,
  "Pamięć"
 ],
 "Memory spike": [
  null,
  "Szczyt pamięci"
 ],
 "Memory usage": [
  null,
  "Użycie pamięci"
 ],
 "Metrics and history": [
  null,
  "Statystyki i historia"
 ],
 "Metrics history could not be loaded": [
  null,
  "Nie można wczytać historii statystyk"
 ],
 "Metrics settings": [
  null,
  "Ustawienia statystyk"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Multi-system chassis": [
  null,
  "Obudowa dla wielu komputerów"
 ],
 "Network": [
  null,
  "Sieć"
 ],
 "Network I/O": [
  null,
  "Wejście/wyjście sieci"
 ],
 "Network I/O spike": [
  null,
  "Szczyt wejścia/wyjścia sieci"
 ],
 "Network usage": [
  null,
  "Użycie sieci"
 ],
 "No data available": [
  null,
  "Brak dostępnych danych"
 ],
 "No data available between $0 and $1": [
  null,
  "Brak dostępnych danych między $0 a $1"
 ],
 "No logs found": [
  null,
  "Nie odnaleziono dzienników"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "Należy otworzyć usługę pmproxy w zaporze sieciowej, aby udostępniać statystyki."
 ],
 "Other": [
  null,
  "Inne"
 ],
 "Out": [
  null,
  "Wyjście"
 ],
 "Overview": [
  null,
  "Przegląd"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "Brak pakietu „cockpit-pcp” dla historii statystyk"
 ],
 "PackageKit crashed": [
  null,
  "Usługa PackageKit uległa awarii"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "Performance Co-Pilot zbiera i analizuje statystyki wydajności komputera."
 ],
 "Peripheral chassis": [
  null,
  "Obudowa peryferyjna"
 ],
 "Pizza box": [
  null,
  "Pizza box"
 ],
 "Portable": [
  null,
  "Przenośne"
 ],
 "Present": [
  null,
  "Obecne"
 ],
 "RAID chassis": [
  null,
  "Obudowa RAID"
 ],
 "RAM": [
  null,
  "RAM"
 ],
 "Rack mount chassis": [
  null,
  "Obudowa do montowania w szafie"
 ],
 "Read": [
  null,
  "Odczyt"
 ],
 "Read more...": [
  null,
  "Więcej informacji…"
 ],
 "Reboot": [
  null,
  "Uruchom ponownie"
 ],
 "Removals:": [
  null,
  "Usuwane:"
 ],
 "Removing $0": [
  null,
  "Usuwanie $0"
 ],
 "Save": [
  null,
  "Zapisz"
 ],
 "Sealed-case PC": [
  null,
  "Sealed-case PC"
 ],
 "Service": [
  null,
  "Usługa"
 ],
 "Single rank": [
  null,
  "Pojedynczy stopień"
 ],
 "Space-saving computer": [
  null,
  "Komputer oszczędzający miejsce"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Sub-Chassis": [
  null,
  "Obudowa podrzędna"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Swap": [
  null,
  "Partycja wymiany"
 ],
 "Swap out": [
  null,
  "Wyjście przestrzeni wymiany"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Today": [
  null,
  "Dzisiaj"
 ],
 "Top 5 CPU services": [
  null,
  "Top 5 usług obciążających procesor"
 ],
 "Top 5 memory services": [
  null,
  "Top 5 usług obciążających pamięć"
 ],
 "Total size: $0": [
  null,
  "Całkowity rozmiar: $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Troubleshoot": [
  null,
  "Rozwiązywanie problemów"
 ],
 "Unknown": [
  null,
  "Nieznane"
 ],
 "Usage": [
  null,
  "Użycie"
 ],
 "Used": [
  null,
  "Używane"
 ],
 "View all CPUs": [
  null,
  "Wszystkie procesory"
 ],
 "View all disks": [
  null,
  "Wszystkie dyski"
 ],
 "View all logs": [
  null,
  "Wszystkie dzienniki"
 ],
 "View detailed logs": [
  null,
  "Szczegółowe dzienniki"
 ],
 "View per-disk throughput": [
  null,
  "Przepustowość każdego dysku"
 ],
 "Visit firewall": [
  null,
  "Otwórz zaporę sieciową"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Oczekiwanie na ukończenie pozostałych działań zarządzania oprogramowaniem"
 ],
 "Write": [
  null,
  "Zapis"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  "Aby wyświetlić historię statystyk, należy się zalogować ponownie"
 ],
 "Zone": [
  null,
  "Strefa"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 B danych binarnych]"
 ],
 "[binary data]": [
  null,
  "[dane binarne]"
 ],
 "[no data]": [
  null,
  "[brak danych]"
 ],
 "average: $0%": [
  null,
  "średnia: $0%"
 ],
 "cockpit-podman is not installed": [
  null,
  "cockpit-podman nie jest zainstalowane"
 ],
 "max: $0%": [
  null,
  "maksymalnie: $0%"
 ],
 "nice": [
  null,
  "nice"
 ],
 "pmlogger.service has failed": [
  null,
  "pmlogger.service się nie powiodło"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "pmlogger.service nie może zbierać danych"
 ],
 "pmlogger.service is not running": [
  null,
  "pmlogger.service nie jest uruchomione"
 ],
 "pod": [
  null,
  "pojemnik"
 ],
 "show less": [
  null,
  "wyświetl mniej"
 ],
 "show more": [
  null,
  "wyświetl więcej"
 ],
 "sys": [
  null,
  "sys"
 ],
 "user": [
  null,
  "użytkownik"
 ]
});
