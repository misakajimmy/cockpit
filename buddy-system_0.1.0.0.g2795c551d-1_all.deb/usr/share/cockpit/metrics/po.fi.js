cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 CPU",
  "$0 CPU:ta"
 ],
 "$0 GiB": [
  null,
  "$0 Git"
 ],
 "$0 available": [
  null,
  "$0 käytettävissä"
 ],
 "$0 free": [
  null,
  "$0 vapaa"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ei ole saatavilla mistään ohjelmistovarastosta."
 ],
 "$0 page": [
  null,
  "$0 sivu",
  "$0 sivua"
 ],
 "$0 total": [
  null,
  "$0 yhteensä"
 ],
 "$0 will be installed.": [
  null,
  "$0 asennetaan."
 ],
 "1 min": [
  null,
  "1 min"
 ],
 "15 min": [
  null,
  "15 min"
 ],
 "5 min": [
  null,
  "5 min"
 ],
 "Absent": [
  null,
  "Poissa"
 ],
 "Add $0": [
  null,
  "Lisää $0"
 ],
 "Additional packages:": [
  null,
  "Ylimääräiset paketit:"
 ],
 "Advanced TCA": [
  null,
  "Edistynyt TCA"
 ],
 "All-in-one": [
  null,
  "Kaikki yhdessä"
 ],
 "Blade": [
  null,
  "Terä"
 ],
 "Blade enclosure": [
  null,
  "Teräkotelo"
 ],
 "Bus expansion chassis": [
  null,
  "Väylän laajennusalusta"
 ],
 "CPU": [
  null,
  "Suoritin"
 ],
 "CPU spike": [
  null,
  "CPU-piikki"
 ],
 "CPU usage": [
  null,
  "Suorittimen käyttö"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Checking installed software": [
  null,
  "Tarkistetaan asennettu ohjelmisto"
 ],
 "Collect metrics": [
  null,
  "Kerää mittarit"
 ],
 "Compact PCI": [
  null,
  "Kompakti PCI"
 ],
 "Convertible": [
  null,
  "Muunnettavissa"
 ],
 "Core $0": [
  null,
  "Ydin $0"
 ],
 "Current top CPU usage": [
  null,
  "Nykyinen korkein suoritinten käyttö"
 ],
 "Desktop": [
  null,
  "Työpöytä"
 ],
 "Detachable": [
  null,
  "Irrotettava"
 ],
 "Device": [
  null,
  "Laite"
 ],
 "Disk I/O": [
  null,
  "Levyn I/O"
 ],
 "Disk I/O spike": [
  null,
  "Levyn I/O -piikki"
 ],
 "Disks": [
  null,
  "Levyt"
 ],
 "Disks usage": [
  null,
  "Levyjen käyttö"
 ],
 "Docking station": [
  null,
  "Telakka"
 ],
 "Downloading $0": [
  null,
  "Ladataan $0"
 ],
 "Dual rank": [
  null,
  "Kaksinkertainen sijoitus"
 ],
 "Embedded PC": [
  null,
  "Sulautettu tietokone"
 ],
 "Error has occurred": [
  null,
  "Tapahtui virhe"
 ],
 "Event": [
  null,
  "Tapahtuma"
 ],
 "Event logs": [
  null,
  "Tapahtumalokeja"
 ],
 "Expansion chassis": [
  null,
  "Laajennusrunko"
 ],
 "Export to network": [
  null,
  "Vie verkkoon"
 ],
 "Failed to configure PCP": [
  null,
  "PCP:n määritys epäonnistui"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0:n käyttöönotto firewalld:ssä epäonnistui"
 ],
 "Handheld": [
  null,
  "Kädessä pidettävä"
 ],
 "In": [
  null,
  "Sisään"
 ],
 "Install": [
  null,
  "Asennus"
 ],
 "Install cockpit-pcp": [
  null,
  "Asenna cockpit-pcp"
 ],
 "Install software": [
  null,
  "Asennetaan ohjelmistoja"
 ],
 "Installing $0": [
  null,
  "Asennetaan $0"
 ],
 "Interface": [
  null,
  "Liitäntä",
  "Liitännät"
 ],
 "IoT gateway": [
  null,
  "IoT -yhdyskäytävä"
 ],
 "Jump to": [
  null,
  "Hyppää päiväykseen"
 ],
 "Laptop": [
  null,
  "Kannettava"
 ],
 "Learn more": [
  null,
  "Opi lisää"
 ],
 "Load": [
  null,
  "Kuormitus"
 ],
 "Load earlier data": [
  null,
  "Lataa aiemmat tiedot"
 ],
 "Load spike": [
  null,
  "Kuormapiikki"
 ],
 "Loading...": [
  null,
  "Ladataan..."
 ],
 "Log out": [
  null,
  "Kirjaudu ulos"
 ],
 "Low profile desktop": [
  null,
  "Matalan tason työpöytä"
 ],
 "Lunch box": [
  null,
  "Eväslaatikko"
 ],
 "Main server chassis": [
  null,
  "Pääpalvelimen runko"
 ],
 "Memory": [
  null,
  "Muisti"
 ],
 "Memory spike": [
  null,
  "Muistipiikki"
 ],
 "Memory usage": [
  null,
  "Muistin käyttö"
 ],
 "Metrics and history": [
  null,
  "Mittarit ja historia"
 ],
 "Metrics history could not be loaded": [
  null,
  "Mittaushistoriaa ei voitu ladata"
 ],
 "Metrics settings": [
  null,
  "Mittareiden asetukset"
 ],
 "Mini PC": [
  null,
  "Minitietokone"
 ],
 "Mini tower": [
  null,
  "Minitorni"
 ],
 "Multi-system chassis": [
  null,
  "Monijärjestelmäinen alusta"
 ],
 "Network": [
  null,
  "Verkko"
 ],
 "Network I/O": [
  null,
  "Verkon I/O"
 ],
 "Network I/O spike": [
  null,
  "Verkon I/O -piikki"
 ],
 "Network usage": [
  null,
  "Verkon käyttö"
 ],
 "No data available": [
  null,
  "Ei tietoja saatavilla"
 ],
 "No data available between $0 and $1": [
  null,
  "Tietoja ei ole saatavilla välillä $0 ja $1"
 ],
 "No logs found": [
  null,
  "Ei löytynyt lokeja"
 ],
 "Notebook": [
  null,
  "Muistikirja"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "Avaa pmproxy-palvelu palomuurissa jakaaksesi mittaustietoja."
 ],
 "Other": [
  null,
  "Muu"
 ],
 "Out": [
  null,
  "Ulos"
 ],
 "Overview": [
  null,
  "Esittely"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "Paketti cockpit-pcp puuttuu, mittarihistoriaa ei voida näyttää"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kaatui"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "Performance Co-Pilot kerää ja analysoi suorituskykymittareita järjestelmästäsi."
 ],
 "Peripheral chassis": [
  null,
  "Lisälaitteen kotelo"
 ],
 "Pizza box": [
  null,
  "Pizza-laatikko"
 ],
 "Portable": [
  null,
  "Kannettava"
 ],
 "Present": [
  null,
  "Nykyinen"
 ],
 "RAID chassis": [
  null,
  "RAID-runko"
 ],
 "RAM": [
  null,
  "RAM-muisti"
 ],
 "Rack mount chassis": [
  null,
  "Räkkiin liitettävä runko"
 ],
 "Read": [
  null,
  "Lue"
 ],
 "Read more...": [
  null,
  "Lue lisää..."
 ],
 "Reboot": [
  null,
  "Käynnistä uudelleen"
 ],
 "Removals:": [
  null,
  "Poistot:"
 ],
 "Removing $0": [
  null,
  "Poistetaan $0"
 ],
 "Save": [
  null,
  "Tallenna"
 ],
 "Sealed-case PC": [
  null,
  "Suljettu tietokonekotelo"
 ],
 "Service": [
  null,
  "Palvelu"
 ],
 "Single rank": [
  null,
  "Yksi sijoitus"
 ],
 "Space-saving computer": [
  null,
  "Tilaa säästävä tietokone"
 ],
 "Stick PC": [
  null,
  "Tikku-PC"
 ],
 "Sub-Chassis": [
  null,
  "Alirunko"
 ],
 "Sub-Notebook": [
  null,
  "Pieni kannettava tietokone"
 ],
 "Swap": [
  null,
  "Sivutus"
 ],
 "Swap out": [
  null,
  "Sivutettu"
 ],
 "Tablet": [
  null,
  "Tabletti"
 ],
 "Today": [
  null,
  "Tänään"
 ],
 "Top 5 CPU services": [
  null,
  "Viisi suorittimen pääpalvelua"
 ],
 "Top 5 memory services": [
  null,
  "Viisi muistin pääpalvelua"
 ],
 "Total size: $0": [
  null,
  "Koko yhteensä: $0"
 ],
 "Tower": [
  null,
  "Torni"
 ],
 "Troubleshoot": [
  null,
  "Vianetsintä"
 ],
 "Unknown": [
  null,
  "Tuntematon"
 ],
 "Usage": [
  null,
  "Käyttö"
 ],
 "Used": [
  null,
  "Käytetty"
 ],
 "View all CPUs": [
  null,
  "Näytä kaikki CPU:t"
 ],
 "View all disks": [
  null,
  "Näytä kaikki levyt"
 ],
 "View all logs": [
  null,
  "Katso kaikki lokit"
 ],
 "View detailed logs": [
  null,
  "Katso yksityiskohtaiset lokit"
 ],
 "View per-disk throughput": [
  null,
  "Näytä levykohtainen suorituskyky"
 ],
 "Visit firewall": [
  null,
  "Käy palomuurissa"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Odotetaan muiden ohjelmistojen hallintatoimintojen päättymistä"
 ],
 "Write": [
  null,
  "Kirjoita"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  "Sinun on kirjauduttava uudelleen sisään, jotta voit nähdä mittausten historiaa"
 ],
 "Zone": [
  null,
  "Alue"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 tavua binääridataa]"
 ],
 "[binary data]": [
  null,
  "[binääridata]"
 ],
 "[no data]": [
  null,
  "[ei dataa]"
 ],
 "average: $0%": [
  null,
  "keskiarvo: $0%"
 ],
 "cockpit-podman is not installed": [
  null,
  "cockpit-podman ei ole asennettu"
 ],
 "max: $0%": [
  null,
  "maksimi: $0%"
 ],
 "nice": [
  null,
  "nice"
 ],
 "pmlogger.service has failed": [
  null,
  "pmlogger.service on epäonnistunut"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "pmlogger.service ei onnistu tietojen keräämisessä"
 ],
 "pmlogger.service is not running": [
  null,
  "pmlogger.service ei ole käynnissä"
 ],
 "pod": [
  null,
  "pod"
 ],
 "show less": [
  null,
  "näytä vähemmän"
 ],
 "show more": [
  null,
  "näytä enemmän"
 ],
 "sys": [
  null,
  "sys"
 ],
 "user": [
  null,
  "käyttäjä"
 ]
});
