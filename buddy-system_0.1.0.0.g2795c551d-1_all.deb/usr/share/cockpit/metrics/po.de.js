cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 CPU",
  "$0 CPUs"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 available": [
  null,
  "$0 verfügbar"
 ],
 "$0 free": [
  null,
  "$0 frei"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ist in keinem Repository verfügbar."
 ],
 "$0 page": [
  null,
  "$0 Seite",
  "$0 Seiten"
 ],
 "$0 total": [
  null,
  "$0 gesamt"
 ],
 "$0 will be installed.": [
  null,
  "$0 wird installiert."
 ],
 "1 min": [
  null,
  "1 minute"
 ],
 "15 min": [
  null,
  "15 Minuten"
 ],
 "5 min": [
  null,
  "5 Minuten"
 ],
 "Absent": [
  null,
  "Abwesend"
 ],
 "Add $0": [
  null,
  "$0 hinzufügen"
 ],
 "Additional packages:": [
  null,
  "Zusatzpakete:"
 ],
 "Advanced TCA": [
  null,
  "Fortgeschrittenes TCA"
 ],
 "All-in-one": [
  null,
  "Alles-in-einem"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Bladegehäuse"
 ],
 "Bus expansion chassis": [
  null,
  "Bus-Erweiterungsgehäuse"
 ],
 "CPU": [
  null,
  "Prozessor"
 ],
 "CPU spike": [
  null,
  "CPU-Lastspitze"
 ],
 "CPU usage": [
  null,
  "Prozessor-Auslastung"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Checking installed software": [
  null,
  "Installierte Software wird überprüft"
 ],
 "Collect metrics": [
  null,
  "Kennzahlen sammeln"
 ],
 "Compact PCI": [
  null,
  "Kompakte PCI"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Core $0": [
  null,
  "Kern $0"
 ],
 "Current top CPU usage": [
  null,
  "Aktuell höchste CPU Last"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Abnehmbar"
 ],
 "Device": [
  null,
  "Gerät"
 ],
 "Disk I/O": [
  null,
  "Festplatten-E/A"
 ],
 "Disk I/O spike": [
  null,
  "Disk I/O Spitze"
 ],
 "Disks": [
  null,
  "Datenträger"
 ],
 "Disks usage": [
  null,
  "Festplattenbelegung"
 ],
 "Docking station": [
  null,
  "Dockingstation"
 ],
 "Downloading $0": [
  null,
  "wird heruntergeladen $0"
 ],
 "Dual rank": [
  null,
  "Doppelter Rang"
 ],
 "Embedded PC": [
  null,
  "Embedded PC"
 ],
 "Error has occurred": [
  null,
  "Fehler ist aufgetreten"
 ],
 "Event": [
  null,
  "Ereignis"
 ],
 "Event logs": [
  null,
  "Ereignisprotokolle"
 ],
 "Expansion chassis": [
  null,
  "Erweiterungsgehäuse"
 ],
 "Export to network": [
  null,
  "In das Netzwerk exportieren"
 ],
 "Failed to configure PCP": [
  null,
  "PCP konnte nicht konfiguriert werden"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "$0 konnte nicht in firewalld aktiviert werden"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "In": [
  null,
  "In"
 ],
 "Install": [
  null,
  "Installation"
 ],
 "Install cockpit-pcp": [
  null,
  "cockpit-pcp installieren"
 ],
 "Install software": [
  null,
  "Software installieren"
 ],
 "Installing $0": [
  null,
  "$0 wird installiert"
 ],
 "Interface": [
  null,
  "Schnittstelle",
  "Schnittstellen"
 ],
 "IoT gateway": [
  null,
  "IoT-Gateway"
 ],
 "Jump to": [
  null,
  "Gehe zu"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "Load": [
  null,
  "Last"
 ],
 "Load earlier data": [
  null,
  "Frühere Daten laden"
 ],
 "Load spike": [
  null,
  "Lastspitze"
 ],
 "Loading...": [
  null,
  "Lade..."
 ],
 "Log out": [
  null,
  "Abmelden"
 ],
 "Low profile desktop": [
  null,
  "Low-Profile-Desktop"
 ],
 "Lunch box": [
  null,
  "Brotdose"
 ],
 "Main server chassis": [
  null,
  "Hauptservergehäuse"
 ],
 "Memory": [
  null,
  "Speicher"
 ],
 "Memory spike": [
  null,
  "Speicherspitze"
 ],
 "Memory usage": [
  null,
  "Speichernutzung"
 ],
 "Metrics and history": [
  null,
  "Metriken und Verlauf"
 ],
 "Metrics history could not be loaded": [
  null,
  "Kennzahlenverlauf konnte nicht geladen werden"
 ],
 "Metrics settings": [
  null,
  "Kennzahleneinstellungen"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini-Tower"
 ],
 "Multi-system chassis": [
  null,
  "Multi-System-Chassis"
 ],
 "Network": [
  null,
  "Netzwerk"
 ],
 "Network I/O": [
  null,
  "Netzwerk-I/O"
 ],
 "Network I/O spike": [
  null,
  "Netzwerk-I/O-Lastspitze"
 ],
 "Network usage": [
  null,
  "Netzwerk-Nutzung"
 ],
 "No data available": [
  null,
  "Keine Daten verfügbar"
 ],
 "No data available between $0 and $1": [
  null,
  "Keine Daten verfügbar zwischen $0 und $1"
 ],
 "No logs found": [
  null,
  "Keine Protokolle gefunden"
 ],
 "Notebook": [
  null,
  "Notizbuch"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "Öffnen Sie den pmproxy-Dienst in der Firewall, um Metriken auszutauschen."
 ],
 "Other": [
  null,
  "Weitere"
 ],
 "Out": [
  null,
  ""
 ],
 "Overview": [
  null,
  "Überblick"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "Paket cockpit-pcp fehlt für den Kennzahlenverlauf"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ist abgestürzt"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "Performance Co-Pilot sammelt und analysiert die Leistungskennzahlen Ihres Systems."
 ],
 "Peripheral chassis": [
  null,
  "Peripheriechassis"
 ],
 "Pizza box": [
  null,
  "Pizza-Box"
 ],
 "Portable": [
  null,
  "tragbar"
 ],
 "Present": [
  null,
  "Derzeit"
 ],
 "RAID chassis": [
  null,
  "RAID-Chassis"
 ],
 "RAM": [
  null,
  "RAM"
 ],
 "Rack mount chassis": [
  null,
  "Rack-Einbaugehäuse"
 ],
 "Read": [
  null,
  "Lesen"
 ],
 "Read more...": [
  null,
  "Mehr lesen..."
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Removals:": [
  null,
  "Umzüge:"
 ],
 "Removing $0": [
  null,
  "Entfernen $0"
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "Sealed-case PC": [
  null,
  "PC mit versiegeltem Gehäuse"
 ],
 "Service": [
  null,
  "Dienst"
 ],
 "Single rank": [
  null,
  "Einzelner Rang"
 ],
 "Space-saving computer": [
  null,
  "Platzsparender Computer"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Swap out": [
  null,
  ""
 ],
 "Tablet": [
  null,
  "Tablett"
 ],
 "Today": [
  null,
  "Heute"
 ],
 "Top 5 CPU services": [
  null,
  "Top 5 CPU-Dienste"
 ],
 "Top 5 memory services": [
  null,
  "Top 5 Speicherdienste"
 ],
 "Total size: $0": [
  null,
  "Gesamtgröße: $0"
 ],
 "Tower": [
  null,
  "Turm"
 ],
 "Troubleshoot": [
  null,
  "Fehlersuche"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ],
 "Usage": [
  null,
  "Nutzung"
 ],
 "Used": [
  null,
  "Benutzt"
 ],
 "View all CPUs": [
  null,
  "Alle CPUs ansehen"
 ],
 "View all logs": [
  null,
  "Alle Protokolle ansehen"
 ],
 "View detailed logs": [
  null,
  "Detaillierte Protokolle ansehen"
 ],
 "View per-disk throughput": [
  null,
  ""
 ],
 "Visit firewall": [
  null,
  "Firewall besuchen"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Warten, bis andere Software-Verwaltungsvorgänge abgeschlossen sind"
 ],
 "Write": [
  null,
  "Schreiben"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  "Sie müssen sich erneut anmelden, um den Kennzahlenverlauf sehen zu können"
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bytes Binäredaten]"
 ],
 "[binary data]": [
  null,
  "[Binärdaten]"
 ],
 "[no data]": [
  null,
  "[keine Daten]"
 ],
 "average: $0%": [
  null,
  "Durchschnitt: $0%"
 ],
 "cockpit-podman is not installed": [
  null,
  "cockpit-podman ist nicht installiert"
 ],
 "max: $0%": [
  null,
  "max: $0%"
 ],
 "nice": [
  null,
  ""
 ],
 "pmlogger.service has failed": [
  null,
  "pmlogger.service ist fehlgeschlagen"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "pmlogger.service kann keine Daten sammeln"
 ],
 "pmlogger.service is not running": [
  null,
  "pmlogger.service läuft nicht"
 ],
 "pod": [
  null,
  ""
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ],
 "sys": [
  null,
  "Sys"
 ],
 "user": [
  null,
  "Benutzer"
 ]
});
