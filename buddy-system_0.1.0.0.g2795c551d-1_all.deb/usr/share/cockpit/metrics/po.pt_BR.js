cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 CPU",
  "$0 CPUs"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 available": [
  null,
  "$0 disponível"
 ],
 "$0 free": [
  null,
  "$0 livre"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 não está disponível em nenhum repositório."
 ],
 "$0 page": [
  null,
  "$0 página",
  "$0 páginas"
 ],
 "$0 total": [
  null,
  "$0 total"
 ],
 "$0 will be installed.": [
  null,
  "$0 será instalado."
 ],
 "1 min": [
  null,
  "1 min"
 ],
 "15 min": [
  null,
  "15 min"
 ],
 "5 min": [
  null,
  "5 min"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Add $0": [
  null,
  "Adicionar $0"
 ],
 "Additional packages:": [
  null,
  "Pacotes adicionais:"
 ],
 "Advanced TCA": [
  null,
  "TCA Avançado"
 ],
 "All-in-one": [
  null,
  ""
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Bus expansion chassis": [
  null,
  "Chassi de Expansão de Barramento"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU usage": [
  null,
  "Uso da CPU"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Checking installed software": [
  null,
  "Verificando o software instalado"
 ],
 "Compact PCI": [
  null,
  "Compacto PCI"
 ],
 "Convertible": [
  null,
  "Conversível"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Destacável"
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Disk I/O": [
  null,
  "Entrada e Saida de disco"
 ],
 "Disks": [
  null,
  "Discos"
 ],
 "Docking station": [
  null,
  "Estação de ancoragem"
 ],
 "Downloading $0": [
  null,
  "Baixando $0"
 ],
 "Dual rank": [
  null,
  ""
 ],
 "Embedded PC": [
  null,
  ""
 ],
 "Error has occurred": [
  null,
  "Ocorreu um erro"
 ],
 "Event": [
  null,
  "Evento"
 ],
 "Expansion chassis": [
  null,
  "Chassi de Expansão"
 ],
 "Failed to configure PCP": [
  null,
  "Falha ao configurar PCP"
 ],
 "In": [
  null,
  ""
 ],
 "Install": [
  null,
  "Instale"
 ],
 "Install cockpit-pcp": [
  null,
  ""
 ],
 "Install software": [
  null,
  "Instale Software"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "IoT gateway": [
  null,
  "Gateway IoT"
 ],
 "Jump to": [
  null,
  ""
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "Load": [
  null,
  ""
 ],
 "Load spike": [
  null,
  ""
 ],
 "Loading...": [
  null,
  "Carregando..."
 ],
 "Log out": [
  null,
  "Log out"
 ],
 "Low profile desktop": [
  null,
  "Desktop de baixo perfil"
 ],
 "Lunch box": [
  null,
  "Lunch box"
 ],
 "Main server chassis": [
  null,
  "Chassi do Servidor Principal"
 ],
 "Memory": [
  null,
  "Memória"
 ],
 "Memory spike": [
  null,
  "Pico de memória"
 ],
 "Memory usage": [
  null,
  "Uso de memória"
 ],
 "Metrics history could not be loaded": [
  null,
  "Não foi possível carregar o histórico de métricas"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Torre"
 ],
 "Multi-system chassis": [
  null,
  "Chassi Multi-sistema"
 ],
 "Network": [
  null,
  "Rede"
 ],
 "Network I/O": [
  null,
  "E/S de rede"
 ],
 "Network I/O spike": [
  null,
  "Pico de E/S de rede"
 ],
 "Network usage": [
  null,
  "Uso de rede"
 ],
 "No logs found": [
  null,
  "Nenhum log encontrado"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  ""
 ],
 "Other": [
  null,
  "De outros"
 ],
 "Out": [
  null,
  "Saída"
 ],
 "Overview": [
  null,
  "Visão geral"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  ""
 ],
 "PackageKit crashed": [
  null,
  "PackageKit caiu"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  ""
 ],
 "Peripheral chassis": [
  null,
  "Chassi Periférico"
 ],
 "Portable": [
  null,
  "Portatil"
 ],
 "Present": [
  null,
  ""
 ],
 "RAM": [
  null,
  "RAM"
 ],
 "Read": [
  null,
  "Leitura"
 ],
 "Read more...": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Removals:": [
  null,
  "Remoções:"
 ],
 "Removing $0": [
  null,
  "Removendo $0"
 ],
 "Save": [
  null,
  "Salvar"
 ],
 "Sealed-case PC": [
  null,
  "PC com caixa vedada"
 ],
 "Service": [
  null,
  "Serviço"
 ],
 "Single rank": [
  null,
  ""
 ],
 "Space-saving computer": [
  null,
  "Computador com economia de espaço"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Today": [
  null,
  "Hoje"
 ],
 "Top 5 CPU services": [
  null,
  "Top 5 serviços de CPU"
 ],
 "Top 5 memory services": [
  null,
  "Top 5 serviços de memória"
 ],
 "Total size: $0": [
  null,
  "Tamanho total: $0"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Troubleshoot": [
  null,
  "Solução de problemas"
 ],
 "Unknown": [
  null,
  "Desconhecido"
 ],
 "Usage": [
  null,
  "Uso"
 ],
 "Used": [
  null,
  "Usado"
 ],
 "View all logs": [
  null,
  "Ver todos os logs"
 ],
 "View per-disk throughput": [
  null,
  ""
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Aguardando que outras operações de gerenciamento de software terminem"
 ],
 "Write": [
  null,
  "Escrita"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  ""
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bytes de data bynária]"
 ],
 "[binary data]": [
  null,
  "[dados binários]"
 ],
 "[no data]": [
  null,
  "[sem dados]"
 ],
 "average: $0%": [
  null,
  ""
 ],
 "max: $0%": [
  null,
  ""
 ],
 "nice": [
  null,
  ""
 ],
 "pmlogger.service is failing to collect data": [
  null,
  ""
 ],
 "pod": [
  null,
  ""
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ],
 "user": [
  null,
  "usuário"
 ]
});
