cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 Processeur",
  "$0 Processeurs"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 available": [
  null,
  "$0 disponible"
 ],
 "$0 free": [
  null,
  "$0 disponible"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 n’est disponible dans aucun référentiel."
 ],
 "$0 page": [
  null,
  "$0 page",
  "$0 pages"
 ],
 "$0 total": [
  null,
  "$0 total"
 ],
 "$0 will be installed.": [
  null,
  "$0 sera installé."
 ],
 "1 min": [
  null,
  "1 min"
 ],
 "15 min": [
  null,
  "15 mns"
 ],
 "5 min": [
  null,
  "5 min"
 ],
 "Absent": [
  null,
  "Absent"
 ],
 "Add $0": [
  null,
  "Ajouter $0"
 ],
 "Additional packages:": [
  null,
  "Paquets supplémentaires :"
 ],
 "Advanced TCA": [
  null,
  "TCA avancé"
 ],
 "All-in-one": [
  null,
  "Tout en un"
 ],
 "Blade": [
  null,
  "Lame"
 ],
 "Blade enclosure": [
  null,
  "Boîtier en lame"
 ],
 "Bus expansion chassis": [
  null,
  "Châssis d’extension de bus"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU spike": [
  null,
  "Pointe de CPU"
 ],
 "CPU usage": [
  null,
  "Utilisation CPU"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Checking installed software": [
  null,
  "Vérification des logiciels installés"
 ],
 "Collect metrics": [
  null,
  "Collecter des mesures"
 ],
 "Compact PCI": [
  null,
  "PCI compact"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Core $0": [
  null,
  "Core $0"
 ],
 "Current top CPU usage": [
  null,
  "Pic d’utilisation du processeur"
 ],
 "Desktop": [
  null,
  "Bureau"
 ],
 "Detachable": [
  null,
  "Détachable"
 ],
 "Device": [
  null,
  "Périphérique"
 ],
 "Disk I/O": [
  null,
  "E / S disque"
 ],
 "Disk I/O spike": [
  null,
  "Pointe d’entrée/sortie de disque"
 ],
 "Disks": [
  null,
  "Disques"
 ],
 "Disks usage": [
  null,
  "Utilisation des disques"
 ],
 "Docking station": [
  null,
  "Station d’accueil"
 ],
 "Downloading $0": [
  null,
  "Téléchargement $0"
 ],
 "Dual rank": [
  null,
  "Double rang"
 ],
 "Embedded PC": [
  null,
  "PC intégré"
 ],
 "Error has occurred": [
  null,
  "Une erreur s’est produite"
 ],
 "Event": [
  null,
  "Événement"
 ],
 "Event logs": [
  null,
  "Journaux événements"
 ],
 "Expansion chassis": [
  null,
  "Châssis d’extension"
 ],
 "Export to network": [
  null,
  "Exporter vers le réseau"
 ],
 "Failed to configure PCP": [
  null,
  "Échec de la configuration de PCP"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Échec de l’activation $0 dans firewalld"
 ],
 "Handheld": [
  null,
  "Portable"
 ],
 "In": [
  null,
  "Dans"
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install cockpit-pcp": [
  null,
  "Installer le cockpit-pcp"
 ],
 "Install software": [
  null,
  "Installer le logiciel"
 ],
 "Installing $0": [
  null,
  "Installation de $0"
 ],
 "Interface": [
  null,
  "Interface",
  "Interfaces"
 ],
 "IoT gateway": [
  null,
  "Passerelle IoT"
 ],
 "Jump to": [
  null,
  "Aller à"
 ],
 "Laptop": [
  null,
  "Portable"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "Load": [
  null,
  "Charger"
 ],
 "Load earlier data": [
  null,
  "Charger des données antérieures"
 ],
 "Load spike": [
  null,
  "Pointe de charge"
 ],
 "Loading...": [
  null,
  "Chargement…"
 ],
 "Log out": [
  null,
  "Déconnexion"
 ],
 "Low profile desktop": [
  null,
  "Bureau de profil bas"
 ],
 "Lunch box": [
  null,
  "Lunch Box"
 ],
 "Main server chassis": [
  null,
  "Châssis principal du serveur"
 ],
 "Memory": [
  null,
  "Mémoire"
 ],
 "Memory spike": [
  null,
  "Pic de mémoire"
 ],
 "Memory usage": [
  null,
  "Utilisation de la mémoire"
 ],
 "Metrics and history": [
  null,
  "Métriques et historique"
 ],
 "Metrics history could not be loaded": [
  null,
  "L’historique des métriques n’a pas pu être chargé"
 ],
 "Metrics settings": [
  null,
  "Paramètres des métriques"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Tour"
 ],
 "Multi-system chassis": [
  null,
  "Châssis multi-système"
 ],
 "Network": [
  null,
  "Réseau"
 ],
 "Network I/O": [
  null,
  "Réseau E/S"
 ],
 "Network I/O spike": [
  null,
  "Pointe d’E/S du réseau"
 ],
 "Network usage": [
  null,
  "Utilisation du réseau"
 ],
 "No data available": [
  null,
  "Aucune donnée disponible"
 ],
 "No data available between $0 and $1": [
  null,
  "Aucune donnée disponible entre $0 et $1"
 ],
 "No logs found": [
  null,
  "Aucun journal trouvé"
 ],
 "Notebook": [
  null,
  "Ordinateur portable"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "Ouvrez le service pmproxy dans le pare-feu pour partager des métriques."
 ],
 "Other": [
  null,
  "Autre"
 ],
 "Out": [
  null,
  "Sortie"
 ],
 "Overview": [
  null,
  "Aperçu"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "Le paquet cockpit-pcp est manquant pour l’historique des métriques"
 ],
 "PackageKit crashed": [
  null,
  "Plantage de « PackageKit »"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "Performance Co-Pilot recueille et analyse les mesures de performance de votre système."
 ],
 "Peripheral chassis": [
  null,
  "Châssis périphérique"
 ],
 "Pizza box": [
  null,
  "Pizza Box"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Present": [
  null,
  "Présent"
 ],
 "RAID chassis": [
  null,
  "Châssis RAID"
 ],
 "RAM": [
  null,
  "RAM"
 ],
 "Rack mount chassis": [
  null,
  "Châssis de montage en rack"
 ],
 "Read": [
  null,
  "Lire"
 ],
 "Read more...": [
  null,
  "En savoir plus…"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Removals:": [
  null,
  "Suppressions :"
 ],
 "Removing $0": [
  null,
  "Suppression de $0"
 ],
 "Save": [
  null,
  "Enregistrer"
 ],
 "Sealed-case PC": [
  null,
  "PC scellé"
 ],
 "Service": [
  null,
  "Service"
 ],
 "Single rank": [
  null,
  "Rang unique"
 ],
 "Space-saving computer": [
  null,
  "Ordinateur gain de place"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Sub-Chassis": [
  null,
  "Sous-châssis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Swap out": [
  null,
  "Échanger"
 ],
 "Tablet": [
  null,
  "Tablette"
 ],
 "Today": [
  null,
  "Aujourd’hui"
 ],
 "Top 5 CPU services": [
  null,
  "Top 5 des services CPU"
 ],
 "Top 5 memory services": [
  null,
  "Top 5 des services de mémoire"
 ],
 "Total size: $0": [
  null,
  "Taille totale : $0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Troubleshoot": [
  null,
  "Dépannage"
 ],
 "Unknown": [
  null,
  "Inconnu"
 ],
 "Usage": [
  null,
  "Utilisation"
 ],
 "Used": [
  null,
  "Utilisé"
 ],
 "View all CPUs": [
  null,
  "Voir tous les processeurs"
 ],
 "View all disks": [
  null,
  "Afficher tous les disques"
 ],
 "View all logs": [
  null,
  "Voir tous les journaux"
 ],
 "View detailed logs": [
  null,
  "Afficher les journaux détaillés"
 ],
 "View per-disk throughput": [
  null,
  "Afficher le débit par disque"
 ],
 "Visit firewall": [
  null,
  "Visitez le pare-feu"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Attente de la fin des autres opérations de gestion du logiciel"
 ],
 "Write": [
  null,
  "Écriture"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  "Vous devez vous connecter à nouveau pour consulter l’historique des métriques"
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[ $0 octets de données binaires]"
 ],
 "[binary data]": [
  null,
  "[données binaires]"
 ],
 "[no data]": [
  null,
  "[pas de données]"
 ],
 "average: $0%": [
  null,
  "moyenne : $0%"
 ],
 "cockpit-podman is not installed": [
  null,
  "cockpit-podman n'est pas installé"
 ],
 "max: $0%": [
  null,
  "max : $0%"
 ],
 "nice": [
  null,
  "nice"
 ],
 "pmlogger.service has failed": [
  null,
  "Le service pmlogger.service a échoué"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "Le service pmlogger.service ne parvient pas à collecter des données"
 ],
 "pmlogger.service is not running": [
  null,
  "Le service pmlogger.service n’est pas en cours d’exécution"
 ],
 "pod": [
  null,
  "pod"
 ],
 "show less": [
  null,
  "montrer moins"
 ],
 "show more": [
  null,
  "montrer plus"
 ],
 "sys": [
  null,
  "sys"
 ],
 "user": [
  null,
  "utilisateur"
 ]
});
