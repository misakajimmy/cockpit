cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 процессор",
  "$0 процессора",
  "$0 процессоров"
 ],
 "$0 GiB": [
  null,
  "$0 ГиБ"
 ],
 "$0 available": [
  null,
  "Доступно $0"
 ],
 "$0 free": [
  null,
  "Свободно $0"
 ],
 "$0 is not available from any repository.": [
  null,
  "Компонент $0 недоступен в репозиториях."
 ],
 "$0 page": [
  null,
  "$0 пакет",
  "$0 пакета",
  "$0 пакетов"
 ],
 "$0 total": [
  null,
  "Всего $0"
 ],
 "$0 will be installed.": [
  null,
  "Будет выполнена установка $0."
 ],
 "1 min": [
  null,
  "1 мин"
 ],
 "15 min": [
  null,
  "15 мин"
 ],
 "5 min": [
  null,
  "5 мин"
 ],
 "Absent": [
  null,
  "Отсутствует"
 ],
 "Add $0": [
  null,
  "Добавить $0"
 ],
 "Additional packages:": [
  null,
  "Дополнительные пакеты:"
 ],
 "Advanced TCA": [
  null,
  "Расширенный TCA"
 ],
 "All-in-one": [
  null,
  "Все в одном"
 ],
 "Blade": [
  null,
  "Ультракомпактный сервер"
 ],
 "Blade enclosure": [
  null,
  "Корзина"
 ],
 "Bus expansion chassis": [
  null,
  "Корпус расширения шины"
 ],
 "CPU": [
  null,
  "ЦП"
 ],
 "CPU spike": [
  null,
  "Всплеск процессора"
 ],
 "CPU usage": [
  null,
  "Использование ЦП"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Checking installed software": [
  null,
  "Проверка установленного программного обеспечения"
 ],
 "Collect metrics": [
  null,
  "Собрать метрики"
 ],
 "Compact PCI": [
  null,
  "Компактный PCI"
 ],
 "Convertible": [
  null,
  "Компьютер-трансформер"
 ],
 "Desktop": [
  null,
  "Настольный компьютер"
 ],
 "Detachable": [
  null,
  "Съёмный компьютер"
 ],
 "Device": [
  null,
  "Устройство"
 ],
 "Disk I/O": [
  null,
  "Дисковый ввод-вывод"
 ],
 "Disks": [
  null,
  "Диски"
 ],
 "Docking station": [
  null,
  "Стыковочный узел"
 ],
 "Downloading $0": [
  null,
  "Загрузка $0"
 ],
 "Dual rank": [
  null,
  "Двухранговая"
 ],
 "Embedded PC": [
  null,
  "Встраиваемый компьютер"
 ],
 "Event": [
  null,
  ""
 ],
 "Expansion chassis": [
  null,
  "Корпус расширения"
 ],
 "In": [
  null,
  ""
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Install cockpit-pcp": [
  null,
  ""
 ],
 "Install software": [
  null,
  "Установка программного обеспечения"
 ],
 "Installing $0": [
  null,
  "Установка $0"
 ],
 "IoT gateway": [
  null,
  "Шлюз Интернета вещей"
 ],
 "Jump to": [
  null,
  ""
 ],
 "Laptop": [
  null,
  "Полноразмерный ноутбук"
 ],
 "Learn more": [
  null,
  "Подробнее..."
 ],
 "Load": [
  null,
  ""
 ],
 "Load spike": [
  null,
  ""
 ],
 "Loading...": [
  null,
  "Загрузка..."
 ],
 "Log out": [
  null,
  "Выход"
 ],
 "Low profile desktop": [
  null,
  "Низкопрофильный настольный компьютер"
 ],
 "Lunch box": [
  null,
  "Портативный компьютер в ударопрочном корпусе"
 ],
 "Main server chassis": [
  null,
  "Главный серверный корпус"
 ],
 "Memory": [
  null,
  "Память"
 ],
 "Mini PC": [
  null,
  "Мини-ПК"
 ],
 "Mini tower": [
  null,
  "Компьютер в корпусе «мини-башня»"
 ],
 "Multi-system chassis": [
  null,
  "Корпус для нескольких систем"
 ],
 "No logs found": [
  null,
  "Журналов не найдено"
 ],
 "Notebook": [
  null,
  "Ноутбук"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  ""
 ],
 "Other": [
  null,
  "Прочее"
 ],
 "Out": [
  null,
  ""
 ],
 "Overview": [
  null,
  "Обзор"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  ""
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  ""
 ],
 "Peripheral chassis": [
  null,
  "Корпус для периферийных устройств"
 ],
 "Pizza box": [
  null,
  "Ультратонкий корпус"
 ],
 "Portable": [
  null,
  "Портативный компьютер"
 ],
 "Present": [
  null,
  "Присутствует"
 ],
 "RAID chassis": [
  null,
  "Корпус для RAID-массива"
 ],
 "RAM": [
  null,
  ""
 ],
 "Rack mount chassis": [
  null,
  "Монтируемый в стойку корпус"
 ],
 "Read more...": [
  null,
  "Подробнее..."
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Removals:": [
  null,
  "Для удаления:"
 ],
 "Removing $0": [
  null,
  "Удаление $0"
 ],
 "Save": [
  null,
  "Сохранить"
 ],
 "Sealed-case PC": [
  null,
  "Компьютер с невскрываемым корпусом"
 ],
 "Service": [
  null,
  "Служба"
 ],
 "Single rank": [
  null,
  "Одноранговая"
 ],
 "Space-saving computer": [
  null,
  "Компактный компьютер"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Swap": [
  null,
  "Подкачка"
 ],
 "Tablet": [
  null,
  "Планшетный ПК"
 ],
 "Today": [
  null,
  ""
 ],
 "Total size: $0": [
  null,
  "Общий размер: $0"
 ],
 "Tower": [
  null,
  "Компьютер в корпусе «башня»"
 ],
 "Troubleshoot": [
  null,
  "Устранить неполадки"
 ],
 "Unknown": [
  null,
  "Неизвестно"
 ],
 "Usage": [
  null,
  "Использование"
 ],
 "Used": [
  null,
  "Использовано"
 ],
 "View all CPUs": [
  null,
  ""
 ],
 "View all logs": [
  null,
  ""
 ],
 "View per-disk throughput": [
  null,
  ""
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Ожидание завершения других операций управления программным обеспечением"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  ""
 ],
 "Zone": [
  null,
  ""
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 байтов двоичных данных]"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "average: $0%": [
  null,
  ""
 ],
 "max: $0%": [
  null,
  ""
 ],
 "nice": [
  null,
  ""
 ],
 "pmlogger.service is failing to collect data": [
  null,
  ""
 ],
 "pod": [
  null,
  ""
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "user": [
  null,
  "пользователь"
 ]
});
