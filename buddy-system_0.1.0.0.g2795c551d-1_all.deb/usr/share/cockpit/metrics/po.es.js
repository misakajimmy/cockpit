cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 CPU",
  "$0 CPUs"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 available": [
  null,
  "$0 disponibles"
 ],
 "$0 free": [
  null,
  "$0 libre"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 no está disponible en ningún repositorio."
 ],
 "$0 page": [
  null,
  "$0 página",
  "$0 páginas"
 ],
 "$0 total": [
  null,
  "$0 total"
 ],
 "$0 will be installed.": [
  null,
  "Se instalará: $0."
 ],
 "1 min": [
  null,
  "1 min"
 ],
 "15 min": [
  null,
  "15 min"
 ],
 "5 min": [
  null,
  "5 min"
 ],
 "Absent": [
  null,
  "Ausente"
 ],
 "Add $0": [
  null,
  "Añadir $0"
 ],
 "Additional packages:": [
  null,
  "Paquetes adicionales:"
 ],
 "Advanced TCA": [
  null,
  "TCA avanzado"
 ],
 "All-in-one": [
  null,
  "Todo en uno"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Chasis tipo blade"
 ],
 "Bus expansion chassis": [
  null,
  "Chasis de expansión de bus"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU spike": [
  null,
  "Pico de CPU"
 ],
 "CPU usage": [
  null,
  "Uso de CPU"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Checking installed software": [
  null,
  "Comprobando el software instalado"
 ],
 "Collect metrics": [
  null,
  "Almacenar métricas"
 ],
 "Compact PCI": [
  null,
  "PCI compacto"
 ],
 "Convertible": [
  null,
  "Convertible"
 ],
 "Core $0": [
  null,
  "Núcleo $0"
 ],
 "Current top CPU usage": [
  null,
  "Uso máximo de CPU actual"
 ],
 "Desktop": [
  null,
  "Escritorio"
 ],
 "Detachable": [
  null,
  "Desmontable"
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Disk I/O": [
  null,
  "E/S de disco"
 ],
 "Disk I/O spike": [
  null,
  "Pico de E/S de disco"
 ],
 "Disks": [
  null,
  "Discos"
 ],
 "Disks usage": [
  null,
  "Uso de discos"
 ],
 "Docking station": [
  null,
  "Estación de acoplamiento"
 ],
 "Downloading $0": [
  null,
  "Descargando $0"
 ],
 "Dual rank": [
  null,
  "Rango dual"
 ],
 "Embedded PC": [
  null,
  "PC integrado"
 ],
 "Error has occurred": [
  null,
  "Ha ocurrido un error"
 ],
 "Event": [
  null,
  "Evento"
 ],
 "Event logs": [
  null,
  "Registro de eventos"
 ],
 "Expansion chassis": [
  null,
  "Chasis de expansión"
 ],
 "Export to network": [
  null,
  "Exportar a la red"
 ],
 "Failed to configure PCP": [
  null,
  "Fallo al configurar PCP"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Fallo al habilitar $0 en firewalld"
 ],
 "Handheld": [
  null,
  "Dispositivo de mano"
 ],
 "In": [
  null,
  "Entrante"
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Install cockpit-pcp": [
  null,
  "Instalar cockpit-pcp"
 ],
 "Install software": [
  null,
  "Instalar software"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Interface": [
  null,
  "Interfaz",
  "Interfaces"
 ],
 "IoT gateway": [
  null,
  "Pasarela IoT"
 ],
 "Jump to": [
  null,
  "Ir a"
 ],
 "Laptop": [
  null,
  "Portátil"
 ],
 "Learn more": [
  null,
  "Aprenda más"
 ],
 "Load": [
  null,
  "Load"
 ],
 "Load earlier data": [
  null,
  "Cargar datos anteriores"
 ],
 "Load spike": [
  null,
  "Pico de Load"
 ],
 "Loading...": [
  null,
  "Cargando..."
 ],
 "Log out": [
  null,
  "Salir"
 ],
 "Low profile desktop": [
  null,
  "Perfil bajo de escritorio"
 ],
 "Lunch box": [
  null,
  "Caja de almuerzo"
 ],
 "Main server chassis": [
  null,
  "Chasis del servidor principal"
 ],
 "Memory": [
  null,
  "Memoria"
 ],
 "Memory spike": [
  null,
  "Pico de memoria"
 ],
 "Memory usage": [
  null,
  "Uso de memoria"
 ],
 "Metrics and history": [
  null,
  "Métricas e histórico"
 ],
 "Metrics history could not be loaded": [
  null,
  "No se pudo cargar el histórico de memoria"
 ],
 "Metrics settings": [
  null,
  "Ajustes de métricas"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini Torre"
 ],
 "Multi-system chassis": [
  null,
  "Chasis multisistema"
 ],
 "Network": [
  null,
  "Red"
 ],
 "Network I/O": [
  null,
  "E/S de red"
 ],
 "Network I/O spike": [
  null,
  "Pico de E/S de red"
 ],
 "Network usage": [
  null,
  "Uso de red"
 ],
 "No data available": [
  null,
  "No hay datos disponibles"
 ],
 "No data available between $0 and $1": [
  null,
  "No hay datos disponibles entre $0 y $1"
 ],
 "No logs found": [
  null,
  "No se encontraron registros"
 ],
 "Notebook": [
  null,
  "Portátil"
 ],
 "Ok": [
  null,
  "Aceptar"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "Abra el servicio pmproxy en el cortafuegos para compartir métricas."
 ],
 "Other": [
  null,
  "Otro"
 ],
 "Out": [
  null,
  "Saliente"
 ],
 "Overview": [
  null,
  "Visión global"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "Falta el paquete cockpit-pcp para realizar un histórico de métricas"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit colapsó"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "Performance Co-Pilot recolecta y analiza métricas de rendimiento de su sistema."
 ],
 "Peripheral chassis": [
  null,
  "Chasis periférico"
 ],
 "Pizza box": [
  null,
  "Caja de pizza"
 ],
 "Portable": [
  null,
  "Portable"
 ],
 "Present": [
  null,
  "Presente"
 ],
 "RAID chassis": [
  null,
  "Chasis RAID"
 ],
 "RAM": [
  null,
  "RAM"
 ],
 "Rack mount chassis": [
  null,
  "Chasis montado en rack"
 ],
 "Read": [
  null,
  "Lectura"
 ],
 "Read more...": [
  null,
  "Leer más..."
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Removals:": [
  null,
  "Borrados:"
 ],
 "Removing $0": [
  null,
  "Eliminando $0"
 ],
 "Save": [
  null,
  "Guardar"
 ],
 "Sealed-case PC": [
  null,
  "PC de caja sellada"
 ],
 "Service": [
  null,
  "Servicio"
 ],
 "Single rank": [
  null,
  "Rango único"
 ],
 "Space-saving computer": [
  null,
  "Ordenador compacto"
 ],
 "Stick PC": [
  null,
  "PC USB"
 ],
 "Sub-Chassis": [
  null,
  "Sub Chasis"
 ],
 "Sub-Notebook": [
  null,
  "Subportátil"
 ],
 "Swap": [
  null,
  "Área de intercambio"
 ],
 "Swap out": [
  null,
  "Área de intercambio usada"
 ],
 "Tablet": [
  null,
  "Tableta"
 ],
 "Today": [
  null,
  "Hoy"
 ],
 "Top 5 CPU services": [
  null,
  "Top 5 servicios de CPU"
 ],
 "Top 5 memory services": [
  null,
  "Top 5 servicios de memoria"
 ],
 "Total size: $0": [
  null,
  "Tamaño total: $0"
 ],
 "Tower": [
  null,
  "Torre"
 ],
 "Troubleshoot": [
  null,
  "Soporte"
 ],
 "Unknown": [
  null,
  "Desconocido"
 ],
 "Usage": [
  null,
  "Uso"
 ],
 "Used": [
  null,
  "Usado"
 ],
 "View all CPUs": [
  null,
  "Mostrar todas las CPUs"
 ],
 "View all disks": [
  null,
  "Mostrar todos los discos"
 ],
 "View all logs": [
  null,
  "Ver todos los registros"
 ],
 "View detailed logs": [
  null,
  "Ver registros detallados"
 ],
 "View per-disk throughput": [
  null,
  "Mostrar tráfico de cada disco"
 ],
 "Visit firewall": [
  null,
  "Ir al cortafuegos"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Esperando a que finalicen otras operaciones de gestión de software"
 ],
 "Write": [
  null,
  "Escritura"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  "Necesitas volver a iniciar sesión para poder ver el histórico de métricas"
 ],
 "Zone": [
  null,
  "Zona"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bites de datos binarios]"
 ],
 "[binary data]": [
  null,
  "[datos binarios]"
 ],
 "[no data]": [
  null,
  "[no hay datos]"
 ],
 "average: $0%": [
  null,
  "media: $0%"
 ],
 "cockpit-podman is not installed": [
  null,
  "cockpit-podman no está instalado"
 ],
 "max: $0%": [
  null,
  "máx: $0%"
 ],
 "nice": [
  null,
  "nice"
 ],
 "pmlogger.service has failed": [
  null,
  "pmlogger.service ha fallado"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "El servicio pmlogger.service no puede recolectar datos"
 ],
 "pmlogger.service is not running": [
  null,
  "pmlogger.service no se está ejecutando"
 ],
 "pod": [
  null,
  "pod"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar más"
 ],
 "sys": [
  null,
  "sistema"
 ],
 "user": [
  null,
  "usuario"
 ]
});
