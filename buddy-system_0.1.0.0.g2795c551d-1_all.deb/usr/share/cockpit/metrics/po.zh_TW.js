cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "$0 GiB": [
  null,
  ""
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 在任何存儲庫中都不可用。"
 ],
 "$0 will be installed.": [
  null,
  "$0 將會被安裝。"
 ],
 "1 min": [
  null,
  "1分鐘"
 ],
 "5 min": [
  null,
  "5分鐘"
 ],
 "Absent": [
  null,
  ""
 ],
 "Add $0": [
  null,
  "新增 $0"
 ],
 "Additional packages:": [
  null,
  "附加包："
 ],
 "Advanced TCA": [
  null,
  "高級TCA"
 ],
 "All-in-one": [
  null,
  ""
 ],
 "Blade": [
  null,
  "刀鋒"
 ],
 "Blade enclosure": [
  null,
  "刀鋒機箱"
 ],
 "Bus expansion chassis": [
  null,
  "總線擴展機箱"
 ],
 "CPU": [
  null,
  "處理器"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Checking installed software": [
  null,
  "檢查已安裝的軟件"
 ],
 "Compact PCI": [
  null,
  "緊湊型PCI"
 ],
 "Convertible": [
  null,
  "可兌換"
 ],
 "Desktop": [
  null,
  "桌面環境"
 ],
 "Detachable": [
  null,
  "可拆開"
 ],
 "Device": [
  null,
  "裝置"
 ],
 "Disk I/O": [
  null,
  "磁碟讀寫"
 ],
 "Disks": [
  null,
  "磁碟"
 ],
 "Docking station": [
  null,
  "停靠站"
 ],
 "Downloading $0": [
  null,
  "下載 $0"
 ],
 "Dual rank": [
  null,
  ""
 ],
 "Embedded PC": [
  null,
  "嵌入式PC"
 ],
 "Event": [
  null,
  ""
 ],
 "Expansion chassis": [
  null,
  "擴展機箱"
 ],
 "Export to network": [
  null,
  ""
 ],
 "In": [
  null,
  ""
 ],
 "Install": [
  null,
  "安裝"
 ],
 "Install cockpit-pcp": [
  null,
  ""
 ],
 "Install software": [
  null,
  "安裝軟件"
 ],
 "Installing $0": [
  null,
  "正在安裝 $0"
 ],
 "IoT gateway": [
  null,
  "物聯網網關"
 ],
 "Jump to": [
  null,
  ""
 ],
 "Laptop": [
  null,
  "筆記本電腦"
 ],
 "Load": [
  null,
  ""
 ],
 "Load spike": [
  null,
  ""
 ],
 "Loading...": [
  null,
  "正在載入..."
 ],
 "Log out": [
  null,
  "登出"
 ],
 "Low profile desktop": [
  null,
  "低調桌面"
 ],
 "Lunch box": [
  null,
  "午餐盒"
 ],
 "Main server chassis": [
  null,
  "主伺服器機箱"
 ],
 "Memory": [
  null,
  "記憶體"
 ],
 "Mini PC": [
  null,
  "迷你電腦"
 ],
 "Mini tower": [
  null,
  "迷你塔"
 ],
 "Multi-system chassis": [
  null,
  "多系統機箱"
 ],
 "No logs found": [
  null,
  ""
 ],
 "Notebook": [
  null,
  "筆記本"
 ],
 "Ok": [
  null,
  "確定"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  ""
 ],
 "Other": [
  null,
  "其它"
 ],
 "Out": [
  null,
  ""
 ],
 "Overview": [
  null,
  "主機狀態"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  ""
 ],
 "PackageKit crashed": [
  null,
  "PackageKit崩潰了"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  ""
 ],
 "Peripheral chassis": [
  null,
  "外圍機箱"
 ],
 "Pizza box": [
  null,
  "披薩盒"
 ],
 "Portable": [
  null,
  "手提"
 ],
 "Present": [
  null,
  ""
 ],
 "RAID chassis": [
  null,
  "RAID機箱"
 ],
 "RAM": [
  null,
  ""
 ],
 "Rack mount chassis": [
  null,
  "機架式機箱"
 ],
 "Read more...": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "重新開機"
 ],
 "Removals:": [
  null,
  "清除："
 ],
 "Removing $0": [
  null,
  "刪除 $0"
 ],
 "Save": [
  null,
  "儲存"
 ],
 "Sealed-case PC": [
  null,
  "密封式PC"
 ],
 "Service": [
  null,
  "服務管理"
 ],
 "Single rank": [
  null,
  ""
 ],
 "Space-saving computer": [
  null,
  "節省空間的計算機"
 ],
 "Stick PC": [
  null,
  "堅持使用PC"
 ],
 "Swap": [
  null,
  "置換"
 ],
 "Tablet": [
  null,
  "面板"
 ],
 "Today": [
  null,
  ""
 ],
 "Total size: $0": [
  null,
  "總大小： $0"
 ],
 "Tower": [
  null,
  "塔"
 ],
 "Troubleshoot": [
  null,
  "疑難排解"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Usage": [
  null,
  "效能狀態"
 ],
 "Used": [
  null,
  "已使用"
 ],
 "View all CPUs": [
  null,
  ""
 ],
 "View all logs": [
  null,
  ""
 ],
 "View per-disk throughput": [
  null,
  ""
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他軟件管理操作完成"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  ""
 ],
 "Zone": [
  null,
  ""
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 二進制數據的字節]"
 ],
 "[binary data]": [
  null,
  "[二進制數據]"
 ],
 "[no data]": [
  null,
  "[沒有數據]"
 ],
 "average: $0%": [
  null,
  ""
 ],
 "max: $0%": [
  null,
  ""
 ],
 "nice": [
  null,
  ""
 ],
 "pmlogger.service is failing to collect data": [
  null,
  ""
 ],
 "pod": [
  null,
  ""
 ],
 "show less": [
  null,
  "顯示較少"
 ],
 "show more": [
  null,
  "顯示更多"
 ],
 "user": [
  null,
  "使用者"
 ]
});
