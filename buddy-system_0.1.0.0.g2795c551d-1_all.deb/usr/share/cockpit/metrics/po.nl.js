cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 CPU",
  "$0 CPU's"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 available": [
  null,
  "$0 beschikbaar"
 ],
 "$0 free": [
  null,
  "$0 vrij"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 is van geen enkele repository beschikbaar."
 ],
 "$0 page": [
  null,
  "$0 pagina",
  "$0 pagina's"
 ],
 "$0 total": [
  null,
  "$0 totaal"
 ],
 "$0 will be installed.": [
  null,
  "$0 zal geïnstalleerd worden."
 ],
 "1 min": [
  null,
  "1 min"
 ],
 "15 min": [
  null,
  "15 min"
 ],
 "5 min": [
  null,
  "5 min"
 ],
 "Absent": [
  null,
  "Afwezig"
 ],
 "Add $0": [
  null,
  "Toevoegen $0"
 ],
 "Additional packages:": [
  null,
  "Extra pakketten:"
 ],
 "Advanced TCA": [
  null,
  "Geavanceerde TCA"
 ],
 "All-in-one": [
  null,
  "Alles in een"
 ],
 "Blade": [
  null,
  "Antenne"
 ],
 "Blade enclosure": [
  null,
  "Antennebehuizing"
 ],
 "Bus expansion chassis": [
  null,
  "Busuitbreidingschassis"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU spike": [
  null,
  "CPU-piek"
 ],
 "CPU usage": [
  null,
  "CPU-gebruik"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Checking installed software": [
  null,
  "Controleren op geïnstalleerde software"
 ],
 "Collect metrics": [
  null,
  "Verzamel metriek"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Convertible": [
  null,
  "Converteerbaar"
 ],
 "Core $0": [
  null,
  "Kern $0"
 ],
 "Current top CPU usage": [
  null,
  "Huidig top CPU-gebruik"
 ],
 "Desktop": [
  null,
  "Bureaublad"
 ],
 "Detachable": [
  null,
  "Demonteerbaar"
 ],
 "Device": [
  null,
  "Apparaat"
 ],
 "Disk I/O": [
  null,
  "Schijf I/O"
 ],
 "Disk I/O spike": [
  null,
  "Schijf I/O piek"
 ],
 "Disks": [
  null,
  "Schijven"
 ],
 "Disks usage": [
  null,
  "Schijfgebruik"
 ],
 "Docking station": [
  null,
  "Docking station"
 ],
 "Downloading $0": [
  null,
  "$0 downloaden"
 ],
 "Dual rank": [
  null,
  "Dubbele rangorde"
 ],
 "Embedded PC": [
  null,
  "Ingebouwde pc"
 ],
 "Error has occurred": [
  null,
  "Er is een fout opgetreden"
 ],
 "Event": [
  null,
  "Gebeurtenis"
 ],
 "Event logs": [
  null,
  "Gebeurtenislogboeken"
 ],
 "Expansion chassis": [
  null,
  "Uitbreidingschassis"
 ],
 "Export to network": [
  null,
  "Exporteer naar netwerk"
 ],
 "Failed to configure PCP": [
  null,
  "Kan PCP niet configureren"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Kan $0 niet inschakelen in firewalld"
 ],
 "Handheld": [
  null,
  "Handheld"
 ],
 "In": [
  null,
  "In"
 ],
 "Install": [
  null,
  "Installeren"
 ],
 "Install cockpit-pcp": [
  null,
  "Installeer cockpit-pcp"
 ],
 "Install software": [
  null,
  "Installeer software"
 ],
 "Installing $0": [
  null,
  "$0 installeren"
 ],
 "Interface": [
  null,
  "Interface",
  "Interfaces"
 ],
 "IoT gateway": [
  null,
  "IoT-gateway"
 ],
 "Jump to": [
  null,
  "Spring naar"
 ],
 "Laptop": [
  null,
  "Laptop"
 ],
 "Learn more": [
  null,
  "Kom meer te weten"
 ],
 "Load": [
  null,
  "Belasting"
 ],
 "Load earlier data": [
  null,
  "Laad eerdere data"
 ],
 "Load spike": [
  null,
  "Laad piek"
 ],
 "Loading...": [
  null,
  "Laden..."
 ],
 "Log out": [
  null,
  "Uitloggen"
 ],
 "Low profile desktop": [
  null,
  "Laag profiel bureaublad"
 ],
 "Lunch box": [
  null,
  "Lunchbox"
 ],
 "Main server chassis": [
  null,
  "Hoofdserverchassis"
 ],
 "Memory": [
  null,
  "Geheugen"
 ],
 "Memory spike": [
  null,
  "Geheugen piek"
 ],
 "Memory usage": [
  null,
  "Geheugengebruik"
 ],
 "Metrics and history": [
  null,
  "Statistieken en geschiedenis"
 ],
 "Metrics history could not be loaded": [
  null,
  "Statistieken kon niet worden geladen"
 ],
 "Metrics settings": [
  null,
  "Metriekinstellingen"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini tower"
 ],
 "Multi-system chassis": [
  null,
  "Chassis met meerdere systemen"
 ],
 "Network": [
  null,
  "Netwerk"
 ],
 "Network I/O": [
  null,
  "Netwerk I/O"
 ],
 "Network I/O spike": [
  null,
  "Netwerk I/O piek"
 ],
 "Network usage": [
  null,
  "Netwerkgebruik"
 ],
 "No data available": [
  null,
  "Geen data beschikbaar"
 ],
 "No data available between $0 and $1": [
  null,
  "Geen data beschikbaar tussen $0 en $1"
 ],
 "No logs found": [
  null,
  "Geen logs gevonden"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "Open de pmproxy-service in de firewall om metrische gegevens te delen."
 ],
 "Other": [
  null,
  "Andere"
 ],
 "Out": [
  null,
  "Uit"
 ],
 "Overview": [
  null,
  "Overzicht"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "Pakket cockpit-pcp ontbreekt voor metrische geschiedenis"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit is gecrasht"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "Performance Co-Pilot verzamelt en analyseert prestatiestatistieken van jouw systeem."
 ],
 "Peripheral chassis": [
  null,
  "Randchassis"
 ],
 "Pizza box": [
  null,
  "Pizzadoos"
 ],
 "Portable": [
  null,
  "Draagbaar"
 ],
 "Present": [
  null,
  "Aanwezig"
 ],
 "RAID chassis": [
  null,
  "RAID-chassis"
 ],
 "RAM": [
  null,
  "RAM"
 ],
 "Rack mount chassis": [
  null,
  "Rackmontagechassis"
 ],
 "Read": [
  null,
  "Lezen"
 ],
 "Read more...": [
  null,
  "Lees meer..."
 ],
 "Reboot": [
  null,
  "Opnieuw opstarten"
 ],
 "Removals:": [
  null,
  "Verwijderingen:"
 ],
 "Removing $0": [
  null,
  "$0 verwijderen"
 ],
 "Save": [
  null,
  "Opslaan"
 ],
 "Sealed-case PC": [
  null,
  "Gesloten PC"
 ],
 "Service": [
  null,
  "Service"
 ],
 "Single rank": [
  null,
  "Enkele rang"
 ],
 "Space-saving computer": [
  null,
  "Ruimtebesparende computer"
 ],
 "Stick PC": [
  null,
  "Stick PC"
 ],
 "Sub-Chassis": [
  null,
  "Sub-chassis"
 ],
 "Sub-Notebook": [
  null,
  "Sub-notebook"
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Swap out": [
  null,
  "Uitwisselen"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Today": [
  null,
  "Vandaag"
 ],
 "Top 5 CPU services": [
  null,
  "Top 5 CPU-services"
 ],
 "Top 5 memory services": [
  null,
  "Top 5 geheugenservices"
 ],
 "Total size: $0": [
  null,
  "Totale grootte: $0"
 ],
 "Tower": [
  null,
  "Toren"
 ],
 "Troubleshoot": [
  null,
  "Problemen"
 ],
 "Unknown": [
  null,
  "Onbekend"
 ],
 "Usage": [
  null,
  "Gebruik"
 ],
 "Used": [
  null,
  "Gebruikt"
 ],
 "View all CPUs": [
  null,
  "Bekijk alle CPU's"
 ],
 "View all disks": [
  null,
  "Bekijk alle schijven"
 ],
 "View all logs": [
  null,
  "Bekijk alle logboeken"
 ],
 "View detailed logs": [
  null,
  "Bekijk gedetailleerde logboeken"
 ],
 "View per-disk throughput": [
  null,
  "Bekijk doorvoer per schijf"
 ],
 "Visit firewall": [
  null,
  "Bezoek firewall"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Wachten tot andere softwarebeheerhandelingen voltooid zijn"
 ],
 "Write": [
  null,
  "Schrijven"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  "Je moet opnieuw inloggen om statistieken te kunnen zien"
 ],
 "Zone": [
  null,
  "Zone"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bytes binaire data]"
 ],
 "[binary data]": [
  null,
  "[binaire data]"
 ],
 "[no data]": [
  null,
  "[geen data]"
 ],
 "average: $0%": [
  null,
  "gemiddelde: $0%"
 ],
 "cockpit-podman is not installed": [
  null,
  "cockpit-podman is niet geïnstalleerd"
 ],
 "max: $0%": [
  null,
  "max: $0%"
 ],
 "nice": [
  null,
  "nice"
 ],
 "pmlogger.service has failed": [
  null,
  "pmlogger.service is mislukt"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "pmlogger.service kan geen data verzamelen"
 ],
 "pmlogger.service is not running": [
  null,
  "pmlogger.service is niet actief"
 ],
 "pod": [
  null,
  "pod"
 ],
 "show less": [
  null,
  "toon minder"
 ],
 "show more": [
  null,
  "toon meer"
 ],
 "sys": [
  null,
  "sys"
 ],
 "user": [
  null,
  "gebruiker"
 ]
});
