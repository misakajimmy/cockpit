cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 CPU"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 available": [
  null,
  "$0 可用"
 ],
 "$0 free": [
  null,
  "$0 可用"
 ],
 "$0 is not available from any repository.": [
  null,
  "所有仓库都不提供 $0。"
 ],
 "$0 page": [
  null,
  "$0 页"
 ],
 "$0 total": [
  null,
  "$0 总计"
 ],
 "$0 will be installed.": [
  null,
  "将安装 $0。"
 ],
 "1 min": [
  null,
  "1 分钟"
 ],
 "15 min": [
  null,
  "15 分钟"
 ],
 "5 min": [
  null,
  "5 分钟"
 ],
 "Absent": [
  null,
  "缺席"
 ],
 "Add $0": [
  null,
  "添加 $0"
 ],
 "Additional packages:": [
  null,
  "额外的软件包："
 ],
 "Advanced TCA": [
  null,
  "高级 TCA"
 ],
 "All-in-one": [
  null,
  "一体化"
 ],
 "Blade": [
  null,
  "刀片"
 ],
 "Blade enclosure": [
  null,
  "刀片机箱"
 ],
 "Bus expansion chassis": [
  null,
  "总线扩展机箱"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU spike": [
  null,
  "CPU 高负载"
 ],
 "CPU usage": [
  null,
  "CPU 使用率"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Checking installed software": [
  null,
  "检查安装的软件"
 ],
 "Collect metrics": [
  null,
  "收集指标"
 ],
 "Compact PCI": [
  null,
  "紧凑型 PCI"
 ],
 "Convertible": [
  null,
  "可转换"
 ],
 "Core $0": [
  null,
  "内核 $0"
 ],
 "Current top CPU usage": [
  null,
  "当前 top CPU 用量"
 ],
 "Desktop": [
  null,
  "桌面"
 ],
 "Detachable": [
  null,
  "可拆开"
 ],
 "Disk I/O": [
  null,
  "磁盘 I/O"
 ],
 "Disk I/O spike": [
  null,
  "磁盘 I/O 高负载"
 ],
 "Disks": [
  null,
  "磁盘"
 ],
 "Docking station": [
  null,
  "扩展坞"
 ],
 "Downloading $0": [
  null,
  "正在下载 $0"
 ],
 "Dual rank": [
  null,
  "双通道"
 ],
 "Embedded PC": [
  null,
  "嵌入式 PC"
 ],
 "Error has occurred": [
  null,
  "发生错误"
 ],
 "Event": [
  null,
  "事件"
 ],
 "Event logs": [
  null,
  "事件日志"
 ],
 "Expansion chassis": [
  null,
  "扩展机箱"
 ],
 "Export to network": [
  null,
  "导出到网络"
 ],
 "Failed to configure PCP": [
  null,
  "配置 PCP 失败"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "在 firewalld 中启用 $0 失败"
 ],
 "Handheld": [
  null,
  "手持式"
 ],
 "In": [
  null,
  "入"
 ],
 "Install": [
  null,
  "安装"
 ],
 "Install cockpit-pcp": [
  null,
  "安装 cockpit-pcp"
 ],
 "Install software": [
  null,
  "安装软件"
 ],
 "Installing $0": [
  null,
  "正在安装 $0"
 ],
 "Interface": [
  null,
  "接口"
 ],
 "IoT gateway": [
  null,
  "IoT 网关"
 ],
 "Jump to": [
  null,
  "跳到"
 ],
 "Laptop": [
  null,
  "笔记本电脑"
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "Load": [
  null,
  "负载"
 ],
 "Load earlier data": [
  null,
  "载入较早的数据"
 ],
 "Load spike": [
  null,
  "负载激增"
 ],
 "Loading...": [
  null,
  "载入中..."
 ],
 "Log out": [
  null,
  "注销"
 ],
 "Low profile desktop": [
  null,
  "低调桌面"
 ],
 "Lunch box": [
  null,
  "主机类型"
 ],
 "Main server chassis": [
  null,
  "主服务器机箱"
 ],
 "Memory": [
  null,
  "内存"
 ],
 "Memory spike": [
  null,
  "内存激增"
 ],
 "Memory usage": [
  null,
  "内存使用率"
 ],
 "Metrics and history": [
  null,
  "指标和历史数据"
 ],
 "Metrics history could not be loaded": [
  null,
  "无法加载指标历史记录"
 ],
 "Metrics settings": [
  null,
  "指标设置"
 ],
 "Mini PC": [
  null,
  "迷你电脑"
 ],
 "Mini tower": [
  null,
  "迷你塔式主机"
 ],
 "Multi-system chassis": [
  null,
  "多系统机箱"
 ],
 "Network": [
  null,
  "网络"
 ],
 "Network I/O": [
  null,
  "网络 I/O"
 ],
 "Network I/O spike": [
  null,
  "网络 I/O 激增"
 ],
 "Network usage": [
  null,
  "网络使用率"
 ],
 "No data available": [
  null,
  "没有可用数据"
 ],
 "No data available between $0 and $1": [
  null,
  "在 $0 和 $1 间没有可用数据"
 ],
 "No logs found": [
  null,
  "没有找到日志"
 ],
 "Notebook": [
  null,
  "笔记本"
 ],
 "Ok": [
  null,
  "确认"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "在防火墙中打开 pmproxy 服务以共享指标。"
 ],
 "Other": [
  null,
  "其他"
 ],
 "Out": [
  null,
  "出"
 ],
 "Overview": [
  null,
  "概览"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "指标历史记录缺少软件包 cockpit-pcp"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit 已崩溃"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "Performance Co-Pilot 会收集或分析来自您的系统的性能指标。"
 ],
 "Peripheral chassis": [
  null,
  "外设机箱"
 ],
 "Pizza box": [
  null,
  "披萨盒"
 ],
 "Portable": [
  null,
  "手提"
 ],
 "Present": [
  null,
  "当前"
 ],
 "RAID chassis": [
  null,
  "RAID 机箱"
 ],
 "RAM": [
  null,
  "RAM"
 ],
 "Rack mount chassis": [
  null,
  "机架式机箱"
 ],
 "Read": [
  null,
  "读取"
 ],
 "Read more...": [
  null,
  "了解更多..."
 ],
 "Reboot": [
  null,
  "重启"
 ],
 "Removals:": [
  null,
  "移除："
 ],
 "Removing $0": [
  null,
  "正在删除 $0"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Sealed-case PC": [
  null,
  "密封式 PC"
 ],
 "Service": [
  null,
  "服务"
 ],
 "Single rank": [
  null,
  "单 rank"
 ],
 "Space-saving computer": [
  null,
  "节省空间的计算机"
 ],
 "Stick PC": [
  null,
  "PC 棒"
 ],
 "Sub-Chassis": [
  null,
  "子机箱"
 ],
 "Sub-Notebook": [
  null,
  "子笔记本"
 ],
 "Swap": [
  null,
  "交换空间"
 ],
 "Swap out": [
  null,
  "交换出"
 ],
 "Tablet": [
  null,
  "平板"
 ],
 "Today": [
  null,
  "今天"
 ],
 "Top 5 CPU services": [
  null,
  "最顶级的 5 个 CPU 服务"
 ],
 "Top 5 memory services": [
  null,
  "最顶级的 5 个内存服务"
 ],
 "Total size: $0": [
  null,
  "总大小：$0"
 ],
 "Tower": [
  null,
  "Tower"
 ],
 "Troubleshoot": [
  null,
  "排错"
 ],
 "Unknown": [
  null,
  "未知"
 ],
 "Usage": [
  null,
  "用法"
 ],
 "Used": [
  null,
  "已使用"
 ],
 "View all CPUs": [
  null,
  "查看所有 CPU"
 ],
 "View all logs": [
  null,
  "查看所有日志"
 ],
 "View detailed logs": [
  null,
  "查看详细日志"
 ],
 "Visit firewall": [
  null,
  "访问防火墙"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他软件管理操作完成"
 ],
 "Write": [
  null,
  "写入"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  "您需要重新登录才能查看指标历史数据"
 ],
 "Zone": [
  null,
  "区域"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 字节二进制数据]"
 ],
 "[binary data]": [
  null,
  "[二进制数据]"
 ],
 "[no data]": [
  null,
  "[没有数据]"
 ],
 "average: $0%": [
  null,
  "平均：$0%"
 ],
 "cockpit-podman is not installed": [
  null,
  "没有安装 cockpit-podman"
 ],
 "max: $0%": [
  null,
  "最大：$0%"
 ],
 "nice": [
  null,
  "nice"
 ],
 "pmlogger.service has failed": [
  null,
  "pmlogger.service 失败"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "pmlogger.service 收集数据失败"
 ],
 "pmlogger.service is not running": [
  null,
  "pmlogger.service 没有运行"
 ],
 "pod": [
  null,
  "pod"
 ],
 "show less": [
  null,
  "显示更少"
 ],
 "show more": [
  null,
  "显示更多"
 ],
 "sys": [
  null,
  "sys"
 ],
 "user": [
  null,
  "用户"
 ]
});
