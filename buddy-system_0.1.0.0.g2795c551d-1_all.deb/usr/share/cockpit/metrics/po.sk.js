cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 procesor",
  "$0 procesory",
  "$0 procesorov"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 free": [
  null,
  "$0 dostupné"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 nie je k dispozícií v žiadom repozitári."
 ],
 "$0 page": [
  null,
  "$0 stránka",
  "$0 stránky",
  "$0 stránok"
 ],
 "$0 total": [
  null,
  "$0 celkom"
 ],
 "$0 will be installed.": [
  null,
  "$0 bude nainštalovaný."
 ],
 "1 min": [
  null,
  "1 min"
 ],
 "15 min": [
  null,
  "15 min"
 ],
 "5 min": [
  null,
  "5 min"
 ],
 "Absent": [
  null,
  "Chýba"
 ],
 "Add $0": [
  null,
  "Pridať $0"
 ],
 "Additional packages:": [
  null,
  "Ďalšie balíky:"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "All-in-one": [
  null,
  "All-in-one"
 ],
 "Blade": [
  null,
  "Blade"
 ],
 "Blade enclosure": [
  null,
  "Skriňa pre blade servery"
 ],
 "Bus expansion chassis": [
  null,
  ""
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU spike": [
  null,
  ""
 ],
 "CPU usage": [
  null,
  "Využitie procesoru"
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Checking installed software": [
  null,
  "Zisťuje sa nainštalovaný software"
 ],
 "Compact PCI": [
  null,
  "Kompaktné PCI"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Core $0": [
  null,
  ""
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojiteľné"
 ],
 "Device": [
  null,
  "Zariadenie"
 ],
 "Disk I/O": [
  null,
  "Diskový V/V"
 ],
 "Disk I/O spike": [
  null,
  "Vrchol diskového V/V"
 ],
 "Disks": [
  null,
  "Disky"
 ],
 "Docking station": [
  null,
  "Dokovacia stanica"
 ],
 "Downloading $0": [
  null,
  "Sťahuje sa $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Embedded PC": [
  null,
  ""
 ],
 "Error has occurred": [
  null,
  "Vyskytla sa chyba"
 ],
 "Event": [
  null,
  "Udalosť"
 ],
 "Expansion chassis": [
  null,
  ""
 ],
 "Handheld": [
  null,
  "Pre držanie do ruky"
 ],
 "In": [
  null,
  "Vstup"
 ],
 "Install": [
  null,
  "Inštalovať"
 ],
 "Install cockpit-pcp": [
  null,
  "Nainštalovať cockpit-pcp"
 ],
 "Install software": [
  null,
  "Inštalovať software"
 ],
 "Installing $0": [
  null,
  "Inštaluje sa $0"
 ],
 "IoT gateway": [
  null,
  ""
 ],
 "Jump to": [
  null,
  "Preskočiť na"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "Load": [
  null,
  "Záťaž"
 ],
 "Load earlier data": [
  null,
  ""
 ],
 "Load spike": [
  null,
  ""
 ],
 "Loading...": [
  null,
  "Načítavanie..."
 ],
 "Log out": [
  null,
  "Odhlásiť"
 ],
 "Low profile desktop": [
  null,
  "Nízky desktop"
 ],
 "Lunch box": [
  null,
  "Kufríkový počítač"
 ],
 "Main server chassis": [
  null,
  "Hlavná skriňa serveru"
 ],
 "Memory": [
  null,
  "Pamäť"
 ],
 "Memory spike": [
  null,
  ""
 ],
 "Memory usage": [
  null,
  "Využitie pamäte"
 ],
 "Metrics history could not be loaded": [
  null,
  ""
 ],
 "Mini PC": [
  null,
  ""
 ],
 "Mini tower": [
  null,
  ""
 ],
 "Multi-system chassis": [
  null,
  ""
 ],
 "Network": [
  null,
  "Sieť"
 ],
 "Network I/O": [
  null,
  "Sieťový vstup/výstup"
 ],
 "Network I/O spike": [
  null,
  ""
 ],
 "Network usage": [
  null,
  "Využitie siete"
 ],
 "No data available": [
  null,
  "Nie sú dostupné žiadne dáta"
 ],
 "No data available between $0 and $1": [
  null,
  ""
 ],
 "No logs found": [
  null,
  "Nenájdené žiadne záznamy udalostí"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  ""
 ],
 "Other": [
  null,
  "Iný"
 ],
 "Out": [
  null,
  "Výstup"
 ],
 "Overview": [
  null,
  "Prehľad"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "Chýba balík cockpit-pcp a preto nie sú k dispozícií historické metriky"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  ""
 ],
 "Peripheral chassis": [
  null,
  ""
 ],
 "Pizza box": [
  null,
  ""
 ],
 "Portable": [
  null,
  "Prenosný"
 ],
 "Present": [
  null,
  "Prítomné"
 ],
 "RAID chassis": [
  null,
  "RAID skriňa"
 ],
 "RAM": [
  null,
  "RAM"
 ],
 "Rack mount chassis": [
  null,
  ""
 ],
 "Read": [
  null,
  "Čítanie"
 ],
 "Read more...": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "Reštartovať"
 ],
 "Removals:": [
  null,
  "Odstránenia:"
 ],
 "Removing $0": [
  null,
  "Odstraňuje sa $0"
 ],
 "Save": [
  null,
  "Uložiť"
 ],
 "Sealed-case PC": [
  null,
  "Počítač so zapäčatenou skriňou"
 ],
 "Service": [
  null,
  "Služba"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Space-saving computer": [
  null,
  "Miesto-šetriaci počítač"
 ],
 "Stick PC": [
  null,
  ""
 ],
 "Sub-Chassis": [
  null,
  "Podskriňa"
 ],
 "Sub-Notebook": [
  null,
  "Sub-Notebook"
 ],
 "Swap": [
  null,
  "Odkladanie"
 ],
 "Swap out": [
  null,
  ""
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Today": [
  null,
  "Dnes"
 ],
 "Top 5 CPU services": [
  null,
  "5 služieb najviac vyťažujúcich procesor"
 ],
 "Top 5 memory services": [
  null,
  ""
 ],
 "Total size: $0": [
  null,
  "Celková veľkosť: $0"
 ],
 "Tower": [
  null,
  "Veža"
 ],
 "Troubleshoot": [
  null,
  "Riešiť problém"
 ],
 "Unknown": [
  null,
  "Neznáme"
 ],
 "Usage": [
  null,
  "Využitie"
 ],
 "Used": [
  null,
  "Využité"
 ],
 "View per-disk throughput": [
  null,
  ""
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čaká sa na dokončenie ostatných operácií správy balíčkov"
 ],
 "Write": [
  null,
  "Zápis"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  ""
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "[$0 bytes of binary data]": [
  null,
  ""
 ],
 "[binary data]": [
  null,
  "[binárne dáta]"
 ],
 "[no data]": [
  null,
  "[žiadne dáta]"
 ],
 "average: $0%": [
  null,
  ""
 ],
 "max: $0%": [
  null,
  ""
 ],
 "nice": [
  null,
  "prednosť (nice)"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  ""
 ],
 "pmlogger.service is not running": [
  null,
  "pmlogger.service nebeží"
 ],
 "pod": [
  null,
  ""
 ],
 "show less": [
  null,
  "ukázať menej"
 ],
 "show more": [
  null,
  "ukázať viac"
 ],
 "sys": [
  null,
  "sys"
 ],
 "user": [
  null,
  "užívateľ"
 ]
});
