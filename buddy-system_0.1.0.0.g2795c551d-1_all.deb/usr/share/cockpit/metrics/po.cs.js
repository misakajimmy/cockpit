cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 CPU": [
  null,
  "$0 procesor",
  "$0 procesory",
  "$0 procesorů"
 ],
 "$0 GiB": [
  null,
  "$0 GiB"
 ],
 "$0 available": [
  null,
  "$0 k dispozici"
 ],
 "$0 free": [
  null,
  "$0 volné"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 není k dispozici z žádného z repozitářů."
 ],
 "$0 page": [
  null,
  "$0 stránka",
  "$0 stránky",
  "$0 stránek"
 ],
 "$0 total": [
  null,
  "$0 celkem"
 ],
 "$0 will be installed.": [
  null,
  "$0 bude nainstalováno."
 ],
 "1 min": [
  null,
  "1 minuta"
 ],
 "15 min": [
  null,
  "15 min"
 ],
 "5 min": [
  null,
  "5 min"
 ],
 "Absent": [
  null,
  "Chybí"
 ],
 "Add $0": [
  null,
  "Přidat $0"
 ],
 "Additional packages:": [
  null,
  "Další balíčky:"
 ],
 "Advanced TCA": [
  null,
  "Pokročilé TCA"
 ],
 "All-in-one": [
  null,
  "Vše-v-jednom"
 ],
 "Blade": [
  null,
  "Blade server"
 ],
 "Blade enclosure": [
  null,
  "Skříň se šachtami pro blade servery"
 ],
 "Bus expansion chassis": [
  null,
  "Skříň rozšíření sběrnice"
 ],
 "CPU": [
  null,
  "Procesor"
 ],
 "CPU spike": [
  null,
  "Špička procesoru"
 ],
 "CPU usage": [
  null,
  "Využití procesoru"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Checking installed software": [
  null,
  "Zjišťuje se nainstalovaný sofware"
 ],
 "Collect metrics": [
  null,
  "Shromažďovat metriky"
 ],
 "Compact PCI": [
  null,
  "Compact PCI"
 ],
 "Convertible": [
  null,
  "Počítač 2v1"
 ],
 "Core $0": [
  null,
  "Jádro $0"
 ],
 "Desktop": [
  null,
  "Desktop"
 ],
 "Detachable": [
  null,
  "Odpojitelné"
 ],
 "Device": [
  null,
  "Zařízení"
 ],
 "Disk I/O": [
  null,
  "Diskový vst/výst."
 ],
 "Disk I/O spike": [
  null,
  "Špička diskového vst/výst."
 ],
 "Disks": [
  null,
  "Disky"
 ],
 "Docking station": [
  null,
  "Dokovací stanice"
 ],
 "Downloading $0": [
  null,
  "Stahuje se $0"
 ],
 "Dual rank": [
  null,
  "Dual rank"
 ],
 "Embedded PC": [
  null,
  "Jednodeskový počítač"
 ],
 "Error has occurred": [
  null,
  "Došlo k chybě"
 ],
 "Event": [
  null,
  "Událost"
 ],
 "Event logs": [
  null,
  "Záznamy událostí"
 ],
 "Expansion chassis": [
  null,
  "Rozšiřující šasi"
 ],
 "Export to network": [
  null,
  "Exportovat do sítě"
 ],
 "Failed to configure PCP": [
  null,
  "Nepodařilo se nastavit PCP"
 ],
 "Failed to enable $0 in firewalld": [
  null,
  "Nepodařilo se povolit $0 ve firewalld"
 ],
 "Handheld": [
  null,
  "Pro držení v rukou"
 ],
 "In": [
  null,
  "V"
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Install cockpit-pcp": [
  null,
  "Nainstalovat cockpit-pcp"
 ],
 "Install software": [
  null,
  "Nainstalovat software"
 ],
 "Installing $0": [
  null,
  "Instaluje se $0"
 ],
 "IoT gateway": [
  null,
  "Brána Internetu věcí (IoT)"
 ],
 "Jump to": [
  null,
  "Přeskočit na"
 ],
 "Laptop": [
  null,
  "Notebook"
 ],
 "Learn more": [
  null,
  "Další informace naleznete"
 ],
 "Load": [
  null,
  "Načíst"
 ],
 "Load earlier data": [
  null,
  "Načíst dřívější data"
 ],
 "Load spike": [
  null,
  "Špička vytížení"
 ],
 "Loading...": [
  null,
  "Načítání…"
 ],
 "Log out": [
  null,
  "Odhlásit"
 ],
 "Low profile desktop": [
  null,
  "Nízký desktop"
 ],
 "Lunch box": [
  null,
  "Kufříkový počítač"
 ],
 "Main server chassis": [
  null,
  "Hlavní skříň serveru"
 ],
 "Memory": [
  null,
  "Paměť"
 ],
 "Memory spike": [
  null,
  "Špička využití paměti"
 ],
 "Memory usage": [
  null,
  "Využití paměti"
 ],
 "Metrics history could not be loaded": [
  null,
  "Nepodařilo se načíst historické metriky"
 ],
 "Metrics settings": [
  null,
  "Nastavení metrik"
 ],
 "Mini PC": [
  null,
  "Mini PC"
 ],
 "Mini tower": [
  null,
  "Mini věž"
 ],
 "Multi-system chassis": [
  null,
  "Skříň pro více systémů"
 ],
 "Network": [
  null,
  "Síť"
 ],
 "Network I/O": [
  null,
  "Síťový vstup/výstup"
 ],
 "Network I/O spike": [
  null,
  "Špička vstupu/výstupu sítě"
 ],
 "Network usage": [
  null,
  "Využití sítě"
 ],
 "No data available": [
  null,
  "Nejsou k dispozici žádná data"
 ],
 "No data available between $0 and $1": [
  null,
  "Nejsou k dispozici žádná data z rozmezí $0 až $1"
 ],
 "No logs found": [
  null,
  "Nenalezeny žádné záznamy událostí"
 ],
 "Notebook": [
  null,
  "Notebook"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Open the pmproxy service in the firewall to share metrics.": [
  null,
  "Pokud chcete sdílet metriky, otevřete na bráně firewall komunikaci pro službu pmproxy."
 ],
 "Other": [
  null,
  "Ostatní"
 ],
 "Out": [
  null,
  "Výstup"
 ],
 "Overview": [
  null,
  "Přehled"
 ],
 "Package cockpit-pcp is missing for metrics history": [
  null,
  "Chybí balíček cockpit-pcp a proto není k dispozici historie metrik"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Performance Co-Pilot collects and analyzes performance metrics from your system.": [
  null,
  "Performance Co-Pilot shromažďuje a analyzuje výkonnostní metriky z vašeho systému."
 ],
 "Peripheral chassis": [
  null,
  "Skříň periferií"
 ],
 "Pizza box": [
  null,
  "Velikost „krabice od pizzy“"
 ],
 "Portable": [
  null,
  "Přenosný"
 ],
 "Present": [
  null,
  "Přítomno"
 ],
 "RAID chassis": [
  null,
  "RAID skříň"
 ],
 "RAM": [
  null,
  "Operační paměť"
 ],
 "Rack mount chassis": [
  null,
  "Skříň do stojanu"
 ],
 "Read": [
  null,
  "Čtení"
 ],
 "Read more...": [
  null,
  "Zjistit více…"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Removals:": [
  null,
  "Odebrání:"
 ],
 "Removing $0": [
  null,
  "Odebírá se $0"
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "Sealed-case PC": [
  null,
  "Počítač se zapečetěnou skříní"
 ],
 "Service": [
  null,
  "Služba"
 ],
 "Single rank": [
  null,
  "Single rank"
 ],
 "Space-saving computer": [
  null,
  "Prostorově úsporný počítač"
 ],
 "Stick PC": [
  null,
  "Počítač v klíčence"
 ],
 "Sub-Chassis": [
  null,
  "Dílčí skříň"
 ],
 "Sub-Notebook": [
  null,
  "Zmenšený notebook"
 ],
 "Swap": [
  null,
  "Odkládací oddíl"
 ],
 "Swap out": [
  null,
  "Odstránkováno"
 ],
 "Tablet": [
  null,
  "Tablet"
 ],
 "Today": [
  null,
  "Dnes"
 ],
 "Top 5 CPU services": [
  null,
  "5 služeb nejvíce vytěžujících procesor"
 ],
 "Top 5 memory services": [
  null,
  "5 služeb zabírajících nejvíce paměti"
 ],
 "Total size: $0": [
  null,
  "Celková velikost: $0"
 ],
 "Tower": [
  null,
  "Věž"
 ],
 "Troubleshoot": [
  null,
  "Řešit potíže"
 ],
 "Unknown": [
  null,
  "Neznámé"
 ],
 "Usage": [
  null,
  "Použití"
 ],
 "Used": [
  null,
  "Využito"
 ],
 "View all logs": [
  null,
  "Zobrazit všechny záznamy událostí"
 ],
 "View per-disk throughput": [
  null,
  ""
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čeká se na dokončení ostatních operací správy balíčků"
 ],
 "Write": [
  null,
  "Zápis"
 ],
 "You need to relogin to be able to see metrics history": [
  null,
  "Pro zobrazení historie metrik je třeba, abyste se odhlásili a znovu přihlásili"
 ],
 "Zone": [
  null,
  "Zóna"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bajtů binárních dat]"
 ],
 "[binary data]": [
  null,
  "[binarní data]"
 ],
 "[no data]": [
  null,
  "[žádná data]"
 ],
 "average: $0%": [
  null,
  ""
 ],
 "max: $0%": [
  null,
  ""
 ],
 "nice": [
  null,
  "pořadí přednosti (nice)"
 ],
 "pmlogger.service has failed": [
  null,
  "služba pmlogger.service zhavarovala"
 ],
 "pmlogger.service is failing to collect data": [
  null,
  "službě pmlogger.service se nedaří shromažďovat data"
 ],
 "pmlogger.service is not running": [
  null,
  "služba pmlogger.service není spuštěná"
 ],
 "pod": [
  null,
  ""
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "sys": [
  null,
  "sys"
 ],
 "user": [
  null,
  "uživatel"
 ]
});
