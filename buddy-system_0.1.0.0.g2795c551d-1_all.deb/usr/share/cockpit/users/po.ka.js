cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  ""
 ],
 "Account expiration": [
  null,
  "ანგარიშის ვადა"
 ],
 "Account not available or cannot be edited.": [
  null,
  "ანგარიში ხელმიუწვდომელია ან ჩასწორებას არ ექვემდებარება."
 ],
 "Accounts": [
  null,
  "ანგარიშები"
 ],
 "Add": [
  null,
  "დამატება"
 ],
 "Add key": [
  null,
  "გასაღების დამატება"
 ],
 "Add public key": [
  null,
  "საჯარო გასაღების დამატება"
 ],
 "Adding key": [
  null,
  "გასაღების დამატება"
 ],
 "Authentication": [
  null,
  "ავთენტიკაცია"
 ],
 "Authorized public SSH keys": [
  null,
  "ავტორიზებული საჯარო SSH გასაღებები"
 ],
 "Back to accounts": [
  null,
  "ანგარიშებზე დაბრუნება"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Change": [
  null,
  "შეცვლა"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Confirm": [
  null,
  "დასტური"
 ],
 "Confirm new password": [
  null,
  "მეორედ შეიყვანეთ ახალი პაროლი"
 ],
 "Container administrator": [
  null,
  "კონტეინერის ადმინისტრატორი"
 ],
 "Create": [
  null,
  "შექმნა"
 ],
 "Create account with weak password": [
  null,
  "შექმენით ანგარიში სუსტი პაროლით"
 ],
 "Create new account": [
  null,
  "ახალი ანგარიშის შექმნა"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Delete $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Delete account": [
  null,
  "ანგარიშის წაშლა"
 ],
 "Delete files": [
  null,
  "ფაილების წაშლა"
 ],
 "Disallow interactive password": [
  null,
  "პაროლის ხელით შეყვანის აკრძალვა"
 ],
 "Disallow password authentication": [
  null,
  "პაროლით შესვლის აკრძალვა"
 ],
 "Edit user": [
  null,
  "მომხმარებლის ჩასწორება"
 ],
 "Ended": [
  null,
  "დასრულდა"
 ],
 "Error saving authorized keys: ": [
  null,
  "ავტორიზაციის გასაღებების ჩაწერის შეცდომა: "
 ],
 "Excellent password": [
  null,
  "გადასარევი პაროლი"
 ],
 "Expire account on": [
  null,
  "ანგარიშის ვადა"
 ],
 "Expire account on $0": [
  null,
  "ანგარიშის ვადა $0"
 ],
 "Failed to change password": [
  null,
  "პაროლის შეცვლის შეცდომა"
 ],
 "Failed to load authorized keys.": [
  null,
  "ავტორიზებული გასაღებების ჩატვირთვის შეცდომა."
 ],
 "Force change": [
  null,
  "ძალით შეცვლა"
 ],
 "Force password change": [
  null,
  "პაროლის ძალით შეცვლა"
 ],
 "From": [
  null,
  "დასაწყისი"
 ],
 "Full name": [
  null,
  "სრული სახელი"
 ],
 "Group": [
  null,
  "ჯგუფი"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Image builder": [
  null,
  "გამოსახულების ამგები"
 ],
 "Invalid expiration date": [
  null,
  "არასწორი ვადა"
 ],
 "Invalid key": [
  null,
  "არასწორი გასაღები"
 ],
 "Invalid number of days": [
  null,
  "დღეებს არასწორი რაოდენობა"
 ],
 "Last active": [
  null,
  "ბოლოს აქტიური"
 ],
 "Last login": [
  null,
  "ბოლო შესვლა"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "Local accounts": [
  null,
  "ლოკალური ანგარიშები"
 ],
 "Lock": [
  null,
  "დაკეტვა"
 ],
 "Lock $0": [
  null,
  "$0-ის დაბლოკვა"
 ],
 "Lock account": [
  null,
  "ანგარიშის დაბლოკვა"
 ],
 "Log out": [
  null,
  "გასვლა"
 ],
 "Log user out": [
  null,
  "მომხმარებლის გაგდება"
 ],
 "Logged in": [
  null,
  "შესვლა წარმატებულია"
 ],
 "Login history": [
  null,
  "შესვლების ისტორია"
 ],
 "Login history list": [
  null,
  "შესვლის ისტორია"
 ],
 "Logout $0": [
  null,
  "$0-ის გაგდება"
 ],
 "Managing user accounts": [
  null,
  "მომხმარებლების ანგარიშების მართვა"
 ],
 "Never": [
  null,
  "არასდროს"
 ],
 "Never expire account": [
  null,
  "უვადო ანგარიში"
 ],
 "Never expire password": [
  null,
  "უვადო პაროლი"
 ],
 "Never logged in": [
  null,
  "არასდროს შემოსულა"
 ],
 "New password": [
  null,
  "ახალი პაროლი"
 ],
 "New password was not accepted": [
  null,
  "ახალი პაროლი მიუღებელია"
 ],
 "No matching results": [
  null,
  "პასუხები არაა"
 ],
 "No real name specified": [
  null,
  "რეალური სახელი მითითებული არაა"
 ],
 "No user name specified": [
  null,
  "მომხმარებელი მითითებული არაა"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "Old password": [
  null,
  "ძველი პაროლი"
 ],
 "Old password not accepted": [
  null,
  "ძველი პაროლი მიუღებელია"
 ],
 "Options": [
  null,
  "პარამეტრები"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "ავთენტიკაციის სხვა მეთოდები ჯერ კიდევ ხელმისაწვდომია იმ დროსაც კი, როცა პაროლით ინტერაქტიული ავთენტიკაცია გამორთულია."
 ],
 "Password": [
  null,
  "პაროლი"
 ],
 "Password expiration": [
  null,
  "პაროლის ვადა"
 ],
 "Password is longer than 256 characters": [
  null,
  "პაროლი 256 სიმბოლოზე გრძელია"
 ],
 "Password is not acceptable": [
  null,
  "პაროლი მიუღებელია"
 ],
 "Password is too weak": [
  null,
  "პაროლი ძალიან სუსტია"
 ],
 "Password must be changed": [
  null,
  "საჭიროა პაროლის შეცვლა"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "ჩააკოპირეთ SSH-ის თქვენი საჯარო გასაღების შემცველობა"
 ],
 "Pick date": [
  null,
  "აირჩიეთ თარიღი"
 ],
 "Please specify an expiration date": [
  null,
  "დააყენეთ ვადა"
 ],
 "Prompting via passwd timed out": [
  null,
  "მოთხოვნას passwd-ის გავლით ვადა გაუვიდა"
 ],
 "Remove": [
  null,
  "წაშლა"
 ],
 "Require password change every $0 days": [
  null,
  "პაროლის შეცვლა ყოველ $0 დღეში"
 ],
 "Require password change on $0": [
  null,
  "$0-ზე პაროლის შეცვლის მოთხოვნა"
 ],
 "Require password change on first login": [
  null,
  "პირველ შესვლაზე პაროლის შეცვლის მოთხოვნა"
 ],
 "Reset password": [
  null,
  "პაროლის თავიდან დაყენება"
 ],
 "Roles": [
  null,
  "როლები"
 ],
 "Search for name, group or ID": [
  null,
  "სახელით, ჯგუფით ან ID-ით ძებნა"
 ],
 "Server administrator": [
  null,
  "სერვერი ადმინისტრატორი"
 ],
 "Set password": [
  null,
  "პაროლის დაყენება"
 ],
 "Set weak password": [
  null,
  "დააყენეთ სუსტი პაროლი"
 ],
 "Started": [
  null,
  "დაწყებულია"
 ],
 "Terminate session": [
  null,
  "სესიის დასრულება"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "ანგარიში '$0' შემდეგ შესვლაზე იძულებული იქნება პაროლი შეცვალოს"
 ],
 "The full name must not contain colons.": [
  null,
  "სრული სახელი ორწერტილებს არ უნდა შეიცავდეს."
 ],
 "The key you provided was not valid.": [
  null,
  "დამატებული გასაღები არასწორია."
 ],
 "The passwords do not match": [
  null,
  "პაროლები არ ემთხვევა"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "როლების სრულად შესაცვლელად მომხმარებელი თავიდან უნდა შევიდეს სისტემაში."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "მომხმარებლის სახელი შეიძლება მხოლოდ შეიცავდეს a-z სიმბოლოებს, ციფრებს, წერტილებს, ტირეებს და ქვედა ტირეებს."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "ამ ანგარიშისთვის ავტორიზებული საჯარო გასაღებები ხელმიუწვდომელია."
 ],
 "This group is the primary group for the following users:": [
  null,
  ""
 ],
 "This user name already exists": [
  null,
  "მომხმარებლის სახელი უკვე არსებობს"
 ],
 "Toggle date picker": [
  null,
  "თარიღის ამრჩევის გადართვა"
 ],
 "Unexpected error": [
  null,
  "მოულოდნელი შეცდომა"
 ],
 "Unix group: $0": [
  null,
  "Unix ჯგუფი: $0"
 ],
 "Unnamed": [
  null,
  "უსახელო"
 ],
 "Use password": [
  null,
  "პაროლის გამოყენება"
 ],
 "User name": [
  null,
  "მომხმარებლის სახელი"
 ],
 "Username": [
  null,
  "მომხმარებლის სახელი"
 ],
 "Validating key": [
  null,
  "გასაღების დადასტურება"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "არ გაქვთ ამ ანგარიშის საჯარო გასაღებების ნახვის წვდომა."
 ],
 "You must wait longer to change your password": [
  null,
  "პაროლის შესაცვლელად უფრო მეტხანს უნდა მოითმინოთ"
 ],
 "Your account": [
  null,
  "თქვენი ანგარიში"
 ],
 "access": [
  null,
  "წვდომა"
 ],
 "edit": [
  null,
  "ჩასწორება"
 ],
 "keys": [
  null,
  "გასაღებები"
 ],
 "login": [
  null,
  "შესვლა"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "პაროლი"
 ],
 "password quality": [
  null,
  "პაროლის ხარისხი"
 ],
 "roles": [
  null,
  "როლები"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "მომხმარებელი"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "მომხმარებლის სახელი"
 ]
});
