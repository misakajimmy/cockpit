cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  ""
 ],
 "Account expiration": [
  null,
  "Konto utløper"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Kontoen er ikke tilgjengelig eller kan ikke redigeres."
 ],
 "Accounts": [
  null,
  "Kontoer"
 ],
 "Add": [
  null,
  "Legg til"
 ],
 "Add key": [
  null,
  "Legg til nøkkel"
 ],
 "Add public key": [
  null,
  "Legg til offentlig nøkkel"
 ],
 "Adding key": [
  null,
  "Legger til nøkkel"
 ],
 "Authentication": [
  null,
  "Autentisering"
 ],
 "Authorized public SSH keys": [
  null,
  "Autoriserte offentlige SSH-nøkler"
 ],
 "Back to accounts": [
  null,
  "Tilbake til kontoer"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Change": [
  null,
  "Endre"
 ],
 "Close": [
  null,
  "Lukk"
 ],
 "Confirm": [
  null,
  "Bekreft"
 ],
 "Confirm new password": [
  null,
  "Bekreft nytt passord"
 ],
 "Container administrator": [
  null,
  "Container administrator"
 ],
 "Create": [
  null,
  "Opprett"
 ],
 "Create account with weak password": [
  null,
  ""
 ],
 "Create new account": [
  null,
  "Opprett ny konto"
 ],
 "Delete": [
  null,
  "Slett"
 ],
 "Delete $0": [
  null,
  "Slett $0"
 ],
 "Delete files": [
  null,
  "Slett filer"
 ],
 "Disallow password authentication": [
  null,
  ""
 ],
 "Ended": [
  null,
  ""
 ],
 "Error saving authorized keys: ": [
  null,
  "Feil ved lagring av autoriserte nøkler: "
 ],
 "Excellent password": [
  null,
  "Utmerket passord"
 ],
 "Failed to change password": [
  null,
  "Kunne ikke endre passord"
 ],
 "Failed to load authorized keys.": [
  null,
  "Kunne ikke laste autoriserte nøkler."
 ],
 "Force change": [
  null,
  "Tving endring"
 ],
 "Force password change": [
  null,
  "Tving passordendring"
 ],
 "From": [
  null,
  ""
 ],
 "Full name": [
  null,
  "Fullt navn"
 ],
 "Group": [
  null,
  "Gruppe"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Image builder": [
  null,
  ""
 ],
 "Invalid expiration date": [
  null,
  "Ugyldig utløpsdato"
 ],
 "Invalid key": [
  null,
  "Ugyldig nøkkel"
 ],
 "Invalid number of days": [
  null,
  "Ugyldig antall dager"
 ],
 "Last login": [
  null,
  "Siste innlogging"
 ],
 "Learn more": [
  null,
  "Lær mer"
 ],
 "Local accounts": [
  null,
  "Lokale kontoer"
 ],
 "Lock": [
  null,
  "Lås"
 ],
 "Lock account": [
  null,
  "Lås konto"
 ],
 "Log out": [
  null,
  "Logg ut"
 ],
 "Logged in": [
  null,
  "Logget inn"
 ],
 "Login history list": [
  null,
  ""
 ],
 "Managing user accounts": [
  null,
  "Administrere brukerkontoer"
 ],
 "Never": [
  null,
  "Aldri"
 ],
 "Never expire password": [
  null,
  "Passordet utløper aldri"
 ],
 "New password": [
  null,
  "Nytt passord"
 ],
 "New password was not accepted": [
  null,
  "Nytt passord ble ikke godtatt"
 ],
 "No matching results": [
  null,
  "Ingen samsvarende resultater"
 ],
 "No real name specified": [
  null,
  "Ingen virkelige navn angitt"
 ],
 "No user name specified": [
  null,
  "Ingen brukernavn spesifisert"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password": [
  null,
  "Gammelt passord"
 ],
 "Old password not accepted": [
  null,
  "Gammelt passord aksepteres ikke"
 ],
 "Options": [
  null,
  "Alternativer"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  ""
 ],
 "Password": [
  null,
  "Passord"
 ],
 "Password expiration": [
  null,
  "Passord utløper"
 ],
 "Password is not acceptable": [
  null,
  "Passord er ikke akseptabelt"
 ],
 "Password is too weak": [
  null,
  "Passordet er for svakt"
 ],
 "Password must be changed": [
  null,
  "Passord må endres"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Lim inn innholdet i den offentlige SSH-nøkkelfilen din her"
 ],
 "Pick date": [
  null,
  "Velg dato"
 ],
 "Please specify an expiration date": [
  null,
  "Angi en utløpsdato"
 ],
 "Prompting via passwd timed out": [
  null,
  "Spørring via passwd ble tidsavbrutt"
 ],
 "Remove": [
  null,
  "Fjern"
 ],
 "Require password change every $0 days": [
  null,
  "Krev passordendring hver $0 dager"
 ],
 "Require password change on $0": [
  null,
  "Krev passordendring på $0"
 ],
 "Reset password": [
  null,
  "Tilbakestill passord"
 ],
 "Roles": [
  null,
  "Roller"
 ],
 "Search for name, group or ID": [
  null,
  ""
 ],
 "Server administrator": [
  null,
  "Server administrator"
 ],
 "Set password": [
  null,
  "Angi passord"
 ],
 "Terminate session": [
  null,
  "Avslutt økt"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Kontoen '$0' vil bli tvunget til å endre passordet ved neste pålogging"
 ],
 "The full name must not contain colons.": [
  null,
  ""
 ],
 "The key you provided was not valid.": [
  null,
  "Nøkkelen du oppga var ikke gyldig."
 ],
 "The passwords do not match": [
  null,
  "Passordene samsvarer ikke"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "Brukeren må logge ut og logge inn for å endre rolle fullstendig."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Brukernavnet kan bare bestå av bokstaver fra a-z, sifre, prikker, bindestreker og understrekninger."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Det er ingen autoriserte offentlige nøkler for denne kontoen."
 ],
 "This group is the primary group for the following users:": [
  null,
  ""
 ],
 "This user name already exists": [
  null,
  "Dette brukernavnet finnes allerede"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Unexpected error": [
  null,
  "Uventet feil"
 ],
 "Unix group: $0": [
  null,
  "Unix-gruppe: $0"
 ],
 "Unnamed": [
  null,
  "Uten navn"
 ],
 "User name": [
  null,
  "Brukernavn"
 ],
 "Username": [
  null,
  "Brukernavn"
 ],
 "Validating key": [
  null,
  "Validerer nøkkel"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Du har ikke tillatelse til å se de autoriserte offentlige nøklene for denne kontoen."
 ],
 "You must wait longer to change your password": [
  null,
  "Du må vente lenger på å endre passordet ditt"
 ],
 "Your account": [
  null,
  "Din konto"
 ],
 "access": [
  null,
  "tilgang"
 ],
 "edit": [
  null,
  "rediger"
 ],
 "keys": [
  null,
  "nøkler"
 ],
 "login": [
  null,
  ""
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "passord"
 ],
 "password quality": [
  null,
  "passordkvalitet"
 ],
 "roles": [
  null,
  "roller"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "bruker"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "brukernavn"
 ]
});
