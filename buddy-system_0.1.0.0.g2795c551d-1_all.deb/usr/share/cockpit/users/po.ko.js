cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  "# 사용자"
 ],
 "$0 more...": [
  null,
  "$0 더 알아보기..."
 ],
 "Account expiration": [
  null,
  "계정 만료"
 ],
 "Account not available or cannot be edited.": [
  null,
  "계정을 사용할 수 없거나 편집 할 수 없습니다."
 ],
 "Accounts": [
  null,
  "계정"
 ],
 "Add": [
  null,
  "추가"
 ],
 "Add key": [
  null,
  "키 추가"
 ],
 "Add public key": [
  null,
  "공개 키 추가"
 ],
 "Adding key": [
  null,
  "키 추가 중"
 ],
 "Authentication": [
  null,
  "인증"
 ],
 "Authorized public SSH keys": [
  null,
  "승인된 공개 SSH 키"
 ],
 "Back to accounts": [
  null,
  "계정으로 돌아가기"
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Change": [
  null,
  "변경"
 ],
 "Close": [
  null,
  "닫기"
 ],
 "Confirm": [
  null,
  "확인"
 ],
 "Confirm new password": [
  null,
  "신규 비밀번호 확인"
 ],
 "Container administrator": [
  null,
  "컨테이너 관리자"
 ],
 "Create": [
  null,
  "생성"
 ],
 "Create account with weak password": [
  null,
  "약한 암호로 계정 만들기"
 ],
 "Create new account": [
  null,
  "신규 계정 만들기"
 ],
 "Delete": [
  null,
  "삭제"
 ],
 "Delete $0": [
  null,
  "$0 삭제"
 ],
 "Delete $0 group": [
  null,
  "$0 그룹 삭제"
 ],
 "Delete account": [
  null,
  "계정 삭제"
 ],
 "Delete files": [
  null,
  "파일 삭제"
 ],
 "Delete group": [
  null,
  "그룹 삭제"
 ],
 "Disallow interactive password": [
  null,
  "대화형 비밀번호 허용 안 함"
 ],
 "Disallow password authentication": [
  null,
  "비밀번호 인증을 허용하지 않습니다"
 ],
 "Edit user": [
  null,
  "사용자 편집"
 ],
 "Ended": [
  null,
  "종료됨"
 ],
 "Error saving authorized keys: ": [
  null,
  "승인된 키를 저장하는 동안 오류가 발생했습니다: "
 ],
 "Excellent password": [
  null,
  "우수한 비밀번호"
 ],
 "Expire account on": [
  null,
  "계정 만료"
 ],
 "Expire account on $0": [
  null,
  "$0의 계정 만료"
 ],
 "Failed to change password": [
  null,
  "비밀번호 변경 실패"
 ],
 "Failed to load authorized keys.": [
  null,
  "승인된 키를 불러오지 못했습니다."
 ],
 "Force change": [
  null,
  "강제 변경"
 ],
 "Force delete": [
  null,
  "강제 삭제"
 ],
 "Force password change": [
  null,
  "강제 비밀번호 변경"
 ],
 "From": [
  null,
  "에서"
 ],
 "Full name": [
  null,
  "성명"
 ],
 "Group": [
  null,
  "그룹"
 ],
 "Group name": [
  null,
  "그룹 이름"
 ],
 "Groups": [
  null,
  "그룹"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Image builder": [
  null,
  "이미지 빌더"
 ],
 "Invalid expiration date": [
  null,
  "잘못된 만료 기간"
 ],
 "Invalid key": [
  null,
  "잘못된 키"
 ],
 "Invalid number of days": [
  null,
  "일 수가 잘못되었습니다"
 ],
 "Last active": [
  null,
  "최근 활성"
 ],
 "Last login": [
  null,
  "마지막 로그인"
 ],
 "Learn more": [
  null,
  "더 알아보기"
 ],
 "Local accounts": [
  null,
  "로컬 계정"
 ],
 "Lock": [
  null,
  "잠그기"
 ],
 "Lock $0": [
  null,
  "$0 잠금"
 ],
 "Lock account": [
  null,
  "계정 잠금"
 ],
 "Log out": [
  null,
  "로그아웃"
 ],
 "Log user out": [
  null,
  "사용자 로그아웃"
 ],
 "Logged in": [
  null,
  "로그인 상태"
 ],
 "Login history": [
  null,
  "로그인 기록"
 ],
 "Login history list": [
  null,
  "로그인 기록 목록"
 ],
 "Logout $0": [
  null,
  "$0 로그아웃"
 ],
 "Managing user accounts": [
  null,
  "사용자 계정 관리"
 ],
 "Never": [
  null,
  "하지 않기"
 ],
 "Never expire account": [
  null,
  "계정 잠금을 하지 않습니다"
 ],
 "Never expire password": [
  null,
  "비밀번호가 만료되어서는 안됩니다"
 ],
 "Never logged in": [
  null,
  "로그인 하지 않음"
 ],
 "New password": [
  null,
  "신규 비밀번호"
 ],
 "New password was not accepted": [
  null,
  "신규 비밀번호가 허용되지 않습니다"
 ],
 "No matching results": [
  null,
  "일치하는 결과를 찾을 수 없습니다"
 ],
 "No real name specified": [
  null,
  "실제 이름이 지정되지 않았습니다"
 ],
 "No user name specified": [
  null,
  "지정된 사용자 이름이 없습니다"
 ],
 "Ok": [
  null,
  "확인"
 ],
 "Old password": [
  null,
  "이전 비밀번호"
 ],
 "Old password not accepted": [
  null,
  "이전 비밀번호가 허용되지 않습니다"
 ],
 "Options": [
  null,
  "옵션"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "다른 인증 방식은 대화형 비밀번호 인증이 허용되지 않을 때에 여전히 사용 할 수 있습니다."
 ],
 "Password": [
  null,
  "비밀번호"
 ],
 "Password expiration": [
  null,
  "비밀번호 만료"
 ],
 "Password is longer than 256 characters": [
  null,
  "비밀번호는 256자보다 길 수 있습니다"
 ],
 "Password is not acceptable": [
  null,
  "비밀번호가 허용되지 않습니다"
 ],
 "Password is too weak": [
  null,
  "비밀번호가 너무 취약합니다"
 ],
 "Password must be changed": [
  null,
  "비밀번호를 변경해야 합니다"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "SSH 공개키 파일 내용을 여기에 붙여넣기합니다"
 ],
 "Pick date": [
  null,
  "날짜 선택"
 ],
 "Please specify an expiration date": [
  null,
  "만료 날짜를 지정해 주십시오"
 ],
 "Prompting via passwd timed out": [
  null,
  "비밀번호를 통한 메세지 제공 시간이 초과되었습니다"
 ],
 "Remove": [
  null,
  "제거"
 ],
 "Require password change every $0 days": [
  null,
  "$0 일 마다 비밀번호를 변경해야 합니다"
 ],
 "Require password change on $0": [
  null,
  "$0에서 비밀번호를 변경해야 합니다"
 ],
 "Require password change on first login": [
  null,
  "처음 로그인에서 비밀번호를 변경해야 합니다"
 ],
 "Reset password": [
  null,
  "비밀번호 재설정"
 ],
 "Roles": [
  null,
  "역할"
 ],
 "Search for name, group or ID": [
  null,
  "이름, 그룹 또는 ID 검색"
 ],
 "Server administrator": [
  null,
  "서버 관리자"
 ],
 "Set password": [
  null,
  "비밀번호 설정"
 ],
 "Set weak password": [
  null,
  "약한 비밀번호 설정"
 ],
 "Started": [
  null,
  "시작됨"
 ],
 "Terminate session": [
  null,
  "세션 종료"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "'$0' 계정은 다음 로그인 시 비밀번호를 변경해야 합니다"
 ],
 "The full name must not contain colons.": [
  null,
  "성명은 쌍점이 포함되지 않아야 합니다."
 ],
 "The key you provided was not valid.": [
  null,
  "입력하신 키가 유효하지 않습니다."
 ],
 "The passwords do not match": [
  null,
  "비밀번호가 일치하지 않습니다"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "역할을 완전히 변경하려면 사용자가 로그 아웃했다가 다시 로그인해야합니다."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "사용자 이름에는 a~z 문자, 숫자, 점, 대시, 밑줄만 사용할 수 있습니다."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "이 계정에 승인된 공개키가 없습니다."
 ],
 "This group is the primary group for the following users:": [
  null,
  "이 그룹은 다음 사용자를 위한 기본 그룹입니다:"
 ],
 "This user name already exists": [
  null,
  "이 사용자 이름이 이미 존재합니다"
 ],
 "Toggle date picker": [
  null,
  "날짜 선택기 전환"
 ],
 "Unexpected error": [
  null,
  "예상치 못한 오류"
 ],
 "Unix group: $0": [
  null,
  "유닉스 그룹: $0"
 ],
 "Unnamed": [
  null,
  "이름 없음"
 ],
 "Use password": [
  null,
  "비밀번호 사용"
 ],
 "User name": [
  null,
  "사용자 이름"
 ],
 "Username": [
  null,
  "사용자 이름"
 ],
 "Validating key": [
  null,
  "키 확인"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "이 계정에 승인된 공개 키를 표시할 수 있는 권한이 없습니다."
 ],
 "You must wait longer to change your password": [
  null,
  "비밀번호 변경을 위해 조금 더 기다려 주십시오"
 ],
 "Your account": [
  null,
  "사용자 계정"
 ],
 "access": [
  null,
  "접근"
 ],
 "edit": [
  null,
  "편집"
 ],
 "keys": [
  null,
  "키"
 ],
 "login": [
  null,
  "로그인"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "비밀번호"
 ],
 "password quality": [
  null,
  "비밀번호 수준"
 ],
 "roles": [
  null,
  "역할"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "사용자"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "사용자 이름"
 ]
});
