cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  ""
 ],
 "Account expiration": [
  null,
  "Skončenie platnosti účtu"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Účet nie je k dispozícií alebo ho nie je možné zmeniť."
 ],
 "Accounts": [
  null,
  "Účty"
 ],
 "Add": [
  null,
  "Pridať"
 ],
 "Add key": [
  null,
  "Pridať kĺúč"
 ],
 "Add public key": [
  null,
  "Pridať verejný kĺúč"
 ],
 "Adding key": [
  null,
  "Pridáva sa kľúč"
 ],
 "Authentication": [
  null,
  "Overovanie"
 ],
 "Authorized public SSH keys": [
  null,
  "Poverené verejné SSH kľúče"
 ],
 "Back to accounts": [
  null,
  "Späť k účtom"
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Change": [
  null,
  "Zmeniť"
 ],
 "Close": [
  null,
  "Zavrieť"
 ],
 "Confirm": [
  null,
  "Potvrdiť"
 ],
 "Confirm new password": [
  null,
  "Potvrdiť nové heslo"
 ],
 "Container administrator": [
  null,
  "Správca kontajnerov"
 ],
 "Create": [
  null,
  "Vytvoriť"
 ],
 "Create account with weak password": [
  null,
  ""
 ],
 "Create new account": [
  null,
  ""
 ],
 "Delete": [
  null,
  "Zmazať"
 ],
 "Delete $0": [
  null,
  "Zmazať $0"
 ],
 "Delete files": [
  null,
  "Zmazať súbory"
 ],
 "Disallow password authentication": [
  null,
  ""
 ],
 "Ended": [
  null,
  ""
 ],
 "Error saving authorized keys: ": [
  null,
  "Chyba pri ukladaní poverených kľúčov: "
 ],
 "Excellent password": [
  null,
  "Skvelé heslo"
 ],
 "Failed to change password": [
  null,
  "Nepodarilo sa zmeniť heslo"
 ],
 "Failed to load authorized keys.": [
  null,
  "Nepodarilo sa načítať poverené kľúče."
 ],
 "Force change": [
  null,
  "Vynútiť zmenu"
 ],
 "Force password change": [
  null,
  "Vynútiť zmenu hesla"
 ],
 "From": [
  null,
  ""
 ],
 "Full name": [
  null,
  "Celé meno"
 ],
 "Group": [
  null,
  "Skupina"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Image builder": [
  null,
  ""
 ],
 "Invalid expiration date": [
  null,
  ""
 ],
 "Invalid key": [
  null,
  "Neplatný kľúč"
 ],
 "Invalid number of days": [
  null,
  ""
 ],
 "Last login": [
  null,
  "Posledné prihlásenie"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "Local accounts": [
  null,
  ""
 ],
 "Lock": [
  null,
  "Zamknúť"
 ],
 "Lock account": [
  null,
  "Zamknúť účet"
 ],
 "Log out": [
  null,
  "Odhlásiť"
 ],
 "Logged in": [
  null,
  "Prihlásený"
 ],
 "Managing user accounts": [
  null,
  "Správa užívateľských účtov"
 ],
 "Never": [
  null,
  "Nikdy"
 ],
 "Never expire password": [
  null,
  "Nikdy neexpirovať heslo"
 ],
 "New password": [
  null,
  "Nové heslo"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebolo prijaté"
 ],
 "No matching results": [
  null,
  "Žiadne vyhovujúce výsledky"
 ],
 "No real name specified": [
  null,
  "Nie je zadaný skutočný názov"
 ],
 "No user name specified": [
  null,
  "Nebolo zadané užívateľské meno"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password": [
  null,
  "Pôvodné heslo"
 ],
 "Old password not accepted": [
  null,
  "Pôvodné heslo nebolo prijaté"
 ],
 "Options": [
  null,
  "Možnosti"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  ""
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Password expiration": [
  null,
  "Skončenie platnosti hesla"
 ],
 "Password is not acceptable": [
  null,
  "Heslo nie je prijatelné"
 ],
 "Password is too weak": [
  null,
  "Heslo je príliš slabé"
 ],
 "Password must be changed": [
  null,
  "Heslo musí byť zmenené"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  ""
 ],
 "Pick date": [
  null,
  "Vybrať dátum"
 ],
 "Please specify an expiration date": [
  null,
  ""
 ],
 "Prompting via passwd timed out": [
  null,
  ""
 ],
 "Remove": [
  null,
  "Odobrať"
 ],
 "Require password change every $0 days": [
  null,
  ""
 ],
 "Require password change on $0": [
  null,
  "Vyžadovať zmenu hesla v $0"
 ],
 "Reset password": [
  null,
  "Resetovať heslo"
 ],
 "Roles": [
  null,
  "Role"
 ],
 "Search for name, group or ID": [
  null,
  ""
 ],
 "Server administrator": [
  null,
  "Správca serveru"
 ],
 "Set password": [
  null,
  "Nastaviť heslo"
 ],
 "Started": [
  null,
  "Spustené"
 ],
 "Terminate session": [
  null,
  "Ukončiť sedenie"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Účet „$0“ bude pri najbližšom prihlásení vyzvaný k vynútenej zmene hesla"
 ],
 "The full name must not contain colons.": [
  null,
  ""
 ],
 "The key you provided was not valid.": [
  null,
  "Zadaný kľúč nie je platný."
 ],
 "The passwords do not match": [
  null,
  "Heslá sa líšia"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  ""
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Užívateľské meno môže obsahovať iba písmená a-z, čísla, bodky, pomlčky a podtržníky."
 ],
 "There are no authorized public keys for this account.": [
  null,
  ""
 ],
 "This group is the primary group for the following users:": [
  null,
  ""
 ],
 "This user name already exists": [
  null,
  "Toto užívateľské meno už existuje"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Unexpected error": [
  null,
  "Neočakávaná chyba"
 ],
 "Unix group: $0": [
  null,
  ""
 ],
 "Unnamed": [
  null,
  "Bez názvu"
 ],
 "User name": [
  null,
  "Užívateľské meno"
 ],
 "Username": [
  null,
  "Užívateľské meno"
 ],
 "Validating key": [
  null,
  "Overuje sa kľúč"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Nemáte oprávnenia zobrazovať overené kľúče pre tento účet."
 ],
 "You must wait longer to change your password": [
  null,
  "Musíte počkať dlhšie aby bolo možné zmeniť vaše heslo"
 ],
 "Your account": [
  null,
  "Váš účet"
 ],
 "access": [
  null,
  "prístup"
 ],
 "edit": [
  null,
  "upraviť"
 ],
 "keys": [
  null,
  "kľúče"
 ],
 "login": [
  null,
  "prihlásenie"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "heslo"
 ],
 "roles": [
  null,
  "role"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "užívateľ"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "username"
 ]
});
