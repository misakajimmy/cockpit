cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  "# gebruikers"
 ],
 "$0 more...": [
  null,
  "$0 meer..."
 ],
 "Account expiration": [
  null,
  "Accountverloop"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Account niet beschikbaar of kan niet worden bewerkt."
 ],
 "Accounts": [
  null,
  "Accounts"
 ],
 "Add": [
  null,
  "Toevoegen"
 ],
 "Add key": [
  null,
  "Sleutel toevoegen"
 ],
 "Add public key": [
  null,
  "Publieke sleutel toevoegen"
 ],
 "Adding key": [
  null,
  "Toevoegen sleutel"
 ],
 "Authentication": [
  null,
  "Authenticatie"
 ],
 "Authorized public SSH keys": [
  null,
  "Geautoriseerde openbare SSH-sleutels"
 ],
 "Back to accounts": [
  null,
  "Terug naar accounts"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Change": [
  null,
  "Verandering"
 ],
 "Close": [
  null,
  "Sluiten"
 ],
 "Confirm": [
  null,
  "Bevestigen"
 ],
 "Confirm new password": [
  null,
  "Bevestig nieuw wachtwoord"
 ],
 "Container administrator": [
  null,
  "Containerbeheerder"
 ],
 "Create": [
  null,
  "Aanmaken"
 ],
 "Create account with weak password": [
  null,
  "Account aanmaken met zwak wachtwoord"
 ],
 "Create new account": [
  null,
  "Nieuw account aanmaken"
 ],
 "Delete": [
  null,
  "Verwijderen"
 ],
 "Delete $0": [
  null,
  "Verwijder $0"
 ],
 "Delete $0 group": [
  null,
  "Verwijder $0 groep"
 ],
 "Delete account": [
  null,
  "Account verwijderen"
 ],
 "Delete files": [
  null,
  "Verwijder bestanden"
 ],
 "Delete group": [
  null,
  "Groep verwijderen"
 ],
 "Disallow interactive password": [
  null,
  "Interactief wachtwoord niet toestaan"
 ],
 "Disallow password authentication": [
  null,
  "Wachtwoordverificatie niet toestaan"
 ],
 "Edit user": [
  null,
  "Bewerk gebruiker"
 ],
 "Ended": [
  null,
  "Beëindigd"
 ],
 "Error saving authorized keys: ": [
  null,
  "Fout tijdens het opslaan van gemachtigde sleutels: "
 ],
 "Excellent password": [
  null,
  "Uitstekend wachtwoord"
 ],
 "Expire account on": [
  null,
  "Account laten verlopen op"
 ],
 "Expire account on $0": [
  null,
  "Account laten verlopen op $0"
 ],
 "Failed to change password": [
  null,
  "Kan wachtwoord niet veranderen"
 ],
 "Failed to load authorized keys.": [
  null,
  "Kan gemachtigde sleutels niet laden."
 ],
 "Force change": [
  null,
  "Forceer verandering"
 ],
 "Force delete": [
  null,
  "Forceer verwijderen"
 ],
 "Force password change": [
  null,
  "Forceer wachtwoordverandering"
 ],
 "From": [
  null,
  "Van"
 ],
 "Full name": [
  null,
  "Volledige naam"
 ],
 "Group": [
  null,
  "Groep"
 ],
 "Group name": [
  null,
  "Naam van groep"
 ],
 "Groups": [
  null,
  "Groepen"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Image builder": [
  null,
  "Image bouwer"
 ],
 "Invalid expiration date": [
  null,
  "Ongeldige vervaldatum"
 ],
 "Invalid key": [
  null,
  "Ongeldige sleutel"
 ],
 "Invalid number of days": [
  null,
  "Ongeldig aantal dagen"
 ],
 "Last active": [
  null,
  "Laatst actief"
 ],
 "Last login": [
  null,
  "Laatste aanmelding"
 ],
 "Learn more": [
  null,
  "Kom meer te weten"
 ],
 "Local accounts": [
  null,
  "Lokale accounts"
 ],
 "Lock": [
  null,
  "Slot"
 ],
 "Lock $0": [
  null,
  "Vergrendel $0"
 ],
 "Lock account": [
  null,
  "Account vergrendelen"
 ],
 "Log out": [
  null,
  "Uitloggen"
 ],
 "Log user out": [
  null,
  "Log de gebruiker uit"
 ],
 "Logged in": [
  null,
  "Ingelogd"
 ],
 "Login history": [
  null,
  "Inloggeschiedenis"
 ],
 "Login history list": [
  null,
  "Inloggeschiedenislijst"
 ],
 "Logout $0": [
  null,
  "$0 uitloggen"
 ],
 "Managing user accounts": [
  null,
  "Gebruikersaccounts beheren"
 ],
 "Never": [
  null,
  "Nooit"
 ],
 "Never expire account": [
  null,
  "Account nooit laten verlopen"
 ],
 "Never expire password": [
  null,
  "Verloop het wachtwoord nooit"
 ],
 "Never logged in": [
  null,
  "Nooit ingelogd"
 ],
 "New password": [
  null,
  "Nieuw wachtwoord"
 ],
 "New password was not accepted": [
  null,
  "Nieuw wachtwoord is niet geaccepteerd"
 ],
 "No matching results": [
  null,
  "Geen overeenkomende resultaten"
 ],
 "No real name specified": [
  null,
  "Geen echte naam opgegeven"
 ],
 "No user name specified": [
  null,
  "Geen gebruikersnaam opgegeven"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password": [
  null,
  "Oud wachtwoord"
 ],
 "Old password not accepted": [
  null,
  "Oude wachtwoord niet geaccepteerd"
 ],
 "Options": [
  null,
  "Opties"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Andere authenticatiemethoden zijn nog steeds beschikbaar, zelfs als interactieve wachtwoordauthenticatie niet is toegestaan."
 ],
 "Password": [
  null,
  "Wachtwoord"
 ],
 "Password expiration": [
  null,
  "Wachtwoord verloop"
 ],
 "Password is longer than 256 characters": [
  null,
  "Wachtwoord is langer dan 256 lettertekens"
 ],
 "Password is not acceptable": [
  null,
  "Wachtwoord is niet acceptabel"
 ],
 "Password is too weak": [
  null,
  "Wachtwoord is te zwak"
 ],
 "Password must be changed": [
  null,
  "Wachtwoord moet veranderd worden"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Plak hier de inhoud van je openbare SSH-sleutelbestand"
 ],
 "Pick date": [
  null,
  "Kies datum"
 ],
 "Please specify an expiration date": [
  null,
  "Geef een vervaldatum op"
 ],
 "Prompting via passwd timed out": [
  null,
  "Vragen via wachtwoord is verlopen"
 ],
 "Remove": [
  null,
  "Verwijderen"
 ],
 "Require password change every $0 days": [
  null,
  "Vereis wachtwoordwijziging elke $0 dagen"
 ],
 "Require password change on $0": [
  null,
  "Verwacht wachtwoordwijziging op $0"
 ],
 "Require password change on first login": [
  null,
  "Verwacht wachtwoordwijziging bij eerste login"
 ],
 "Reset password": [
  null,
  "Wachtwoord herstellen"
 ],
 "Roles": [
  null,
  "Rollen"
 ],
 "Search for name, group or ID": [
  null,
  "Zoek op naam, groep of ID"
 ],
 "Server administrator": [
  null,
  "Serverbeheerder"
 ],
 "Set password": [
  null,
  "Wachtwoord instellen"
 ],
 "Set weak password": [
  null,
  "Zwak wachtwoord instellen"
 ],
 "Started": [
  null,
  "Gestart"
 ],
 "Terminate session": [
  null,
  "Sessie beëindigen"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Het account '$0' zal zijn wachtwoord moeten wijzigen bij de volgende inlog"
 ],
 "The full name must not contain colons.": [
  null,
  "De volledige naam mag geen dubbele punten bevatten."
 ],
 "The key you provided was not valid.": [
  null,
  "De sleutel die je hebt opgegeven, is niet geldig."
 ],
 "The passwords do not match": [
  null,
  "De wachtwoorden komen niet overeen"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "De gebruiker moet zich afmelden en weer aanmelden om de rollen volledig te wijzigen."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "De gebruikersnaam kan alleen bestaan uit letters van a-z, cijfers, punten, streepjes en onderstrepingstekens."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Er zijn geen geautoriseerde openbare sleutels voor dit account."
 ],
 "This group is the primary group for the following users:": [
  null,
  "Deze groep is de primaire groep voor de volgende gebruikers:"
 ],
 "This user name already exists": [
  null,
  "Deze gebruikersnaam bestaat al"
 ],
 "Toggle date picker": [
  null,
  "Datumkiezer omschakelen"
 ],
 "Unexpected error": [
  null,
  "Onverwachte fout"
 ],
 "Unix group: $0": [
  null,
  "Unix groep: $0"
 ],
 "Unnamed": [
  null,
  "Naamloos"
 ],
 "Use password": [
  null,
  "Gebruik wachtwoord"
 ],
 "User name": [
  null,
  "Gebruikersnaam"
 ],
 "Username": [
  null,
  "Gebruikersnaam"
 ],
 "Validating key": [
  null,
  "Sleutel valideren"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Je hebt geen toestemming om de geautoriseerde openbare sleutels voor dit account te bekijken."
 ],
 "You must wait longer to change your password": [
  null,
  "Je moet langer wachten om je wachtwoord te wijzigen"
 ],
 "Your account": [
  null,
  "Jouw account"
 ],
 "access": [
  null,
  "toegang"
 ],
 "edit": [
  null,
  "bewerken"
 ],
 "keys": [
  null,
  "sleutels"
 ],
 "login": [
  null,
  "inloggen"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "wachtwoord"
 ],
 "password quality": [
  null,
  "wachtwoordkwaliteit"
 ],
 "roles": [
  null,
  "rollen"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "gebruiker"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "gebruikersnaam"
 ]
});
