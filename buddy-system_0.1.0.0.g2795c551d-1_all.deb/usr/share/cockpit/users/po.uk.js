cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  "К-ть користувачів"
 ],
 "$0 more...": [
  null,
  "І ще $0…"
 ],
 "Account expiration": [
  null,
  "Строк дії облікового запису"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Обліковий запис недоступний або його не можна редагувати."
 ],
 "Accounts": [
  null,
  "Облікові записи"
 ],
 "Add": [
  null,
  "Додати"
 ],
 "Add key": [
  null,
  "Додати ключ"
 ],
 "Add public key": [
  null,
  "Додати відкритий ключ"
 ],
 "Adding key": [
  null,
  "Додавання ключа"
 ],
 "Authentication": [
  null,
  "Розпізнавання"
 ],
 "Authorized public SSH keys": [
  null,
  "Уповноважені відкриті ключі SSH"
 ],
 "Back to accounts": [
  null,
  "Назад до облікових записів"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Change": [
  null,
  "Змінити"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Confirm": [
  null,
  "Підтвердити"
 ],
 "Confirm new password": [
  null,
  "Підтвердження нового пароля"
 ],
 "Container administrator": [
  null,
  "Адміністратор контейнера"
 ],
 "Create": [
  null,
  "Створити"
 ],
 "Create account with weak password": [
  null,
  "Створити обліковий запис із простим паролем"
 ],
 "Create new account": [
  null,
  "Створити новий рахунок"
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Delete $0": [
  null,
  "Вилучити $0"
 ],
 "Delete $0 group": [
  null,
  "Вилучити групу $0"
 ],
 "Delete account": [
  null,
  "Вилучити обліковий запис"
 ],
 "Delete files": [
  null,
  "Вилучити файли"
 ],
 "Delete group": [
  null,
  "Вилучити групу"
 ],
 "Disallow interactive password": [
  null,
  "Заборонити інтерактивний пароль"
 ],
 "Disallow password authentication": [
  null,
  "Заборонити розпізнавання за паролем"
 ],
 "Edit user": [
  null,
  "Змінити запис користувача"
 ],
 "Ended": [
  null,
  "Завершено"
 ],
 "Error saving authorized keys: ": [
  null,
  "Помилка під час спроби зберегти уповноважені ключі: "
 ],
 "Excellent password": [
  null,
  "Чудовий пароль"
 ],
 "Expire account on": [
  null,
  "Завершити строк дії облікового запису"
 ],
 "Expire account on $0": [
  null,
  "Завершити строк дії облікового запису $0"
 ],
 "Failed to change password": [
  null,
  "Не вдалося змінити пароль"
 ],
 "Failed to load authorized keys.": [
  null,
  "Не вдалося завантажити уповноважені ключі."
 ],
 "Force change": [
  null,
  "Примусова зміна"
 ],
 "Force delete": [
  null,
  "Примусове вилучення"
 ],
 "Force password change": [
  null,
  "Примусова зміна пароля"
 ],
 "From": [
  null,
  "Від"
 ],
 "Full name": [
  null,
  "Повне ім'я"
 ],
 "Group": [
  null,
  "Група"
 ],
 "Group name": [
  null,
  "Назва групи"
 ],
 "Groups": [
  null,
  "Групи"
 ],
 "ID": [
  null,
  "Ід."
 ],
 "Image builder": [
  null,
  "Побудова образів"
 ],
 "Invalid expiration date": [
  null,
  "Некоректна дата строку завершення дії"
 ],
 "Invalid key": [
  null,
  "Некоректний ключ"
 ],
 "Invalid number of days": [
  null,
  "Некоректна кількість днів"
 ],
 "Last active": [
  null,
  "Останній активний"
 ],
 "Last login": [
  null,
  "Останній вхід"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "Local accounts": [
  null,
  "Локальні облікові записи"
 ],
 "Lock": [
  null,
  "Заблокувати"
 ],
 "Lock $0": [
  null,
  "Заблокувати $0"
 ],
 "Lock account": [
  null,
  "Заблокувати обліковий запис"
 ],
 "Log out": [
  null,
  "Вийти"
 ],
 "Log user out": [
  null,
  "Вийти з облікового запису користувача"
 ],
 "Logged in": [
  null,
  "Вхід"
 ],
 "Login history": [
  null,
  "Журнал входів"
 ],
 "Login history list": [
  null,
  "Список журналу входів"
 ],
 "Logout $0": [
  null,
  "Вийти з $0"
 ],
 "Managing user accounts": [
  null,
  "Керування обліковими записами користувачів"
 ],
 "Never": [
  null,
  "Ніколи"
 ],
 "Never expire account": [
  null,
  "Строк дії облікового запису є нескінченним"
 ],
 "Never expire password": [
  null,
  "Необмежений строк дії пароля"
 ],
 "Never logged in": [
  null,
  "Ніколи не входив"
 ],
 "New password": [
  null,
  "Новий пароль"
 ],
 "New password was not accepted": [
  null,
  "Новий пароль не прийнято"
 ],
 "No matching results": [
  null,
  "Нічого не знайдено"
 ],
 "No real name specified": [
  null,
  "Не вказано справжнього імені"
 ],
 "No user name specified": [
  null,
  "Не вказано імені користувача"
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "Old password": [
  null,
  "Старий пароль"
 ],
 "Old password not accepted": [
  null,
  "Старий пароль не прийнято"
 ],
 "Options": [
  null,
  "Параметри"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Навіть якщо розпізнавання за інтерактивним паролем заборонено, можна скористатися іншими способами розпізнавання."
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password expiration": [
  null,
  "Строк дії пароля"
 ],
 "Password is longer than 256 characters": [
  null,
  "Довжина пароля перевищує 256 символів"
 ],
 "Password is not acceptable": [
  null,
  "Пароль є неприйнятним"
 ],
 "Password is too weak": [
  null,
  "Пароль є надто простим"
 ],
 "Password must be changed": [
  null,
  "Пароль має бути змінено"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Сюди слід вставити вміст файла вашого відкритого ключа SSH"
 ],
 "Pick date": [
  null,
  "Вибрати дату"
 ],
 "Please specify an expiration date": [
  null,
  "Будь ласка, вкажіть кінцеву дату строку дії"
 ],
 "Prompting via passwd timed out": [
  null,
  "Час очікування відповіді на запит за допомогою passwd вичерпано"
 ],
 "Remove": [
  null,
  "Вилучити"
 ],
 "Require password change every $0 days": [
  null,
  "Вимагати зміну пароля кожні $0 днів"
 ],
 "Require password change on $0": [
  null,
  "Вимагати зміну пароля $0"
 ],
 "Require password change on first login": [
  null,
  "Вимагати зміну пароля при першому вході"
 ],
 "Reset password": [
  null,
  "Скинути пароль"
 ],
 "Roles": [
  null,
  "Ролі"
 ],
 "Search for name, group or ID": [
  null,
  "Шукати за назвою, групою або ідентифікатором"
 ],
 "Server administrator": [
  null,
  "Адміністратор сервера"
 ],
 "Set password": [
  null,
  "Встановити пароль"
 ],
 "Set weak password": [
  null,
  "Встановити простий пароль"
 ],
 "Started": [
  null,
  "Почато"
 ],
 "Terminate session": [
  null,
  "Перервати сеанс"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Обліковий запис «$0» має примусово змінити пароль під час наступного входу"
 ],
 "The full name must not contain colons.": [
  null,
  "У повному імені не повинно міститися двокрапок."
 ],
 "The key you provided was not valid.": [
  null,
  "Наданий вами ключ є некоректним."
 ],
 "The passwords do not match": [
  null,
  "Паролі не збігаються"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "Для повної зміни ролей користувач має вийти із системи і увійти до неї знову."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Ім’я користувача може складатися лише із літер a-z, цифр, крапок, дефісів та символів підкреслювання."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Для цього облікового запису немає уповноважених відкритих ключів."
 ],
 "This group is the primary group for the following users:": [
  null,
  "Ця група є основою групою для таких користувачів:"
 ],
 "This user name already exists": [
  null,
  "Запис користувача із таким іменем уже існує"
 ],
 "Toggle date picker": [
  null,
  "Перемкнути засіб вибору дати"
 ],
 "Unexpected error": [
  null,
  "Неочікувана помилка"
 ],
 "Unix group: $0": [
  null,
  "Група у Unix: $0"
 ],
 "Unnamed": [
  null,
  "Без назви"
 ],
 "Use password": [
  null,
  "Використати пароль"
 ],
 "User name": [
  null,
  "Ім'я користувача"
 ],
 "Username": [
  null,
  "Користувач"
 ],
 "Validating key": [
  null,
  "Перевірка ключа"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "У вас немає прав доступу для перегляду уповноважених відкритих ключів для цього облікового запису."
 ],
 "You must wait longer to change your password": [
  null,
  "Для зміни вашого пароля вам доведеться ще почекати"
 ],
 "Your account": [
  null,
  "Ваш обліковий запис"
 ],
 "access": [
  null,
  "доступ"
 ],
 "edit": [
  null,
  "редагувати"
 ],
 "keys": [
  null,
  "ключі"
 ],
 "login": [
  null,
  "вхід"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "пароль"
 ],
 "password quality": [
  null,
  "якість пароля"
 ],
 "roles": [
  null,
  "ролі"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "користувач"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "користувач"
 ]
});
