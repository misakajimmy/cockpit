cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  ""
 ],
 "Account expiration": [
  null,
  "Tilin vanheneminen"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Tili ei ole käytettävissä tai sitä ei voi muokata."
 ],
 "Accounts": [
  null,
  "Käyttäjätilit"
 ],
 "Add": [
  null,
  "Lisää"
 ],
 "Add key": [
  null,
  "Lisää avain"
 ],
 "Add public key": [
  null,
  "Lisää julkinen avain"
 ],
 "Adding key": [
  null,
  "Avainta lisätään"
 ],
 "Authentication": [
  null,
  "Tunnistautuminen"
 ],
 "Authorized public SSH keys": [
  null,
  "Valtuutetut julkiset SSH-avaimet"
 ],
 "Back to accounts": [
  null,
  "Takaisin käyttäjätileihin"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Change": [
  null,
  "Vaihda"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Confirm": [
  null,
  "Vahvista"
 ],
 "Confirm new password": [
  null,
  "Vahvista uusi salasana"
 ],
 "Container administrator": [
  null,
  "Kontin ylläpitäjä"
 ],
 "Create": [
  null,
  "Luo"
 ],
 "Create account with weak password": [
  null,
  "Luo tili heikolla salasanalla"
 ],
 "Create new account": [
  null,
  "Luo uusi tili"
 ],
 "Delete": [
  null,
  "Poista"
 ],
 "Delete $0": [
  null,
  "Poista $0"
 ],
 "Delete account": [
  null,
  "Poista tili"
 ],
 "Delete files": [
  null,
  "Poista tiedostot"
 ],
 "Disallow interactive password": [
  null,
  "Estä interaktiivinen salasana"
 ],
 "Disallow password authentication": [
  null,
  "Kiellä salasanalla tunnistautuminen"
 ],
 "Edit user": [
  null,
  "Muokkaa käyttäjää"
 ],
 "Ended": [
  null,
  "Päättynyt"
 ],
 "Error saving authorized keys: ": [
  null,
  "Virhe tallentaessa valtuutettuja avaimia: "
 ],
 "Excellent password": [
  null,
  "Erinomainen salasana"
 ],
 "Expire account on": [
  null,
  "Vanhenna tili"
 ],
 "Expire account on $0": [
  null,
  "Vanhenna tili $0"
 ],
 "Failed to change password": [
  null,
  "Salasanan vaihtaminen epäonnistui"
 ],
 "Failed to load authorized keys.": [
  null,
  "Valtuutettujen avainten lataaminen epäonnistui."
 ],
 "Force change": [
  null,
  "Pakota muutos"
 ],
 "Force delete": [
  null,
  "Pakota poisto"
 ],
 "Force password change": [
  null,
  "Pakota salasanan vaihdos"
 ],
 "From": [
  null,
  "Lähde"
 ],
 "Full name": [
  null,
  "Koko nimi"
 ],
 "Group": [
  null,
  "Ryhmä"
 ],
 "ID": [
  null,
  "Tunniste"
 ],
 "Image builder": [
  null,
  "Kuvanrakentaja"
 ],
 "Invalid expiration date": [
  null,
  "Ei kelvollinen vanhenemispäivä"
 ],
 "Invalid key": [
  null,
  "Virheellinen avain"
 ],
 "Invalid number of days": [
  null,
  "Virheellinen päivien lukumäärä"
 ],
 "Last active": [
  null,
  "Viimeksi aktiivinen"
 ],
 "Last login": [
  null,
  "Edellinen kirjautuminen"
 ],
 "Learn more": [
  null,
  "Opi lisää"
 ],
 "Local accounts": [
  null,
  "Paikalliset tilit"
 ],
 "Lock": [
  null,
  "Lukitse"
 ],
 "Lock $0": [
  null,
  "Lukitse $0"
 ],
 "Lock account": [
  null,
  "Lukitse tili"
 ],
 "Log out": [
  null,
  "Kirjaudu ulos"
 ],
 "Log user out": [
  null,
  "Kirjaa käyttäjä ulos"
 ],
 "Logged in": [
  null,
  "Kirjautunut sisään"
 ],
 "Login history": [
  null,
  "Kirjautumishistoria"
 ],
 "Login history list": [
  null,
  "Sisäänkirjautumisten historialista"
 ],
 "Logout $0": [
  null,
  "Kirjaa $0 ulos"
 ],
 "Managing user accounts": [
  null,
  "Käyttäjätilien hallinta"
 ],
 "Never": [
  null,
  "Ei koskaan"
 ],
 "Never expire account": [
  null,
  "Älä koskaan vanhenna tiliä"
 ],
 "Never expire password": [
  null,
  "Älä koskaan vanhenna salasanaa"
 ],
 "Never logged in": [
  null,
  "Ei koskaan sisäänkirjautuneena"
 ],
 "New password": [
  null,
  "Uusi salasana"
 ],
 "New password was not accepted": [
  null,
  "Uutta salasanaa ei hyväksytty"
 ],
 "No matching results": [
  null,
  "Ei vastaavia tuloksia"
 ],
 "No real name specified": [
  null,
  "Oikeaa nimeä ei ole määritetty"
 ],
 "No user name specified": [
  null,
  "Käyttäjänimeä ei ole määritetty"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password": [
  null,
  "Vanha salasana"
 ],
 "Old password not accepted": [
  null,
  "Vanhaa salasanaa ei hyväksytty"
 ],
 "Options": [
  null,
  "Valinnat"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Vaikka interaktiivinen salasanalla tunnistautuminen on estetty, muut tunnistusmenetelmät ovat edelleen käytettävissä."
 ],
 "Password": [
  null,
  "Salasana"
 ],
 "Password expiration": [
  null,
  "Salasanan vanheneminen"
 ],
 "Password is longer than 256 characters": [
  null,
  "Salasana on yli 256 merkkiä pitkä"
 ],
 "Password is not acceptable": [
  null,
  "Salasana ei ole hyväksyttävä"
 ],
 "Password is too weak": [
  null,
  "Salasana on liian heikko"
 ],
 "Password must be changed": [
  null,
  "Salasana tulee vaihtaa"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Liitä julkisen SSH-avaintiedostosi sisältö tähän"
 ],
 "Pick date": [
  null,
  "Valitse päivämäärä"
 ],
 "Please specify an expiration date": [
  null,
  "Määritä vanhenemispäivä"
 ],
 "Prompting via passwd timed out": [
  null,
  "Kysely 'passwd':n kautta aikakatkaistiin"
 ],
 "Remove": [
  null,
  "Poista"
 ],
 "Require password change every $0 days": [
  null,
  "Vaadi salasanan vaihto $0 päivän välein"
 ],
 "Require password change on $0": [
  null,
  "Vaadi salasanan vaihto $0"
 ],
 "Require password change on first login": [
  null,
  "Vaadi salasanan vaihto ensimmäisen käynnistyksen yhteydessä"
 ],
 "Reset password": [
  null,
  "Nollaa salasana"
 ],
 "Roles": [
  null,
  "Roolit"
 ],
 "Search for name, group or ID": [
  null,
  "Etsi nimeä, ryhmää tai ID:tä"
 ],
 "Server administrator": [
  null,
  "Palvelimen ylläpitäjä"
 ],
 "Set password": [
  null,
  "Aseta salasana"
 ],
 "Set weak password": [
  null,
  "Aseta heikko salasana"
 ],
 "Started": [
  null,
  "Aloitettu"
 ],
 "Terminate session": [
  null,
  "Lopeta istunto"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Tili '$0' on pakotettu vaihtamaan salasanan seuraavalla sisäänkirjautumiskerralla"
 ],
 "The full name must not contain colons.": [
  null,
  "Koko nimi ei saa sisältää kaksoispisteitä."
 ],
 "The key you provided was not valid.": [
  null,
  "Antamasi avain ei ollut kelvollinen."
 ],
 "The passwords do not match": [
  null,
  "Salasanat eivät täsmää"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "Käyttäjän on kirjauduttava ulos ja kirjauduttava sisään, jotta roolit voidaan täysin muuttaa."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Käyttäjänimi voi koostua vain a–z-kirjaimista, numeroista, pisteistä, viivoista ja alaviivoista."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Tällä tilillä ei ole valtuutettuja julkisia avaimia."
 ],
 "This group is the primary group for the following users:": [
  null,
  ""
 ],
 "This user name already exists": [
  null,
  "Käyttäjätunnus on jo olemassa"
 ],
 "Toggle date picker": [
  null,
  "Vaihda päivämäärän valitsin"
 ],
 "Unexpected error": [
  null,
  "Odottamaton virhe"
 ],
 "Unix group: $0": [
  null,
  "Unix-ryhmä: $0"
 ],
 "Unnamed": [
  null,
  "Nimeämätön"
 ],
 "Use password": [
  null,
  "Käytä salasanaa"
 ],
 "User name": [
  null,
  "Käyttäjänimi"
 ],
 "Username": [
  null,
  "Käyttäjätunnus"
 ],
 "Validating key": [
  null,
  "Vahvistetaan avainta"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Sinulla ei ole oikeutta tarkastella tämän käyttäjätilin julkisia avaimia."
 ],
 "You must wait longer to change your password": [
  null,
  "Sinun täytyy odottaa kauemmin vaihtaaksesi salasanasi"
 ],
 "Your account": [
  null,
  "Tilisi"
 ],
 "access": [
  null,
  "pääsy"
 ],
 "edit": [
  null,
  "muokkaa"
 ],
 "keys": [
  null,
  "avaimet"
 ],
 "login": [
  null,
  "sisäänkirjautuminen"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "salasana"
 ],
 "password quality": [
  null,
  "salasanan laatu"
 ],
 "roles": [
  null,
  "roolit"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "käyttäjä"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "käyttäjänimi"
 ]
});
