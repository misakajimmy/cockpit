cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  ""
 ],
 "$0 more...": [
  null,
  ""
 ],
 "Account expiration": [
  null,
  "帳號到期"
 ],
 "Account not available or cannot be edited.": [
  null,
  "帳號不可用或無法編輯。"
 ],
 "Accounts": [
  null,
  "帳號管理"
 ],
 "Add": [
  null,
  "加入"
 ],
 "Add key": [
  null,
  "新增密鑰"
 ],
 "Add public key": [
  null,
  "新增公鑰"
 ],
 "Adding key": [
  null,
  "新增密鑰"
 ],
 "Authentication": [
  null,
  "核對"
 ],
 "Authorized public SSH keys": [
  null,
  "授權的公共SSH密鑰"
 ],
 "Back to accounts": [
  null,
  "回到帳號"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Change": [
  null,
  "改變"
 ],
 "Close": [
  null,
  "關閉"
 ],
 "Confirm": [
  null,
  "確認"
 ],
 "Container administrator": [
  null,
  "容器管理員"
 ],
 "Create": [
  null,
  "建立"
 ],
 "Create account with weak password": [
  null,
  ""
 ],
 "Create new account": [
  null,
  "建立新帳號"
 ],
 "Delete": [
  null,
  "刪除"
 ],
 "Delete $0": [
  null,
  "刪除 $0"
 ],
 "Delete files": [
  null,
  "刪除檔案"
 ],
 "Disallow password authentication": [
  null,
  ""
 ],
 "Ended": [
  null,
  ""
 ],
 "Error saving authorized keys: ": [
  null,
  "保存授權密鑰時出錯： "
 ],
 "Excellent password": [
  null,
  "優秀的密碼"
 ],
 "Failed to change password": [
  null,
  "無法更改密碼"
 ],
 "Failed to load authorized keys.": [
  null,
  "無法加載授權密鑰。"
 ],
 "Force change": [
  null,
  "強制改變"
 ],
 "Force delete": [
  null,
  "強制刪除"
 ],
 "Force password change": [
  null,
  "強制更改密碼"
 ],
 "From": [
  null,
  ""
 ],
 "Full name": [
  null,
  "全名"
 ],
 "Group": [
  null,
  ""
 ],
 "Groups": [
  null,
  ""
 ],
 "ID": [
  null,
  ""
 ],
 "Image builder": [
  null,
  "圖像生成器"
 ],
 "Invalid expiration date": [
  null,
  "失效日期無效"
 ],
 "Invalid key": [
  null,
  "無效的密鑰"
 ],
 "Invalid number of days": [
  null,
  "無效天數"
 ],
 "Last login": [
  null,
  "上次登錄"
 ],
 "Local accounts": [
  null,
  "本地帳號"
 ],
 "Lock": [
  null,
  "鎖定"
 ],
 "Lock account": [
  null,
  "鎖定帳號"
 ],
 "Log out": [
  null,
  "登出"
 ],
 "Logged in": [
  null,
  "登錄"
 ],
 "Login history list": [
  null,
  ""
 ],
 "Managing user accounts": [
  null,
  ""
 ],
 "Never": [
  null,
  "永不"
 ],
 "Never expire password": [
  null,
  "永不過期密碼"
 ],
 "New password": [
  null,
  "新密碼"
 ],
 "New password was not accepted": [
  null,
  "不接受新密碼"
 ],
 "No matching results": [
  null,
  ""
 ],
 "No real name specified": [
  null,
  "沒有指定實名"
 ],
 "No user name specified": [
  null,
  "未指定用戶名"
 ],
 "Ok": [
  null,
  "確定"
 ],
 "Old password": [
  null,
  "舊密碼"
 ],
 "Old password not accepted": [
  null,
  "舊密碼不被接受"
 ],
 "Options": [
  null,
  "選項"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  ""
 ],
 "Password": [
  null,
  "密碼"
 ],
 "Password expiration": [
  null,
  "密碼到期"
 ],
 "Password is not acceptable": [
  null,
  "密碼是不可接受的"
 ],
 "Password is too weak": [
  null,
  "密碼太弱了"
 ],
 "Password must be changed": [
  null,
  "密碼必須更改"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "在此處粘貼公共SSH密鑰文件的內容"
 ],
 "Pick date": [
  null,
  ""
 ],
 "Please specify an expiration date": [
  null,
  "請指定到期日期"
 ],
 "Prompting via passwd timed out": [
  null,
  "通過passwd提示超時"
 ],
 "Remove": [
  null,
  "移除"
 ],
 "Require password change every $0 days": [
  null,
  "每次都需要密碼更改 $0 天"
 ],
 "Require password change on $0": [
  null,
  "需要更改密碼 $0"
 ],
 "Roles": [
  null,
  "角色"
 ],
 "Search for name, group or ID": [
  null,
  ""
 ],
 "Server administrator": [
  null,
  "Server administrator"
 ],
 "Set password": [
  null,
  "設置密碼"
 ],
 "Terminate session": [
  null,
  "終止會話"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "帳號'$0'將在下次登錄時被迫更改密碼"
 ],
 "The full name must not contain colons.": [
  null,
  ""
 ],
 "The key you provided was not valid.": [
  null,
  "您提供的密鑰無效。"
 ],
 "The passwords do not match": [
  null,
  "密碼不匹配"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  ""
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "用戶名只能包含來自az，數字，點，短劃線和下劃線的字母。"
 ],
 "There are no authorized public keys for this account.": [
  null,
  "此帳號沒有授權的公鑰。"
 ],
 "This group is the primary group for the following users:": [
  null,
  ""
 ],
 "This user name already exists": [
  null,
  "這個用戶名已經存在"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Unexpected error": [
  null,
  "未預期的錯誤"
 ],
 "Unix group: $0": [
  null,
  ""
 ],
 "Unnamed": [
  null,
  "未命名"
 ],
 "User name": [
  null,
  "使用者名稱"
 ],
 "Username": [
  null,
  "使用者名稱"
 ],
 "Validating key": [
  null,
  "驗證密鑰"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "您無權查看此帳號的授權公鑰。"
 ],
 "You must wait longer to change your password": [
  null,
  "您必須等待更長時間才能更改密碼"
 ],
 "access": [
  null,
  ""
 ],
 "edit": [
  null,
  "編輯"
 ],
 "keys": [
  null,
  ""
 ],
 "login": [
  null,
  ""
 ],
 "passwd": [
  null,
  ""
 ],
 "password": [
  null,
  ""
 ],
 "password quality": [
  null,
  ""
 ],
 "roles": [
  null,
  ""
 ],
 "ssh": [
  null,
  ""
 ],
 "user": [
  null,
  "使用者"
 ],
 "useradd": [
  null,
  ""
 ],
 "username": [
  null,
  ""
 ]
});
