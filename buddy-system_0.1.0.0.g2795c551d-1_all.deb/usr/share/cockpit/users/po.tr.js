cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  "Kullanıcı sayısı"
 ],
 "$0 more...": [
  null,
  "$0 daha..."
 ],
 "Account expiration": [
  null,
  "Hesap süresinin dolması"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Hesap kullanılabilir değil ya da düzenlenemez."
 ],
 "Accounts": [
  null,
  "Hesaplar"
 ],
 "Add": [
  null,
  "Ekle"
 ],
 "Add key": [
  null,
  "Anahtar ekle"
 ],
 "Add public key": [
  null,
  "Ortak anahtar ekle"
 ],
 "Adding key": [
  null,
  "Anahtar ekleniyor"
 ],
 "Authentication": [
  null,
  "Kimlik doğrulama"
 ],
 "Authorized public SSH keys": [
  null,
  "Yetkilendirilmiş ortak SSH anahtarları"
 ],
 "Back to accounts": [
  null,
  "Hesaplara geri dön"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Change": [
  null,
  "Değiştir"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Confirm": [
  null,
  "Onayla"
 ],
 "Confirm new password": [
  null,
  "Yeni parolayı onayla"
 ],
 "Container administrator": [
  null,
  "Kapsayıcı yöneticisi"
 ],
 "Create": [
  null,
  "Oluştur"
 ],
 "Create account with weak password": [
  null,
  "Zayıf parola ile hesap oluştur"
 ],
 "Create new account": [
  null,
  "Yeni hesap oluştur"
 ],
 "Delete": [
  null,
  "Sil"
 ],
 "Delete $0": [
  null,
  "$0 sil"
 ],
 "Delete $0 group": [
  null,
  "$0 grubunu sil"
 ],
 "Delete account": [
  null,
  "Hesabı sil"
 ],
 "Delete files": [
  null,
  "Dosyaları sil"
 ],
 "Delete group": [
  null,
  "Grubu sil"
 ],
 "Disallow interactive password": [
  null,
  "Etkileşimli parolaya izin verme"
 ],
 "Disallow password authentication": [
  null,
  "Parola ile kimlik doğrulamaya izin verme"
 ],
 "Edit user": [
  null,
  "Kullanıcı düzenle"
 ],
 "Ended": [
  null,
  "Bitti"
 ],
 "Error saving authorized keys: ": [
  null,
  "Yetkili anahtarlar kaydedilirken hata oldu: "
 ],
 "Excellent password": [
  null,
  "Mükemmel parola"
 ],
 "Expire account on": [
  null,
  "Hesap süresi dolma zamanı"
 ],
 "Expire account on $0": [
  null,
  "$0 tarihinde hesap süresi doluyor"
 ],
 "Failed to change password": [
  null,
  "Parolayı değiştirme başarısız oldu"
 ],
 "Failed to load authorized keys.": [
  null,
  "Yetkilendirilmiş anahtarları yükleme başarısız oldu."
 ],
 "Force change": [
  null,
  "Değiştirmeye zorla"
 ],
 "Force delete": [
  null,
  "Silmeye Zorla"
 ],
 "Force password change": [
  null,
  "Parola değiştirmeye zorla"
 ],
 "From": [
  null,
  "Nereden"
 ],
 "Full name": [
  null,
  "Ad soyad"
 ],
 "Group": [
  null,
  "Grup"
 ],
 "Group name": [
  null,
  "Grup adı"
 ],
 "Groups": [
  null,
  "Gruplar"
 ],
 "ID": [
  null,
  "Kimlik"
 ],
 "Image builder": [
  null,
  "Kalıp oluşturucu"
 ],
 "Invalid expiration date": [
  null,
  "Geçersiz süre dolma tarihi"
 ],
 "Invalid key": [
  null,
  "Geçersiz anahtar"
 ],
 "Invalid number of days": [
  null,
  "Geçersiz gün sayısı"
 ],
 "Last active": [
  null,
  "Son etkin olma"
 ],
 "Last login": [
  null,
  "Son oturum açma"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "Local accounts": [
  null,
  "Yerel hesaplar"
 ],
 "Lock": [
  null,
  "Kilitle"
 ],
 "Lock $0": [
  null,
  "$0 kilitle"
 ],
 "Lock account": [
  null,
  "Hesabı kilitle"
 ],
 "Log out": [
  null,
  "Oturumu kapat"
 ],
 "Log user out": [
  null,
  "Kullanıcı oturumunu kapat"
 ],
 "Logged in": [
  null,
  "Oturum açıldı"
 ],
 "Login history": [
  null,
  "Oturum açma geçmişi"
 ],
 "Login history list": [
  null,
  "Oturum açma geçmişi listesi"
 ],
 "Logout $0": [
  null,
  "$0 oturumunu kapat"
 ],
 "Managing user accounts": [
  null,
  "Kullanıcı hesaplarını yönetme"
 ],
 "Never": [
  null,
  "Yok"
 ],
 "Never expire account": [
  null,
  "Hesabın süresi asla dolmasın"
 ],
 "Never expire password": [
  null,
  "Parolanın süresi asla dolmasın"
 ],
 "Never logged in": [
  null,
  "Hiç oturum açılmadı"
 ],
 "New password": [
  null,
  "Yeni parola"
 ],
 "New password was not accepted": [
  null,
  "Yeni parola kabul edilmedi"
 ],
 "No matching results": [
  null,
  "Eşleşen sonuçlar yok"
 ],
 "No real name specified": [
  null,
  "Belirtilen gerçek ad yok"
 ],
 "No user name specified": [
  null,
  "Belirtilen kullanıcı adı yok"
 ],
 "Ok": [
  null,
  "Tamam"
 ],
 "Old password": [
  null,
  "Eski parola"
 ],
 "Old password not accepted": [
  null,
  "Eski parola kabul edilmedi"
 ],
 "Options": [
  null,
  "Seçenekler"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Etkileşimli parola kimlik doğrulamasına izin verilmese bile diğer kimlik doğrulama yöntemleri hala kullanılabilir."
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Password expiration": [
  null,
  "Parolanın süresinin dolması"
 ],
 "Password is longer than 256 characters": [
  null,
  "Parola 256 karakterden uzun"
 ],
 "Password is not acceptable": [
  null,
  "Parola kabul edilebilir değil"
 ],
 "Password is too weak": [
  null,
  "Parola çok zayıf"
 ],
 "Password must be changed": [
  null,
  "Parola değiştirilmek zorundadır"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Ortak SSH anahtar dosyanızın içeriğini buraya yapıştırın"
 ],
 "Pick date": [
  null,
  "Tarih seçin"
 ],
 "Please specify an expiration date": [
  null,
  "Lütfen bir süre dolma tarihi belirtin"
 ],
 "Prompting via passwd timed out": [
  null,
  "passwd aracılığıyla sorma zaman aşımına uğradı"
 ],
 "Remove": [
  null,
  "Kaldır"
 ],
 "Require password change every $0 days": [
  null,
  "Her $0 günde bir parola değişikliği gerektir"
 ],
 "Require password change on $0": [
  null,
  "$0 tarihinde parola değişikliği gerektir"
 ],
 "Require password change on first login": [
  null,
  "İlk oturum açıldığında parola değişikliği gerektir"
 ],
 "Reset password": [
  null,
  "Parolayı sıfırla"
 ],
 "Roles": [
  null,
  "Roller"
 ],
 "Search for name, group or ID": [
  null,
  "Ad, grup veya kimlik ara"
 ],
 "Server administrator": [
  null,
  "Sunucu yöneticisi"
 ],
 "Set password": [
  null,
  "Parola ayarla"
 ],
 "Set weak password": [
  null,
  "Zayıf parola ayarla"
 ],
 "Started": [
  null,
  "Başladı"
 ],
 "Terminate session": [
  null,
  "Oturumu sonlandır"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "'$0' hesabı, bir sonraki oturum açışında parolasını değiştirmeye zorlanacaktır"
 ],
 "The full name must not contain colons.": [
  null,
  "Ad soyad iki nokta üst üste içermemek zorundadır."
 ],
 "The key you provided was not valid.": [
  null,
  "Sağladığınız anahtar geçerli değil."
 ],
 "The passwords do not match": [
  null,
  "Parolalar eşleşmiyor"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "Rolleri tamamen değiştirmek için kullanıcı oturumu kapatmak ve tekrar oturum açmak zorunda."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Kullanıcı adı sadece a-z arasındaki harf, rakam, nokta, tire ve alt çizgi karakterlerinden oluşabilir."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Bu hesap için yetkilendirilmiş ortak anahtarlar yok."
 ],
 "This group is the primary group for the following users:": [
  null,
  "Bu grup, aşağıdaki kullanıcılar için birincil gruptur:"
 ],
 "This user name already exists": [
  null,
  "Bu kullanıcı adı zaten var"
 ],
 "Toggle date picker": [
  null,
  "Tarihi seçiciyi aç/kapat"
 ],
 "Unexpected error": [
  null,
  "Beklenmeyen hata"
 ],
 "Unix group: $0": [
  null,
  "Unix grubu: $0"
 ],
 "Unnamed": [
  null,
  "Adsız"
 ],
 "Use password": [
  null,
  "Parola kullan"
 ],
 "User name": [
  null,
  "Kullanıcı adı"
 ],
 "Username": [
  null,
  "Kullanıcı adı"
 ],
 "Validating key": [
  null,
  "Anahtar doğrulanıyor"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Bu hesap için yetkilendirilmiş ortak anahtarları görüntüleme izniniz yok."
 ],
 "You must wait longer to change your password": [
  null,
  "Parolanızı değiştirmek için daha uzun süre beklemek zorundasınız"
 ],
 "Your account": [
  null,
  "Hesabınız"
 ],
 "access": [
  null,
  "erişim"
 ],
 "edit": [
  null,
  "düzenle"
 ],
 "keys": [
  null,
  "anahtarlar"
 ],
 "login": [
  null,
  "oturum aç"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "parola"
 ],
 "password quality": [
  null,
  "parola kalitesi"
 ],
 "roles": [
  null,
  "roller"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "kullanıcı"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "kullanıcı adı"
 ]
});
