cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Account expiration": [
  null,
  "账号过期"
 ],
 "Account not available or cannot be edited.": [
  null,
  "帐户不可用或不可编辑."
 ],
 "Accounts": [
  null,
  "账户"
 ],
 "Add": [
  null,
  "添加"
 ],
 "Add key": [
  null,
  "添加密钥"
 ],
 "Add public key": [
  null,
  "添加公钥"
 ],
 "Adding key": [
  null,
  "添加密钥"
 ],
 "Authentication": [
  null,
  "验证"
 ],
 "Authorized public SSH keys": [
  null,
  "授权公共 SSH 密钥"
 ],
 "Back to accounts": [
  null,
  "返回账号"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Change": [
  null,
  "变更"
 ],
 "Close": [
  null,
  "关闭"
 ],
 "Confirm": [
  null,
  "确认"
 ],
 "Confirm new password": [
  null,
  "确认新密码"
 ],
 "Container administrator": [
  null,
  "容器管理员"
 ],
 "Create": [
  null,
  "创建"
 ],
 "Create account with weak password": [
  null,
  "创建具有弱密码的帐户"
 ],
 "Create new account": [
  null,
  "创建新账户"
 ],
 "Delete": [
  null,
  "删除"
 ],
 "Delete $0": [
  null,
  "删除 $0"
 ],
 "Delete files": [
  null,
  "删除文件"
 ],
 "Disallow interactive password": [
  null,
  "禁用交互式密码"
 ],
 "Disallow password authentication": [
  null,
  "不允许密码验证"
 ],
 "Ended": [
  null,
  "结束"
 ],
 "Error saving authorized keys: ": [
  null,
  "保存授权密钥时出错: "
 ],
 "Excellent password": [
  null,
  "密码强度良好"
 ],
 "Expire account on": [
  null,
  "过期账号于"
 ],
 "Expire account on $0": [
  null,
  "过期帐号于 $0"
 ],
 "Failed to change password": [
  null,
  "修改密码失败"
 ],
 "Failed to load authorized keys.": [
  null,
  "载入 authorized key 失败。"
 ],
 "Force change": [
  null,
  "强制变更"
 ],
 "Force password change": [
  null,
  "强制密码变更"
 ],
 "From": [
  null,
  "自"
 ],
 "Full name": [
  null,
  "全名"
 ],
 "Image builder": [
  null,
  "图像生成器"
 ],
 "Invalid expiration date": [
  null,
  "无效的过期时间"
 ],
 "Invalid key": [
  null,
  "无效的 key"
 ],
 "Invalid number of days": [
  null,
  "无效的天数"
 ],
 "Last login": [
  null,
  "最近登陆"
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "Local accounts": [
  null,
  "本地账户"
 ],
 "Logged in": [
  null,
  "登录"
 ],
 "Login history": [
  null,
  "登录历史"
 ],
 "Login history list": [
  null,
  "登陆历史列表"
 ],
 "Managing user accounts": [
  null,
  "管理用户帐户"
 ],
 "Never": [
  null,
  "从不"
 ],
 "Never expire account": [
  null,
  "账号从不过期"
 ],
 "Never expire password": [
  null,
  "密码从不过期"
 ],
 "New password": [
  null,
  "新密码"
 ],
 "New password was not accepted": [
  null,
  "新密码不被接受"
 ],
 "No real name specified": [
  null,
  "未指定真实姓名"
 ],
 "No user name specified": [
  null,
  "未指定用户名"
 ],
 "Ok": [
  null,
  "确认"
 ],
 "Old password": [
  null,
  "旧密码"
 ],
 "Old password not accepted": [
  null,
  "旧密码不被接受"
 ],
 "Options": [
  null,
  "选项"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "即使不允许交互式密码身份验证，仍可使用其他身份验证方法。"
 ],
 "Password": [
  null,
  "密码"
 ],
 "Password expiration": [
  null,
  "密码过期"
 ],
 "Password is longer than 256 characters": [
  null,
  "密码长度不能超过 256 个字符"
 ],
 "Password is not acceptable": [
  null,
  "不接受该密码"
 ],
 "Password is too weak": [
  null,
  "密码太弱"
 ],
 "Password must be changed": [
  null,
  "密码必须被修改"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "在这里粘贴 SSH 公钥文件内容"
 ],
 "Pick date": [
  null,
  "选择日期"
 ],
 "Please specify an expiration date": [
  null,
  "请指定一个过期时间"
 ],
 "Prompting via passwd timed out": [
  null,
  "通过密码提示已超时"
 ],
 "Remove": [
  null,
  "删除"
 ],
 "Require password change every $0 days": [
  null,
  "要求每 $0 天修改密码"
 ],
 "Require password change on $0": [
  null,
  "要求于 $0 修改密码"
 ],
 "Require password change on first login": [
  null,
  "在第一次登录时需要更改密码"
 ],
 "Reset password": [
  null,
  "重置密码"
 ],
 "Roles": [
  null,
  "角色"
 ],
 "Server administrator": [
  null,
  "服务器管理员"
 ],
 "Set password": [
  null,
  "设置密码"
 ],
 "Set weak password": [
  null,
  "设置弱密码"
 ],
 "Started": [
  null,
  "启动"
 ],
 "Terminate session": [
  null,
  "终止会话"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "账号 '$0' 将在下次登录时被强制变更其密码"
 ],
 "The key you provided was not valid.": [
  null,
  "您提供的 key 是无效的."
 ],
 "The passwords do not match": [
  null,
  "密码不匹配"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "用户必须先注销，然后再重新登录才能完全更改角色。"
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "用户名仅能包含 a-z、数字、点、破折号和下划线的字母。"
 ],
 "There are no authorized public keys for this account.": [
  null,
  "没有这个帐户的授权公钥."
 ],
 "This user name already exists": [
  null,
  "用户名已存在"
 ],
 "Toggle date picker": [
  null,
  "切换日期选择器"
 ],
 "Unexpected error": [
  null,
  "意外的错误"
 ],
 "Unix group: $0": [
  null,
  "Unix 组：$0"
 ],
 "Unnamed": [
  null,
  "未命名"
 ],
 "Use password": [
  null,
  "使用密码"
 ],
 "User name": [
  null,
  "用户名"
 ],
 "Validating key": [
  null,
  "验证 key"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "您没有权限查看此帐户的授权公钥."
 ],
 "You must wait longer to change your password": [
  null,
  "您需要等待更长时间来修改您的密码"
 ],
 "Your account": [
  null,
  "您的账户"
 ],
 "access": [
  null,
  "访问"
 ],
 "edit": [
  null,
  "编辑"
 ],
 "keys": [
  null,
  "密钥"
 ],
 "login": [
  null,
  "登录"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "密码"
 ],
 "password quality": [
  null,
  "密码质量"
 ],
 "roles": [
  null,
  "角色"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "用户"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "用户名"
 ]
});
