cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  ""
 ],
 "Account expiration": [
  null,
  "Skončení platnosti účtu"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Účet není k dispozici nebo ho není možné měnit."
 ],
 "Accounts": [
  null,
  "Účty"
 ],
 "Add": [
  null,
  "Přidat"
 ],
 "Add key": [
  null,
  "Přidat klíč"
 ],
 "Add public key": [
  null,
  "Přidat veřejnou část klíče"
 ],
 "Adding key": [
  null,
  "Přidání klíče"
 ],
 "Authentication": [
  null,
  "Ověření"
 ],
 "Authorized public SSH keys": [
  null,
  "Pověřené veřejné SSH klíče"
 ],
 "Back to accounts": [
  null,
  "Zpět k účtům"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Confirm": [
  null,
  "Potvrdit"
 ],
 "Confirm new password": [
  null,
  "Potvrdit nové heslo"
 ],
 "Container administrator": [
  null,
  "Správce kontejneru"
 ],
 "Create": [
  null,
  "Vytvořit"
 ],
 "Create account with weak password": [
  null,
  ""
 ],
 "Create new account": [
  null,
  "Vytvořit nový účet"
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Delete $0": [
  null,
  "Smazat $0"
 ],
 "Delete files": [
  null,
  "Smazat soubory"
 ],
 "Disallow password authentication": [
  null,
  ""
 ],
 "Ended": [
  null,
  "Ukončeno"
 ],
 "Error saving authorized keys: ": [
  null,
  "Chyba při ukládání pověřených klíčů: "
 ],
 "Excellent password": [
  null,
  "Skvělé heslo"
 ],
 "Expire account on": [
  null,
  "Ukončit platnost účtu v"
 ],
 "Expire account on $0": [
  null,
  "Ukončit platnost účtu v $0"
 ],
 "Failed to change password": [
  null,
  "Nepodařilo se změnit heslo"
 ],
 "Failed to load authorized keys.": [
  null,
  "Nepodařilo se nahrát ověřovací klíče."
 ],
 "Force change": [
  null,
  "Vynutit změnu"
 ],
 "Force delete": [
  null,
  "Vynutit smazání"
 ],
 "Force password change": [
  null,
  "Vynutit změnu hesla"
 ],
 "From": [
  null,
  "Z"
 ],
 "Full name": [
  null,
  "Celé jméno"
 ],
 "Group": [
  null,
  "Skupina"
 ],
 "ID": [
  null,
  "Identif."
 ],
 "Image builder": [
  null,
  "Tvorba obrazů"
 ],
 "Invalid expiration date": [
  null,
  "Neplatné datum skončení platnosti"
 ],
 "Invalid key": [
  null,
  "Neplatný klíč"
 ],
 "Invalid number of days": [
  null,
  "Neplatný počet dnů"
 ],
 "Last login": [
  null,
  "Poslední přihlášení"
 ],
 "Learn more": [
  null,
  "Další informace naleznete"
 ],
 "Local accounts": [
  null,
  "Místní účty"
 ],
 "Lock": [
  null,
  "Uzamknout"
 ],
 "Lock account": [
  null,
  "Uzamknout účet"
 ],
 "Log out": [
  null,
  "Odhlásit"
 ],
 "Logged in": [
  null,
  "Přihlášeni"
 ],
 "Managing user accounts": [
  null,
  "Správa uživatelských účtů"
 ],
 "Never": [
  null,
  "Nikdy"
 ],
 "Never expire account": [
  null,
  "Účet s neomezenou dobou platnosti"
 ],
 "Never expire password": [
  null,
  "Heslo platí napořád"
 ],
 "New password": [
  null,
  "Nové heslo"
 ],
 "New password was not accepted": [
  null,
  "Nové heslo nebylo přijato"
 ],
 "No matching results": [
  null,
  "Žádné shodující se výsledky"
 ],
 "No real name specified": [
  null,
  "Není zadán skutečný název"
 ],
 "No user name specified": [
  null,
  "Nebylo zadáno uživatelské jméno"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password": [
  null,
  "Původní heslo"
 ],
 "Old password not accepted": [
  null,
  "Původní heslo nebylo přijato"
 ],
 "Options": [
  null,
  "Přepínače"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  ""
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Password expiration": [
  null,
  "Skončení platnosti hesla"
 ],
 "Password is longer than 256 characters": [
  null,
  "Heslo nemůže být delší než 256 znaků"
 ],
 "Password is not acceptable": [
  null,
  "Heslo není přijatelné"
 ],
 "Password is too weak": [
  null,
  "Heslo je příliš slabé"
 ],
 "Password must be changed": [
  null,
  "Heslo je třeba změnit"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Sem vložte obsah veřejné části svého ssh klíče"
 ],
 "Pick date": [
  null,
  "Vyberte datum"
 ],
 "Please specify an expiration date": [
  null,
  "Zadejte datum skončení platnosti"
 ],
 "Prompting via passwd timed out": [
  null,
  "Časový limit výzvy prostřednictvím hesla překročen"
 ],
 "Remove": [
  null,
  "Odebrat"
 ],
 "Require password change every $0 days": [
  null,
  "Vyžadovat změnu hesla každých $0 dnů"
 ],
 "Require password change on $0": [
  null,
  "Vyžadovat změnu hesla na $0"
 ],
 "Reset password": [
  null,
  "Resetovat heslo"
 ],
 "Roles": [
  null,
  "Role"
 ],
 "Search for name, group or ID": [
  null,
  ""
 ],
 "Server administrator": [
  null,
  "Správce serveru"
 ],
 "Set password": [
  null,
  "Nastavit heslo"
 ],
 "Terminate session": [
  null,
  "Ukončit sezení"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Účet „$0“ bude při příštím přihlášení vyzván k vynucené změně hesla"
 ],
 "The full name must not contain colons.": [
  null,
  ""
 ],
 "The key you provided was not valid.": [
  null,
  "Zadaný klíč není platný."
 ],
 "The passwords do not match": [
  null,
  "Zadání hesla se neshodují"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "Pro úplnou změnu rolí je třeba, aby se uživatel odhlásil a přihlásil znovu."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Uživatelské jméno se může sestávat pouze z písmen a-z (bez diakritiky), číslic, teček, spojovníků a podtržítek."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Pro tento účet nejsou žádné pověřené klíče."
 ],
 "This group is the primary group for the following users:": [
  null,
  ""
 ],
 "This user name already exists": [
  null,
  "Toto uživatelské jméno už existuje"
 ],
 "Toggle date picker": [
  null,
  "Přepnout volič datumů"
 ],
 "Unexpected error": [
  null,
  "Neočekávaná chyba"
 ],
 "Unix group: $0": [
  null,
  "Unixová skupina: $0"
 ],
 "Unnamed": [
  null,
  "Bez názvu"
 ],
 "User name": [
  null,
  "Uživatelské jméno"
 ],
 "Username": [
  null,
  "Uživatelské jméno"
 ],
 "Validating key": [
  null,
  "Ověřuje se klíč"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Nemáte oprávnění zobrazovat pověřené klíče pro tento účet."
 ],
 "You must wait longer to change your password": [
  null,
  "Pro změnu hesla je třeba vyčkat déle"
 ],
 "Your account": [
  null,
  "Váš účet"
 ],
 "access": [
  null,
  "přístup"
 ],
 "edit": [
  null,
  "upravit"
 ],
 "keys": [
  null,
  "klíče"
 ],
 "login": [
  null,
  "přihlášení"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "heslo"
 ],
 "password quality": [
  null,
  "odolnost hesla"
 ],
 "roles": [
  null,
  "role"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "uživatel"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "uživatelské jméno"
 ]
});
