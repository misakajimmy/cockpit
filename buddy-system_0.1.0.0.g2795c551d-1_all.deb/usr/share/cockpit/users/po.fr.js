cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  ""
 ],
 "Account expiration": [
  null,
  "Expiration du compte"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Le compte n’est pas disponible ou ne peut pas être modifié."
 ],
 "Accounts": [
  null,
  "Comptes"
 ],
 "Add": [
  null,
  "Ajouter"
 ],
 "Add key": [
  null,
  "Ajouter une clé"
 ],
 "Add public key": [
  null,
  "Ajouter une clé publique"
 ],
 "Adding key": [
  null,
  "Ajout d’une clé"
 ],
 "Authentication": [
  null,
  "Authentification"
 ],
 "Authorized public SSH keys": [
  null,
  "Clés SSH publiques autorisées"
 ],
 "Back to accounts": [
  null,
  "Retour aux comptes"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Change": [
  null,
  "Modification"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Confirm": [
  null,
  "Confirmer"
 ],
 "Confirm new password": [
  null,
  "Confirmer le nouveau mot de passe"
 ],
 "Container administrator": [
  null,
  "Administrateur de conteneur"
 ],
 "Create": [
  null,
  "Créer"
 ],
 "Create account with weak password": [
  null,
  "Créer un compte avec un mot de passe faible"
 ],
 "Create new account": [
  null,
  "Créer un nouveau compte"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Delete $0": [
  null,
  "Supprimer $0"
 ],
 "Delete files": [
  null,
  "Supprimer les fichiers"
 ],
 "Disallow interactive password": [
  null,
  "Interdire le mot de passe interactif"
 ],
 "Disallow password authentication": [
  null,
  "Interdire l’authentification par mot de passe"
 ],
 "Ended": [
  null,
  "Terminé"
 ],
 "Error saving authorized keys: ": [
  null,
  "Erreur lors de l’enregistrement des clés autorisées : "
 ],
 "Excellent password": [
  null,
  "Mot de passe excellent"
 ],
 "Expire account on": [
  null,
  "Expiration du compte le"
 ],
 "Expire account on $0": [
  null,
  "Expiration du compte le $0"
 ],
 "Failed to change password": [
  null,
  "Échec de la modification du mot de passe"
 ],
 "Failed to load authorized keys.": [
  null,
  "Échec du chargement des clés autorisées."
 ],
 "Force change": [
  null,
  "Forcer la modification"
 ],
 "Force delete": [
  null,
  "Forcer la suppression"
 ],
 "Force password change": [
  null,
  "Forcer la modification de mot de passe"
 ],
 "From": [
  null,
  "De"
 ],
 "Full name": [
  null,
  "Nom complet"
 ],
 "Group": [
  null,
  "Groupe"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Image builder": [
  null,
  "Image Builder"
 ],
 "Invalid expiration date": [
  null,
  "Date d’expiration non valide"
 ],
 "Invalid key": [
  null,
  "Clé non valide"
 ],
 "Invalid number of days": [
  null,
  "Nombre de jours non valide"
 ],
 "Last login": [
  null,
  "Dernière connexion"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "Local accounts": [
  null,
  "Comptes locaux"
 ],
 "Lock": [
  null,
  "Verrouillage"
 ],
 "Lock account": [
  null,
  "Verrouiller le compte"
 ],
 "Log out": [
  null,
  "Déconnexion"
 ],
 "Logged in": [
  null,
  "Connecté"
 ],
 "Login history": [
  null,
  "Historique des connexions"
 ],
 "Login history list": [
  null,
  "Liste de l’historique des connexions"
 ],
 "Managing user accounts": [
  null,
  "Gestion des comptes utilisateurs"
 ],
 "Never": [
  null,
  "Jamais"
 ],
 "Never expire account": [
  null,
  "Ne jamais expirer le compte"
 ],
 "Never expire password": [
  null,
  "Ne jamais faire expirer le mot de passe"
 ],
 "New password": [
  null,
  "Nouveau mot de passe"
 ],
 "New password was not accepted": [
  null,
  "Le nouveau mot de passe n’a pas été accepté"
 ],
 "No matching results": [
  null,
  "Aucun résultat correspondant n’a été trouvé"
 ],
 "No real name specified": [
  null,
  "Aucun nom réel n’est renseigné"
 ],
 "No user name specified": [
  null,
  "Aucun nom d’utilisateur n’est renseigné"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password": [
  null,
  "Ancien mot de passe"
 ],
 "Old password not accepted": [
  null,
  "Ancien mot de passe non accepté"
 ],
 "Options": [
  null,
  "Options"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "D’autres méthodes d’authentification sont toujours disponibles même lorsque l’authentification par mot de passe interactif n’est pas autorisée."
 ],
 "Password": [
  null,
  "Mot de passe"
 ],
 "Password expiration": [
  null,
  "Expiration du mot de passe"
 ],
 "Password is longer than 256 characters": [
  null,
  "Le mot de passe fait plus de 256 caractères"
 ],
 "Password is not acceptable": [
  null,
  "Le mot de passe n’est pas acceptable"
 ],
 "Password is too weak": [
  null,
  "Le mot de passe est trop faible"
 ],
 "Password must be changed": [
  null,
  "Le mot de passe doit être changé"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Collez le contenu de votre clé publique SSH ici"
 ],
 "Pick date": [
  null,
  "Choisissez une date"
 ],
 "Please specify an expiration date": [
  null,
  "Veuillez spécifier une date d’expiration"
 ],
 "Prompting via passwd timed out": [
  null,
  "L’invite via passwd a expiré"
 ],
 "Remove": [
  null,
  "Retirer"
 ],
 "Require password change every $0 days": [
  null,
  "Exiger un changement de mot de passe tous les $0 jours"
 ],
 "Require password change on $0": [
  null,
  "Exiger un changement de mot de passe sur $0"
 ],
 "Require password change on first login": [
  null,
  "Exiger un changement de mot de passe à la première connexion"
 ],
 "Reset password": [
  null,
  "Définir le mot de passe"
 ],
 "Roles": [
  null,
  "Les rôles"
 ],
 "Search for name, group or ID": [
  null,
  ""
 ],
 "Server administrator": [
  null,
  "Administrateur de serveur"
 ],
 "Set password": [
  null,
  "Définir le mot de passe"
 ],
 "Set weak password": [
  null,
  "Définir un mot de passe faible"
 ],
 "Started": [
  null,
  "Démarré"
 ],
 "Terminate session": [
  null,
  "Terminer la session"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Le compte « $0 » sera forcé de changer de mot de passe lors de la prochaine connexion"
 ],
 "The full name must not contain colons.": [
  null,
  ""
 ],
 "The key you provided was not valid.": [
  null,
  "La clé que vous avez fournie n’était pas valide."
 ],
 "The passwords do not match": [
  null,
  "Le mot de passe ne correspond pas"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "L’utilisateur doit se déconnecter et se reconnecter pour changer complètement de rôle."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Le nom d’utilisateur ne peut contenir que des lettres de az, des chiffres, des points, des tirets et des traits de soulignement."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Il n’y a aucune clé publique autorisée pour ce compte."
 ],
 "This group is the primary group for the following users:": [
  null,
  ""
 ],
 "This user name already exists": [
  null,
  "Cet identifiant existe déjà"
 ],
 "Toggle date picker": [
  null,
  "Basculer le sélecteur de date"
 ],
 "Unexpected error": [
  null,
  "Erreur inattendue"
 ],
 "Unix group: $0": [
  null,
  "Groupe Unix : $0"
 ],
 "Unnamed": [
  null,
  "Anonyme"
 ],
 "Use password": [
  null,
  "Utiliser un mot de passe"
 ],
 "User name": [
  null,
  "Nom d’utilisateur"
 ],
 "Username": [
  null,
  "Nom d’utilisateur"
 ],
 "Validating key": [
  null,
  "Clé de validation"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Vous n’êtes pas autorisé à afficher les clés publiques autorisées pour ce compte."
 ],
 "You must wait longer to change your password": [
  null,
  "Vous devez encore attendre avant de changer votre mot de passe"
 ],
 "Your account": [
  null,
  "Votre compte"
 ],
 "access": [
  null,
  "accès"
 ],
 "edit": [
  null,
  "modifier"
 ],
 "keys": [
  null,
  "clés"
 ],
 "login": [
  null,
  "login"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "mot de passe"
 ],
 "password quality": [
  null,
  "qualité mot de passe"
 ],
 "roles": [
  null,
  "rôles"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "utilisateur"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "nom d’utilisateur"
 ]
});
