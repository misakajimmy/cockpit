cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "# of users": [
  null,
  ""
 ],
 "Account expiration": [
  null,
  "תפוגת תוקף חשבון"
 ],
 "Account not available or cannot be edited.": [
  null,
  "החשבון לא זמין או שאין אפשרות לערוך אותו."
 ],
 "Accounts": [
  null,
  "חשבונות"
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "Add key": [
  null,
  "הוספת מפתח"
 ],
 "Add public key": [
  null,
  "הוספת מפתח ציבורי"
 ],
 "Adding key": [
  null,
  "נוסף מפתח"
 ],
 "Authentication": [
  null,
  "אימות"
 ],
 "Authorized public SSH keys": [
  null,
  "מפתחות SSH ציבוריים מורשים"
 ],
 "Back to accounts": [
  null,
  "חזרה לחשבונות"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Change": [
  null,
  "החלפה"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Confirm": [
  null,
  "אישור"
 ],
 "Confirm new password": [
  null,
  "אישור סיסמה חדשה"
 ],
 "Container administrator": [
  null,
  "מנהל המכולה"
 ],
 "Create": [
  null,
  "יצירה"
 ],
 "Create account with weak password": [
  null,
  "יצירת חשבון עם סיסמה חלשה"
 ],
 "Create new account": [
  null,
  "יצירת חשבון חדש"
 ],
 "Delete": [
  null,
  "מחיקה"
 ],
 "Delete $0": [
  null,
  "מחיקת $0"
 ],
 "Delete account": [
  null,
  "מחיקת חשבון"
 ],
 "Delete files": [
  null,
  "מחיקת קבצים"
 ],
 "Disallow password authentication": [
  null,
  "לא לאפשר אימות בסיסמה"
 ],
 "Edit user": [
  null,
  "עריכת משתמש"
 ],
 "Ended": [
  null,
  "הסתיים"
 ],
 "Error saving authorized keys: ": [
  null,
  "שגיאה בשמירת המפתחות המורשים: "
 ],
 "Excellent password": [
  null,
  "סיסמה מצוינת"
 ],
 "Expire account on": [
  null,
  "החשבון יפוג ב־"
 ],
 "Expire account on $0": [
  null,
  "החשבון יפוג ב־$0"
 ],
 "Failed to change password": [
  null,
  "החלפת הסיסמה נכשלה"
 ],
 "Failed to load authorized keys.": [
  null,
  "טעינת המפתחות המורשים נכשלה."
 ],
 "Force change": [
  null,
  "לאלץ החלפה"
 ],
 "Force delete": [
  null,
  "לאלץ מחיקה"
 ],
 "Force password change": [
  null,
  "לאלץ החלפת סיסמה"
 ],
 "From": [
  null,
  "התחלה"
 ],
 "Full name": [
  null,
  "שם מלא"
 ],
 "Group": [
  null,
  "קבוצה"
 ],
 "ID": [
  null,
  "מזהה"
 ],
 "Image builder": [
  null,
  "בונה תמונות"
 ],
 "Invalid expiration date": [
  null,
  "מועד התפוגה שגוי"
 ],
 "Invalid key": [
  null,
  "מפתח שגוי"
 ],
 "Invalid number of days": [
  null,
  "מספר הימים שגוי"
 ],
 "Last login": [
  null,
  "כניסה אחרונה"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "Local accounts": [
  null,
  "חשבונות מקומיים"
 ],
 "Lock": [
  null,
  "נעילה"
 ],
 "Lock account": [
  null,
  "נעילת חשבון"
 ],
 "Log out": [
  null,
  "יציאה"
 ],
 "Logged in": [
  null,
  "נכנסת"
 ],
 "Login history": [
  null,
  "היסטוריית כניסות"
 ],
 "Login history list": [
  null,
  "רשימת היסטוריית כניסות"
 ],
 "Managing user accounts": [
  null,
  "ניהול חשבונות משתמשים"
 ],
 "Never": [
  null,
  "אף פעם"
 ],
 "Never expire account": [
  null,
  "חשבון שתוקפו לא פג"
 ],
 "Never expire password": [
  null,
  "הסיסמה לא תפוג לעולם"
 ],
 "New password": [
  null,
  "סיסמה חדשה"
 ],
 "New password was not accepted": [
  null,
  "הסיסמה החדשה לא התקבלה"
 ],
 "No matching results": [
  null,
  "אין כללים תואמים"
 ],
 "No real name specified": [
  null,
  "לא צוין שם אמתי"
 ],
 "No user name specified": [
  null,
  "לא צוין שם משתמש"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "Old password": [
  null,
  "סיסמה ישנה"
 ],
 "Old password not accepted": [
  null,
  "הסיסמה הישנה לא התקבלה"
 ],
 "Options": [
  null,
  "אפשרויות"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  ""
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Password expiration": [
  null,
  "תפוגת סיסמה"
 ],
 "Password is longer than 256 characters": [
  null,
  "הסיסמה ארוכה מ־256 תווים"
 ],
 "Password is not acceptable": [
  null,
  "הסיסמה לא מקובלת"
 ],
 "Password is too weak": [
  null,
  "הסיסמה חלשה מדי"
 ],
 "Password must be changed": [
  null,
  "חובה לשנות את הסיסמה"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "עליך להדביק את תוכן קובץ מפתח ה־SSH הציבורי שלך כאן"
 ],
 "Pick date": [
  null,
  "בחירת תאריך"
 ],
 "Please specify an expiration date": [
  null,
  "נא לציין מועד תפוגת תוקף"
 ],
 "Prompting via passwd timed out": [
  null,
  "משך הצגת הבקשה דרך passwd תם"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "Require password change every $0 days": [
  null,
  "לדרוש החלפת סיסמה כל $0 ימים"
 ],
 "Require password change on $0": [
  null,
  "לדרוש החלפת סיסמה ב־$0"
 ],
 "Reset password": [
  null,
  "איפוס סיסמה"
 ],
 "Roles": [
  null,
  "תפקידים"
 ],
 "Search for name, group or ID": [
  null,
  ""
 ],
 "Server administrator": [
  null,
  "הנהלת השרת"
 ],
 "Set password": [
  null,
  "הגדרת סיסמה"
 ],
 "Terminate session": [
  null,
  "חיסול הפעלה"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "החשבון ‚$0’ יאולץ להחליף את הסיסמה שלו עם כניסתו הבאה למערכת"
 ],
 "The full name must not contain colons.": [
  null,
  ""
 ],
 "The key you provided was not valid.": [
  null,
  "המפתח שסיפקת אינו תקף."
 ],
 "The passwords do not match": [
  null,
  "הסיסמאות אינן תואמות"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "על המשתמש לצאת ולהיכנס בחזרה למערכת כדי לשנות תפקידים באופן מלא."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "שם המשתמש יכול להיות מורכב מהתווים a-z, ספרות, נקודות, מינוסים וקווים תחתונים."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "אין מפתחות ציבוריים מורשים לחשבון זה."
 ],
 "This group is the primary group for the following users:": [
  null,
  ""
 ],
 "This user name already exists": [
  null,
  "שם משתמש זה כבר קיים"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Unexpected error": [
  null,
  "שגיאה בלתי צפויה"
 ],
 "Unix group: $0": [
  null,
  "קבוצת יוניקס: $0"
 ],
 "Unnamed": [
  null,
  "ללא שם"
 ],
 "User name": [
  null,
  "שם משתמש"
 ],
 "Username": [
  null,
  "שם משתמש"
 ],
 "Validating key": [
  null,
  "המפתח מתוקף"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "אין לך הרשאה לצפות במפתחות ציבוריים מורשים לחשבון זה."
 ],
 "You must wait longer to change your password": [
  null,
  "עליך להמתין זמן רב יותר כדי להחליף את הסיסמה שלך"
 ],
 "Your account": [
  null,
  "החשבון שלך"
 ],
 "access": [
  null,
  "גישה"
 ],
 "edit": [
  null,
  "עריכה"
 ],
 "keys": [
  null,
  "מפתחות"
 ],
 "login": [
  null,
  "כניסה"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "סיסמה"
 ],
 "password quality": [
  null,
  "איכות הסיסמה"
 ],
 "roles": [
  null,
  "תפקידים"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "משתמש"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "שם משתמש"
 ]
});
