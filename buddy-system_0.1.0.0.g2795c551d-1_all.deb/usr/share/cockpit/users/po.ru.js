cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  ""
 ],
 "Account expiration": [
  null,
  "Срок действия учётной записи"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Учётная запись недоступна или не может быть изменена."
 ],
 "Accounts": [
  null,
  "Учётные записи"
 ],
 "Add": [
  null,
  "Добавить"
 ],
 "Add key": [
  null,
  "Добавить ключ"
 ],
 "Add public key": [
  null,
  "Добавить открытый ключ"
 ],
 "Adding key": [
  null,
  "Добавление ключа"
 ],
 "Authentication": [
  null,
  "Проверка подлинности"
 ],
 "Authorized public SSH keys": [
  null,
  "Авторизованные открытые SSH-ключи"
 ],
 "Back to accounts": [
  null,
  "Вернуться к учётным записям"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Confirm": [
  null,
  "Подтверждение"
 ],
 "Confirm new password": [
  null,
  "Подтвердите новый пароль"
 ],
 "Container administrator": [
  null,
  "Администратор контейнера"
 ],
 "Create": [
  null,
  "Создать"
 ],
 "Create account with weak password": [
  null,
  ""
 ],
 "Create new account": [
  null,
  "Создать учётную запись"
 ],
 "Delete": [
  null,
  "Удалить"
 ],
 "Delete $0": [
  null,
  "Удалить $0"
 ],
 "Delete files": [
  null,
  "Удалить файлы"
 ],
 "Disallow password authentication": [
  null,
  ""
 ],
 "Ended": [
  null,
  ""
 ],
 "Error saving authorized keys: ": [
  null,
  "Ошибка при сохранении авторизованных ключей: "
 ],
 "Excellent password": [
  null,
  "Отличный пароль"
 ],
 "Failed to change password": [
  null,
  "Не удалось изменить пароль"
 ],
 "Failed to load authorized keys.": [
  null,
  "Не удалось загрузить авторизованные ключи."
 ],
 "Force change": [
  null,
  "Принудительно изменить"
 ],
 "Force delete": [
  null,
  "Принудительно удалить"
 ],
 "Force password change": [
  null,
  "Принудительно изменить пароль"
 ],
 "From": [
  null,
  ""
 ],
 "Full name": [
  null,
  "Полное имя"
 ],
 "Group": [
  null,
  ""
 ],
 "Groups": [
  null,
  ""
 ],
 "ID": [
  null,
  "Идентификатор"
 ],
 "Image builder": [
  null,
  "Image builder"
 ],
 "Invalid expiration date": [
  null,
  "Неверная дата окончания срока действия"
 ],
 "Invalid key": [
  null,
  "Недопустимый ключ"
 ],
 "Invalid number of days": [
  null,
  "Недопустимое количество дней"
 ],
 "Last login": [
  null,
  "Последний вход"
 ],
 "Learn more": [
  null,
  "Подробнее..."
 ],
 "Local accounts": [
  null,
  "Локальные учётные записи"
 ],
 "Lock": [
  null,
  "Заблокировать"
 ],
 "Lock account": [
  null,
  "Заблокировать учётную запись"
 ],
 "Log out": [
  null,
  "Выход"
 ],
 "Logged in": [
  null,
  "Вход выполнен"
 ],
 "Managing user accounts": [
  null,
  "Управление учетными записями пользователей"
 ],
 "Never": [
  null,
  "Никогда"
 ],
 "Never expire password": [
  null,
  "Пароль с неограниченным сроком действия"
 ],
 "New password": [
  null,
  "Новый пароль"
 ],
 "New password was not accepted": [
  null,
  "Новый пароль не был принят"
 ],
 "No real name specified": [
  null,
  "Не указано настоящее имя"
 ],
 "No user name specified": [
  null,
  "Не указано имя пользователя"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password": [
  null,
  "Старый пароль"
 ],
 "Old password not accepted": [
  null,
  "Старый пароль не был принят"
 ],
 "Options": [
  null,
  "Параметры"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  ""
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Password expiration": [
  null,
  "Срок действия пароля"
 ],
 "Password is not acceptable": [
  null,
  "Недопустимый пароль"
 ],
 "Password is too weak": [
  null,
  "Пароль недостаточно надёжен"
 ],
 "Password must be changed": [
  null,
  "Необходимо изменить пароль"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Вставьте сюда содержимое вашего файла открытого SSH-ключа."
 ],
 "Please specify an expiration date": [
  null,
  "Укажите дату окончания срока действия"
 ],
 "Prompting via passwd timed out": [
  null,
  "Превышено время ожидания запроса по passwd"
 ],
 "Remove": [
  null,
  "Удалить"
 ],
 "Require password change every $0 days": [
  null,
  "Требовать изменения пароля каждые $0 дней"
 ],
 "Require password change on $0": [
  null,
  "Потребовать смену пароля $0"
 ],
 "Roles": [
  null,
  "Роли"
 ],
 "Search for name, group or ID": [
  null,
  ""
 ],
 "Server administrator": [
  null,
  "Администратор сервера"
 ],
 "Set password": [
  null,
  "Задать пароль"
 ],
 "Terminate session": [
  null,
  "Завершить сеанс"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Для учётной записи «$0» будет запрошено принудительное изменение пароля при следующем входе в систему"
 ],
 "The full name must not contain colons.": [
  null,
  ""
 ],
 "The key you provided was not valid.": [
  null,
  "Предоставленный ключ недействителен."
 ],
 "The passwords do not match": [
  null,
  "Пароли не совпадают"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "Пользователь должен выйти и снова войти в систему, чтобы полностью сменить роли."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Имя пользователя может содержать только латинские буквы a-z, цифры, точки, тире и символы подчёркивания."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Для этой учётной записи нет авторизованных открытых ключей."
 ],
 "This group is the primary group for the following users:": [
  null,
  ""
 ],
 "This user name already exists": [
  null,
  "Такое имя пользователя уже существует"
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Unexpected error": [
  null,
  "Непредвиденная ошибка"
 ],
 "Unix group: $0": [
  null,
  ""
 ],
 "Unnamed": [
  null,
  "Без названия"
 ],
 "User name": [
  null,
  "Имя пользователя"
 ],
 "Username": [
  null,
  "Имя пользователя"
 ],
 "Validating key": [
  null,
  "Проверка ключа"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Отсутствует разрешение на просмотр авторизованных открытых ключей для этой учётной записи."
 ],
 "You must wait longer to change your password": [
  null,
  "Для изменения пароля необходимо подождать"
 ],
 "access": [
  null,
  "доступ"
 ],
 "edit": [
  null,
  "редактировать"
 ],
 "keys": [
  null,
  "ключи"
 ],
 "login": [
  null,
  "вход"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "пароль"
 ],
 "roles": [
  null,
  "роли"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "пользователь"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "имя пользователя"
 ]
});
