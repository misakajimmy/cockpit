cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  ""
 ],
 "Account expiration": [
  null,
  "Kontoablauf"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Konto nicht verfügbar oder Änderungen nicht möglich."
 ],
 "Accounts": [
  null,
  "Konten"
 ],
 "Add": [
  null,
  "Hinzufügen"
 ],
 "Add key": [
  null,
  "Schlüssel hinzufügen"
 ],
 "Add public key": [
  null,
  "Öffentlichen Schlüssel hinzufügen"
 ],
 "Adding key": [
  null,
  "Schlüssel wird hinzugefügt"
 ],
 "Authentication": [
  null,
  "Authentifizierung"
 ],
 "Authorized public SSH keys": [
  null,
  "Autorisierte öffentliche SSH-Schlüssel"
 ],
 "Back to accounts": [
  null,
  "Zurück zu den Konten"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Change": [
  null,
  "Ändern"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Confirm": [
  null,
  "Bestätigen"
 ],
 "Confirm new password": [
  null,
  "Neues Passwort wiederholen"
 ],
 "Container administrator": [
  null,
  "Container administrator"
 ],
 "Create": [
  null,
  "Erstellen"
 ],
 "Create account with weak password": [
  null,
  "Account mit schwachem Passwort erstellen"
 ],
 "Create new account": [
  null,
  "Neues Konto anlegen"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Delete $0": [
  null,
  "$0 löschen"
 ],
 "Delete files": [
  null,
  "Dateien löschen"
 ],
 "Disallow interactive password": [
  null,
  "Interaktives Passwort nicht erlauben"
 ],
 "Disallow password authentication": [
  null,
  "Authentifizierung durch Passwort nicht erlauben"
 ],
 "Ended": [
  null,
  "Beendet"
 ],
 "Error saving authorized keys: ": [
  null,
  "Fehler beim Speichern der autorisierten Schlüssel: "
 ],
 "Excellent password": [
  null,
  "Perfektes Passwort"
 ],
 "Expire account on": [
  null,
  "Konto ablaufen lassen am"
 ],
 "Expire account on $0": [
  null,
  "Konto auf $0 ablaufen lassen"
 ],
 "Failed to change password": [
  null,
  "Passwort konnte nicht geändert werden"
 ],
 "Failed to load authorized keys.": [
  null,
  "Fehler beim Laden autorisierter Schlüssel."
 ],
 "Force change": [
  null,
  "Änderung erzwingen"
 ],
 "Force delete": [
  null,
  "Löschen erzwingen"
 ],
 "Force password change": [
  null,
  "Passwortänderung erzwingen"
 ],
 "From": [
  null,
  "Von"
 ],
 "Full name": [
  null,
  "Vollständiger Name"
 ],
 "Group": [
  null,
  "Gruppe"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Image builder": [
  null,
  "Image builder"
 ],
 "Invalid expiration date": [
  null,
  "Ungültiges Ablaufdatum"
 ],
 "Invalid key": [
  null,
  "Ungültiger Schlüssel"
 ],
 "Invalid number of days": [
  null,
  "Ungültige Anzahl von Tagen"
 ],
 "Last login": [
  null,
  "Letzte Anmeldung"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "Local accounts": [
  null,
  "Lokale Konten"
 ],
 "Lock": [
  null,
  "Schließen"
 ],
 "Lock account": [
  null,
  "Konto sperren"
 ],
 "Log out": [
  null,
  "Abmelden"
 ],
 "Logged in": [
  null,
  "Angemeldet"
 ],
 "Login history": [
  null,
  "Anmeldeverlauf"
 ],
 "Login history list": [
  null,
  "Liste des Anmeldeverlaufs"
 ],
 "Managing user accounts": [
  null,
  "Benutzerkonten verwalten"
 ],
 "Never": [
  null,
  "Nie"
 ],
 "Never expire account": [
  null,
  "Konto nie ablaufen lassen"
 ],
 "Never expire password": [
  null,
  "Passwort verfällt niemals"
 ],
 "New password": [
  null,
  "Neues Passwort"
 ],
 "New password was not accepted": [
  null,
  "Das neue Passwort wurde nicht akzeptiert"
 ],
 "No matching results": [
  null,
  "Keine passenden Ergebnisse"
 ],
 "No real name specified": [
  null,
  "Es wurde kein echter Name angegeben"
 ],
 "No user name specified": [
  null,
  "Es wurde kein Benutzername angegeben."
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password": [
  null,
  "Altes Passwort"
 ],
 "Old password not accepted": [
  null,
  "Altes Passwort wurde nicht akzeptiert"
 ],
 "Options": [
  null,
  "Einstellungen"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Andere Authentifizierungsmethoden stehen auch dann zur Verfügung, wenn die interaktive Passwortauthentifizierung nicht erlaubt ist."
 ],
 "Password": [
  null,
  "Passwort"
 ],
 "Password expiration": [
  null,
  "Passwort ablaufen"
 ],
 "Password is longer than 256 characters": [
  null,
  "Passwort ist länger als 256 Zeichen"
 ],
 "Password is not acceptable": [
  null,
  "Das Passwort kann nicht akzeptiert werden"
 ],
 "Password is too weak": [
  null,
  "Das gewählte Passwort ist zu schwach"
 ],
 "Password must be changed": [
  null,
  "Passwort muss geändert werden"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Fügen Sie hier den Inhalt Ihrer öffentlichen SSH-Schlüsseldatei ein"
 ],
 "Pick date": [
  null,
  "Datum auswählen"
 ],
 "Please specify an expiration date": [
  null,
  "Bitte geben Sie ein Ablaufdatum an"
 ],
 "Prompting via passwd timed out": [
  null,
  "Die Aufforderung über passwd ist abgelaufen"
 ],
 "Remove": [
  null,
  "Entfernen"
 ],
 "Require password change every $0 days": [
  null,
  "Erfordert jedes Mal ein Passwort $0 Tage"
 ],
 "Require password change on $0": [
  null,
  "Kennwortänderung an erforderlich $0"
 ],
 "Require password change on first login": [
  null,
  "Passwortänderung bei der ersten Anmeldung verlangen"
 ],
 "Reset password": [
  null,
  "Passwort zurücksetzen"
 ],
 "Roles": [
  null,
  "Rollen"
 ],
 "Search for name, group or ID": [
  null,
  ""
 ],
 "Server administrator": [
  null,
  "Server administrator"
 ],
 "Set password": [
  null,
  "Passwort setzen"
 ],
 "Set weak password": [
  null,
  "Schwaches Passwort festlegen"
 ],
 "Started": [
  null,
  "Gestartet"
 ],
 "Terminate session": [
  null,
  "Sitzung beenden"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Das Konto '$0'wird gezwungen sein Passwort bei der nächsten Anmeldung zu ändern"
 ],
 "The full name must not contain colons.": [
  null,
  ""
 ],
 "The key you provided was not valid.": [
  null,
  "Der von Ihnen angegebene Schlüssel ist ungültig."
 ],
 "The passwords do not match": [
  null,
  "Die Passwörter stimmen nicht überein"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "Der Benutzer muss sich ab- und wieder anmelden, um die Rollen vollständig zu ändern."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Der Benutzername darf nur aus Buchstaben, Zahlen, Punkten, Binde- und Unterstrichen bestehen."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Für dieses Konto existieren keine autorisierten öffentlichen Schlüssel"
 ],
 "This group is the primary group for the following users:": [
  null,
  ""
 ],
 "This user name already exists": [
  null,
  "Dieser Benutzername existiert bereits"
 ],
 "Toggle date picker": [
  null,
  "Datumsauswahl umschalten"
 ],
 "Unexpected error": [
  null,
  "Unerwarteter Fehler"
 ],
 "Unix group: $0": [
  null,
  "Unix-Gruppe: $0"
 ],
 "Unnamed": [
  null,
  "Unbennant"
 ],
 "Use password": [
  null,
  "Passwort verwenden"
 ],
 "User name": [
  null,
  "Benutzername"
 ],
 "Username": [
  null,
  "Benutzername"
 ],
 "Validating key": [
  null,
  "Schlüssel wird überprüft"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Sie haben keine Berechtigung, die autorisierten öffentlichen Schlüssel von diesem Konto anzuzeigen."
 ],
 "You must wait longer to change your password": [
  null,
  "Sie müssen länger warten, um Ihr Passwort zu ändern"
 ],
 "Your account": [
  null,
  "Ihr Konto"
 ],
 "access": [
  null,
  "Zugriff"
 ],
 "edit": [
  null,
  "bearbeiten"
 ],
 "keys": [
  null,
  "Schlüssel"
 ],
 "login": [
  null,
  "Login"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "Passwort"
 ],
 "password quality": [
  null,
  "Passwortqualität"
 ],
 "roles": [
  null,
  "Rollen"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "Benutzer"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "Benutzername"
 ]
});
