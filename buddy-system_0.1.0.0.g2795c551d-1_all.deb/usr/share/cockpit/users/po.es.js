cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  "Número de usuarios"
 ],
 "$0 more...": [
  null,
  "$0 más..."
 ],
 "Account expiration": [
  null,
  "Expiración de la cuenta"
 ],
 "Account not available or cannot be edited.": [
  null,
  "La cuenta no está disponible o no se puede modificar."
 ],
 "Accounts": [
  null,
  "Cuentas"
 ],
 "Add": [
  null,
  "Añadir"
 ],
 "Add key": [
  null,
  "Añadir clave"
 ],
 "Add public key": [
  null,
  "Añadir clave pública"
 ],
 "Adding key": [
  null,
  "Añadiendo clave"
 ],
 "Authentication": [
  null,
  "Autenticación"
 ],
 "Authorized public SSH keys": [
  null,
  "Claves SSH públicas autorizadas"
 ],
 "Back to accounts": [
  null,
  "Volver a cuentas de usuario"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Change": [
  null,
  "Cambiar"
 ],
 "Close": [
  null,
  "Cerrar"
 ],
 "Confirm": [
  null,
  "Confirmar"
 ],
 "Confirm new password": [
  null,
  "Confirme la nueva contraseña"
 ],
 "Container administrator": [
  null,
  "Administrador de contenedores"
 ],
 "Create": [
  null,
  "Crear"
 ],
 "Create account with weak password": [
  null,
  "Crear la cuenta con la contraseña débil"
 ],
 "Create new account": [
  null,
  "Crear una cuenta"
 ],
 "Delete": [
  null,
  "Eliminar"
 ],
 "Delete $0": [
  null,
  "Eliminar $0"
 ],
 "Delete $0 group": [
  null,
  "Eliminar grupo $0"
 ],
 "Delete account": [
  null,
  "Eliminar cuenta"
 ],
 "Delete files": [
  null,
  "Borrar ficheros"
 ],
 "Delete group": [
  null,
  "Eliminar grupo"
 ],
 "Disallow interactive password": [
  null,
  "Denegar la autenticación interactiva con contraseña"
 ],
 "Disallow password authentication": [
  null,
  "Denegar autenticación por contraseña"
 ],
 "Edit user": [
  null,
  "Editar usuario"
 ],
 "Ended": [
  null,
  "Finalizado"
 ],
 "Error saving authorized keys: ": [
  null,
  "Error al guardar las llaves autorizadas: "
 ],
 "Excellent password": [
  null,
  "Contraseña excelente"
 ],
 "Expire account on": [
  null,
  "Expirar la cuenta en"
 ],
 "Expire account on $0": [
  null,
  "Expirar la cuenta en $0"
 ],
 "Failed to change password": [
  null,
  "Error al cambiar contraseña"
 ],
 "Failed to load authorized keys.": [
  null,
  "Fallo al cargar las claves autorizadas."
 ],
 "Force change": [
  null,
  "Forzar cambio"
 ],
 "Force delete": [
  null,
  "Forzar el borrado"
 ],
 "Force password change": [
  null,
  "Cambio forzado de la contraseña"
 ],
 "From": [
  null,
  "Desde"
 ],
 "Full name": [
  null,
  "Nombre completo"
 ],
 "Group": [
  null,
  "Grupo"
 ],
 "Group name": [
  null,
  "Nombre del grupo"
 ],
 "Groups": [
  null,
  "Grupos"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Image builder": [
  null,
  "Constructor de imágenes"
 ],
 "Invalid expiration date": [
  null,
  "Fecha de expiración invalida"
 ],
 "Invalid key": [
  null,
  "Llave inválida"
 ],
 "Invalid number of days": [
  null,
  "Numero de días incorrecto"
 ],
 "Last active": [
  null,
  "Última vez activo"
 ],
 "Last login": [
  null,
  "Último inicio de sesión"
 ],
 "Learn more": [
  null,
  "Aprenda más"
 ],
 "Local accounts": [
  null,
  "Cuentas locales"
 ],
 "Lock": [
  null,
  "Bloquear"
 ],
 "Lock $0": [
  null,
  "Bloquear a $0"
 ],
 "Lock account": [
  null,
  "Bloquear cuenta"
 ],
 "Log out": [
  null,
  "Salir"
 ],
 "Log user out": [
  null,
  "Finalizar sesión del usuario"
 ],
 "Logged in": [
  null,
  "Sesión iniciada"
 ],
 "Login history": [
  null,
  "Historial de inicios de sesión"
 ],
 "Login history list": [
  null,
  "Lista del historial de inicios de sesión"
 ],
 "Logout $0": [
  null,
  "Finalizar sesión de $0"
 ],
 "Managing user accounts": [
  null,
  "Gestión de cuentas de usuario"
 ],
 "Never": [
  null,
  "Nunca"
 ],
 "Never expire account": [
  null,
  "La cuenta nunca expira"
 ],
 "Never expire password": [
  null,
  "La clave nunca expira"
 ],
 "Never logged in": [
  null,
  "Nunca ha iniciado sesión"
 ],
 "New password": [
  null,
  "Nueva contraseña"
 ],
 "New password was not accepted": [
  null,
  "No se aceptó la nueva contraseña"
 ],
 "No matching results": [
  null,
  "No se encontraron resultados"
 ],
 "No real name specified": [
  null,
  "No hay un nombre real especificado"
 ],
 "No user name specified": [
  null,
  "Nombre de usuario no especificado"
 ],
 "Ok": [
  null,
  "Aceptar"
 ],
 "Old password": [
  null,
  "Contraseña vieja"
 ],
 "Old password not accepted": [
  null,
  "No se aceptó la contraseña vieja"
 ],
 "Options": [
  null,
  "Opciones"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Hay otros métodos de autenticación disponibles incluso cuando se deshabilita la autenticación interactiva con contraseña."
 ],
 "Password": [
  null,
  "Contraseña"
 ],
 "Password expiration": [
  null,
  "Expiración de la contraseña"
 ],
 "Password is longer than 256 characters": [
  null,
  "La contraseña no puede superar los 256 caracteres"
 ],
 "Password is not acceptable": [
  null,
  "La contraseña no es válida"
 ],
 "Password is too weak": [
  null,
  "La contraseña es muy débil"
 ],
 "Password must be changed": [
  null,
  "Se debe cambiar la contraseña"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Pegue aquí el contenido de su clave SSH pública"
 ],
 "Pick date": [
  null,
  "Selecciona una fecha"
 ],
 "Please specify an expiration date": [
  null,
  "Por favor especifique una fecha de expiración"
 ],
 "Prompting via passwd timed out": [
  null,
  "Se ha agotado el tiempo de espera para passwd"
 ],
 "Remove": [
  null,
  "Eliminar"
 ],
 "Require password change every $0 days": [
  null,
  "Hay que cambiar la contraseña cada $0 días"
 ],
 "Require password change on $0": [
  null,
  "Hay que cambiar la contraseña en $0"
 ],
 "Require password change on first login": [
  null,
  "Requerir cambiar la contraseña en el primer inicio de sesión"
 ],
 "Reset password": [
  null,
  "Restablecer contraseña"
 ],
 "Roles": [
  null,
  "Roles"
 ],
 "Search for name, group or ID": [
  null,
  "Buscar por nombre, grupo o ID"
 ],
 "Server administrator": [
  null,
  "Administrador del servidor"
 ],
 "Set password": [
  null,
  "Establecer contraseña"
 ],
 "Set weak password": [
  null,
  "Establecer contraseña débil"
 ],
 "Started": [
  null,
  "Iniciado"
 ],
 "Terminate session": [
  null,
  "Cerrar sesión"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Se forzará a la cuenta '$0' para que cambie su contraseña en el próximo acceso"
 ],
 "The full name must not contain colons.": [
  null,
  "El nombre completo no debe contener dos puntos."
 ],
 "The key you provided was not valid.": [
  null,
  "La clave introducida no resultó válida."
 ],
 "The passwords do not match": [
  null,
  "Las contraseñas no coinciden"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "El usuario debe cerrar sesión y volverla a iniciar para cambiar completamente los roles."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "El nombre de usuario sólo puede contener letras (a-z), dígitos, puntos, guiones y guiones bajos."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "No hay claves públicas autorizadas para esta cuenta."
 ],
 "This group is the primary group for the following users:": [
  null,
  "Este grupo es el grupo primario para los siguientes usuarios:"
 ],
 "This user name already exists": [
  null,
  "El nombre del usuario ya existe"
 ],
 "Toggle date picker": [
  null,
  "Alternar el selector de fecha"
 ],
 "Unexpected error": [
  null,
  "Error inesperado"
 ],
 "Unix group: $0": [
  null,
  "Grupo Unix: $0"
 ],
 "Unnamed": [
  null,
  "Sin nombre"
 ],
 "Use password": [
  null,
  "Usar contraseña"
 ],
 "User name": [
  null,
  "Nombre de usuario"
 ],
 "Username": [
  null,
  "Nombre de usuario"
 ],
 "Validating key": [
  null,
  "Validando clave"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "No tiene permiso para ver las claves públicas autorizadas para esta cuenta."
 ],
 "You must wait longer to change your password": [
  null,
  "Debe esperar más tiempo para cambiar su contraseña"
 ],
 "Your account": [
  null,
  "Su cuenta"
 ],
 "access": [
  null,
  "acceso"
 ],
 "edit": [
  null,
  "editar"
 ],
 "keys": [
  null,
  "teclas"
 ],
 "login": [
  null,
  "login"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "contraseña"
 ],
 "password quality": [
  null,
  "calidad de la contraseña"
 ],
 "roles": [
  null,
  "roles"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "usuario"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "nombre de usuario"
 ]
});
