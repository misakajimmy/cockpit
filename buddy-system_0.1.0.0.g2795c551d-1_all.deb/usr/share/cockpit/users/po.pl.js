cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  "Liczba użytkowników"
 ],
 "$0 more...": [
  null,
  "$0 więcej…"
 ],
 "Account expiration": [
  null,
  "Wygasanie konta"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Konto jest niedostępne lub nie może być modyfikowane."
 ],
 "Accounts": [
  null,
  "Konta"
 ],
 "Add": [
  null,
  "Dodaj"
 ],
 "Add key": [
  null,
  "Dodaj klucz"
 ],
 "Add public key": [
  null,
  "Dodaj klucz publiczny"
 ],
 "Adding key": [
  null,
  "Dodawanie klucza"
 ],
 "Authentication": [
  null,
  "Uwierzytelnienie"
 ],
 "Authorized public SSH keys": [
  null,
  "Upoważnione publiczne klucze SSH"
 ],
 "Back to accounts": [
  null,
  "Wróć do kont"
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Change": [
  null,
  "Zmień"
 ],
 "Close": [
  null,
  "Zamknij"
 ],
 "Confirm": [
  null,
  "Potwierdź"
 ],
 "Confirm new password": [
  null,
  "Potwierdź nowe hasło"
 ],
 "Container administrator": [
  null,
  "Administrator kontenera"
 ],
 "Create": [
  null,
  "Utwórz"
 ],
 "Create account with weak password": [
  null,
  "Utwórz konto ze słabym hasłem"
 ],
 "Create new account": [
  null,
  "Utwórz nowe konto"
 ],
 "Delete": [
  null,
  "Usuń"
 ],
 "Delete $0": [
  null,
  "Usuń $0"
 ],
 "Delete $0 group": [
  null,
  "Usuń grupę $0"
 ],
 "Delete account": [
  null,
  "Usuń konto"
 ],
 "Delete files": [
  null,
  "Usuń pliki"
 ],
 "Delete group": [
  null,
  "Usuń grupę"
 ],
 "Disallow interactive password": [
  null,
  "Bez zezwolenia na interaktywne hasło"
 ],
 "Disallow password authentication": [
  null,
  "Bez zezwolenia na uwierzytelnianie hasłem"
 ],
 "Edit user": [
  null,
  "Modyfikuj użytkownika"
 ],
 "Ended": [
  null,
  "Zakończono"
 ],
 "Error saving authorized keys: ": [
  null,
  "Błąd podczas zapisywania upoważnionych kluczy: "
 ],
 "Excellent password": [
  null,
  "Doskonałe hasło"
 ],
 "Expire account on": [
  null,
  "Wygaś konto w dniu"
 ],
 "Expire account on $0": [
  null,
  "Wygaś konto w dniu $0"
 ],
 "Failed to change password": [
  null,
  "Zmiana hasła się nie powiodła"
 ],
 "Failed to load authorized keys.": [
  null,
  "Wczytanie upoważnionych kluczy się nie powiodło."
 ],
 "Force change": [
  null,
  "Wymuś zmianę"
 ],
 "Force delete": [
  null,
  "Wymuś usunięcie"
 ],
 "Force password change": [
  null,
  "Wymuszenie zmiany hasła"
 ],
 "From": [
  null,
  "Od"
 ],
 "Full name": [
  null,
  "Imię i nazwisko"
 ],
 "Group": [
  null,
  "Grupa"
 ],
 "Group name": [
  null,
  "Nazwa grupy"
 ],
 "Groups": [
  null,
  "Grupy"
 ],
 "ID": [
  null,
  "Identyfikator"
 ],
 "Image builder": [
  null,
  "Budowanie obrazu"
 ],
 "Invalid expiration date": [
  null,
  "Nieprawidłowa data wygaśnięcia"
 ],
 "Invalid key": [
  null,
  "Nieprawidłowy klucz"
 ],
 "Invalid number of days": [
  null,
  "Nieprawidłowa liczba dni"
 ],
 "Last active": [
  null,
  "Ostatnia aktywność"
 ],
 "Last login": [
  null,
  "Ostatnie logowanie"
 ],
 "Learn more": [
  null,
  "Więcej informacji"
 ],
 "Local accounts": [
  null,
  "Lokalne konta"
 ],
 "Lock": [
  null,
  "Zablokuj"
 ],
 "Lock $0": [
  null,
  "Zablokuj „$0”"
 ],
 "Lock account": [
  null,
  "Zablokuj konto"
 ],
 "Log out": [
  null,
  "Wyloguj"
 ],
 "Log user out": [
  null,
  "Wyloguj użytkownika"
 ],
 "Logged in": [
  null,
  "Zalogowano"
 ],
 "Login history": [
  null,
  "Historia logowania"
 ],
 "Login history list": [
  null,
  "Lista historii logowania"
 ],
 "Logout $0": [
  null,
  "Wyloguj użytkownika „$0”"
 ],
 "Managing user accounts": [
  null,
  "Zarządzanie kontami użytkowników"
 ],
 "Never": [
  null,
  "Nigdy"
 ],
 "Never expire account": [
  null,
  "Bez wygasania konta"
 ],
 "Never expire password": [
  null,
  "Bez wygasania hasła"
 ],
 "Never logged in": [
  null,
  "Nigdy nie zalogowano"
 ],
 "New password": [
  null,
  "Nowe hasło"
 ],
 "New password was not accepted": [
  null,
  "Nie przyjęto nowego hasła"
 ],
 "No matching results": [
  null,
  "Brak wyników"
 ],
 "No real name specified": [
  null,
  "Nie podano nazwy obszaru"
 ],
 "No user name specified": [
  null,
  "Nie podano nazwy użytkownika"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password": [
  null,
  "Poprzednie hasło"
 ],
 "Old password not accepted": [
  null,
  "Nie przyjęto poprzedniego hasła"
 ],
 "Options": [
  null,
  "Opcje"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Inne metody uwierzytelniania są nadal dostępne, nawet kiedy uwierzytelnianie interaktywnym hasłem nie jest dozwolone."
 ],
 "Password": [
  null,
  "Hasło"
 ],
 "Password expiration": [
  null,
  "Wygasanie hasła"
 ],
 "Password is longer than 256 characters": [
  null,
  "Hasło jest dłuższe niż 256 znaków"
 ],
 "Password is not acceptable": [
  null,
  "Hasło jest do przyjęcia"
 ],
 "Password is too weak": [
  null,
  "Hasło jest za słabe"
 ],
 "Password must be changed": [
  null,
  "Należy zmienić hasło"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Proszę tutaj wkleić zawartość pliku publicznego klucza SSH"
 ],
 "Pick date": [
  null,
  "Wybierz datę"
 ],
 "Please specify an expiration date": [
  null,
  "Proszę podać datę wygaśnięcia"
 ],
 "Prompting via passwd timed out": [
  null,
  "Pytanie przez passwd przekroczyło czas oczekiwania"
 ],
 "Remove": [
  null,
  "Usuń"
 ],
 "Require password change every $0 days": [
  null,
  "Wymaganie zmiany hasła co $0 dni"
 ],
 "Require password change on $0": [
  null,
  "Wymaganie zmiany hasła w dniu $0"
 ],
 "Require password change on first login": [
  null,
  "Wymaganie zmiany hasła po pierwszym zalogowaniu"
 ],
 "Reset password": [
  null,
  "Przywróć hasło"
 ],
 "Roles": [
  null,
  "Role"
 ],
 "Search for name, group or ID": [
  null,
  "Wyszukiwanie nazwy, grupy lub identyfikatora"
 ],
 "Server administrator": [
  null,
  "Administrator serwera"
 ],
 "Set password": [
  null,
  "Ustaw hasło"
 ],
 "Set weak password": [
  null,
  "Ustaw słabe hasło"
 ],
 "Started": [
  null,
  "Rozpoczęto"
 ],
 "Terminate session": [
  null,
  "Zakończ sesję"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Konto „$0” będzie zmuszone do zmiany hasła podczas następnego logowania"
 ],
 "The full name must not contain colons.": [
  null,
  "Imię i nazwisko nie może zawierać dwukropków."
 ],
 "The key you provided was not valid.": [
  null,
  "Podany klucz jest nieprawidłowy."
 ],
 "The passwords do not match": [
  null,
  "Hasła się nie zgadzają"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "Użytkownik musi zostać wylogowany i zalogowany z powrotem, aby w pełni zmienić role."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Nazwa użytkownika może składać się tylko z liter od A do Z, cyfr, kropek, myślników i podkreślników."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Brak upoważnionych publicznych kluczy dla tego konta."
 ],
 "This group is the primary group for the following users:": [
  null,
  "Ta grupa jest główną grupą dla tych użytkowników:"
 ],
 "This user name already exists": [
  null,
  "Ta nazwa użytkownika już istnieje"
 ],
 "Toggle date picker": [
  null,
  "Przełącz wybór daty"
 ],
 "Unexpected error": [
  null,
  "Nieoczekiwany błąd"
 ],
 "Unix group: $0": [
  null,
  "Grupa uniksowa: $0"
 ],
 "Unnamed": [
  null,
  "Bez nazwy"
 ],
 "Use password": [
  null,
  "Użycie hasła"
 ],
 "User name": [
  null,
  "Nazwa użytkownika"
 ],
 "Username": [
  null,
  "Nazwa użytkownika"
 ],
 "Validating key": [
  null,
  "Sprawdzanie poprawności klucza"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Brak uprawnienia do wyświetlania upoważnionych publicznych kluczy dla tego konta."
 ],
 "You must wait longer to change your password": [
  null,
  "Należy poczekać dłużej na zmianę hasła"
 ],
 "Your account": [
  null,
  "Twoje konto"
 ],
 "access": [
  null,
  "dostęp"
 ],
 "edit": [
  null,
  "modyfikuj"
 ],
 "keys": [
  null,
  "klucze"
 ],
 "login": [
  null,
  "logowanie"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "hasło"
 ],
 "password quality": [
  null,
  "jakość hasła"
 ],
 "roles": [
  null,
  "role"
 ],
 "ssh": [
  null,
  "SSH"
 ],
 "user": [
  null,
  "użytkownik"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "nazwa użytkownika"
 ]
});
