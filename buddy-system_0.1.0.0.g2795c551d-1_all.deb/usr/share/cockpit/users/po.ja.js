cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  ""
 ],
 "Account expiration": [
  null,
  "アカウントの有効期限"
 ],
 "Account not available or cannot be edited.": [
  null,
  "アカウントが利用可能でないか、アカウントを編集できません。"
 ],
 "Accounts": [
  null,
  "アカウント"
 ],
 "Add": [
  null,
  "追加する"
 ],
 "Add key": [
  null,
  "キーを追加する"
 ],
 "Add public key": [
  null,
  "公開鍵の追加"
 ],
 "Adding key": [
  null,
  "キーの追加"
 ],
 "Authentication": [
  null,
  "認証"
 ],
 "Authorized public SSH keys": [
  null,
  "承認された公開 SSH 鍵"
 ],
 "Back to accounts": [
  null,
  "アカウントに戻る"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Change": [
  null,
  "変更"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Confirm": [
  null,
  "確定します"
 ],
 "Confirm new password": [
  null,
  "新規パスワードの確認"
 ],
 "Container administrator": [
  null,
  "コンテナー管理者"
 ],
 "Create": [
  null,
  "作成"
 ],
 "Create account with weak password": [
  null,
  "脆弱なパスワードを使用したアカウントの作成"
 ],
 "Create new account": [
  null,
  "アカウントの新規作成"
 ],
 "Delete": [
  null,
  "削除"
 ],
 "Delete $0": [
  null,
  "$0 の削除"
 ],
 "Delete files": [
  null,
  "ファイルの削除"
 ],
 "Disallow interactive password": [
  null,
  "対話式パスワードを禁止する"
 ],
 "Disallow password authentication": [
  null,
  "パスワード認証を禁止する"
 ],
 "Ended": [
  null,
  "終了"
 ],
 "Error saving authorized keys: ": [
  null,
  "承認された鍵の保存中にエラーが発生しました: "
 ],
 "Excellent password": [
  null,
  "優れたパスワード"
 ],
 "Expire account on": [
  null,
  "アカウントの有効期限:"
 ],
 "Expire account on $0": [
  null,
  "アカウントの有効期限: $0"
 ],
 "Failed to change password": [
  null,
  "パスワードの変更に失敗しました"
 ],
 "Failed to load authorized keys.": [
  null,
  "承認された鍵のロードに失敗しました。"
 ],
 "Force change": [
  null,
  "変更の強制"
 ],
 "Force delete": [
  null,
  "削除の強制"
 ],
 "Force password change": [
  null,
  "パスワード変更の強制"
 ],
 "From": [
  null,
  "以下から"
 ],
 "Full name": [
  null,
  "フルネーム"
 ],
 "Group": [
  null,
  "グループ"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Image builder": [
  null,
  "イメージビルダー"
 ],
 "Invalid expiration date": [
  null,
  "無効な有効期限"
 ],
 "Invalid key": [
  null,
  "無効な鍵"
 ],
 "Invalid number of days": [
  null,
  "無効な日数"
 ],
 "Last login": [
  null,
  "最終ログイン"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "Local accounts": [
  null,
  "ローカルアカウント"
 ],
 "Lock": [
  null,
  "ロック"
 ],
 "Lock account": [
  null,
  "アカウントのロック"
 ],
 "Log out": [
  null,
  "ログアウト"
 ],
 "Logged in": [
  null,
  "すでにログインしています"
 ],
 "Login history": [
  null,
  "ログイン履歴"
 ],
 "Login history list": [
  null,
  "ログイン履歴の一覧"
 ],
 "Managing user accounts": [
  null,
  "ユーザーアカウント管理"
 ],
 "Never": [
  null,
  "しない"
 ],
 "Never expire account": [
  null,
  "アカウントを失効しない"
 ],
 "Never expire password": [
  null,
  "パスワードを失効しない"
 ],
 "New password": [
  null,
  "新規パスワード"
 ],
 "New password was not accepted": [
  null,
  "新規パスワードは受け入れられませんでした"
 ],
 "No matching results": [
  null,
  "一致する結果はありません"
 ],
 "No real name specified": [
  null,
  "実際の名前が指定されていません"
 ],
 "No user name specified": [
  null,
  "ユーザー名が指定されていません"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old password": [
  null,
  "古いパスワード"
 ],
 "Old password not accepted": [
  null,
  "古いパスワードは受け入れられません"
 ],
 "Options": [
  null,
  "オプション"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "対話式パスワード認証が許可されない場合でも、他の認証方法を利用できます。"
 ],
 "Password": [
  null,
  "パスワード"
 ],
 "Password expiration": [
  null,
  "パスワードの有効期限"
 ],
 "Password is longer than 256 characters": [
  null,
  "パスワードは 256 文字以内で設定する必要があります"
 ],
 "Password is not acceptable": [
  null,
  "パスワードは受け入れられません"
 ],
 "Password is too weak": [
  null,
  "パスワードが弱すぎます"
 ],
 "Password must be changed": [
  null,
  "パスワードを変更する必要があります"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "公開 SSH 鍵ファイルの内容をここに貼り付けます"
 ],
 "Pick date": [
  null,
  "日付けの選択"
 ],
 "Please specify an expiration date": [
  null,
  "有効期限を指定してください"
 ],
 "Prompting via passwd timed out": [
  null,
  "passwd によるプロンプトがタイムアウトしました"
 ],
 "Remove": [
  null,
  "削除"
 ],
 "Require password change every $0 days": [
  null,
  "$0 日ごとのパスワードの変更が必要"
 ],
 "Require password change on $0": [
  null,
  "$0 でパスワードの変更が必要"
 ],
 "Require password change on first login": [
  null,
  "初回ログイン時にパスワードの変更が必要"
 ],
 "Reset password": [
  null,
  "パスワードのリセット"
 ],
 "Roles": [
  null,
  "ロール"
 ],
 "Search for name, group or ID": [
  null,
  ""
 ],
 "Server administrator": [
  null,
  "サーバー管理者"
 ],
 "Set password": [
  null,
  "パスワードの設定"
 ],
 "Set weak password": [
  null,
  "脆弱なパスワードの設定"
 ],
 "Started": [
  null,
  "開始済み"
 ],
 "Terminate session": [
  null,
  "セッションの終了"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "アカウント '$0' が次回ログインする際に、パスワードの変更が求められます"
 ],
 "The full name must not contain colons.": [
  null,
  ""
 ],
 "The key you provided was not valid.": [
  null,
  "提供した鍵が有効ではありません。"
 ],
 "The passwords do not match": [
  null,
  "パスワードが一致しません"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "ロールを完全に変更するには、ユーザーはログアウトしてからログインし直す必要があります。"
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "ユーザー名は a〜z の文字、数字、ドット、ダッシュ、およびアンダースコアだけで構成されます。"
 ],
 "There are no authorized public keys for this account.": [
  null,
  "このアカウントに承認された公開鍵がありません。"
 ],
 "This group is the primary group for the following users:": [
  null,
  ""
 ],
 "This user name already exists": [
  null,
  "このユーザー名はすでに存在します"
 ],
 "Toggle date picker": [
  null,
  "日付選択の切り替え"
 ],
 "Unexpected error": [
  null,
  "予期しないエラー"
 ],
 "Unix group: $0": [
  null,
  "Unixグループ: $0"
 ],
 "Unnamed": [
  null,
  "名前なし"
 ],
 "Use password": [
  null,
  "ユーザーパスワード"
 ],
 "User name": [
  null,
  "ユーザー名"
 ],
 "Username": [
  null,
  "ユーザー名"
 ],
 "Validating key": [
  null,
  "鍵の検証"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "このアカウントに承認された公開鍵を表示するパーミッションがありません。"
 ],
 "You must wait longer to change your password": [
  null,
  "パスワードを変更するにはより長い時間の経過が必要です"
 ],
 "Your account": [
  null,
  "お使いのアカウント"
 ],
 "access": [
  null,
  "アクセス"
 ],
 "edit": [
  null,
  "編集"
 ],
 "keys": [
  null,
  "鍵"
 ],
 "login": [
  null,
  "ログイン"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "パスワード"
 ],
 "password quality": [
  null,
  "パスワードの強度"
 ],
 "roles": [
  null,
  "ロール"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "ユーザー"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "ユーザー名"
 ]
});
