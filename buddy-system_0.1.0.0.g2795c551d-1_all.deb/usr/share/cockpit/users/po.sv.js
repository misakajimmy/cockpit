cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "# of users": [
  null,
  ""
 ],
 "Account expiration": [
  null,
  "Utgång av konto"
 ],
 "Account not available or cannot be edited.": [
  null,
  "Kontot är inte tillgängligt eller kan inte redigeras."
 ],
 "Accounts": [
  null,
  "Konton"
 ],
 "Add": [
  null,
  "Lägg till"
 ],
 "Add key": [
  null,
  "Lägg till nyckel"
 ],
 "Add public key": [
  null,
  "Lägg till publik nyckel"
 ],
 "Adding key": [
  null,
  "Lägger till nyckel"
 ],
 "Authentication": [
  null,
  "Autentisering"
 ],
 "Authorized public SSH keys": [
  null,
  "Auktoriserade publika SSH-nycklar"
 ],
 "Back to accounts": [
  null,
  "Tilllbaka till konton"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Change": [
  null,
  "Ändra"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Confirm": [
  null,
  "Bekräfta"
 ],
 "Confirm new password": [
  null,
  "Bekräfta nytt lösenord"
 ],
 "Container administrator": [
  null,
  "Behållaradministratör"
 ],
 "Create": [
  null,
  "Skapa"
 ],
 "Create account with weak password": [
  null,
  "Skapa konto med svagt lösenord"
 ],
 "Create new account": [
  null,
  "Skapa ett nytt konto"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Delete $0": [
  null,
  "Ta bort $0"
 ],
 "Delete files": [
  null,
  "Ta bort filer"
 ],
 "Disallow interactive password": [
  null,
  "Tillåt inte interaktivt lösenord"
 ],
 "Disallow password authentication": [
  null,
  "Tillåt inte lösenordsautentisering"
 ],
 "Ended": [
  null,
  "Slutade"
 ],
 "Error saving authorized keys: ": [
  null,
  "Fel när auktoriserade nycklar sparades: "
 ],
 "Excellent password": [
  null,
  "Utmärkt lösenord"
 ],
 "Expire account on": [
  null,
  "Upphör konto på"
 ],
 "Expire account on $0": [
  null,
  "Upphör konto på $0"
 ],
 "Failed to change password": [
  null,
  "Misslyckades att ändra lösenord"
 ],
 "Failed to load authorized keys.": [
  null,
  "Misslyckades att läsa in auktoriserade nycklar."
 ],
 "Force change": [
  null,
  "Framtvinga ändring"
 ],
 "Force delete": [
  null,
  "Framtvinga borttagande"
 ],
 "Force password change": [
  null,
  "Framtvinga lösenordsändring"
 ],
 "From": [
  null,
  "Från"
 ],
 "Full name": [
  null,
  "Fullständigt namn"
 ],
 "Group": [
  null,
  "Grupp"
 ],
 "ID": [
  null,
  "ID"
 ],
 "Image builder": [
  null,
  "Avbildsbyggare"
 ],
 "Invalid expiration date": [
  null,
  "Felaktigt utgångsdatum"
 ],
 "Invalid key": [
  null,
  "Felaktig nyckel"
 ],
 "Invalid number of days": [
  null,
  "Felaktigt antal dagar"
 ],
 "Last login": [
  null,
  "Senaste inloggning"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "Local accounts": [
  null,
  "Lokala konton"
 ],
 "Lock": [
  null,
  "Lås"
 ],
 "Lock account": [
  null,
  "Lås kontot"
 ],
 "Log out": [
  null,
  "Logga ut"
 ],
 "Logged in": [
  null,
  "Inloggad"
 ],
 "Login history": [
  null,
  "Inloggningshistorik"
 ],
 "Login history list": [
  null,
  "Inloggningshistorielista"
 ],
 "Managing user accounts": [
  null,
  "Hantera användarkonton"
 ],
 "Never": [
  null,
  "Aldrig"
 ],
 "Never expire account": [
  null,
  "Upphör aldrig konto"
 ],
 "Never expire password": [
  null,
  "Låt aldrig lösenord gå ut"
 ],
 "New password": [
  null,
  "Nytt lösenord"
 ],
 "New password was not accepted": [
  null,
  "Det nya lösenordet godtogs inte"
 ],
 "No matching results": [
  null,
  "Inga matchande resultat"
 ],
 "No real name specified": [
  null,
  "Inget verkligt namn angivet"
 ],
 "No user name specified": [
  null,
  "Inget användarnamn angivet"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old password": [
  null,
  "Gammalt lösenord"
 ],
 "Old password not accepted": [
  null,
  "Det gamla lösenordet accepterades inte"
 ],
 "Options": [
  null,
  "Alternativ"
 ],
 "Other authentication methods are still available even when interactive password authentication is not allowed.": [
  null,
  "Andra autentiseringsmetoder är fortfarande tillgängliga även när interaktiv lösenordsautentisering inte är tillåten."
 ],
 "Password": [
  null,
  "Lösenord"
 ],
 "Password expiration": [
  null,
  "Utgång av lösenord"
 ],
 "Password is longer than 256 characters": [
  null,
  "Lösenord får inte vara längre än 256 tecken"
 ],
 "Password is not acceptable": [
  null,
  "Lösenordet är inte godtagbart"
 ],
 "Password is too weak": [
  null,
  "Lösenordet är för svagt"
 ],
 "Password must be changed": [
  null,
  "Lösenordet måste ändras"
 ],
 "Paste the contents of your public SSH key file here": [
  null,
  "Klistra in innehållet i din publika SSH-nyckelfil här"
 ],
 "Pick date": [
  null,
  "Välj datum"
 ],
 "Please specify an expiration date": [
  null,
  "Ange ett utgångsdatum"
 ],
 "Prompting via passwd timed out": [
  null,
  "Tidsgränsen överskreds vid fråga via passwd"
 ],
 "Remove": [
  null,
  "Ta bort"
 ],
 "Require password change every $0 days": [
  null,
  "Begär en lösenordsändring var $0:e dag"
 ],
 "Require password change on $0": [
  null,
  "Begär lösenordsändring den $0"
 ],
 "Require password change on first login": [
  null,
  "Begär lösenordsändring vid första inloggningen"
 ],
 "Reset password": [
  null,
  "Återställ lösenord"
 ],
 "Roles": [
  null,
  "Roller"
 ],
 "Search for name, group or ID": [
  null,
  ""
 ],
 "Server administrator": [
  null,
  "Serveradministratör"
 ],
 "Set password": [
  null,
  "Sätt lösenord"
 ],
 "Set weak password": [
  null,
  "Ställ in ett svagt lösenord"
 ],
 "Started": [
  null,
  "Startad"
 ],
 "Terminate session": [
  null,
  "Avsluta sessionen"
 ],
 "The account '$0' will be forced to change their password on next login": [
  null,
  "Kontot ”$0” kommer att tvingas ändra sitt lösenord vid nästa inloggning"
 ],
 "The full name must not contain colons.": [
  null,
  ""
 ],
 "The key you provided was not valid.": [
  null,
  "Nyckeln du angav var inte giltig."
 ],
 "The passwords do not match": [
  null,
  "Lösenorden stämmer inte överens"
 ],
 "The user must log out and log back in to fully change roles.": [
  null,
  "Användaren måste logga ut och logga in igen för att helt byta roller."
 ],
 "The user name can only consist of letters from a-z, digits, dots, dashes and underscores.": [
  null,
  "Användarnamnet får endast bestå av bokstäver från a-z, siffror, punkter, bindestreck och understreck."
 ],
 "There are no authorized public keys for this account.": [
  null,
  "Det finns inga auktoriserade publika nycklar för detta konto."
 ],
 "This group is the primary group for the following users:": [
  null,
  ""
 ],
 "This user name already exists": [
  null,
  "Detta användarnamn finns redan"
 ],
 "Toggle date picker": [
  null,
  "Växla datumväljare"
 ],
 "Unexpected error": [
  null,
  "Oväntat fel"
 ],
 "Unix group: $0": [
  null,
  "Unix grupp: $0"
 ],
 "Unnamed": [
  null,
  "Namnlös"
 ],
 "Use password": [
  null,
  "Använd lösenord"
 ],
 "User name": [
  null,
  "Användarnamn"
 ],
 "Username": [
  null,
  "Användarnamn"
 ],
 "Validating key": [
  null,
  "Validerar nyckeln"
 ],
 "You do not have permission to view the authorized public keys for this account.": [
  null,
  "Du har inte rättigheter att se de auktoriserade publika nycklarna för detta konto."
 ],
 "You must wait longer to change your password": [
  null,
  "Du måste vänta längre på att ändra ditt lösenord"
 ],
 "Your account": [
  null,
  "Ditt konto"
 ],
 "access": [
  null,
  "åtkomst"
 ],
 "edit": [
  null,
  "redigera"
 ],
 "keys": [
  null,
  "nycklar"
 ],
 "login": [
  null,
  "login"
 ],
 "passwd": [
  null,
  "passwd"
 ],
 "password": [
  null,
  "lösenord"
 ],
 "password quality": [
  null,
  "lösenordskvalitet"
 ],
 "roles": [
  null,
  "roller"
 ],
 "ssh": [
  null,
  "ssh"
 ],
 "user": [
  null,
  "användare"
 ],
 "useradd": [
  null,
  "useradd"
 ],
 "username": [
  null,
  "användarnamn"
 ]
});
