cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "Administrative access is required to create and access reports.": [
  null,
  ""
 ],
 "Attributes": [
  null,
  ""
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Close": [
  null,
  "關閉"
 ],
 "Created": [
  null,
  "已建立"
 ],
 "Delete": [
  null,
  "刪除"
 ],
 "Delete report permanently?": [
  null,
  ""
 ],
 "Diagnostic reports": [
  null,
  "診斷報告"
 ],
 "Download": [
  null,
  "下載"
 ],
 "Error": [
  null,
  "錯誤"
 ],
 "Limit access": [
  null,
  ""
 ],
 "Limited access": [
  null,
  ""
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  ""
 ],
 "Method": [
  null,
  ""
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  ""
 ],
 "Obfuscated": [
  null,
  ""
 ],
 "Options": [
  null,
  "選項"
 ],
 "Password": [
  null,
  "密碼"
 ],
 "Please authenticate to gain administrative access": [
  null,
  ""
 ],
 "Progress: $0": [
  null,
  ""
 ],
 "Report": [
  null,
  "回報"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  ""
 ],
 "Turn on administrative access": [
  null,
  ""
 ],
 "You now have administrative access.": [
  null,
  ""
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  ""
 ],
 "show less": [
  null,
  "顯示較少"
 ],
 "show more": [
  null,
  "顯示更多"
 ],
 "sos": [
  null,
  ""
 ]
});
