cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Accès administrateur"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "Un accès administratif est nécessaire pour créer et accéder aux rapports."
 ],
 "Administrative access required": [
  null,
  "Accès administratif requis"
 ],
 "Attributes": [
  null,
  "Attributs"
 ],
 "Authenticate": [
  null,
  "S’authentifier"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Created": [
  null,
  "Créé"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Delete report permanently?": [
  null,
  "Supprimer définitivement le rapport ?"
 ],
 "Diagnostic reports": [
  null,
  "Rapports de diagnostic"
 ],
 "Download": [
  null,
  "Télécharger"
 ],
 "Encrypted": [
  null,
  "Chiffré"
 ],
 "Encryption passphrase": [
  null,
  "Phrase de chiffrement"
 ],
 "Error": [
  null,
  "Erreur"
 ],
 "Leave empty to skip encryption": [
  null,
  "Laissez vide pour ignorer le cryptage"
 ],
 "Limit access": [
  null,
  "Limiter l’accès"
 ],
 "Limited access": [
  null,
  "Accès limité"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Le mode accès limité restreint les privilèges d’administration. Certaines parties de la console web auront des fonctionnalités réduites."
 ],
 "Method": [
  null,
  "Méthode"
 ],
 "No system reports.": [
  null,
  "Aucun rapport sur le système."
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "Obscurcir les adresses réseau, les noms d'hôtes et les noms d'utilisateurs"
 ],
 "Obfuscated": [
  null,
  "Rendu obscure"
 ],
 "Options": [
  null,
  "Options"
 ],
 "Password": [
  null,
  "Mot de passe"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Veuillez vous authentifier pour obtenir un accès administrateur"
 ],
 "Problem becoming administrator": [
  null,
  "Problème pour devenir administrateur"
 ],
 "Progress: $0": [
  null,
  "Progrès : $0"
 ],
 "Report": [
  null,
  "Signaler"
 ],
 "Report label": [
  null,
  "Étiquette de rapport"
 ],
 "Reports": [
  null,
  "Rapports"
 ],
 "Run new report": [
  null,
  "Exécuter un nouveau rapport"
 ],
 "Run report": [
  null,
  "Exécuter le rapport"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "Le rapport SOS recueille des informations sur le système afin de faciliter le diagnostic des problèmes."
 ],
 "Stop report": [
  null,
  "Arrêter le rapport"
 ],
 "Switch to administrative access": [
  null,
  "Passer à l’accès administrateur"
 ],
 "Switch to limited access": [
  null,
  "Passer en accès limité"
 ],
 "System diagnostics": [
  null,
  "Diagnostics du système"
 ],
 "The file $0 will be deleted.": [
  null,
  "Le fichier $0 sera supprimé."
 ],
 "This information is stored only on the system.": [
  null,
  "Ces informations sont stockées uniquement sur le système."
 ],
 "Turn on administrative access": [
  null,
  "Activez l’accès administrateur"
 ],
 "Use verbose logging": [
  null,
  "Utiliser la journalisation verbeuse"
 ],
 "You now have administrative access.": [
  null,
  "Vous avez l’accès administrateur."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Votre navigateur se souviendra de votre niveau d’accès d’une session à l’autre."
 ],
 "show less": [
  null,
  "montrer moins"
 ],
 "show more": [
  null,
  "montrer plus"
 ],
 "sos": [
  null,
  "sos"
 ]
});
