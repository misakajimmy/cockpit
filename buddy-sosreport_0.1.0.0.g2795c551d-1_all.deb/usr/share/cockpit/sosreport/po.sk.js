cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Prístup na úrovni správcu"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  ""
 ],
 "Authenticate": [
  null,
  "Overiť sa"
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Close": [
  null,
  "Zavrieť"
 ],
 "Delete": [
  null,
  "Zmazať"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostické hlásenia"
 ],
 "Download": [
  null,
  "Stiahnúť"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Limit access": [
  null,
  ""
 ],
 "Limited access": [
  null,
  ""
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  ""
 ],
 "Method": [
  null,
  "Metóda"
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  ""
 ],
 "Obfuscated": [
  null,
  ""
 ],
 "Options": [
  null,
  "Možnosti"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Please authenticate to gain administrative access": [
  null,
  ""
 ],
 "Progress: $0": [
  null,
  ""
 ],
 "Report": [
  null,
  "Nahlásiť"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  "Prepnúť na obmedzený prístup"
 ],
 "Turn on administrative access": [
  null,
  ""
 ],
 "You now have administrative access.": [
  null,
  ""
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  ""
 ],
 "show less": [
  null,
  "ukázať menej"
 ],
 "show more": [
  null,
  "ukázať viac"
 ],
 "sos": [
  null,
  "sos"
 ]
});
