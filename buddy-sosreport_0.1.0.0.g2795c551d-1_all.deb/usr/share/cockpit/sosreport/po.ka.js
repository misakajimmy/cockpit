cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "ადმინისტრატიული წვდომა"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "რეპორტების შესაქმნელად საჭიროა გადაერთოთ \"ადმინისტრატორის წვდომა\"-ზე."
 ],
 "Administrative access required": [
  null,
  "საჭიროა ადმინისტრაციული წვდომა"
 ],
 "Attributes": [
  null,
  "ატრიბუტები"
 ],
 "Authenticate": [
  null,
  "ავთენტიკაცია"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Created": [
  null,
  "შეიქმნა"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Delete report permanently?": [
  null,
  "წავშალო ანგარიში სამუდამოდ?"
 ],
 "Diagnostic reports": [
  null,
  "დიაგნოსტიკის ანგარიშები"
 ],
 "Download": [
  null,
  "გადმოწერა"
 ],
 "Encrypted": [
  null,
  "დაშიფრულია"
 ],
 "Encryption passphrase": [
  null,
  "დაშიფვრის საკვანძო ფრაზა"
 ],
 "Error": [
  null,
  "შეცდომა"
 ],
 "Leave empty to skip encryption": [
  null,
  "შიფრაციის გამოსატოვებლად ცარიელი დატოვეთ"
 ],
 "Limit access": [
  null,
  "წვდომის შეზღუდვა"
 ],
 "Limited access": [
  null,
  "შეზღუდული წვდომა"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "შეზღუდული წვდომა გისაზღვრავთ ადმინისტრატიულ პრივილეგიებს. ვებ კონსოლის ზოგიერთი ნაწილი შეზღუდული იქნება."
 ],
 "Method": [
  null,
  "მეთოდი"
 ],
 "No system reports.": [
  null,
  "სისტემის ანგარიშების გარეშე."
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "ქსელის მისამართების, ჰოსტისა და მომხმარებლის სახელების ობფუსკაცია"
 ],
 "Obfuscated": [
  null,
  "ობფუსკირებულია"
 ],
 "Options": [
  null,
  "პარამეტრები"
 ],
 "Password": [
  null,
  "პაროლი"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "ადმინისტრატორი წვდომის მისაღებად გთხოვთ გაიაროთ ავთენტიკაცია"
 ],
 "Problem becoming administrator": [
  null,
  "ადმინისტრატორად გახდომის შეცდომა"
 ],
 "Progress: $0": [
  null,
  "მიმდინარეობა: $0"
 ],
 "Report": [
  null,
  "ანგარიში"
 ],
 "Report label": [
  null,
  "ანგარიშის ჭდე"
 ],
 "Reports": [
  null,
  "ანგარიშები"
 ],
 "Run new report": [
  null,
  "ახალი ანგარიშის გაშვება"
 ],
 "Run report": [
  null,
  "ანგარიშის გაშვება"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "SOS reporting აგროვებს სისტემურ ინფორმაციას პრობლემების გამოვლენაში დასახმარებლად."
 ],
 "Stop report": [
  null,
  "ანგარიშის გაჩერება"
 ],
 "Switch to administrative access": [
  null,
  "ადმინისტრატორის წვდომაზე გადართვა"
 ],
 "Switch to limited access": [
  null,
  "შეზღუდულ წვდომებზე გადართვა"
 ],
 "System diagnostics": [
  null,
  "სისტემური დიაგნოსტიკა"
 ],
 "The file $0 will be deleted.": [
  null,
  "$0 წაიშლება."
 ],
 "This information is stored only on the system.": [
  null,
  "შეგროვებული ინფორმაცია მხოლოდ სისტემაში ინახება."
 ],
 "Turn on administrative access": [
  null,
  "ადმინისტრატორის წვდომების ჩართვა"
 ],
 "Use verbose logging": [
  null,
  "გაფართოებული ჟურნალიზაციის ჩართვა"
 ],
 "You now have administrative access.": [
  null,
  "ახლა გაქვთ ადმინისტრატორის წვდომა."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "თქვენი ბრაუზერი თქვენი წვდომის დონეებს სესიებს შორისაც დაიმახსოვრებს."
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ],
 "sos": [
  null,
  "sos"
 ]
});
