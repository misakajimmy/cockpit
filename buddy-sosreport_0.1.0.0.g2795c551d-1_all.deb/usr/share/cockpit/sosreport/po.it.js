cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Accesso amministrativo"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "È necessario l'accesso amministrativo per creare e accedere ai report."
 ],
 "Administrative access required": [
  null,
  "Richiesto accesso amministrativo"
 ],
 "Attributes": [
  null,
  "Attributi"
 ],
 "Authenticate": [
  null,
  "Autenticare"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Created": [
  null,
  "Creato"
 ],
 "Delete": [
  null,
  "Cancella"
 ],
 "Delete report permanently?": [
  null,
  "Eliminare il rapporto in modo permanente?"
 ],
 "Diagnostic reports": [
  null,
  "Rapporti diagnostici"
 ],
 "Download": [
  null,
  "Scarica"
 ],
 "Encrypted": [
  null,
  "Crittografato"
 ],
 "Encryption passphrase": [
  null,
  "Passphrase di crittografia"
 ],
 "Error": [
  null,
  "Errore"
 ],
 "Leave empty to skip encryption": [
  null,
  "Lascia vuoto per saltare la crittografia"
 ],
 "Limit access": [
  null,
  "Limitare l'accesso"
 ],
 "Limited access": [
  null,
  "Accesso limitato"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "La modalità di accesso limitato limita i privilegi di amministratore. Alcune parti della Web Console avranno funzionalità ridotte."
 ],
 "Method": [
  null,
  "Metodo"
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "Offuscare indirizzi di rete, nomi host e nomi utente"
 ],
 "Obfuscated": [
  null,
  "Offuscato"
 ],
 "Options": [
  null,
  "Opzioni"
 ],
 "Password": [
  null,
  "Password"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autenticarsi per ottenere l'accesso amministrativo"
 ],
 "Progress: $0": [
  null,
  "Progresso: $0"
 ],
 "Report": [
  null,
  "Notifica"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "I rapporti SOS raccolgono informazioni di sistema per aiutare nella diagnosi dei problemi."
 ],
 "Switch to limited access": [
  null,
  "Passa ad accesso limitato"
 ],
 "Turn on administrative access": [
  null,
  "Attiva l'accesso amministrativo"
 ],
 "You now have administrative access.": [
  null,
  "Ora hai accesso amministrativo."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Il tuo browser ricorderà il tuo livello di accesso tra le sessioni."
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ],
 "sos": [
  null,
  "sos"
 ]
});
