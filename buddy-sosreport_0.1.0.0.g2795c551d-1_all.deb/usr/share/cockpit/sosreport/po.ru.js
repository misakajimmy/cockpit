cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Административный доступ"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "Требуется административный доступ для создания отчетов и доступа к ним."
 ],
 "Administrative access required": [
  null,
  "Требуется административный доступ"
 ],
 "Attributes": [
  null,
  "Атрибуты"
 ],
 "Authenticate": [
  null,
  "Проверка подлинности"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Created": [
  null,
  "Дата создания"
 ],
 "Delete": [
  null,
  "Удалить"
 ],
 "Diagnostic reports": [
  null,
  "Диагностические отчёты"
 ],
 "Download": [
  null,
  "Загрузить"
 ],
 "Error": [
  null,
  "Ошибка"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  ""
 ],
 "Method": [
  null,
  ""
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  ""
 ],
 "Obfuscated": [
  null,
  ""
 ],
 "Options": [
  null,
  "Параметры"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Please authenticate to gain administrative access": [
  null,
  ""
 ],
 "Progress: $0": [
  null,
  ""
 ],
 "Report": [
  null,
  "Сообщить"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  ""
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  ""
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "sos": [
  null,
  "sos"
 ]
});
