cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Přístup na úrovni správce"
 ],
 "Authenticate": [
  null,
  "Ověřit se"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Created": [
  null,
  "Vytvořeno"
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostická hlášení"
 ],
 "Download": [
  null,
  "Stáhnout"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Limit access": [
  null,
  "Omezit přístup"
 ],
 "Limited access": [
  null,
  "Omezený přístup"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Režim omezeného přístupu omezuje oprávnění pro správu. Některé části webové konzole budou poskytovat méně funkcí."
 ],
 "Method": [
  null,
  "Metoda"
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  ""
 ],
 "Obfuscated": [
  null,
  ""
 ],
 "Options": [
  null,
  "Přepínače"
 ],
 "Password": [
  null,
  "Heslo"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Pro získání přístupu na úrovni správce se prosím ověřte"
 ],
 "Problem becoming administrator": [
  null,
  "Problém s tím, stát se správcem"
 ],
 "Progress: $0": [
  null,
  ""
 ],
 "Report": [
  null,
  "Nahlásit"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  ""
 ],
 "Switch to administrative access": [
  null,
  "Přepnout na přístup správce"
 ],
 "Switch to limited access": [
  null,
  "Přepnout na omezený přístup"
 ],
 "Turn on administrative access": [
  null,
  "Zapnout přístup na úrovni správce"
 ],
 "You now have administrative access.": [
  null,
  "Nyní máte přístup na úrovni správy systému."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Váš prohlížeč si bude úroveň přístupu pamatovat i pro příště."
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "sos": [
  null,
  "sos"
 ]
});
