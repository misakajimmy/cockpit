cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Administrativ tilgang"
 ],
 "Authenticate": [
  null,
  "Autentiser"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Close": [
  null,
  "Lukk"
 ],
 "Delete": [
  null,
  "Slett"
 ],
 "Diagnostic reports": [
  null,
  "Diagnose rapporter"
 ],
 "Error": [
  null,
  "Feil"
 ],
 "Limit access": [
  null,
  "Begrens tilgang"
 ],
 "Limited access": [
  null,
  "Begrenset tilgang"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Begrenset tilgangsmodus begrenser administrative rettigheter. Noen deler av webkonsollet har redusert funksjonalitet."
 ],
 "Method": [
  null,
  "Metode"
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  ""
 ],
 "Obfuscated": [
  null,
  ""
 ],
 "Options": [
  null,
  "Alternativer"
 ],
 "Password": [
  null,
  "Passord"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentiser for å få administrativ tilgang"
 ],
 "Progress: $0": [
  null,
  ""
 ],
 "Report": [
  null,
  "Rapport"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  "Bytt til begrenset tilgang"
 ],
 "Turn on administrative access": [
  null,
  "Slå på administrativ tilgang"
 ],
 "Use verbose logging": [
  null,
  ""
 ],
 "You now have administrative access.": [
  null,
  "Du har nå administrativ tilgang."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Nettleseren din husker tilgangsnivået ditt på tvers av øktene."
 ],
 "show less": [
  null,
  "vis mindre"
 ],
 "show more": [
  null,
  "vis mer"
 ],
 "sos": [
  null,
  "sos"
 ]
});
