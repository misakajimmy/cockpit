cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Administratieve toegang"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "Beheerderstoegang is vereist om rapporten te maken en te openen."
 ],
 "Administrative access required": [
  null,
  "Beheerderstoegang vereist"
 ],
 "Attributes": [
  null,
  "Attributen"
 ],
 "Authenticate": [
  null,
  "Authenticatie uitvoeren"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Close": [
  null,
  "Sluiten"
 ],
 "Created": [
  null,
  "Aangemaakt"
 ],
 "Delete": [
  null,
  "Verwijderen"
 ],
 "Delete report permanently?": [
  null,
  "Rapport definitief verwijderen?"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostische rapporten"
 ],
 "Download": [
  null,
  "Download"
 ],
 "Encrypted": [
  null,
  "Versleuteld"
 ],
 "Encryption passphrase": [
  null,
  "Versleutelingswachtzin"
 ],
 "Error": [
  null,
  "Fout"
 ],
 "Leave empty to skip encryption": [
  null,
  "Laat leeg om versleuteling over te slaan"
 ],
 "Limit access": [
  null,
  "Beperk toegang"
 ],
 "Limited access": [
  null,
  "Beperkte toegang"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "De beperkte toegangsmodus beperkt de beheerdersrechten. Sommige delen van de webconsole hebben een verminderde functionaliteit."
 ],
 "Method": [
  null,
  "Methode"
 ],
 "No system reports.": [
  null,
  "Geen systeemrapporten."
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "Verduister netwerkadressen, hostnamen en gebruikersnamen"
 ],
 "Obfuscated": [
  null,
  "Verduisterd"
 ],
 "Options": [
  null,
  "Opties"
 ],
 "Password": [
  null,
  "Wachtwoord"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Authenticeer om administratieve toegang te krijgen"
 ],
 "Problem becoming administrator": [
  null,
  "Probleem om beheerder te worden"
 ],
 "Progress: $0": [
  null,
  "Voortgang: $0"
 ],
 "Report": [
  null,
  "Rapport"
 ],
 "Report label": [
  null,
  "Rapporteer label"
 ],
 "Reports": [
  null,
  "Rapporten"
 ],
 "Run new report": [
  null,
  "Vier nieuw rapport uit"
 ],
 "Run report": [
  null,
  "Voer rapport uit"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "SOS-rapportage verzamelt systeeminformatie om te helpen bij het diagnosticeren van problemen."
 ],
 "Stop report": [
  null,
  "Stop rapport"
 ],
 "Switch to administrative access": [
  null,
  "Schakel om naar beheerderstoegang"
 ],
 "Switch to limited access": [
  null,
  "Schakel over naar beperkte toegang"
 ],
 "System diagnostics": [
  null,
  "Systeemdiagnose"
 ],
 "The file $0 will be deleted.": [
  null,
  "De bestand $0 kon niet worden verwijderd."
 ],
 "This information is stored only on the system.": [
  null,
  "Deze informatie wordt alleen op het systeem opgeslagen."
 ],
 "Turn on administrative access": [
  null,
  "Schakel beheerderstoegang in"
 ],
 "Use verbose logging": [
  null,
  "Uitgebreide logboekregistratie gebruiken"
 ],
 "You now have administrative access.": [
  null,
  "Je hebt nu administratieve toegang."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Je browser onthoudt je toegangsniveau tijdens sessies."
 ],
 "show less": [
  null,
  "toon minder"
 ],
 "show more": [
  null,
  "toon meer"
 ],
 "sos": [
  null,
  "sos"
 ]
});
