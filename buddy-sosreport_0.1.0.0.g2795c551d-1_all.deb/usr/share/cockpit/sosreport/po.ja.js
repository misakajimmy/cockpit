cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "管理アクセス"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "レポートの作成およびアクセスには、管理アクセスが必要です。"
 ],
 "Administrative access required": [
  null,
  "管理アクセスが必要"
 ],
 "Attributes": [
  null,
  "属性"
 ],
 "Authenticate": [
  null,
  "認証する"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Created": [
  null,
  "作成済み"
 ],
 "Delete": [
  null,
  "削除"
 ],
 "Delete report permanently?": [
  null,
  "レポートを完全に削除しますか?"
 ],
 "Diagnostic reports": [
  null,
  "診断レポート"
 ],
 "Download": [
  null,
  "ダウンロード"
 ],
 "Encrypted": [
  null,
  "暗号化"
 ],
 "Encryption passphrase": [
  null,
  "暗号化パスフレーズ"
 ],
 "Error": [
  null,
  "エラー"
 ],
 "Leave empty to skip encryption": [
  null,
  "空白のままにして暗号化をスキップする"
 ],
 "Limit access": [
  null,
  "アクセスの制限"
 ],
 "Limited access": [
  null,
  "制限付きアクセス"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "限定アクセスモードでは、管理者権限が制限されます。Web コンソールの一部の機能が低下します。"
 ],
 "Method": [
  null,
  "メソッド"
 ],
 "No system reports.": [
  null,
  "システムレポートがありません。"
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "ネットワークアドレス、ホスト名、およびユーザー名の難読化"
 ],
 "Obfuscated": [
  null,
  "難読化"
 ],
 "Options": [
  null,
  "オプション"
 ],
 "Password": [
  null,
  "パスワード"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "管理者アクセスを得るために認証を行ってください"
 ],
 "Problem becoming administrator": [
  null,
  "管理者への切り替えに問題が発生しました"
 ],
 "Progress: $0": [
  null,
  "進行状況: $0"
 ],
 "Report": [
  null,
  "レポート"
 ],
 "Report label": [
  null,
  "レポートラベル"
 ],
 "Reports": [
  null,
  "レポート"
 ],
 "Run new report": [
  null,
  "新規レポートを実行する"
 ],
 "Run report": [
  null,
  "レポートを実行する"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "SOS レポートは、問題の診断に役立つシステム情報を収集します。"
 ],
 "Stop report": [
  null,
  "レポートを停止する"
 ],
 "Switch to administrative access": [
  null,
  "管理者アクセスへの切り替え"
 ],
 "Switch to limited access": [
  null,
  "アクセス制限への切り替え"
 ],
 "System diagnostics": [
  null,
  "システムの診断"
 ],
 "The file $0 will be deleted.": [
  null,
  "ファイル $0 が削除されます。"
 ],
 "This information is stored only on the system.": [
  null,
  "この情報は、システムにのみ保存されます。"
 ],
 "Turn on administrative access": [
  null,
  "管理者アクセスをオンにする"
 ],
 "Use verbose logging": [
  null,
  "詳細なログを使用する"
 ],
 "You now have administrative access.": [
  null,
  "これで管理者アクセスが可能になりました。"
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "ブラウザーはセッション間のアクセスレベルを記憶します。"
 ],
 "show less": [
  null,
  "簡易表示"
 ],
 "show more": [
  null,
  "詳細表示"
 ],
 "sos": [
  null,
  "sos"
 ]
});
