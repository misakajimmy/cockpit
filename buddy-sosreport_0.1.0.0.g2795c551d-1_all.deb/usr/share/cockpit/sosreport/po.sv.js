cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Administrativ tillgång"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "Administrativ åtkomst krävs för att skapa och komma åt rapporter."
 ],
 "Administrative access required": [
  null,
  "Administrativ åtkomst krävs"
 ],
 "Attributes": [
  null,
  "Attribut"
 ],
 "Authenticate": [
  null,
  "Autentisera"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Created": [
  null,
  "Skapad"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Delete report permanently?": [
  null,
  "Ta bort rapporten permanent?"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostikrapporter"
 ],
 "Download": [
  null,
  "Hämta"
 ],
 "Encrypted": [
  null,
  "Krypterad"
 ],
 "Encryption passphrase": [
  null,
  "Krypteringslösenfras"
 ],
 "Error": [
  null,
  "Fel"
 ],
 "Leave empty to skip encryption": [
  null,
  "Lämna tomt för att hoppa över kryptering"
 ],
 "Limit access": [
  null,
  "Begränsa tillgång"
 ],
 "Limited access": [
  null,
  "Begränsad tillgång"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Begränsat läge begränsar administratörsprivilegier och tar bort funktionalitet i delar av webbkonsolen."
 ],
 "Method": [
  null,
  "Metod"
 ],
 "No system reports.": [
  null,
  "Inga systemrapporter."
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "Mörka nätverksadresser, värdnamn och användarnamn"
 ],
 "Obfuscated": [
  null,
  "Mörkad"
 ],
 "Options": [
  null,
  "Alternativ"
 ],
 "Password": [
  null,
  "Lösenord"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentisera för att få administrativ åtkomst"
 ],
 "Problem becoming administrator": [
  null,
  "Problem med att bli administratör"
 ],
 "Progress: $0": [
  null,
  "Förlopp: $0"
 ],
 "Report": [
  null,
  "Rapport"
 ],
 "Report label": [
  null,
  "Rapportetikett"
 ],
 "Reports": [
  null,
  "Rapporter"
 ],
 "Run new report": [
  null,
  "Kör en ny rapport"
 ],
 "Run report": [
  null,
  "Kör en rapport"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "SOS-rapportering samlar systeminformation för att hjälpa till med diagnostisering av problem."
 ],
 "Stop report": [
  null,
  "Stoppa rapporten"
 ],
 "Switch to administrative access": [
  null,
  "Byt till administrativ åtkomst"
 ],
 "Switch to limited access": [
  null,
  "Byt till begränsad åtkomst"
 ],
 "System diagnostics": [
  null,
  "Systemdiagnostik"
 ],
 "The file $0 will be deleted.": [
  null,
  "Filen $0 kommer att raderas."
 ],
 "This information is stored only on the system.": [
  null,
  "Denna information lagras endast på systemet."
 ],
 "Turn on administrative access": [
  null,
  "Aktivera administrativ åtkomst"
 ],
 "Use verbose logging": [
  null,
  "Använd utförlig loggning"
 ],
 "You now have administrative access.": [
  null,
  "Du har nu administrativ åtkomst."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Din webbläsare kommer ihåg din åtkomstnivå över sessioner."
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ],
 "sos": [
  null,
  "sos"
 ]
});
