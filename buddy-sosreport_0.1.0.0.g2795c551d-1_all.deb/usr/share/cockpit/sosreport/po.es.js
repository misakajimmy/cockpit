cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Acceso administrativo"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "Se requiere acceso administrativo para crear y acceder a los informes."
 ],
 "Administrative access required": [
  null,
  "Se requiere acceso administrativo"
 ],
 "Attributes": [
  null,
  "Atributos"
 ],
 "Authenticate": [
  null,
  "Autenticar"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Close": [
  null,
  "Cerrar"
 ],
 "Created": [
  null,
  "Creado"
 ],
 "Delete": [
  null,
  "Eliminar"
 ],
 "Delete report permanently?": [
  null,
  "¿Eliminar informe permanentemente?"
 ],
 "Diagnostic reports": [
  null,
  "Informes de diagnóstico"
 ],
 "Download": [
  null,
  "Descargar"
 ],
 "Encrypted": [
  null,
  "Cifrado"
 ],
 "Encryption passphrase": [
  null,
  "Contraseña de cifrado"
 ],
 "Error": [
  null,
  "Error"
 ],
 "Leave empty to skip encryption": [
  null,
  "Dejar en blanco para omitir cifrado"
 ],
 "Limit access": [
  null,
  "Limitar acceso"
 ],
 "Limited access": [
  null,
  "Acceso limitado"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "El modo de acceso limitado restringe los privilegios administrativos. Algunas partes de la consola web tendrán funcionalidad reducida."
 ],
 "Method": [
  null,
  "Método"
 ],
 "No system reports.": [
  null,
  "No hay informes del sistema."
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "Ofuscar direcciones de red, nombres de anfitriones y de usuarios"
 ],
 "Obfuscated": [
  null,
  "Ofuscado"
 ],
 "Options": [
  null,
  "Opciones"
 ],
 "Password": [
  null,
  "Contraseña"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Autentíquese para obtener acceso administrativo"
 ],
 "Problem becoming administrator": [
  null,
  "Problema al cambiar a administrador"
 ],
 "Progress: $0": [
  null,
  "Progreso: $0"
 ],
 "Report": [
  null,
  "Informe"
 ],
 "Report label": [
  null,
  "Etiqueta de informe"
 ],
 "Reports": [
  null,
  "Informes"
 ],
 "Run new report": [
  null,
  "Crear nuevo informe"
 ],
 "Run report": [
  null,
  "Crear informe"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "Los informes SOS recogen información del sistema para ayudarle a diagnosticar problemas."
 ],
 "Stop report": [
  null,
  "Detener informe"
 ],
 "Switch to administrative access": [
  null,
  "Cambiar a acceso administrativo"
 ],
 "Switch to limited access": [
  null,
  "Pasar a acceso limitado"
 ],
 "System diagnostics": [
  null,
  "Diagnósticos del sistema"
 ],
 "The file $0 will be deleted.": [
  null,
  "Se eliminará el archivo $0."
 ],
 "This information is stored only on the system.": [
  null,
  "La información sólo se almacenará en el sistema."
 ],
 "Turn on administrative access": [
  null,
  "Habilitar el acceso administrativo"
 ],
 "Use verbose logging": [
  null,
  "Usar registros detallados"
 ],
 "You now have administrative access.": [
  null,
  "Ahora tienes acceso administrativo."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Su navegador recordará su nivel de acceso entre sesiones."
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar más"
 ],
 "sos": [
  null,
  "sos"
 ]
});
