cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "管理员权限"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "需要具备管理访问权限才能创建和访问报告。"
 ],
 "Administrative access required": [
  null,
  "需要管理访问权限"
 ],
 "Attributes": [
  null,
  "属性"
 ],
 "Authenticate": [
  null,
  "认证"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Close": [
  null,
  "关闭"
 ],
 "Created": [
  null,
  "创建于"
 ],
 "Delete": [
  null,
  "删除"
 ],
 "Delete report permanently?": [
  null,
  "永久删除报告？"
 ],
 "Diagnostic reports": [
  null,
  "诊断报告"
 ],
 "Download": [
  null,
  "下载"
 ],
 "Encrypted": [
  null,
  "已加密"
 ],
 "Encryption passphrase": [
  null,
  "加密密码短语"
 ],
 "Error": [
  null,
  "错误"
 ],
 "Leave empty to skip encryption": [
  null,
  "留空以跳过加密"
 ],
 "Limit access": [
  null,
  "限制访问"
 ],
 "Limited access": [
  null,
  "被限制的访问"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "限制访问模式会限制管理员权限。Web 控制台部分功能将会减少。"
 ],
 "Method": [
  null,
  "模式"
 ],
 "No system reports.": [
  null,
  "没有系统报告。"
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "模糊处理网络地址、主机名和用户名"
 ],
 "Obfuscated": [
  null,
  "模糊处理"
 ],
 "Options": [
  null,
  "选项"
 ],
 "Password": [
  null,
  "密码"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "请认证以获得管理员权限"
 ],
 "Problem becoming administrator": [
  null,
  "成为管理员时出现问题"
 ],
 "Progress: $0": [
  null,
  "进度：$0"
 ],
 "Report": [
  null,
  "报告"
 ],
 "Report label": [
  null,
  "报告标签"
 ],
 "Reports": [
  null,
  "报告"
 ],
 "Run new report": [
  null,
  "运行新报告"
 ],
 "Run report": [
  null,
  "运行报告"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "SOS 报告会收集系统信息，以帮助诊断问题。"
 ],
 "Stop report": [
  null,
  "停止报告"
 ],
 "Switch to administrative access": [
  null,
  "切换到管理权限"
 ],
 "Switch to limited access": [
  null,
  "切换到限制权限"
 ],
 "System diagnostics": [
  null,
  "系统诊断"
 ],
 "The file $0 will be deleted.": [
  null,
  "文件 $0 将被删除。"
 ],
 "This information is stored only on the system.": [
  null,
  "这些信息只保存在系统中。"
 ],
 "Turn on administrative access": [
  null,
  "开启管理员权限"
 ],
 "Use verbose logging": [
  null,
  "使用详细日志记录"
 ],
 "You now have administrative access.": [
  null,
  "您已经获取了管理员权限。"
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "您的浏览器将会在不同会话之间记住您的访问级别。"
 ],
 "show less": [
  null,
  "显示更少"
 ],
 "show more": [
  null,
  "显示更多"
 ],
 "sos": [
  null,
  "sos"
 ]
});
