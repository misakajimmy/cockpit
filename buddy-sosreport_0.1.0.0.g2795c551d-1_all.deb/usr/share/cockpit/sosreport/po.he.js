cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "Administrative access": [
  null,
  "גישה ניהולית"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "נדרשת גישה ניהולית כדי ליצור ולגשת לדוחות."
 ],
 "Administrative access required": [
  null,
  "נדרשת גישה ניהולית"
 ],
 "Attributes": [
  null,
  "מאפיינים"
 ],
 "Authenticate": [
  null,
  "אימות"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Created": [
  null,
  "נוצרה"
 ],
 "Delete": [
  null,
  "מחיקה"
 ],
 "Delete report permanently?": [
  null,
  "למחוק את הדוח לצמיתות?"
 ],
 "Diagnostic reports": [
  null,
  "דוחות אבחון"
 ],
 "Download": [
  null,
  "הורדה"
 ],
 "Encrypted": [
  null,
  "מוצפן"
 ],
 "Encryption passphrase": [
  null,
  "מילת צופן ההצפנה"
 ],
 "Error": [
  null,
  "שגיאה"
 ],
 "Limit access": [
  null,
  "הגבלת גישה"
 ],
 "Limited access": [
  null,
  "גישה מוגבלת"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "מצב גישה מוגבלת מגביל את ההרשאות הניהוליות. חלקים מסוימים במסוף המקוון יפעלו באופן חלקי."
 ],
 "Method": [
  null,
  "שיטה"
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  ""
 ],
 "Obfuscated": [
  null,
  ""
 ],
 "Options": [
  null,
  "אפשרויות"
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "נא לעבור אימות כדי לקבל גישת ניהול"
 ],
 "Progress: $0": [
  null,
  ""
 ],
 "Report": [
  null,
  "דיווח"
 ],
 "Reports": [
  null,
  "דוחות"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  "העברה לגישה מוגבלת"
 ],
 "Turn on administrative access": [
  null,
  "הפעלת גישה ניהולית"
 ],
 "You now have administrative access.": [
  null,
  "מעתה יש לך גישה ניהולית."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "הדפדפן שלך יזכור את רמת הגישה שלך בין הפעלות."
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ],
 "sos": [
  null,
  "חירום"
 ]
});
