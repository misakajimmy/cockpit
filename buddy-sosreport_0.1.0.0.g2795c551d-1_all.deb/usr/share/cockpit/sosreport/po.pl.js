cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Dostęp administracyjny"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "Do tworzenia i wyświetlania zgłoszeń wymagany jest dostęp administracyjny."
 ],
 "Administrative access required": [
  null,
  "Wymagany jest dostęp administracyjny"
 ],
 "Attributes": [
  null,
  "Atrybuty"
 ],
 "Authenticate": [
  null,
  "Uwierzytelnij"
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Close": [
  null,
  "Zamknij"
 ],
 "Created": [
  null,
  "Utworzono"
 ],
 "Delete": [
  null,
  "Usuń"
 ],
 "Delete report permanently?": [
  null,
  "Trwale usunąć zgłoszenie?"
 ],
 "Diagnostic reports": [
  null,
  "Raporty diagnostyczne"
 ],
 "Download": [
  null,
  "Pobierz"
 ],
 "Encrypted": [
  null,
  "Zaszyfrowane"
 ],
 "Encryption passphrase": [
  null,
  "Hasło szyfrowania"
 ],
 "Error": [
  null,
  "Błąd"
 ],
 "Leave empty to skip encryption": [
  null,
  "Pozostawienie pustego pola spowoduje pominięcie szyfrowania"
 ],
 "Limit access": [
  null,
  "Ogranicz dostęp"
 ],
 "Limited access": [
  null,
  "Ograniczony dostęp"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Tryb ograniczonego dostępu ogranicza uprawnienia administracyjne. Część konsoli internetowej będzie miała zmniejszoną funkcjonalność."
 ],
 "Method": [
  null,
  "Metoda"
 ],
 "No system reports.": [
  null,
  "Brak zgłoszeń systemowych."
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "Zaciemnienie adresów sieciowych, nazw komputerów i nazw użytkowników"
 ],
 "Obfuscated": [
  null,
  "Zaciemnione"
 ],
 "Options": [
  null,
  "Opcje"
 ],
 "Password": [
  null,
  "Hasło"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Proszę się uwierzytelnić, aby uzyskać dostęp administracyjny"
 ],
 "Problem becoming administrator": [
  null,
  "Problem podczas zostawania administratorem"
 ],
 "Progress: $0": [
  null,
  "Postęp: $0"
 ],
 "Report": [
  null,
  "Zgłoś"
 ],
 "Report label": [
  null,
  "Etykieta zgłoszenia"
 ],
 "Reports": [
  null,
  "Zgłoszenia"
 ],
 "Run new report": [
  null,
  "Wykonaj nowe zgłoszenie"
 ],
 "Run report": [
  null,
  "Wykonaj zgłoszenie"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "Zgłaszanie SOS zbiera informacje o systemie, aby pomóc diagnozować problemy."
 ],
 "Stop report": [
  null,
  "Zatrzymaj zgłoszenie"
 ],
 "Switch to administrative access": [
  null,
  "Przełącz na dostęp administracyjny"
 ],
 "Switch to limited access": [
  null,
  "Przełącz na ograniczony dostęp"
 ],
 "System diagnostics": [
  null,
  "Diagnostyka systemu"
 ],
 "The file $0 will be deleted.": [
  null,
  "Plik $0 zostanie usunięty."
 ],
 "This information is stored only on the system.": [
  null,
  "Ta informacja jest przechowywana tylko na komputerze."
 ],
 "Turn on administrative access": [
  null,
  "Włącz dostęp administracyjny"
 ],
 "Use verbose logging": [
  null,
  "Więcej informacji w dzienniku"
 ],
 "You now have administrative access.": [
  null,
  "Uzyskano dostęp administracyjny."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Używana przeglądarka będzie pamiętała poziom dostępu użytkownika między sesjami."
 ],
 "show less": [
  null,
  "wyświetl mniej"
 ],
 "show more": [
  null,
  "wyświetl więcej"
 ],
 "sos": [
  null,
  "sos"
 ]
});
