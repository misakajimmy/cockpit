cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "관리 액세스"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "관리 접근은 보고서 생성하거고 접근해야 합니다."
 ],
 "Administrative access required": [
  null,
  "필요한 관리 접근"
 ],
 "Attributes": [
  null,
  "속성"
 ],
 "Authenticate": [
  null,
  "인증"
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Close": [
  null,
  "닫기"
 ],
 "Created": [
  null,
  "생성일"
 ],
 "Delete": [
  null,
  "삭제"
 ],
 "Delete report permanently?": [
  null,
  "영구적으로 보고를 삭제?"
 ],
 "Diagnostic reports": [
  null,
  "진단 보고서"
 ],
 "Download": [
  null,
  "내려받기"
 ],
 "Encrypted": [
  null,
  "암호화됨"
 ],
 "Encryption passphrase": [
  null,
  "암호화된 암호"
 ],
 "Error": [
  null,
  "오류"
 ],
 "Leave empty to skip encryption": [
  null,
  "암호화를 건너뛰려면 공백으로 둡니다"
 ],
 "Limit access": [
  null,
  "접근 제한"
 ],
 "Limited access": [
  null,
  "제한된 접근"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "제한된 접근 방식은 관리 권한을 제한합니다. 웹 콘솔의 일부 부분은 기능이 축소됩니다."
 ],
 "Method": [
  null,
  "방식"
 ],
 "No system reports.": [
  null,
  "시스템 보고 없음."
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "네트워크 주소, 호스트이름과 사용자이름 난독화"
 ],
 "Obfuscated": [
  null,
  "난독화됨"
 ],
 "Options": [
  null,
  "옵션"
 ],
 "Password": [
  null,
  "비밀번호"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "관리 액세스 권한을 얻으려면 인증하십시오"
 ],
 "Problem becoming administrator": [
  null,
  "관리자에게서 발생한 문제"
 ],
 "Progress: $0": [
  null,
  "진행: $0"
 ],
 "Report": [
  null,
  "보고"
 ],
 "Report label": [
  null,
  "보고 이름표"
 ],
 "Reports": [
  null,
  "보고서"
 ],
 "Run new report": [
  null,
  "신규 보고서 실행"
 ],
 "Run report": [
  null,
  "보고서 실행"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "SOS 보고는 문제 진단과 함께 도움이 되는 시스템 정보를 수집합니다."
 ],
 "Stop report": [
  null,
  "보고서 멈춤"
 ],
 "Switch to administrative access": [
  null,
  "관리자 접근으로 전환"
 ],
 "Switch to limited access": [
  null,
  "제한된 접근으로 전환"
 ],
 "System diagnostics": [
  null,
  "시스템 진단"
 ],
 "The file $0 will be deleted.": [
  null,
  "파일 $0가 삭제됩니다."
 ],
 "This information is stored only on the system.": [
  null,
  "이와 같은 정보는 시스템에서만 저장됩니다."
 ],
 "Turn on administrative access": [
  null,
  "관리자 접근 설정"
 ],
 "Use verbose logging": [
  null,
  "상세한 로그인 사용"
 ],
 "You now have administrative access.": [
  null,
  "이제 관리자 액세스 권한이 있습니다."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "브라우저는 서로 다른 세션 간의 액세스 수준을 기억합니다."
 ],
 "show less": [
  null,
  "덜 보기"
 ],
 "show more": [
  null,
  "더 보기"
 ],
 "sos": [
  null,
  "sos"
 ]
});
