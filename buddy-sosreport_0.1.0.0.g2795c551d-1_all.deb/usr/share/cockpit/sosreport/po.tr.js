cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Yönetimsel erişim"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "Raporları oluşturmak ve raporlara erişmek için yönetimsel erişim gerekir."
 ],
 "Administrative access required": [
  null,
  "Yönetimsel erişim gerekli"
 ],
 "Attributes": [
  null,
  "Öznitelikler"
 ],
 "Authenticate": [
  null,
  "Kimlik doğrula"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Created": [
  null,
  "Oluşturuldu"
 ],
 "Delete": [
  null,
  "Sil"
 ],
 "Delete report permanently?": [
  null,
  "Rapor kalıcı olarak silinsin mi?"
 ],
 "Diagnostic reports": [
  null,
  "Tanılama raporları"
 ],
 "Download": [
  null,
  "İndir"
 ],
 "Encrypted": [
  null,
  "Şifrelenmiş"
 ],
 "Encryption passphrase": [
  null,
  "Şifreleme parolası"
 ],
 "Error": [
  null,
  "Hata"
 ],
 "Leave empty to skip encryption": [
  null,
  "Şifrelemeyi atlamak için boş bırakın"
 ],
 "Limit access": [
  null,
  "Erişimi sınırla"
 ],
 "Limited access": [
  null,
  "Sınırlı erişim"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Sınırlı erişim kipi, yönetimsel yetkileri kısıtlar. Web konsolunun bazı kısımları sınırlı işlevselliğe sahip olacaktır."
 ],
 "Method": [
  null,
  "Yöntem"
 ],
 "No system reports.": [
  null,
  "Sistem raporları yok."
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "Ağ adreslerini, anamakine adlarını ve kullanıcı adlarını gizleyin"
 ],
 "Obfuscated": [
  null,
  "Gizlenmiş"
 ],
 "Options": [
  null,
  "Seçenekler"
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Lütfen yönetimsel erişim elde etmek için kimlik doğrulayın"
 ],
 "Problem becoming administrator": [
  null,
  "Yönetici olma sorunu"
 ],
 "Progress: $0": [
  null,
  "İlerleme: $0"
 ],
 "Report": [
  null,
  "Bildir"
 ],
 "Report label": [
  null,
  "Bildirme etiketi"
 ],
 "Reports": [
  null,
  "Bildirmeler"
 ],
 "Run new report": [
  null,
  "Yeni rapor çalıştır"
 ],
 "Run report": [
  null,
  "Raporu çalıştır"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "SOS raporlaması, sorunların teşhis edilmesine yardımcı olmak için sistem bilgilerini toplar."
 ],
 "Stop report": [
  null,
  "Raporu durdur"
 ],
 "Switch to administrative access": [
  null,
  "Yönetimsel erişime geç"
 ],
 "Switch to limited access": [
  null,
  "Sınırlı erişime geç"
 ],
 "System diagnostics": [
  null,
  "Sistem tanılamaları"
 ],
 "The file $0 will be deleted.": [
  null,
  "$0 dosyası silinecektir."
 ],
 "This information is stored only on the system.": [
  null,
  "Bu bilgiler sadece sistemde saklanır."
 ],
 "Turn on administrative access": [
  null,
  "Yönetimsel erişimi aç"
 ],
 "Use verbose logging": [
  null,
  "Ayrıntılı günlükleme kullan"
 ],
 "You now have administrative access.": [
  null,
  "Artık yönetimsel erişiminiz var."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Tarayıcınız, oturumlar arasında erişim seviyenizi hatırlayacaktır."
 ],
 "show less": [
  null,
  "daha az göster"
 ],
 "show more": [
  null,
  "daha fazla göster"
 ],
 "sos": [
  null,
  "sos"
 ]
});
