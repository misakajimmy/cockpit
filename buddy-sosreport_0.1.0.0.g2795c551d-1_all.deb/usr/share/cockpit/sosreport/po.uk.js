cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Адміністративний доступ"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "Для створення звітів і доступу до звітів потрібен адміністративний доступ."
 ],
 "Administrative access required": [
  null,
  "Потрібен адміністративний доступ"
 ],
 "Attributes": [
  null,
  "Атрибути"
 ],
 "Authenticate": [
  null,
  "Розпізнавання"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Created": [
  null,
  "Створено"
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Delete report permanently?": [
  null,
  "Вилучити звіт остаточно?"
 ],
 "Diagnostic reports": [
  null,
  "Діагностичні звіти"
 ],
 "Download": [
  null,
  "Отримати"
 ],
 "Encrypted": [
  null,
  "Зашифрований"
 ],
 "Encryption passphrase": [
  null,
  "Пароль шифрування"
 ],
 "Error": [
  null,
  "Помилка"
 ],
 "Leave empty to skip encryption": [
  null,
  "Не заповнюйте, щоб пропустити шифрування"
 ],
 "Limit access": [
  null,
  "Обмежити доступ"
 ],
 "Limited access": [
  null,
  "Обмежений доступ"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Модель із обмеженим доступом обмежує адміністративні привілеї. Функціональні можливості деяких частин вебконсолі буде суттєво зменшено."
 ],
 "Method": [
  null,
  "Метод"
 ],
 "No system reports.": [
  null,
  "Немає системних звітів."
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "Заплутувати адреси мережі, назви вузлів та імена користувачів"
 ],
 "Obfuscated": [
  null,
  "Заплутано"
 ],
 "Options": [
  null,
  "Параметри"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Будь ласка, пройдіть розпізнавання, щоб отримати адміністративний доступ"
 ],
 "Problem becoming administrator": [
  null,
  "Проблеми із набуттям прав адміністратора"
 ],
 "Progress: $0": [
  null,
  "Поступ: $0"
 ],
 "Report": [
  null,
  "Звіт"
 ],
 "Report label": [
  null,
  "Мітка звіту"
 ],
 "Reports": [
  null,
  "Звіти"
 ],
 "Run new report": [
  null,
  "Запустити новий звіт"
 ],
 "Run report": [
  null,
  "Запустити звітування"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "SOS-звітування збирає дані щодо системи для того, щоб допомогти у діагностуванні проблем."
 ],
 "Stop report": [
  null,
  "Зупинити звітування"
 ],
 "Switch to administrative access": [
  null,
  "Перемкнутися на адміністративний доступ"
 ],
 "Switch to limited access": [
  null,
  "Перемкнутися на обмежений доступ"
 ],
 "System diagnostics": [
  null,
  "Діагностика системи"
 ],
 "The file $0 will be deleted.": [
  null,
  "Файл $0 буде вилучено."
 ],
 "This information is stored only on the system.": [
  null,
  "Ці дані зберігатимуться лише у системі."
 ],
 "Turn on administrative access": [
  null,
  "Увімкнути адміністративний доступ"
 ],
 "Use verbose logging": [
  null,
  "Скористатися докладним журналюванням"
 ],
 "You now have administrative access.": [
  null,
  "Тепер ви маєте адміністративний доступ."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Ваш браузер запам'ятовуватиме ваш рівень доступу між сеансами."
 ],
 "show less": [
  null,
  "показати менше"
 ],
 "show more": [
  null,
  "показати більше"
 ],
 "sos": [
  null,
  "sos"
 ]
});
