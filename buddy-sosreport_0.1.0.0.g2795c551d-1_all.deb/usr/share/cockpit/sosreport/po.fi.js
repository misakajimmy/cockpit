cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Ylläpitäjän käyttöoikeudet"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "Raporttien luomiseen ja käyttämiseen tarvitaan ylläpitäjän käyttöoikeudet."
 ],
 "Administrative access required": [
  null,
  "Tarvitaan ylläpitäjän käyttöoikeudet"
 ],
 "Attributes": [
  null,
  "Attribuutit"
 ],
 "Authenticate": [
  null,
  "Tunnistaudu"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Created": [
  null,
  "Luotu"
 ],
 "Delete": [
  null,
  "Poista"
 ],
 "Delete report permanently?": [
  null,
  "Poista raportti pysyvästi?"
 ],
 "Diagnostic reports": [
  null,
  "Diagnostiikkaraportit"
 ],
 "Download": [
  null,
  "Lataa"
 ],
 "Encrypted": [
  null,
  "Salattu"
 ],
 "Encryption passphrase": [
  null,
  "Salauksen tunnuslause"
 ],
 "Error": [
  null,
  "Virhe"
 ],
 "Leave empty to skip encryption": [
  null,
  "Jätä tyhjäksi ohittaaksesi salauksen"
 ],
 "Limit access": [
  null,
  "Rajoita pääsyä"
 ],
 "Limited access": [
  null,
  "Rajoitettu käyttö"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Rajoitettu käyttö -tila rajoittaa ylläpito-oikeuksia. Joitakin verkkokonsolin toimintoja on karsittu."
 ],
 "Method": [
  null,
  "Menetelmä"
 ],
 "No system reports.": [
  null,
  "Ei järjestelmän ilmoituksia."
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "Hämärrä verkko-osoitteet, isäntänimet ja käyttäjänimet"
 ],
 "Obfuscated": [
  null,
  "Hämärretty"
 ],
 "Options": [
  null,
  "Valinnat"
 ],
 "Password": [
  null,
  "Salasana"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Kirjaudu ylläpito-oikeuksien saamiseksi"
 ],
 "Problem becoming administrator": [
  null,
  "Ongelma ylläpitäjäksi tulemisessa"
 ],
 "Progress: $0": [
  null,
  "Edistyminen: $0"
 ],
 "Report": [
  null,
  "Raportoi"
 ],
 "Report label": [
  null,
  "Raportin nimiö"
 ],
 "Reports": [
  null,
  "Ilmoitukset"
 ],
 "Run new report": [
  null,
  "Tee uusi raportti"
 ],
 "Run report": [
  null,
  "Tee raportti"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "SOS-raportointi kerää järjestelmätietoja auttaakseen ongelmien diagnosoinnissa."
 ],
 "Stop report": [
  null,
  "Pysäytä raportti"
 ],
 "Switch to administrative access": [
  null,
  "Vaihda ylläpitäjän käyttöoikeuksiin"
 ],
 "Switch to limited access": [
  null,
  "Vaihda rajoitettuun käyttöön"
 ],
 "System diagnostics": [
  null,
  "Järjestelmän diagnostiikka"
 ],
 "The file $0 will be deleted.": [
  null,
  "Tiedosto $0 poistetaan."
 ],
 "This information is stored only on the system.": [
  null,
  "Nämä tiedot tallennetaan vain järjestelmään."
 ],
 "Turn on administrative access": [
  null,
  "Ota ylläpitäjän käyttöoikeudet käyttöön"
 ],
 "Use verbose logging": [
  null,
  "Käytä monisanaista lokia"
 ],
 "You now have administrative access.": [
  null,
  "Sinulla on nyt ylläpitäjän käyttöoikeudet."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Selaimesi muistaa käyttöoikeustasosi istuntojen ajan."
 ],
 "show less": [
  null,
  "näytä vähemmän"
 ],
 "show more": [
  null,
  "näytä enemmän"
 ],
 "sos": [
  null,
  "sos"
 ]
});
