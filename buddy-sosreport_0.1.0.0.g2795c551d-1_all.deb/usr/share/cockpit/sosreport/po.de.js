cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Administrativer Zugang"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  "Zum Erstellen und Abrufen von Berichten ist ein administrativer Zugang erforderlich."
 ],
 "Administrative access required": [
  null,
  "Administrativer Zugang erforderlich"
 ],
 "Attributes": [
  null,
  "Attribute"
 ],
 "Authenticate": [
  null,
  "Authentifiziere"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Created": [
  null,
  "Erstellt"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Delete report permanently?": [
  null,
  "Bericht dauerhaft löschen?"
 ],
 "Diagnostic reports": [
  null,
  "Diagnoseberichte"
 ],
 "Download": [
  null,
  "Herunterladen"
 ],
 "Encrypted": [
  null,
  "Verschlüsselt"
 ],
 "Encryption passphrase": [
  null,
  "Verschlüsselungs-Passphrase"
 ],
 "Error": [
  null,
  "Fehler"
 ],
 "Leave empty to skip encryption": [
  null,
  "Leer lassen, um die Verschlüsselung zu überspringen"
 ],
 "Limit access": [
  null,
  "Zugang einschränken"
 ],
 "Limited access": [
  null,
  "Eingeschränkter Zugang"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  "Der eingeschränkte Zugriffsmodus schränkt die administrativen Rechte ein. Einige Teile der Web-Konsole sind in ihrer Funktionalität eingeschränkt."
 ],
 "Method": [
  null,
  "Methode"
 ],
 "No system reports.": [
  null,
  "Keine Systemberichte."
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  "Netzwerkadressen, Hostnamen und Benutzernamen obfuskieren"
 ],
 "Obfuscated": [
  null,
  "Obfuskiert"
 ],
 "Options": [
  null,
  "Einstellungen"
 ],
 "Password": [
  null,
  "Passwort"
 ],
 "Please authenticate to gain administrative access": [
  null,
  "Bitte authentifizieren Sie sich, um administrativen Zugriff zu erhalten"
 ],
 "Problem becoming administrator": [
  null,
  "Problem beim Administrator werden"
 ],
 "Progress: $0": [
  null,
  "Fortschritt: $0"
 ],
 "Report": [
  null,
  "Melden"
 ],
 "Report label": [
  null,
  ""
 ],
 "Reports": [
  null,
  "Berichte"
 ],
 "Run new report": [
  null,
  "Neuen Bericht ausführen"
 ],
 "Run report": [
  null,
  "Bericht ausführen"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  "Die SOS-Berichterstattung sammelt Systeminformationen, die bei der Diagnose von Problemen helfen."
 ],
 "Stop report": [
  null,
  "Bericht stoppen"
 ],
 "Switch to administrative access": [
  null,
  "Auf administrativen Zugang umschalten"
 ],
 "Switch to limited access": [
  null,
  "Auf eingeschränkten Zugang umschalten"
 ],
 "System diagnostics": [
  null,
  "Systemdiagnose"
 ],
 "The file $0 will be deleted.": [
  null,
  "Die Datei $0 wird gelöscht."
 ],
 "This information is stored only on the system.": [
  null,
  "Diese Informationen werden nur auf dem System gespeichert."
 ],
 "Turn on administrative access": [
  null,
  "Administrator-Zugriff aktivieren"
 ],
 "Use verbose logging": [
  null,
  "Ausführliche Protokollierung verwenden"
 ],
 "You now have administrative access.": [
  null,
  "Sie haben nun Administrator Zugriff."
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  "Ihr Browser speichert Ihre Zugriffsstufe über mehrere Sitzungen hinweg."
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ],
 "sos": [
  null,
  "Sos"
 ]
});
