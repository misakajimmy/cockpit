cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Administrative access": [
  null,
  "Acesso administrativo"
 ],
 "Administrative access is required to create and access reports.": [
  null,
  ""
 ],
 "Attributes": [
  null,
  ""
 ],
 "Authenticate": [
  null,
  "Autenticar"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Created": [
  null,
  "Criado"
 ],
 "Delete": [
  null,
  "Excluir"
 ],
 "Diagnostic reports": [
  null,
  "Relatório de diagnostico"
 ],
 "Download": [
  null,
  "Baixar"
 ],
 "Error": [
  null,
  "Erro"
 ],
 "Limit access": [
  null,
  "Limitar acesso"
 ],
 "Limited access": [
  null,
  "Acesso limitado"
 ],
 "Limited access mode restricts administrative privileges. Some parts of the web console will have reduced functionality.": [
  null,
  ""
 ],
 "Method": [
  null,
  ""
 ],
 "Obfuscate network addresses, hostnames, and usernames": [
  null,
  ""
 ],
 "Obfuscated": [
  null,
  ""
 ],
 "Options": [
  null,
  "Opções"
 ],
 "Password": [
  null,
  "Senha"
 ],
 "Please authenticate to gain administrative access": [
  null,
  ""
 ],
 "Progress: $0": [
  null,
  ""
 ],
 "Report": [
  null,
  "Relatório"
 ],
 "SOS reporting collects system information to help with diagnosing problems.": [
  null,
  ""
 ],
 "Switch to limited access": [
  null,
  ""
 ],
 "Turn on administrative access": [
  null,
  ""
 ],
 "You now have administrative access.": [
  null,
  ""
 ],
 "Your browser will remember your access level across sessions.": [
  null,
  ""
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ],
 "sos": [
  null,
  ""
 ]
});
