cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "$0 exited with code $1": [
  null,
  "$0 skončilo s kódom $1"
 ],
 "$0 failed": [
  null,
  "$0 sa nepodarilo"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 nútene ukončené signálom $1"
 ],
 "Cannot forward login credentials": [
  null,
  "Nie je možné preposlať prístupové údaje"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpitu sa nepodarilo kontaktovať daného hostiteľa."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit nie je kompatibilný so sofvérom na systéme."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit nie je nainštalovaný na tomto systéme."
 ],
 "Connection has timed out.": [
  null,
  "Časový limit spojenia vypršal."
 ],
 "Host key is incorrect": [
  null,
  "Kľúč stroja nie je správny"
 ],
 "Internal error": [
  null,
  "Interná chyba"
 ],
 "Login failed": [
  null,
  "Prihlásenie sa nepodarilo"
 ],
 "Not permitted to perform this action.": [
  null,
  "Neoprávený k vykonaniu tejto akcie."
 ],
 "Server has closed the connection.": [
  null,
  "Server zavrel spojenie."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  ""
 ],
 "Too much data": [
  null,
  ""
 ],
 "Untrusted host": [
  null,
  "Nedôveryhodnotný stroj"
 ],
 "Your session has been terminated.": [
  null,
  ""
 ],
 "Your session has expired. Please log in again.": [
  null,
  ""
 ],
 "[$0 bytes of binary data]": [
  null,
  ""
 ],
 "[binary data]": [
  null,
  "[binárne dáta]"
 ],
 "[no data]": [
  null,
  "[žiadne dáta]"
 ]
});
