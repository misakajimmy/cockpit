cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 exited with code $1": [
  null,
  "$0 завершено роботу з кодом $1"
 ],
 "$0 failed": [
  null,
  "Помилка $0"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 завершено з сигналом $1"
 ],
 "Cannot forward login credentials": [
  null,
  "Не вдалося переспрямувати реєстраційні дані для входу"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit не вдалося встановити зв’язок із вказаним вузлом."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit є несумісним із програмним забезпеченням цієї системи."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit у цій системі не встановлено."
 ],
 "Connection has timed out.": [
  null,
  "Вичерпано час очікування на з’єднання."
 ],
 "Host key is incorrect": [
  null,
  "Ключ вузла є неправильним"
 ],
 "Internal error": [
  null,
  "Внутрішня помилка"
 ],
 "Login failed": [
  null,
  "Невдала спроба увійти"
 ],
 "Not permitted to perform this action.": [
  null,
  "Немає дозволу на виконання цієї дії."
 ],
 "Server has closed the connection.": [
  null,
  "З’єднання розірвано сервером."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "Сервер відмовився розпізнавати користувача за допомогою будь-якого з підтримуваних методів."
 ],
 "Too much data": [
  null,
  "Забагато даних"
 ],
 "Untrusted host": [
  null,
  "Ненадійний вузол"
 ],
 "Your session has been terminated.": [
  null,
  "Ваш сеанс перервано."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "Строк роботи у вашому сеансі вичерпано. Будь ласка, увійдіть до системи ще раз."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 байтів двійкових даних]"
 ],
 "[binary data]": [
  null,
  "[двійкові дані]"
 ],
 "[no data]": [
  null,
  "[немає даних]"
 ]
});
