cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "$0 exited with code $1": [
  null,
  "$0 退出代碼 $1"
 ],
 "$0 failed": [
  null,
  "$0 失敗"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 信號殺了 $1"
 ],
 "Cannot forward login credentials": [
  null,
  "無法轉發登錄憑據"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "駕駛艙無法聯繫給定的主人。"
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "駕駛艙與系統上的軟件不兼容。"
 ],
 "Cockpit is not installed on the system.": [
  null,
  "系統上未安裝駕駛艙。"
 ],
 "Connection has timed out.": [
  null,
  "連接已超時。"
 ],
 "Host key is incorrect": [
  null,
  "主機密鑰不正確"
 ],
 "Internal error": [
  null,
  "內部錯誤"
 ],
 "Login failed": [
  null,
  "登錄失敗"
 ],
 "Not permitted to perform this action.": [
  null,
  "不允許執行此操作。"
 ],
 "Server has closed the connection.": [
  null,
  "伺服器已關閉連接。"
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "伺服器拒絕使用任何受支持的方法進行身份驗證。"
 ],
 "Too much data": [
  null,
  "數據太多了"
 ],
 "Untrusted host": [
  null,
  "不受信任的主機"
 ],
 "Your session has been terminated.": [
  null,
  "您的會話已被終止。"
 ],
 "Your session has expired. Please log in again.": [
  null,
  "您的會話已過期。請再次登錄。"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 二進制數據的字節]"
 ],
 "[binary data]": [
  null,
  "[二進制數據]"
 ],
 "[no data]": [
  null,
  "[沒有數據]"
 ]
});
