cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 exited with code $1": [
  null,
  "$0-ის გამოსვლის კოდია $1"
 ],
 "$0 failed": [
  null,
  "$0 წარუმატებელია"
 ],
 "$0 killed with signal $1": [
  null,
  "$0 მოკვდა სიგნალით $1"
 ],
 "Cannot forward login credentials": [
  null,
  "მომხმარებლისადაპაროლის გადაგზავნის შეცდომა"
 ],
 "Cockpit could not contact the given host.": [
  null,
  "Cockpit-ს მითითებულ ჰოსტთან დაკავშირება არ შეუძლია ."
 ],
 "Cockpit is not compatible with the software on the system.": [
  null,
  "Cockpit-ი შეუთავსებელია თქვენს სერვერზე დაყენებულ პროგრამულ უზრუნველყოფასთან."
 ],
 "Cockpit is not installed on the system.": [
  null,
  "Cockpit-ი ამ სისტემაზე დაყენებული არაა."
 ],
 "Connection has timed out.": [
  null,
  "კავშირის დრო გავიდა."
 ],
 "Host key is incorrect": [
  null,
  "ჰოსტის გასაღები არასწორია"
 ],
 "Internal error": [
  null,
  "შიდა შეცდომა"
 ],
 "Login failed": [
  null,
  "შესვლა წარუმატებელია"
 ],
 "Not permitted to perform this action.": [
  null,
  "არ გაქვთ მითითებული მოქმედების შესასრულებლად საკმარისი წვდომა."
 ],
 "Server has closed the connection.": [
  null,
  "სერვერმა დახურა კავშირი."
 ],
 "The server refused to authenticate using any supported methods.": [
  null,
  "სერვერმა ყველა მხარდაჭერილი მეთოდით ავთენტიკაცია უარჰყო."
 ],
 "Too much data": [
  null,
  "მეტისმეტად ბევრი მონაცემი"
 ],
 "Untrusted host": [
  null,
  "არასანდო ჰოსტი"
 ],
 "Your session has been terminated.": [
  null,
  "თქვენი სესია გაწყვეტილია."
 ],
 "Your session has expired. Please log in again.": [
  null,
  "სესიის ვადა გასულია. თავიდან შედით."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[ბინარული მონაცემების $0 ბაიტი]"
 ],
 "[binary data]": [
  null,
  "[ბინარული მონაცემები]"
 ],
 "[no data]": [
  null,
  "[მონაცემების გარეშე]"
 ]
});
