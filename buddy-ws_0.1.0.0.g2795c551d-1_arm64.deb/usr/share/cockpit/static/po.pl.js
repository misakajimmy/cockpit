window.cockpit_po = {
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "            Bypass browser check          ": [
  null,
  "            Obejdź sprawdzanie przeglądarki          "
 ],
 "$0 error": [
  null,
  "błąd $0"
 ],
 "$0 key changed": [
  null,
  "Zmieniono klucz $0"
 ],
 "A modern browser is required for security, reliability, and performance.": [
  null,
  "Z powodów bezpieczeństwa, niezawodności i wydajności wymagana jest nowoczesna przeglądarka."
 ],
 "Accept key and log in": [
  null,
  "Przyjmij klucz i zaloguj się"
 ],
 "Authentication failed": [
  null,
  "Uwierzytelnienie się nie powiodło"
 ],
 "Authentication failed: Server closed connection": [
  null,
  "Uwierzytelnienie się nie powiodło: serwer zamknął połączenie"
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Zmienione klucze są często wynikiem przeinstalowania systemu operacyjnego. Nieoczekiwana zmiana może jednak wskazywać na próbę przechwycenia połączenia przez stronę trzecią."
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit authentication is configured incorrectly.": [
  null,
  "Uwierzytelnianie Cockpit jest niepoprawnie skonfigurowane."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit to menedżer serwerów ułatwiający administrowanie serwerów Linux przez przeglądarkę WWW. Można z łatwością przechodzić między terminalem a narzędziami WWW. Usługa uruchomiona za pomocą Cockpit może zostać zatrzymana za pomocą terminala. Jeśli błąd wystąpi w terminalu, to można go zobaczyć w interfejsie dziennika Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit jest idealny dla nowych administratorów, umożliwiając łatwe wykonywanie prostych zadań, takich jak administracja urządzeniami do przechowywania danych, badanie dzienników oraz uruchamianie i zatrzymywanie usług. Można monitorować i administrować wiele serwerów w tym samym czasie. Wystarczy dodać je pojedynczym kliknięciem."
 ],
 "Cockpit might not render correctly in your browser": [
  null,
  "Cockpit może nie być poprawnie wyświetlany w używanej przeglądarce"
 ],
 "Connect to": [
  null,
  "Połącz z"
 ],
 "Connect to:": [
  null,
  "Połącz z:"
 ],
 "Download a new browser for free": [
  null,
  "Pobierz nową przeglądarkę za darmo"
 ],
 "If the fingerprint matches, click \"Accept key and log in\". Otherwise, do not log in and contact your administrator.": [
  null,
  "Jeśli odcisk się zgadza, należy kliknąć „Przyjmij klucz i zaloguj się”. W przeciwnym przypadku nie należy się logować i należy skontaktować się z administratorem."
 ],
 "Internal error: Invalid challenge header": [
  null,
  "Wewnętrzny błąd: nieprawidłowy nagłówek wyzwania"
 ],
 "Log in": [
  null,
  "Zaloguj"
 ],
 "Log in with your server user account.": [
  null,
  "Logowanie za pomocą konta użytkownika serwera."
 ],
 "Login": [
  null,
  "Logowanie"
 ],
 "Login again": [
  null,
  "Zaloguj ponownie"
 ],
 "Logout successful": [
  null,
  "Pomyślnie wylogowano"
 ],
 "New host": [
  null,
  "Nowy komputer"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Po zainstalowaniu programu Cockpit należy go włączyć za pomocą polecenia „systemctl enable --now cockpit.socket”."
 ],
 "Or use a bundled browser": [
  null,
  "Lub użyj dołączonej przeglądarki"
 ],
 "Other options": [
  null,
  "Inne opcje"
 ],
 "Password": [
  null,
  "Hasło"
 ],
 "Permission denied": [
  null,
  "Odmowa dostępu"
 ],
 "Please enable JavaScript to use the Web Console.": [
  null,
  "Proszę włączyć obsługę języka JavaScript, aby używać konsoli internetowej."
 ],
 "Please specify the host to connect to": [
  null,
  "Proszę podać komputer, z którym się połączyć"
 ],
 "Recent hosts": [
  null,
  "Ostatnie komputery"
 ],
 "Refusing to connect. Host is unknown": [
  null,
  "Odmowa połączenia. Komputer jest nieznany"
 ],
 "Refusing to connect. Hostkey does not match": [
  null,
  "Odmowa połączenia. Klucze komputera się nie zgadzają"
 ],
 "Refusing to connect. Hostkey is unknown": [
  null,
  "Odmowa połączenia. Klucz komputera jest nieznany"
 ],
 "Remove host": [
  null,
  "Usuń komputer"
 ],
 "Server": [
  null,
  "Serwer"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Powstały odcisk można udostępniać publicznie, na przykład przez e-mail."
 ],
 "The server refused to authenticate '$0' using password authentication, and no other supported authentication methods are available.": [
  null,
  "Serwer odmówił uwierzytelnienia „$0” za pomocą hasła, a żadne inne obsługiwane metody uwierzytelniania nie są dostępne."
 ],
 "The web browser configuration prevents Cockpit from running (inaccessible $0)": [
  null,
  "Konfiguracja przeglądarki uniemożliwia działanie programu Cockpit ($0 jest niedostępne)"
 ],
 "This web browser is too old to run the Web Console (missing $0)": [
  null,
  "Ta przeglądarka jest za stara, aby uruchomić konsolę internetową (brak $0)"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Aby upewnić się, że połączenie nie jest przechwytywane przez szkodliwą stronę trzecią, proszę sprawdzić poprawność odcisku klucza komputera:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Aby sprawdzić poprawność odcisku klucza, należy wykonać poniższe polecenie na $0 fizycznie siedząc przy komputerze lub przez zaufaną sieć:"
 ],
 "Try again": [
  null,
  "Spróbuj ponownie"
 ],
 "Unable to connect to that address": [
  null,
  "Nie można połączyć z tym adresem"
 ],
 "User name": [
  null,
  "Nazwa użytkownika"
 ],
 "User name cannot be empty": [
  null,
  "Nazwa użytkownika nie może być pusta"
 ],
 "Validating authentication token": [
  null,
  "Sprawdzanie poprawności tokenu uwierzytelniania"
 ],
 "Web Console for Linux servers": [
  null,
  "Konsola internetowa dla serwerów systemu Linux"
 ],
 "Wrong user name or password": [
  null,
  "Błędna nazwa użytkownika lub hasło"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Łączenie z $0 po raz pierwszy."
 ]
};
