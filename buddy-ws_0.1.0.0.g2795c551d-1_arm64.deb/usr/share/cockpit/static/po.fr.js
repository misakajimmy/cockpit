window.cockpit_po = {
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "            Bypass browser check          ": [
  null,
  "            Ignorer la vérification du navigateur          "
 ],
 "$0 error": [
  null,
  "$0 erreur"
 ],
 "$0 key changed": [
  null,
  "$0 clé modifiée"
 ],
 "A modern browser is required for security, reliability, and performance.": [
  null,
  "Un navigateur moderne est nécessaire pour la sécurité, la fiabilité et la performance."
 ],
 "Accept key and log in": [
  null,
  "Accepter la clé et se connecter"
 ],
 "Authentication failed": [
  null,
  "Échec d’authentification"
 ],
 "Authentication failed: Server closed connection": [
  null,
  "Échec d’authentification : connexion close par le serveur"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Les changements de clés sont souvent le résultat d’une réinstallation du système d’exploitation. Cependant, un changement inattendu peut indiquer une tentative d’interception de votre connexion par un tiers."
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit authentication is configured incorrectly.": [
  null,
  "L’authentification de Cockpit est mal configurée."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit est un gestionnaire de serveur qui facilite l’administration de vos serveurs Linux via un navigateur Web. Sauter entre le terminal et l’outil web n’est pas un problème. Un service démarré via Cockpit peut être arrêté via le terminal. De même, si une erreur se produit dans le terminal, elle s’affiche dans l’interface du journal Cockpit."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit est parfait pour les nouveaux administrateurs système, leur permettant d’effectuer facilement des tâches simples telles que l’administration du stockage, l’inspection des journaux, le démarrage et l’arrêt des services. Vous pouvez surveiller et administrer plusieurs serveurs en même temps. Il suffit de les ajouter en un seul clic et vos machines s’occuperont de leurs pairs."
 ],
 "Cockpit might not render correctly in your browser": [
  null,
  "Cockpit peut ne pas s'afficher correctement dans votre navigateur"
 ],
 "Connect to": [
  null,
  "Se connecter à"
 ],
 "Connect to:": [
  null,
  "Se connecter à :"
 ],
 "Download a new browser for free": [
  null,
  "Télécharger un nouveau navigateur gratuitement"
 ],
 "If the fingerprint matches, click \"Accept key and log in\". Otherwise, do not log in and contact your administrator.": [
  null,
  "Si l’empreinte digitale correspond, cliquez sur « Accepter la clé et se connecter ». Sinon, ne vous connectez pas et contactez votre administrateur."
 ],
 "Internal error: Invalid challenge header": [
  null,
  "Erreur interne : en-tête de la question de Challenge non valide"
 ],
 "Log in": [
  null,
  "Connexion"
 ],
 "Log in with your server user account.": [
  null,
  "Connectez-vous avec votre compte d’utilisateur du serveur."
 ],
 "Login": [
  null,
  "Nom d’utilisateur"
 ],
 "Login again": [
  null,
  "Se connecter à nouveau"
 ],
 "Logout successful": [
  null,
  "Déconnexion réussie"
 ],
 "New host": [
  null,
  "Nouvel hôte"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Une fois que Cockpit est installé, l’activer avec « systemctl enable --now cockpit.socket »."
 ],
 "Or use a bundled browser": [
  null,
  "Ou utilisez un navigateur groupé"
 ],
 "Other options": [
  null,
  "Autres options"
 ],
 "Password": [
  null,
  "Mot de passe"
 ],
 "Permission denied": [
  null,
  "Permission refusée"
 ],
 "Please enable JavaScript to use the Web Console.": [
  null,
  "Veuillez activer JavaScript pour utiliser la console Web."
 ],
 "Please specify the host to connect to": [
  null,
  "Veuillez spécifier l’hôte auquel vous connecter"
 ],
 "Recent hosts": [
  null,
  "Hôtes récents"
 ],
 "Refusing to connect. Host is unknown": [
  null,
  "Connexion refusée. L’hôte est inconnu"
 ],
 "Refusing to connect. Hostkey does not match": [
  null,
  "Connexion refusée. Hostkey ne correspond pas"
 ],
 "Refusing to connect. Hostkey is unknown": [
  null,
  "Connexion refusée. Hostkey est inconnu"
 ],
 "Remove host": [
  null,
  "Retirer l’hôte"
 ],
 "Server": [
  null,
  "Serveur"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "L’empreinte digitale qui en résulte peut être partagée via des méthodes publiques, y compris par courrier électronique."
 ],
 "The server refused to authenticate '$0' using password authentication, and no other supported authentication methods are available.": [
  null,
  "Le serveur a refusé d’authentifier « $0 » en utilisant l’authentification par mot de passe, et aucune autre méthode d’authentification prise en charge n’est disponible."
 ],
 "The web browser configuration prevents Cockpit from running (inaccessible $0)": [
  null,
  "La configuration du navigateur Web empêche l’exécution de Cockpit (inaccessible $0 )"
 ],
 "This web browser is too old to run the Web Console (missing $0)": [
  null,
  "Ce navigateur est trop vieux pour faire fonctionner la console Web (manquant $0)"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Pour vous assurer que votre connexion n’est pas interceptée par un tiers malveillant, veuillez vérifier l’empreinte de la clé de l’hôte :"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Pour vérifier une empreinte digitale, exécutez les opérations suivantes sur $0 en étant physiquement assis devant la machine ou en passant par un réseau de confiance :"
 ],
 "Try again": [
  null,
  "Réessayer"
 ],
 "Unable to connect to that address": [
  null,
  "Incapable de se connecter à cette adresse"
 ],
 "User name": [
  null,
  "Nom d’utilisateur"
 ],
 "User name cannot be empty": [
  null,
  "Le nom d’utilisateur ne peut pas être vide"
 ],
 "Validating authentication token": [
  null,
  "Validation du jeton d’authentification"
 ],
 "Web Console for Linux servers": [
  null,
  "Console web pour serveurs Linux"
 ],
 "Wrong user name or password": [
  null,
  "Mauvais nom d’utilisateur ou mot de passe"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Vous vous connectez à $0 pour la première fois."
 ]
};
