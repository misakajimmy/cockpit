window.cockpit_po = {
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "            Bypass browser check          ": [
  null,
  ""
 ],
 "$0 error": [
  null,
  "$0 feil"
 ],
 "$0 key changed": [
  null,
  "$0 nøkkel endret"
 ],
 "A modern browser is required for security, reliability, and performance.": [
  null,
  "Det kreves en moderne nettleser for sikkerhet, pålitelighet og ytelse."
 ],
 "Accept key and log in": [
  null,
  "Godta nøkkel og logg inn"
 ],
 "Authentication failed": [
  null,
  "Autentisering feilet"
 ],
 "Authentication failed: Server closed connection": [
  null,
  "Autentisering feilet: Serveren lukket tilkoblingen"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Endrede nøkler er ofte resultatet av reinstallering av operativsystemet. Imidlertid kan en uventet endring indikere et tredjepartsforsøk på å fange opp forbindelsen din."
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit authentication is configured incorrectly.": [
  null,
  "Cockpit autentisering er konfigurert feil."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit er en serveradministrator som gjør det enkelt å administrere Linux-serverne dine via en nettleser. Å bytte mellom terminalen og nettverktøyet er ikke noe problem. En tjeneste startet via Cockpit kan stoppes via terminalen. På samme måte, hvis det oppstår en feil i terminalen, kan den sees i Cockpit journal-grensesnittet."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit er perfekt for nye sysadminer, slik at de enkelt kan utføre enkle oppgaver som lagringsadministrasjon, inspisere journaler og starte og stoppe tjenester. Du kan overvåke og administrere flere servere samtidig. Bare legg dem til med et enkelt klikk, så vil maskinene dine se etter kompisene."
 ],
 "Cockpit might not render correctly in your browser": [
  null,
  ""
 ],
 "Connect to": [
  null,
  "Koble til"
 ],
 "Download a new browser for free": [
  null,
  "Last ned en ny nettleser gratis"
 ],
 "If the fingerprint matches, click \"Accept key and log in\". Otherwise, do not log in and contact your administrator.": [
  null,
  "Hvis fingeravtrykket stemmer overens, klikker du på \"Godta nøkkel og logg inn\". Ellers ikke logg inn og kontakt administratoren din."
 ],
 "Internal error: Invalid challenge header": [
  null,
  ""
 ],
 "Log in": [
  null,
  "Logg inn"
 ],
 "Log in with your server user account.": [
  null,
  "Logg inn med server brukerkontoen din."
 ],
 "Login again": [
  null,
  "Logg inn igjen"
 ],
 "Logout successful": [
  null,
  ""
 ],
 "New host": [
  null,
  "Ny vert"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Når Cockpit er installert, kan den aktiveres med \"systemctl enable --now cockpit.socket\"."
 ],
 "Or use a bundled browser": [
  null,
  "Eller bruk en nettleser som følger med"
 ],
 "Other options": [
  null,
  "Andre alternativer"
 ],
 "Password": [
  null,
  "Passord"
 ],
 "Permission denied": [
  null,
  "Ingen tilgang"
 ],
 "Please enable JavaScript to use the Web Console.": [
  null,
  "Aktiver JavaScript for å bruke Web konsollet."
 ],
 "Please specify the host to connect to": [
  null,
  "Vennligst angi verten du vil koble til"
 ],
 "Refusing to connect. Host is unknown": [
  null,
  "Nekter å koble til. Verten er ukjent"
 ],
 "Refusing to connect. Hostkey does not match": [
  null,
  "Nekter å koble til. Vertsnøkkel samsvarer ikke"
 ],
 "Refusing to connect. Hostkey is unknown": [
  null,
  "Nekter å koble til. Vertsnøkkel er ukjent"
 ],
 "Server": [
  null,
  "Server"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "Det resulterende fingeravtrykket er greit å dele via offentlige metoder, inkludert e-post."
 ],
 "The server refused to authenticate '$0' using password authentication, and no other supported authentication methods are available.": [
  null,
  "Serveren nektet å autentisere '$0' ved hjelp av passordgodkjenning, og ingen andre støttede godkjenningsmetoder er tilgjengelige."
 ],
 "The web browser configuration prevents Cockpit from running (inaccessible $0)": [
  null,
  "Nettleserkonfigurasjonen forhindrer Cockpit i å kjøre (utilgjengelig $0)"
 ],
 "This web browser is too old to run the Web Console (missing $0)": [
  null,
  "Denne nettleseren er for gammel til å kjøre web konsollet (mangler $0)"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "For å sikre at forbindelsen din ikke blir fanget opp av en ondsinnet tredjepart, må du verifisere vertsnøkkelens fingeravtrykk:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "For å bekrefte et fingeravtrykk, kjør følgende på $ 0 mens du sitter fysisk ved maskinen eller gjennom et pålitelig nettverk:"
 ],
 "Try again": [
  null,
  "Prøv på nytt"
 ],
 "Unable to connect to that address": [
  null,
  "Kan ikke koble til den adressen"
 ],
 "User name": [
  null,
  "Brukernavn"
 ],
 "User name cannot be empty": [
  null,
  "Brukernavnet kan ikke være tomt"
 ],
 "Validating authentication token": [
  null,
  "Validerer godkjenningstoken"
 ],
 "Web Console for Linux servers": [
  null,
  "Web konsoll for Linux servere"
 ],
 "Wrong user name or password": [
  null,
  "Feil brukernavn eller passord"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Du kobler til $0 for første gang."
 ]
};
