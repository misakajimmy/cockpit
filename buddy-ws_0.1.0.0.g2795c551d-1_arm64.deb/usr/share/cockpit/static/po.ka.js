window.cockpit_po = {
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "            Bypass browser check          ": [
  null,
  "            ბრაუზერის შემოწმების გამოტოვება          "
 ],
 "$0 error": [
  null,
  "$0 შეცდომა"
 ],
 "$0 key changed": [
  null,
  "$0 გასაღები შეიცვალა"
 ],
 "A modern browser is required for security, reliability, and performance.": [
  null,
  "უსაფრთხოებისთვის, წარმადობისთვის და საიმედოობისთვის საჭიროა ახალი ბრაუზერი."
 ],
 "Accept key and log in": [
  null,
  "მიიღეთ გასაღები და შედით"
 ],
 "Authentication failed": [
  null,
  "ავთენტიკაციის შეცდომა"
 ],
 "Authentication failed: Server closed connection": [
  null,
  "ავთენტიკაციის შეცდომა: სერვერმა კავშირი დახურა"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "შეცვლილი გასაღებები ხშირად ოპერაციული სისტემის გადაყენებაზე მიუთითებს. ამავე დროს მოულოდნელი ცვლილება კავშირის გადასაჭერად მესამე პირის ჩარევასაც შეიძლება ნიშნავდეს."
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit authentication is configured incorrectly.": [
  null,
  "Cockpit-ის ავთენტიკაციის არასწორი კონფიგურაცია."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit წარმოადგენს სერვერის მმართველს, რომლითაც Linux სერვერების ადმინისტრირება ბრაუზერითაც შეგიძლიათ. ტერმინალსა და ვებ ხელსაწყოს შორის გადართვა პრობლემა არაა. Cockpit-ით გაშვებული სერვისი შეგიძლიათ გააჩეროთ ტერმინალთაც. ასევე, თუ შეცდომა დაფიქსირდება ტერმინალში, მისი ნახვა Cockpit-ის საშუალებითაც შეგიძლიათ."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit შესანიშნავია ახალი სისტემური ადმინისტრატორებისთვის. ის მათ საშუალებას აძლევს ადვილად შეასრულონ ისეთი მარტივი ამოცანები, როგორიცაა შენახვის ადმინისტრირება, ჟურნალების შემოწმება და სერვისების დაწყება და გაჩერება. შეგიძლიათ ერთდროულად რამდენიმე სერვერის მონიტორინგი და ადმინისტრირება. უბრალოდ დაამატეთ ისინი ერთი დაწკაპუნებით და თქვენი მანქანები იზრუნებს მის მეგობრებზე."
 ],
 "Cockpit might not render correctly in your browser": [
  null,
  "Cockpit-ი თქვენს ბრაუზერში შეიძლება არასწორად გამოჩნდეს"
 ],
 "Connect to": [
  null,
  "დაკავშირება"
 ],
 "Connect to:": [
  null,
  "დაკავშირება:"
 ],
 "Download a new browser for free": [
  null,
  "გადმოწერეთ ახალი ბრაუზერი უფასოდ"
 ],
 "If the fingerprint matches, click \"Accept key and log in\". Otherwise, do not log in and contact your administrator.": [
  null,
  "თუ ანაბეჭდი ემთხვევა, დააწექით \"გასაღების მიღება და შესვლა\"-ს. ან არ შეხვიდეთ და დაუკავშირდით ადმინისტრატორს."
 ],
 "Internal error: Invalid challenge header": [
  null,
  "შიდა შეცდომა: გამოწვევის არასწორი თავსართი"
 ],
 "Log in": [
  null,
  "შესვლა"
 ],
 "Log in with your server user account.": [
  null,
  "შედით სერვერის თქვენი ანგარიშით."
 ],
 "Login": [
  null,
  "შესვლა"
 ],
 "Login again": [
  null,
  "თავიდან შესვლა"
 ],
 "Logout successful": [
  null,
  "გასვლა წარმატებულია"
 ],
 "New host": [
  null,
  "ახალი ჰოსტი"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "როცა Cockpit-ს დააყენებთ, შეგიძლიათ მისი ჩართვაც, ბრძანებით \"systemctl enable --now cockpit.socket\"."
 ],
 "Or use a bundled browser": [
  null,
  "ან გამოიყენეთ მოყოლილი ბრაუზერი"
 ],
 "Other options": [
  null,
  "სხვა პარამეტრები"
 ],
 "Password": [
  null,
  "პაროლი"
 ],
 "Permission denied": [
  null,
  "წვდომა აკრძალულია"
 ],
 "Please enable JavaScript to use the Web Console.": [
  null,
  "ვებ კონსოლის გამოსაყენებლად საჭიროა JavaScript-ის ჩართვა."
 ],
 "Please specify the host to connect to": [
  null,
  "შეიყვანეთ მისაერთებელი ჰოსტის სახელი"
 ],
 "Recent hosts": [
  null,
  "ბოლო ჰოსტები"
 ],
 "Refusing to connect. Host is unknown": [
  null,
  "კავშირი უარყოფილია. ჰოსტი უცნობია"
 ],
 "Refusing to connect. Hostkey does not match": [
  null,
  "კავშირი უარყოფითია. ჰოსტის გასაღებები არ ემთხვევა"
 ],
 "Refusing to connect. Hostkey is unknown": [
  null,
  "კავშირი უარყოფილია. ჰოსტის უცნობი გასაღები"
 ],
 "Remove host": [
  null,
  "ჰოსტის წაშლა"
 ],
 "Server": [
  null,
  "სერვერი"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "მიღებული ანაბეჭდების გაზიარება პრობლემა არაა."
 ],
 "The server refused to authenticate '$0' using password authentication, and no other supported authentication methods are available.": [
  null,
  "სერვერმა უარყო $0-ის ავთენტიკაცია პაროლის საშუალებით და ავთენტიკაციის სხვა საშუალებები ხელმიუწვდომელია."
 ],
 "The web browser configuration prevents Cockpit from running (inaccessible $0)": [
  null,
  "Cockpit-ის გაშვება შეუძლებელია ბრაუზერის კონფიგურაციის გამო ($0 მიუწვდომელია)"
 ],
 "This web browser is too old to run the Web Console (missing $0)": [
  null,
  "ეს ბრაუზერ ძალიან ძველია ვებ კონსოლის გასაშვებად (არ გააჩნია $0)"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "იმაში დასარწმუნებლად, რომ არ ხდება კავშირის გადაჭერა, შეამოწმეთ ჰოსტის ანაბეჭდი:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "ანაბეჭდის შესამოწმებლად გაუშვით ეს ბრძანება $0-ზე როცა ფიზიკურად ან სანდო ქსელით იქნებით შესული მანქანაზე:"
 ],
 "Try again": [
  null,
  "თავიდან სცადეთ"
 ],
 "Unable to connect to that address": [
  null,
  "მისამართზე დაკავშირების შეცდომა"
 ],
 "User name": [
  null,
  "მომხმარებლის სახელი"
 ],
 "User name cannot be empty": [
  null,
  "მომხმარებლის სახელი ცარიელი არ შეიძლება იყოს"
 ],
 "Validating authentication token": [
  null,
  "ავთენტიკაციის კოდის გადამოწმება"
 ],
 "Web Console for Linux servers": [
  null,
  "ვებ კონსოლი Linux სერვერებისთვის"
 ],
 "Wrong user name or password": [
  null,
  "არასწორი მოხმარებელი ან პაროლი"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "$0-ს პირველად უკავშირდებით."
 ]
};
