window.cockpit_po = {
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "            Bypass browser check          ": [
  null,
  ""
 ],
 "$0 error": [
  null,
  "$0 錯誤"
 ],
 "A modern browser is required for security, reliability, and performance.": [
  null,
  "安全性，可靠性和性能需要現代瀏覽器。"
 ],
 "Accept key and log in": [
  null,
  ""
 ],
 "Authentication failed: Server closed connection": [
  null,
  "身份驗證失敗：伺服器已中斷連接"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  ""
 ],
 "Cockpit": [
  null,
  ""
 ],
 "Cockpit authentication is configured incorrectly.": [
  null,
  "駕駛艙身份驗證配置不正確。"
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit是一個伺服器管理器，可以通過Web瀏覽器輕鬆管理Linux伺服器。在終端和Web工具之間跳轉是沒有問題的。可以通過終端停止通過Cockpit啟動的服務。同樣，如果終端中發生錯誤，可以在駕駛艙日誌界面中看到。"
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "駕駛艙非常適合新的系統管理員，使他們能夠輕鬆執行簡單的任務，如存儲管理，檢查期刊以及啟動和停止服務。您可以同時監視和管理多個伺服器。只需點擊一下即可新增它們，您的機器將照顧好友。"
 ],
 "Cockpit might not render correctly in your browser": [
  null,
  ""
 ],
 "Connect to": [
  null,
  "連接至"
 ],
 "Download a new browser for free": [
  null,
  "免費下載新的瀏覽器"
 ],
 "If the fingerprint matches, click \"Accept key and log in\". Otherwise, do not log in and contact your administrator.": [
  null,
  ""
 ],
 "Internal error: Invalid challenge header": [
  null,
  "內部錯誤：無效的質詢標頭"
 ],
 "Log in": [
  null,
  "登入"
 ],
 "Log in with your server user account.": [
  null,
  "使用您的伺服器用戶帳號登錄。"
 ],
 "Login again": [
  null,
  "再次登錄"
 ],
 "Logout successful": [
  null,
  "註銷成功"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "安裝Cockpit後，使用“systemctl enable --now cockpit.socket”啟用它。"
 ],
 "Or use a bundled browser": [
  null,
  "或者使用捆綁的瀏覽器"
 ],
 "Other options": [
  null,
  "其他選擇"
 ],
 "Password": [
  null,
  "密碼"
 ],
 "Permission denied": [
  null,
  "使用權限被拒"
 ],
 "Please enable JavaScript to use the Web Console.": [
  null,
  ""
 ],
 "Please specify the host to connect to": [
  null,
  "請指定要連接的主機"
 ],
 "Refusing to connect. Host is unknown": [
  null,
  "拒絕連接。主持人不明"
 ],
 "Refusing to connect. Hostkey does not match": [
  null,
  "拒絕連接。 Hostkey不匹配"
 ],
 "Refusing to connect. Hostkey is unknown": [
  null,
  "拒絕連接。 Hostkey未知"
 ],
 "Server": [
  null,
  "伺服器"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  ""
 ],
 "The server refused to authenticate '$0' using password authentication, and no other supported authentication methods are available.": [
  null,
  "伺服器拒絕驗證'$0'使用密碼驗證，並且沒有其他支持的驗證方法可用。"
 ],
 "The web browser configuration prevents Cockpit from running (inaccessible $0)": [
  null,
  "Web瀏覽器配置可防止Cockpit運行（無法訪問） $0）"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  ""
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  ""
 ],
 "Try again": [
  null,
  "再試一次"
 ],
 "Unable to connect to that address": [
  null,
  "無法連接到該地址"
 ],
 "User name": [
  null,
  "使用者名稱"
 ],
 "User name cannot be empty": [
  null,
  "用戶名不能為空"
 ],
 "Validating authentication token": [
  null,
  "驗證身份驗證令牌"
 ],
 "Web Console for Linux servers": [
  null,
  "Linux伺服器的Web控制台"
 ],
 "Wrong user name or password": [
  null,
  "錯誤的用戶名或密碼"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  ""
 ]
};
