window.cockpit_po = {
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "            Bypass browser check          ": [
  null,
  "            웹 탐색기 점검을 우회합니다          "
 ],
 "$0 error": [
  null,
  "$0 오류"
 ],
 "$0 key changed": [
  null,
  "$0 키 변경됩니다"
 ],
 "A modern browser is required for security, reliability, and performance.": [
  null,
  "보안, 안정성, 성능을 위해 최신 브라우저가 필요합니다."
 ],
 "Accept key and log in": [
  null,
  "키 수락 및 로그인"
 ],
 "Authentication failed": [
  null,
  "인증 실패"
 ],
 "Authentication failed: Server closed connection": [
  null,
  "인증 실패: 서버 연결 끊김"
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "때때로 운영 체제 재설치로 인해 키가 변경될 수 있습니다. 그러나 예기치 않은 변경은 연결을 가로채는 타사의 시도를 나타낼 수도 있습니다."
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit authentication is configured incorrectly.": [
  null,
  "Cockpit 인증이 잘못 설정되어 있습니다."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit은 웹 브라우저에서 리눅스 서버를 쉽게 관리 할 수 있는 서버 관리자입니다. 터미널과 웹 도구을 구분하지 않고 사용할 수 있습니다. Cockpit에서 시작된 서비스는 터미널을 통해 중지할 수 있습니다. 마찬가지로 터미널에서 오류가 발생한 경우 해당 오류를 Cockpit 저널 연결장치에서 확인 할 수 있습니다."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit은 경험이 적은 시스템 관리자에게 적합합니다. 시스템 관리자는 저장장치 관리, 저널 검사, 서비스 시작 및 중지 등의 간단한 작업을 쉽게 수행할 수 있으며 여러 서버를 동시에 모니터링 및 관리 할 수 있습니다. 간단하게 장비를 추가하여 서버를 추가할 수 있으며 추가 후 다른 기기를 관리할 수 있습니다."
 ],
 "Cockpit might not render correctly in your browser": [
  null,
  "Cockpit은 자신의 웹 탐색기에서 정확하게 렌더링 되지 않을 수 있습니다"
 ],
 "Connect to": [
  null,
  "연결 대상"
 ],
 "Connect to:": [
  null,
  "연결 대상:"
 ],
 "Download a new browser for free": [
  null,
  "신규 브라우저 내려받기 (무료)"
 ],
 "If the fingerprint matches, click \"Accept key and log in\". Otherwise, do not log in and contact your administrator.": [
  null,
  "지문이 일치하면 \"키 수락 및 로그인\"을 눌러주세요. 일치 하지 않을 경우 로그인하지 않고 관리자에게 문의하십시오."
 ],
 "Internal error: Invalid challenge header": [
  null,
  "내부 오류: 잘못된 챌린지 헤더"
 ],
 "Log in": [
  null,
  "로그인"
 ],
 "Log in with your server user account.": [
  null,
  "서버 사용자 계정으로 로그인합니다."
 ],
 "Login": [
  null,
  "로그인"
 ],
 "Login again": [
  null,
  "다시 로그인"
 ],
 "Logout successful": [
  null,
  "성공적으로 로그아웃되었습니다"
 ],
 "New host": [
  null,
  "신규 호스트"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Cockpit이 설치되면 \"systemctl enable --now cockpit.socket\"을 사용하여 이를 활성화합니다."
 ],
 "Or use a bundled browser": [
  null,
  "번들된 브라우저 사용"
 ],
 "Other options": [
  null,
  "기타 옵션"
 ],
 "Password": [
  null,
  "비밀번호"
 ],
 "Permission denied": [
  null,
  "권한이 거부되었습니다"
 ],
 "Please enable JavaScript to use the Web Console.": [
  null,
  "웹 콘솔을 사용하려면 JavaScript를 활성화하십시오."
 ],
 "Please specify the host to connect to": [
  null,
  "연결할 호스트를 지정해 주십시오"
 ],
 "Recent hosts": [
  null,
  "최근 호스트"
 ],
 "Refusing to connect. Host is unknown": [
  null,
  "연결을 거부하고 있습니다. 알 수 없는 호스트입니다"
 ],
 "Refusing to connect. Hostkey does not match": [
  null,
  "연결을 거부하고 있습니다. 호스트 키가 일치하지 않습니다"
 ],
 "Refusing to connect. Hostkey is unknown": [
  null,
  "연결을 거부하고 있습니다. 알 수 없는 호스트 키입니다"
 ],
 "Remove host": [
  null,
  "호스트 제거"
 ],
 "Server": [
  null,
  "서버"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "최종 지문을 전자우편을 포함한 공개적인 방법을 통해 공유 할 수 있습니다."
 ],
 "The server refused to authenticate '$0' using password authentication, and no other supported authentication methods are available.": [
  null,
  "서버가 비밀번호 인증을 사용하여 '$0' 인증을 거부했습니다. 지원되는 다른 인증 방법을 사용 할 수 없습니다."
 ],
 "The web browser configuration prevents Cockpit from running (inaccessible $0)": [
  null,
  "웹 브라우저의 설정에 따라 Cockpit이 실행되지 않습니다 (액세스 불가능 $0)"
 ],
 "This web browser is too old to run the Web Console (missing $0)": [
  null,
  "이 웹 브라우저는 오래되어 웹 콘솔을 실행할 수 없습니다($0 누락)"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "악성의 제3자가 귀하의 연결을 가로채지 않도록 하려면 호스트 키 지문을 확인하십시오:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "지문을 확인하려면 물리적인 장치 또는 신뢰할 수 있는 네트워크를 통해 $0에서 다음을 실행합니다:"
 ],
 "Try again": [
  null,
  "다시 시도"
 ],
 "Unable to connect to that address": [
  null,
  "해당 주소에 연결 할 수 없음"
 ],
 "User name": [
  null,
  "사용자 이름"
 ],
 "User name cannot be empty": [
  null,
  "사용자 이름을 입력하셔야 합니다"
 ],
 "Validating authentication token": [
  null,
  "인증 토큰 확인"
 ],
 "Web Console for Linux servers": [
  null,
  "리눅스 서버를 위한 웹콘솔"
 ],
 "Wrong user name or password": [
  null,
  "잘못된 사용자 이름 또는 비밀번호"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "처음으로 $0에 연결됩니다."
 ]
};
