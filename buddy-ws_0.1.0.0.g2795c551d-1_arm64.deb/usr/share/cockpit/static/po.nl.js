window.cockpit_po = {
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "            Bypass browser check          ": [
  null,
  "            Browsercontrole omzeilen          "
 ],
 "$0 error": [
  null,
  "$0 fout"
 ],
 "$0 key changed": [
  null,
  "$0 sleutel gewijzigd"
 ],
 "A modern browser is required for security, reliability, and performance.": [
  null,
  "Een moderne browser is vereist voor goede beveiliging, betrouwbaarheid en prestaties."
 ],
 "Accept key and log in": [
  null,
  "Accepteer sleutel en log in"
 ],
 "Authentication failed": [
  null,
  "Authenticatie mislukte"
 ],
 "Authentication failed: Server closed connection": [
  null,
  "Authenticatie mislukte: Server verbrak verbinding"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Changed keys are often the result of an operating system reinstallation. However, an unexpected change may indicate a third-party attempt to intercept your connection.": [
  null,
  "Gewijzigde sleutels zijn vaak het resultaat van een herinstallatie van het besturingssysteem. Een onverwachte wijziging kan echter wijzen op een poging van derden om je verbinding te onderscheppen."
 ],
 "Cockpit": [
  null,
  "Cockpit"
 ],
 "Cockpit authentication is configured incorrectly.": [
  null,
  "Cockpit authenticatie is verkeerd geconfigureerd."
 ],
 "Cockpit is a server manager that makes it easy to administer your Linux servers via a web browser. Jumping between the terminal and the web tool is no problem. A service started via Cockpit can be stopped via the terminal. Likewise, if an error occurs in the terminal, it can be seen in the Cockpit journal interface.": [
  null,
  "Cockpit is een serverbeheerder waarmee je Linux-servers eenvoudig kunt beheren via een webbrowser. Omschakelen tussen de terminal en het webgereedschap is geen probleem. Een service gestart via Cockpit kan via de terminal worden gestopt. Evenzo, als er een fout optreedt in de terminal, kan deze worden gezien in de Cockpit-logboekinterface."
 ],
 "Cockpit is perfect for new sysadmins, allowing them to easily perform simple tasks such as storage administration, inspecting journals and starting and stopping services. You can monitor and administer several servers at the same time. Just add them with a single click and your machines will look after its buddies.": [
  null,
  "Cockpit is perfect voor nieuwe systeembeheerders, waardoor ze eenvoudig eenvoudige taken kunnen uitvoeren, zoals opslagbeheer, het inspecteren van logboeken en het starten en stoppen van services. Je kunt meerdere servers tegelijkertijd bewaken en beheren. Voeg ze gewoon toe met een enkele klik en je machines zullen voor zijn maatjes zorgen."
 ],
 "Cockpit might not render correctly in your browser": [
  null,
  "Cockpit wordt mogelijk niet correct weergegeven in je browser"
 ],
 "Connect to": [
  null,
  "Verbinden met"
 ],
 "Connect to:": [
  null,
  "Verbinden met:"
 ],
 "Download a new browser for free": [
  null,
  "Download gratis een nieuwe browser"
 ],
 "If the fingerprint matches, click \"Accept key and log in\". Otherwise, do not log in and contact your administrator.": [
  null,
  "Als de vingerafdruk overeenkomt, klik dan op \"Accepteer sleutel en log in\". Log anders niet in en neem contact op met je beheerder."
 ],
 "Internal error: Invalid challenge header": [
  null,
  "Interne fout: ongeldige exceptie koptekst"
 ],
 "Log in": [
  null,
  "Inloggen"
 ],
 "Log in with your server user account.": [
  null,
  "Log in met je servergebruikersaccount."
 ],
 "Login": [
  null,
  "Log in"
 ],
 "Login again": [
  null,
  "Log opnieuw in"
 ],
 "Logout successful": [
  null,
  "Uitloggen succesvol"
 ],
 "New host": [
  null,
  "Nieuwe host"
 ],
 "Once Cockpit is installed, enable it with \"systemctl enable --now cockpit.socket\".": [
  null,
  "Nadat Cockpit geïnstalleerd is, schakel je het in met \"systemctl enable --now cockpit.socket\"."
 ],
 "Or use a bundled browser": [
  null,
  "Of gebruik een gebundelde browser"
 ],
 "Other options": [
  null,
  "Andere opties"
 ],
 "Password": [
  null,
  "Wachtwoord"
 ],
 "Permission denied": [
  null,
  "Toestemming geweigerd"
 ],
 "Please enable JavaScript to use the Web Console.": [
  null,
  "Zet JavaScript aan om de Webconsole te gebruiken."
 ],
 "Please specify the host to connect to": [
  null,
  "Geef de host op waarmee je verbinding wilt maken"
 ],
 "Recent hosts": [
  null,
  "Recente hosts"
 ],
 "Refusing to connect. Host is unknown": [
  null,
  "Verbinding maken geweigerd. Host is onbekend"
 ],
 "Refusing to connect. Hostkey does not match": [
  null,
  "Verbinding maken geweigerd. Hostsleutel komt niet overeen"
 ],
 "Refusing to connect. Hostkey is unknown": [
  null,
  "Verbinding maken geweigerd. Hostsleutel is onbekend"
 ],
 "Remove host": [
  null,
  "Verwijder host"
 ],
 "Server": [
  null,
  "Server"
 ],
 "The resulting fingerprint is fine to share via public methods, including email.": [
  null,
  "De resulterende vingerafdruk is prima te delen via openbare methoden, inclusief e-mail."
 ],
 "The server refused to authenticate '$0' using password authentication, and no other supported authentication methods are available.": [
  null,
  "De server weigerde '$0' te verifiëren met wachtwoordverificatie en er zijn geen andere ondersteunde verificatiemethoden beschikbaar."
 ],
 "The web browser configuration prevents Cockpit from running (inaccessible $0)": [
  null,
  "De configuratie van de webbrowser voorkomt dat Cockpit wordt uitgevoerd (ontoegankelijk $0)"
 ],
 "This web browser is too old to run the Web Console (missing $0)": [
  null,
  "Deze webbrowser is te oud om de Webconsole uit te voeren ($0 ontbreekt)"
 ],
 "To ensure that your connection is not intercepted by a malicious third-party, please verify the host key fingerprint:": [
  null,
  "Controleer de vingerafdruk van de hostsleutel om ervoor te zorgen dat je verbinding niet wordt onderschept door een kwaadwillende derde partij:"
 ],
 "To verify a fingerprint, run the following on $0 while physically sitting at the machine or through a trusted network:": [
  null,
  "Om een vingerafdruk te verifiëren, voer je het volgende uit op $0 terwijl je fysiek achter de machine zit of via een vertrouwd netwerk:"
 ],
 "Try again": [
  null,
  "Probeer opnieuw"
 ],
 "Unable to connect to that address": [
  null,
  "Kan niet verbinden met dat adres"
 ],
 "User name": [
  null,
  "Gebruikersnaam"
 ],
 "User name cannot be empty": [
  null,
  "Gebruikersnaam mag niet leeg zijn"
 ],
 "Validating authentication token": [
  null,
  "Verificatietoken valideren"
 ],
 "Web Console for Linux servers": [
  null,
  "Webconsole voor Linux-servers"
 ],
 "Wrong user name or password": [
  null,
  "Verkeerde gebruikersnaam of wachtwoord"
 ],
 "You are connecting to $0 for the first time.": [
  null,
  "Je maakt voor de eerste keer verbinding met $0."
 ]
};
