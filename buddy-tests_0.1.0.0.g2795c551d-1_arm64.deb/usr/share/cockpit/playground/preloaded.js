/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "cockpit":
/*!**************************!*\
  !*** external "cockpit" ***!
  \**************************/
/***/ ((module) => {

module.exports = cockpit;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!*************************************!*\
  !*** ./pkg/playground/preloaded.js ***!
  \*************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var cockpit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cockpit */ "cockpit");
/* harmony import */ var cockpit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cockpit__WEBPACK_IMPORTED_MODULE_0__);




// This is the basic structure of a preloaded page.  It has a two
// phase initialization: phase 1 while it is still invisible, and
// phase 2 when it becomes visible.
//
// Elements on the page (including the body) are made visible only
// once the page itself is visible.  Otherwise layout might go wrong
// and not recover automatically.

function init_1() {
  return cockpit__WEBPACK_IMPORTED_MODULE_0___default().spawn(["hostname"]).then(data => {
    document.getElementById("host").innerText = data.trim();
  });
}
function init_2() {
  return cockpit__WEBPACK_IMPORTED_MODULE_0___default().file("/etc/os-release").read().then(data => {
    document.getElementById("release").innerText = data;
  });
}
function navigate() {
  document.getElementById("path").innerText = cockpit__WEBPACK_IMPORTED_MODULE_0___default().location.path.join("/");
  document.body.removeAttribute("hidden");
}
function maybe_phase_2() {
  cockpit__WEBPACK_IMPORTED_MODULE_0___default().removeEventListener("visibilitychange", maybe_phase_2);
  if ((cockpit__WEBPACK_IMPORTED_MODULE_0___default().hidden)) {
    cockpit__WEBPACK_IMPORTED_MODULE_0___default().addEventListener("visibilitychange", maybe_phase_2);
  } else {
    init_2().then(navigate);
  }
}
function init() {
  init_1().then(maybe_phase_2);
}
document.addEventListener("DOMContentLoaded", init);
})();

/******/ })()
;
//# sourceMappingURL=preloaded.js.map