cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagar"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk saknas",
  "$0 diskar saknas"
 ],
 "$0 hour": [
  null,
  "$0 timme",
  "$0 timmar"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minuter"
 ],
 "$0 month": [
  null,
  "$0 månad",
  "$0 månader"
 ],
 "$0 week": [
  null,
  "$0 vecka",
  "$0 veckor"
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 timme"
 ],
 "1 week": [
  null,
  "1 vecka"
 ],
 "5 minutes": [
  null,
  "5 minuter"
 ],
 "6 hours": [
  null,
  "6 timmar"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Control": [
  null,
  "Styrning"
 ],
 "Create": [
  null,
  "Skapa"
 ],
 "Development": [
  null,
  "Utveckling"
 ],
 "Empty": [
  null,
  "Tom"
 ],
 "Go to now": [
  null,
  "Gå till nu"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "No such file or directory": [
  null,
  "Filen eller katalogen finns inte"
 ],
 "Not ready": [
  null,
  "Inte klar"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Path to file": [
  null,
  "Sökväg till filen"
 ],
 "Ready": [
  null,
  "Klar"
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Unavailable": [
  null,
  "Otillgänglig"
 ],
 "View all logs": [
  null,
  "Visa alla loggar"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 byte med binärdata]"
 ],
 "[binary data]": [
  null,
  "[binärdata]"
 ],
 "[no data]": [
  null,
  "[inga data]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 disk saknas",
  "$0 diskar saknas"
 ],
 "key\u0004Control": [
  null,
  "Styrning"
 ],
 "verb\u0004Empty": [
  null,
  "Töm"
 ],
 "verb\u0004Ready": [
  null,
  "Klar"
 ]
});
