cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 dia",
  "$0 dias"
 ],
 "$0 disk is missing": [
  null,
  "$0 disco não encontrado",
  "$0 discos não encontrados"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "$0 month": [
  null,
  "$0 mês",
  "$0 meses"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 year": [
  null,
  "$0 ano",
  "$0 anos"
 ],
 "1 day": [
  null,
  "1 dia"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Control": [
  null,
  "Controle"
 ],
 "Create": [
  null,
  "Criar"
 ],
 "Development": [
  null,
  "Desenvolvimento"
 ],
 "Empty": [
  null,
  "Vazio"
 ],
 "Go to now": [
  null,
  "Ir para agora"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "No such file or directory": [
  null,
  "Diretório ou arquivo não encontrado"
 ],
 "Not ready": [
  null,
  "Não está pronto"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Path to file": [
  null,
  "Caminho para o arquivo"
 ],
 "Ready": [
  null,
  "Pronto"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Unavailable": [
  null,
  "Indisponível"
 ],
 "View all logs": [
  null,
  "Ver todos os logs"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bytes de data bynária]"
 ],
 "[binary data]": [
  null,
  "[dados binários]"
 ],
 "[no data]": [
  null,
  "[sem dados]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 disco não encontrado",
  "$0 discos não encontrados"
 ],
 "key\u0004Control": [
  null,
  "Controle"
 ],
 "verb\u0004Empty": [
  null,
  "Vazio"
 ],
 "verb\u0004Ready": [
  null,
  "Pronto"
 ]
});
