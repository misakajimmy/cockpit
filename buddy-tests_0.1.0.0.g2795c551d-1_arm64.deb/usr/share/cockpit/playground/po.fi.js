cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 päivä",
  "$0 päivää"
 ],
 "$0 disk is missing": [
  null,
  "$0 levyä ei löydy",
  "$0 levyjä ei löydy"
 ],
 "$0 hour": [
  null,
  "$0 tunti",
  "$0 tuntia"
 ],
 "$0 minute": [
  null,
  "$0 minuutti",
  "$0 minuuttia"
 ],
 "$0 month": [
  null,
  "$0 kuukausi",
  "$0 kuukautta"
 ],
 "$0 week": [
  null,
  "$0 viikko",
  "$0 viikkoa"
 ],
 "$0 year": [
  null,
  "$0 vuosi",
  "$0 vuotta"
 ],
 "1 day": [
  null,
  "1 päivä"
 ],
 "1 hour": [
  null,
  "1 tunti"
 ],
 "1 week": [
  null,
  "1 viikko"
 ],
 "5 minutes": [
  null,
  "5 minuuttia"
 ],
 "6 hours": [
  null,
  "6 tuntia"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Control": [
  null,
  "Hallinta"
 ],
 "Create": [
  null,
  "Luo"
 ],
 "Development": [
  null,
  "Kehitys"
 ],
 "Empty": [
  null,
  "Tyhjä"
 ],
 "Go to now": [
  null,
  "Mene nyt"
 ],
 "Learn more": [
  null,
  "Opi lisää"
 ],
 "No such file or directory": [
  null,
  "Tiedostoa tai hakemistoa ei löydy"
 ],
 "Not ready": [
  null,
  "Ei valmiina"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Path to file": [
  null,
  "Polku tiedostoon"
 ],
 "Ready": [
  null,
  "Valmis"
 ],
 "Reboot": [
  null,
  "Käynnistä uudelleen"
 ],
 "Unavailable": [
  null,
  "Ei käytettävissä"
 ],
 "View all logs": [
  null,
  "Katso kaikki lokit"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 tavua binääridataa]"
 ],
 "[binary data]": [
  null,
  "[binääridata]"
 ],
 "[no data]": [
  null,
  "[ei dataa]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 levyä ei löydy",
  "$0 levyjä ei löydy"
 ],
 "key\u0004Control": [
  null,
  "Hallinta"
 ],
 "verb\u0004Empty": [
  null,
  "Tyhjä"
 ],
 "verb\u0004Ready": [
  null,
  "Valmis"
 ]
});
