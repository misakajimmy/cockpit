cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 日"
 ],
 "$0 disk is missing": [
  null,
  "$0 本のディスクがありません"
 ],
 "$0 hour": [
  null,
  "$0 時間"
 ],
 "$0 minute": [
  null,
  "$0 分"
 ],
 "$0 month": [
  null,
  "$0 カ月"
 ],
 "$0 week": [
  null,
  "$0 週"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "1 day": [
  null,
  "1 日"
 ],
 "1 hour": [
  null,
  "1 時間"
 ],
 "1 week": [
  null,
  "1 週間"
 ],
 "5 minutes": [
  null,
  "5 分"
 ],
 "6 hours": [
  null,
  "6 時間"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Control": [
  null,
  "コントロール"
 ],
 "Create": [
  null,
  "作成"
 ],
 "Development": [
  null,
  "開発"
 ],
 "Empty": [
  null,
  "空"
 ],
 "Go to now": [
  null,
  "今すぐ移動"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "No such file or directory": [
  null,
  "このようなファイルまたはディレクトリーがありません"
 ],
 "Not ready": [
  null,
  "準備ができていません"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Path to file": [
  null,
  "ファイルのパス"
 ],
 "Ready": [
  null,
  "準備ができています"
 ],
 "Reboot": [
  null,
  "再起動"
 ],
 "Unavailable": [
  null,
  "利用できません"
 ],
 "View all logs": [
  null,
  "すべてのログの表示"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[バイナリーデータの $0 バイト]"
 ],
 "[binary data]": [
  null,
  "[バイナリーデータ]"
 ],
 "[no data]": [
  null,
  "[データなし]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 本のディスクがありません"
 ],
 "key\u0004Control": [
  null,
  "コントロール"
 ],
 "verb\u0004Empty": [
  null,
  "空"
 ],
 "verb\u0004Ready": [
  null,
  "準備ができています"
 ]
});
