cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 día",
  "$0 días"
 ],
 "$0 disk is missing": [
  null,
  "Falta $0 disco",
  "Faltan $0 discos"
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "$0 month": [
  null,
  "$0 mes",
  "$0 meses"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 year": [
  null,
  "$0 año",
  "$0 años"
 ],
 "1 day": [
  null,
  "1 día"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Control": [
  null,
  "Control"
 ],
 "Create": [
  null,
  "Crear"
 ],
 "Development": [
  null,
  "Desarrollo"
 ],
 "Empty": [
  null,
  "Vacío"
 ],
 "Go to now": [
  null,
  "Ir a ahora"
 ],
 "Learn more": [
  null,
  "Aprenda más"
 ],
 "No such file or directory": [
  null,
  "No existe el archivo o directorio"
 ],
 "Not ready": [
  null,
  "No está listo"
 ],
 "Ok": [
  null,
  "Aceptar"
 ],
 "Path to file": [
  null,
  "Ruta al fichero"
 ],
 "Ready": [
  null,
  "Listo"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Unavailable": [
  null,
  "No disponible"
 ],
 "View all logs": [
  null,
  "Ver todos los registros"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bites de datos binarios]"
 ],
 "[binary data]": [
  null,
  "[datos binarios]"
 ],
 "[no data]": [
  null,
  "[no hay datos]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "Falta $0 disco",
  "Faltan $0 discos"
 ],
 "key\u0004Control": [
  null,
  "Control"
 ],
 "verb\u0004Empty": [
  null,
  "Vacío"
 ],
 "verb\u0004Ready": [
  null,
  "Preparado"
 ]
});
