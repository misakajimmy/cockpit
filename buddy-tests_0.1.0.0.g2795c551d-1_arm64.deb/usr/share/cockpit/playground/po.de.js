cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 Tag",
  "$0 Tage"
 ],
 "$0 disk is missing": [
  null,
  "$0 Festplatte fehlt",
  "$0 Festplatten fehlen"
 ],
 "$0 hour": [
  null,
  "$0 Stunde",
  "$0 Stunden"
 ],
 "$0 minute": [
  null,
  "$0 Minute",
  "$0 Minuten"
 ],
 "$0 month": [
  null,
  "$0 Monat",
  "$0 Monate"
 ],
 "$0 week": [
  null,
  "$0 Woche",
  "$0 Wochen"
 ],
 "$0 year": [
  null,
  "$0 Jahr",
  "$0 Jahre"
 ],
 "1 day": [
  null,
  "1 Tag"
 ],
 "1 hour": [
  null,
  "1 Stunde"
 ],
 "1 week": [
  null,
  "1 Woche"
 ],
 "5 minutes": [
  null,
  "5 Minuten"
 ],
 "6 hours": [
  null,
  "6 Stunden"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Control": [
  null,
  "Steuerung"
 ],
 "Create": [
  null,
  "Erstellen"
 ],
 "Development": [
  null,
  "Entwicklung"
 ],
 "Empty": [
  null,
  "Leer"
 ],
 "Go to now": [
  null,
  "Zu 'Jetzt' gehen"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "No such file or directory": [
  null,
  "Datei oder Verzeichnis nicht vorhanden"
 ],
 "Not ready": [
  null,
  "Nicht bereit"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Path to file": [
  null,
  "Pfad zur Datei"
 ],
 "Ready": [
  null,
  "Bereit"
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Unavailable": [
  null,
  "Nicht verfügbar"
 ],
 "View all logs": [
  null,
  "Alle Protokolle ansehen"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bytes Binäredaten]"
 ],
 "[binary data]": [
  null,
  "[Binärdaten]"
 ],
 "[no data]": [
  null,
  "[keine Daten]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 Datenträger fehlt",
  "$0 Datenträger fehlen"
 ],
 "key\u0004Control": [
  null,
  "Strg"
 ],
 "verb\u0004Empty": [
  null,
  "Leeren"
 ],
 "verb\u0004Ready": [
  null,
  "Bereiten"
 ]
});
