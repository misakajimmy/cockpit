cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 일"
 ],
 "$0 disk is missing": [
  null,
  "$0 디스크가 없습니다"
 ],
 "$0 hour": [
  null,
  "$0 시"
 ],
 "$0 minute": [
  null,
  "$0 분"
 ],
 "$0 month": [
  null,
  "$0 달"
 ],
 "$0 week": [
  null,
  "$0 주"
 ],
 "$0 year": [
  null,
  "$0 년"
 ],
 "1 day": [
  null,
  "1 일"
 ],
 "1 hour": [
  null,
  "1시간"
 ],
 "1 week": [
  null,
  "1 주"
 ],
 "5 minutes": [
  null,
  "5분"
 ],
 "6 hours": [
  null,
  "6 시간"
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Control": [
  null,
  "제어"
 ],
 "Create": [
  null,
  "생성"
 ],
 "Development": [
  null,
  "개발"
 ],
 "Empty": [
  null,
  "비었음"
 ],
 "Go to now": [
  null,
  "지금 바로 가기"
 ],
 "Learn more": [
  null,
  "더 알아보기"
 ],
 "No such file or directory": [
  null,
  "이러한 파일 또는 디렉토리가 없습니다"
 ],
 "Not ready": [
  null,
  "준비되지 않음"
 ],
 "Ok": [
  null,
  "확인"
 ],
 "Path to file": [
  null,
  "파일의 경로"
 ],
 "Ready": [
  null,
  "준비"
 ],
 "Reboot": [
  null,
  "재시작"
 ],
 "Unavailable": [
  null,
  "사용 불가능"
 ],
 "View all logs": [
  null,
  "모든 기록 보기"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[바이너리 데이터의 $0 바이트]"
 ],
 "[binary data]": [
  null,
  "[바이너리 데이터]"
 ],
 "[no data]": [
  null,
  "[데이터 없음]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 디스크가 없습니다"
 ],
 "key\u0004Control": [
  null,
  "제어"
 ],
 "verb\u0004Empty": [
  null,
  "비었음"
 ],
 "verb\u0004Ready": [
  null,
  "준비"
 ]
});
