cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 giorno",
  "$0 giorni"
 ],
 "$0 disk is missing": [
  null,
  "$0 disco inesistente",
  "$0 dischi inesistenti"
 ],
 "$0 hour": [
  null,
  "$0 ora",
  "$0 ore"
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minuti"
 ],
 "$0 month": [
  null,
  "$0 mese",
  "$0 mesi"
 ],
 "$0 week": [
  null,
  "$0 settimana",
  "$0 settimane"
 ],
 "$0 year": [
  null,
  "$0 anno",
  "$0 anni"
 ],
 "1 day": [
  null,
  "1 giorno"
 ],
 "1 hour": [
  null,
  "1 ora"
 ],
 "1 week": [
  null,
  "1 settimana"
 ],
 "5 minutes": [
  null,
  "5 minuti"
 ],
 "6 hours": [
  null,
  "6 ore"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Control": [
  null,
  "Controllo"
 ],
 "Create": [
  null,
  "Crea"
 ],
 "Development": [
  null,
  "Sviluppo"
 ],
 "Empty": [
  null,
  "Vuoto"
 ],
 "Go to now": [
  null,
  "Vai ora"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "No such file or directory": [
  null,
  "Nessun file o directory"
 ],
 "Not ready": [
  null,
  "Non pronto"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Path to file": [
  null,
  "Percorso del file"
 ],
 "Ready": [
  null,
  "Pronto"
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Unavailable": [
  null,
  "Non disponibile"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0byte di dati binari]"
 ],
 "[binary data]": [
  null,
  "[dati binari]"
 ],
 "[no data]": [
  null,
  "[nessun dato]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 disco inesistente",
  "$0 dischi inesistenti"
 ],
 "key\u0004Control": [
  null,
  "Controllo"
 ],
 "verb\u0004Empty": [
  null,
  "Vuoto"
 ],
 "verb\u0004Ready": [
  null,
  "Pronto"
 ]
});
