cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 dzień",
  "$0 dni",
  "$0 dni"
 ],
 "$0 disk is missing": [
  null,
  "Brak $0 dysku",
  "Brak $0 dysków",
  "Brak $0 dysków"
 ],
 "$0 hour": [
  null,
  "$0 godzina",
  "$0 godziny",
  "$0 godzin"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "$0 month": [
  null,
  "$0 miesiąc",
  "$0 miesiące",
  "$0 miesięcy"
 ],
 "$0 week": [
  null,
  "$0 tydzień",
  "$0 tygodnie",
  "$0 tygodni"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 lata",
  "$0 lat"
 ],
 "1 day": [
  null,
  "1 dzień"
 ],
 "1 hour": [
  null,
  "1 godzina"
 ],
 "1 week": [
  null,
  "1 tydzień"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "6 hours": [
  null,
  "6 godzin"
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Control": [
  null,
  "Sterowanie"
 ],
 "Create": [
  null,
  "Utwórz"
 ],
 "Development": [
  null,
  "Rozwój"
 ],
 "Empty": [
  null,
  "Puste"
 ],
 "Go to now": [
  null,
  "Przejdź teraz"
 ],
 "Learn more": [
  null,
  "Więcej informacji"
 ],
 "No such file or directory": [
  null,
  "Nie ma takiego pliku lub katalogu"
 ],
 "Not ready": [
  null,
  "Niegotowe"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Path to file": [
  null,
  "Ścieżka do pliku"
 ],
 "Ready": [
  null,
  "Gotowe"
 ],
 "Reboot": [
  null,
  "Uruchom ponownie"
 ],
 "Unavailable": [
  null,
  "Niedostępne"
 ],
 "View all logs": [
  null,
  "Wszystkie dzienniki"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 B danych binarnych]"
 ],
 "[binary data]": [
  null,
  "[dane binarne]"
 ],
 "[no data]": [
  null,
  "[brak danych]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "Brak $0 dysku",
  "Brak $0 dysków",
  "Brak $0 dysków"
 ],
 "key\u0004Control": [
  null,
  "Sterowanie"
 ],
 "verb\u0004Empty": [
  null,
  "Puste"
 ],
 "verb\u0004Ready": [
  null,
  "Gotowe"
 ]
});
