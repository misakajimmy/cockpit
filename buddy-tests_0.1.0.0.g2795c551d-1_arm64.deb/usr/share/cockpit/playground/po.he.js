cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "$0 day": [
  null,
  "יום",
  "יומיים",
  "$0 ימים",
  "$0 ימים"
 ],
 "$0 disk is missing": [
  null,
  "כונן אחד חסר",
  "$0 כוננים חסרים",
  "$0 כוננים חסרים",
  "$0 כוננים חסרים"
 ],
 "$0 hour": [
  null,
  "שעה",
  "שעתיים",
  "$0 שעות",
  "$0 שעות"
 ],
 "$0 minute": [
  null,
  "דקה",
  "$0 דקות",
  "$0 דקות",
  "$0 דקות"
 ],
 "$0 month": [
  null,
  "חודש",
  "חודשיים",
  "$0 חודשים",
  "$0 חודשים"
 ],
 "$0 week": [
  null,
  "שבוע",
  "שבועיים",
  "$0 שבועות",
  "$0 שבועות"
 ],
 "$0 year": [
  null,
  "שנה",
  "שנתיים",
  "$0 שנים",
  "$0 שנים"
 ],
 "1 day": [
  null,
  "יום"
 ],
 "1 hour": [
  null,
  "שעה"
 ],
 "1 week": [
  null,
  "שבוע"
 ],
 "5 minutes": [
  null,
  "5 דקות"
 ],
 "6 hours": [
  null,
  "6 שעות"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Control": [
  null,
  "בקרה"
 ],
 "Create": [
  null,
  "יצירה"
 ],
 "Development": [
  null,
  "פיתוח"
 ],
 "Empty": [
  null,
  "ריק"
 ],
 "Go to now": [
  null,
  "לעבור כעת"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "No such file or directory": [
  null,
  "אין קובץ או תיקייה בשם הזה"
 ],
 "Not ready": [
  null,
  "לא מוכן"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "Path to file": [
  null,
  "הנתיב לקובץ"
 ],
 "Ready": [
  null,
  "מוכן"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Unavailable": [
  null,
  "לא זמין"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 בתים של נתונים בינריים]"
 ],
 "[binary data]": [
  null,
  "[נתונים בינריים]"
 ],
 "[no data]": [
  null,
  "[אין נתונים]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "כונן אחד חסר",
  "$0 כוננים חסרים",
  "$0 כוננים חסרים",
  "$0 כוננים חסרים"
 ],
 "key\u0004Control": [
  null,
  "Control"
 ],
 "verb\u0004Empty": [
  null,
  "לרוקן"
 ],
 "verb\u0004Ready": [
  null,
  "מוכן"
 ]
});
