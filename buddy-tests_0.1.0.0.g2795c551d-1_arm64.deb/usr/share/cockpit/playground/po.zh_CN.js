cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 天"
 ],
 "$0 disk is missing": [
  null,
  "$0 磁盘无法找到"
 ],
 "$0 hour": [
  null,
  "$0 小时"
 ],
 "$0 minute": [
  null,
  "$0 分钟"
 ],
 "$0 month": [
  null,
  "$0 月"
 ],
 "$0 week": [
  null,
  "$0 周"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "1 day": [
  null,
  "1 天"
 ],
 "1 hour": [
  null,
  "1 小时"
 ],
 "1 week": [
  null,
  "1 周"
 ],
 "5 minutes": [
  null,
  "5 分钟"
 ],
 "6 hours": [
  null,
  "6 小时"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Control": [
  null,
  "控制"
 ],
 "Create": [
  null,
  "创建"
 ],
 "Development": [
  null,
  "开发"
 ],
 "Empty": [
  null,
  "空"
 ],
 "Go to now": [
  null,
  "转到现在"
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "No such file or directory": [
  null,
  "没有该文件或目录"
 ],
 "Not ready": [
  null,
  "未就绪"
 ],
 "Ok": [
  null,
  "确认"
 ],
 "Path to file": [
  null,
  "文件路径"
 ],
 "Ready": [
  null,
  "就绪"
 ],
 "Reboot": [
  null,
  "重启"
 ],
 "Unavailable": [
  null,
  "不可用"
 ],
 "View all logs": [
  null,
  "查看所有日志"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 字节二进制数据]"
 ],
 "[binary data]": [
  null,
  "[二进制数据]"
 ],
 "[no data]": [
  null,
  "[没有数据]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 磁盘无法找到"
 ],
 "key\u0004Control": [
  null,
  "控制"
 ],
 "verb\u0004Empty": [
  null,
  "空"
 ],
 "verb\u0004Ready": [
  null,
  "就绪"
 ]
});
