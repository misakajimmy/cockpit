cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 день",
  "$0 дня",
  "$0 дней"
 ],
 "$0 disk is missing": [
  null,
  "$0 диск отсутствует",
  "$0 диска отсутствуют",
  "$0 дисков отсутствуют"
 ],
 "$0 hour": [
  null,
  "$0 час",
  "$0 часа",
  "$0 часов"
 ],
 "$0 minute": [
  null,
  "$0 минута",
  "$0 минуты",
  "$0 минут"
 ],
 "$0 month": [
  null,
  "$0 месяц",
  "$0 месяца",
  "$0 месяцев"
 ],
 "$0 week": [
  null,
  "$0 неделя",
  "$0 недели",
  "$0 недель"
 ],
 "$0 year": [
  null,
  "$0 год",
  "$0 года",
  "$0 лет"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 час"
 ],
 "1 week": [
  null,
  "1 неделя"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "6 hours": [
  null,
  "6 часов"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Control": [
  null,
  "Управление"
 ],
 "Create": [
  null,
  "Создать"
 ],
 "Development": [
  null,
  "Разработка"
 ],
 "Empty": [
  null,
  "Пусто"
 ],
 "Go to now": [
  null,
  "Текущий момент"
 ],
 "Learn more": [
  null,
  "Подробнее..."
 ],
 "No such file or directory": [
  null,
  "Нет такого файла или каталога"
 ],
 "Not ready": [
  null,
  "Не готово"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Path to file": [
  null,
  "Путь к файлу"
 ],
 "Ready": [
  null,
  "Готово"
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Unavailable": [
  null,
  "Недоступно"
 ],
 "View all logs": [
  null,
  ""
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 байтов двоичных данных]"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 диск отсутствует",
  "$0 диска отсутствуют",
  "$0 дисков отсутствуют"
 ],
 "key\u0004Control": [
  null,
  "Управление"
 ],
 "verb\u0004Empty": [
  null,
  "Очистить"
 ],
 "verb\u0004Ready": [
  null,
  "Готово"
 ]
});
