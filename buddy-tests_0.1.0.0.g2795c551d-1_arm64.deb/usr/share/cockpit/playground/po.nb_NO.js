cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 dag",
  "$0 dager"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk mangler",
  "$0 disker mangler"
 ],
 "$0 hour": [
  null,
  "$0 time",
  "$0 timer"
 ],
 "$0 minute": [
  null,
  "$0 minutt",
  "$0 minutter"
 ],
 "$0 month": [
  null,
  "$0 måned",
  "$0 måneder"
 ],
 "$0 week": [
  null,
  "$0 uke",
  "$0 uker"
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 time"
 ],
 "1 week": [
  null,
  "1 uke"
 ],
 "5 minutes": [
  null,
  "5 minutter"
 ],
 "6 hours": [
  null,
  "6 timer"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Control": [
  null,
  "Kontroll"
 ],
 "Create": [
  null,
  "Opprett"
 ],
 "Development": [
  null,
  "Utvikling"
 ],
 "Empty": [
  null,
  "Tom"
 ],
 "Go to now": [
  null,
  "Gå til nå"
 ],
 "Learn more": [
  null,
  "Lær mer"
 ],
 "No such file or directory": [
  null,
  "Ingen slik fil eller katalog"
 ],
 "Not ready": [
  null,
  "Ikke klar"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Path to file": [
  null,
  "Sti til fil"
 ],
 "Ready": [
  null,
  "Klar"
 ],
 "Reboot": [
  null,
  "Omstart"
 ],
 "Unavailable": [
  null,
  "Utilgjengelig"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bytes med binære data]"
 ],
 "[binary data]": [
  null,
  "[binære data]"
 ],
 "[no data]": [
  null,
  "[ingen data]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 disk mangler",
  "$0 disker mangler"
 ],
 "key\u0004Control": [
  null,
  "Kontroll"
 ],
 "verb\u0004Empty": [
  null,
  "Tom"
 ],
 "verb\u0004Ready": [
  null,
  "Klar"
 ]
});
