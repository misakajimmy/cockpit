/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./pkg/lib/patternfly/patternfly-4-cockpit.scss":
/*!******************************************************!*\
  !*** ./pkg/lib/patternfly/patternfly-4-cockpit.scss ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./node_modules/@patternfly/patternfly/components/Button/button.css":
/*!**************************************************************************!*\
  !*** ./node_modules/@patternfly/patternfly/components/Button/button.css ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./node_modules/@patternfly/patternfly/components/Page/page.css":
/*!**********************************************************************!*\
  !*** ./node_modules/@patternfly/patternfly/components/Page/page.css ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "cockpit":
/*!**************************!*\
  !*** external "cockpit" ***!
  \**************************/
/***/ ((module) => {

module.exports = cockpit;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other entry modules.
(() => {
var __webpack_exports__ = {};
/*!*********************************!*\
  !*** ./pkg/playground/speed.js ***!
  \*********************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var cockpit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cockpit */ "cockpit");
/* harmony import */ var cockpit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cockpit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_patternfly_patternfly_4_cockpit_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/patternfly/patternfly-4-cockpit.scss */ "./pkg/lib/patternfly/patternfly-4-cockpit.scss");
/* harmony import */ var _node_modules_patternfly_patternfly_components_Button_button_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/@patternfly/patternfly/components/Button/button.css */ "./node_modules/@patternfly/patternfly/components/Button/button.css");
/* harmony import */ var _node_modules_patternfly_patternfly_components_Page_page_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../node_modules/@patternfly/patternfly/components/Page/page.css */ "./node_modules/@patternfly/patternfly/components/Page/page.css");






let channel = null;
let websocket = null;
let timer = null;
let start = null;
let total = 0;
let proc = null;
let close_problem;
function update() {
  const element = document.getElementById("speed");
  if (channel || websocket) {
    element.innerHTML = cockpit__WEBPACK_IMPORTED_MODULE_0___default().format_bytes_per_sec(total * 1000 / (Date.now() - start));
    console.log(total);
  } else {
    element.innerHTML = "";
  }
  const memory = document.getElementById("memory");
  const pid = document.getElementById("pid");
  if (!proc) {
    proc = cockpit__WEBPACK_IMPORTED_MODULE_0___default().script("echo $PPID && cat /proc/$PPID/statm");
    proc.then(function (data) {
      const parts = data.split("\n");
      pid.innerHTML = parts[0];
      memory.innerHTML = parts[1];
      proc = null;
    }, function (ex) {
      memory.innerHTML = String(ex);
      proc = null;
    });
  }
}
function echo(ev) {
  stop();
  const sideband = ev.target.id == "echo-sideband";
  function generate(length, binary) {
    if (binary) return new window.ArrayBuffer(length);else return new Array(length).join("x");
  }
  const length = parseInt(document.getElementById("message").value, 10);
  const batch = parseInt(document.getElementById("batch").value, 10);
  const interval = parseInt(document.getElementById("interval").value, 10);
  if (isNaN(length) || isNaN(interval) || isNaN(batch)) {
    window.alert("Bad value");
    return;
  }
  const binary = document.getElementById.checked;
  const options = {
    payload: "echo"
  };
  const input = generate(length, binary);
  start = new Date();
  total = 0;
  if (sideband) {
    if (binary) options.binary = "raw";
    websocket = new window.WebSocket(cockpit__WEBPACK_IMPORTED_MODULE_0___default().transport.uri("channel/" + (cockpit__WEBPACK_IMPORTED_MODULE_0___default().transport.csrf_token)) + "?" + window.btoa(JSON.stringify(options)));
    websocket.binaryType = 'arraybuffer';
    websocket.onopen = function () {
      for (let i = 0; i < batch; i++) websocket.send(input);
      timer = window.setInterval(function () {
        for (let i = 0; i < batch; i++) websocket.send(input);
      }, interval);
    };
    websocket.onmessage = function (event) {
      if (binary) total += event.data.byteLength;else total += event.data.length;
    };
    websocket.onclose = function (event) {
      if (websocket) window.alert("channel closed");
      stop();
    };
  } else {
    if (binary) options.binary = true;
    channel = cockpit__WEBPACK_IMPORTED_MODULE_0___default().channel(options);
    channel.addEventListener("message", function (event, data) {
      total += data.length;
    });
    channel.addEventListener("close", function (event, options) {
      if (options.problem) window.alert(options.problem);
      stop();
    });
    for (let i = 0; i < batch; i++) channel.send(input);
    timer = window.setInterval(function () {
      for (let i = 0; i < batch; i++) channel.send(input);
    }, interval);
  }
}
function read(ev) {
  stop();
  const sideband = ev.target.id == "read-sideband";
  const path = document.getElementById("read-path");
  const options = {
    payload: "fsread1",
    path: path.value,
    max_read_size: 100 * 1024 * 1024 * 1024,
    binary: sideband ? "raw" : true
  };
  start = Date.now();
  total = 0;
  if (sideband) {
    websocket = new window.WebSocket(cockpit__WEBPACK_IMPORTED_MODULE_0___default().transport.uri("channel/" + (cockpit__WEBPACK_IMPORTED_MODULE_0___default().transport.csrf_token)) + "?" + window.btoa(JSON.stringify(options)));
    websocket.binaryType = 'arraybuffer';
    websocket.onmessage = function (event) {
      total += event.data.byteLength;
    };
    websocket.onclose = function (event) {
      if (websocket) window.alert("channel closed");
      stop();
    };
  } else {
    channel = cockpit__WEBPACK_IMPORTED_MODULE_0___default().channel(options);
    channel.addEventListener("message", function (event, data) {
      total += data.length;
    });
    channel.addEventListener("close", function (event, options) {
      if (options.problem) window.alert(options.problem);
      stop();
    });
  }
}
function download(ev) {
  stop();
  const path = document.getElementById("download-path");
  const options = {
    binary: "raw",
    max_read_size: 100 * 1024 * 1024 * 1024,
    external: {
      "content-disposition": 'attachment; filename="download"',
      "content-type": "application/octet-stream"
    }
  };

  /* Allow use of HTTP URLs */
  if (path.value.indexOf("http") === 0) {
    const anchor = document.createElement("a");
    anchor.href = path.value;
    options.payload = "http-stream2";
    options.address = anchor.hostname;
    options.port = parseInt(anchor.port, 10);
    options.path = anchor.pathname;
    options.method = "GET";
  } else {
    options.payload = "fsread1";
    options.path = path.value;
  }
  console.log("Download", options);
  start = Date.now();
  total = 0;
  const prefix = new URL(cockpit__WEBPACK_IMPORTED_MODULE_0___default().transport.uri("channel/" + (cockpit__WEBPACK_IMPORTED_MODULE_0___default().transport.csrf_token))).pathname;
  const query = window.btoa(JSON.stringify(options));
  window.open(prefix + "?" + query);
}
function spawn() {
  stop();
  document.getElementById("spawn-result").innerHTML = "Running...";
  const command = document.getElementById("spawn-command").value;
  start = Date.now();
  total = 0;
  close_problem = "terminated";
  console.log("spawning", command);
  channel = cockpit__WEBPACK_IMPORTED_MODULE_0___default().script(command, {
    err: "message"
  });
  channel.stream(data => {
    console.log("spawn: stream block length", data.length);
    total += data.length;
    document.getElementById("spawn-output").innerHTML = data;
  });
  channel.then(() => {
    console.log("spawn: command finished successfully");
    stop();
    document.getElementById("spawn-result").innerHTML = "success";
  });
  channel.catch(ex => {
    console.log("spawn: command failed", JSON.stringify(ex));
    stop();
    document.getElementById("spawn-result").innerHTML = `failed with exit code ${ex.exit_status}: ${ex.message}`;
  });
}
function stop() {
  update();
  if (channel) channel.close(close_problem);
  channel = null;
  close_problem = undefined;
  const ws = websocket;
  websocket = null;
  if (ws) ws.close();
  window.clearInterval(timer);
  timer = null;
}
cockpit__WEBPACK_IMPORTED_MODULE_0___default().transport.wait(function () {
  document.getElementById("echo-normal").addEventListener("click", echo);
  document.getElementById("echo-sideband").addEventListener("click", echo);
  document.getElementById("read-normal").addEventListener("click", read);
  document.getElementById("read-sideband").addEventListener("click", read);
  document.getElementById("download-external").addEventListener("click", download);
  document.getElementById("spawn").addEventListener("click", spawn);
  document.getElementById("stop").addEventListener("click", stop);
  window.setInterval(update, 500);
  document.body.removeAttribute("hidden");
});
})();

// This entry need to be wrapped in an IIFE because it need to be isolated against other entry modules.
(() => {
/*!**********************************!*\
  !*** ./pkg/playground/speed.css ***!
  \**********************************/
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin

})();

/******/ })()
;
//# sourceMappingURL=speed.js.map