cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_TW",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 天"
 ],
 "$0 disk is missing": [
  null,
  "$0 磁碟遺失"
 ],
 "$0 hour": [
  null,
  "$0 小時"
 ],
 "$0 minute": [
  null,
  "$0 分鐘"
 ],
 "$0 month": [
  null,
  "$0 月"
 ],
 "$0 week": [
  null,
  "$0 週"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "1 day": [
  null,
  "1天"
 ],
 "1 hour": [
  null,
  "1小時"
 ],
 "1 week": [
  null,
  "1週"
 ],
 "5 minutes": [
  null,
  "5分鐘"
 ],
 "6 hours": [
  null,
  "6小時"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Control": [
  null,
  "控制"
 ],
 "Create": [
  null,
  "建立"
 ],
 "Development": [
  null,
  ""
 ],
 "Empty": [
  null,
  "空的"
 ],
 "Go to now": [
  null,
  "去吧"
 ],
 "No such file or directory": [
  null,
  "沒有相應的文件和目錄"
 ],
 "Not ready": [
  null,
  "沒有準備好"
 ],
 "Ok": [
  null,
  "確定"
 ],
 "Path to file": [
  null,
  "文件路徑"
 ],
 "Ready": [
  null,
  "已準備好"
 ],
 "Reboot": [
  null,
  "重新開機"
 ],
 "Unavailable": [
  null,
  "無法使用"
 ],
 "View all logs": [
  null,
  ""
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 二進制數據的字節]"
 ],
 "[binary data]": [
  null,
  "[二進制數據]"
 ],
 "[no data]": [
  null,
  "[沒有數據]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 磁碟遺失"
 ],
 "key\u0004Control": [
  null,
  "控制"
 ],
 "verb\u0004Empty": [
  null,
  "空的"
 ],
 "verb\u0004Ready": [
  null,
  "已準備好"
 ]
});
