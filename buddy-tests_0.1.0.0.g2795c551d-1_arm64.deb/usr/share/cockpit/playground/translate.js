/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./pkg/lib/patternfly/patternfly-4-cockpit.scss":
/*!******************************************************!*\
  !*** ./pkg/lib/patternfly/patternfly-4-cockpit.scss ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "cockpit":
/*!**************************!*\
  !*** external "cockpit" ***!
  \**************************/
/***/ ((module) => {

module.exports = cockpit;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!*************************************!*\
  !*** ./pkg/playground/translate.js ***!
  \*************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var cockpit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cockpit */ "cockpit");
/* harmony import */ var cockpit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cockpit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_patternfly_patternfly_4_cockpit_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/patternfly/patternfly-4-cockpit.scss */ "./pkg/lib/patternfly/patternfly-4-cockpit.scss");




const _ = (cockpit__WEBPACK_IMPORTED_MODULE_0___default().gettext);
const C_ = (cockpit__WEBPACK_IMPORTED_MODULE_0___default().gettext);
document.addEventListener("DOMContentLoaded", () => {
  cockpit__WEBPACK_IMPORTED_MODULE_0___default().translate();
  let text = _("Empty");
  document.getElementById("underscore-empty").textContent = text;
  text = _("verb", "Empty");
  document.getElementById("underscore-context-empty").textContent = text;
  text = C_("verb", "Empty");
  document.getElementById("cunderscore-context-empty").textContent = text;
  text = cockpit__WEBPACK_IMPORTED_MODULE_0___default().gettext("Control");
  document.getElementById("gettext-control").textContent = text;
  text = cockpit__WEBPACK_IMPORTED_MODULE_0___default().gettext("key", "Control");
  document.getElementById("gettext-context-control").textContent = text;
  text = cockpit__WEBPACK_IMPORTED_MODULE_0___default().ngettext("$0 disk is missing", "$0 disks are missing", 1);
  document.getElementById("ngettext-disks-1").textContent = text;
  text = cockpit__WEBPACK_IMPORTED_MODULE_0___default().ngettext("$0 disk is missing", "$0 disks are missing", 2);
  document.getElementById("ngettext-disks-2").textContent = text;
  text = cockpit__WEBPACK_IMPORTED_MODULE_0___default().ngettext("disk-non-rotational", "$0 disk is missing", "$0 disks are missing", 1);
  document.getElementById("ngettext-context-disks-1").textContent = text;
  text = cockpit__WEBPACK_IMPORTED_MODULE_0___default().ngettext("disk-non-rotational", "$0 disk is missing", "$0 disks are missing", 2);
  document.getElementById("ngettext-context-disks-2").textContent = text;
  cockpit__WEBPACK_IMPORTED_MODULE_0___default().transport.wait(() => document.body.removeAttribute("hidden"));
});
})();

/******/ })()
;
//# sourceMappingURL=translate.js.map