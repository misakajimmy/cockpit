cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 den",
  "$0 dny",
  "$0 dnů"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk chybí",
  "$0 disky chybí",
  "$0 disků chybí"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodin"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "$0 month": [
  null,
  "$0 měsíc",
  "$0 měsíce",
  "$0 měsíců"
 ],
 "$0 week": [
  null,
  "$0 týden",
  "$0 týdny",
  "$0 týdnů"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 let"
 ],
 "1 day": [
  null,
  "1 den"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "1 week": [
  null,
  "1 týden"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "6 hours": [
  null,
  "6 hodin"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Control": [
  null,
  "Ovládání"
 ],
 "Create": [
  null,
  "Vytvořit"
 ],
 "Development": [
  null,
  "Vývoj"
 ],
 "Empty": [
  null,
  "Prázdný"
 ],
 "Go to now": [
  null,
  "Přejít na nyní"
 ],
 "Learn more": [
  null,
  "Další informace naleznete"
 ],
 "No such file or directory": [
  null,
  "Žádný takový soubor nebo složka"
 ],
 "Not ready": [
  null,
  "Nepřipraveno"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Path to file": [
  null,
  "Popis umístění serveru"
 ],
 "Ready": [
  null,
  "Připraveno"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Unavailable": [
  null,
  "Nedostupné"
 ],
 "View all logs": [
  null,
  "Zobrazit všechny záznamy událostí"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bajtů binárních dat]"
 ],
 "[binary data]": [
  null,
  "[binarní data]"
 ],
 "[no data]": [
  null,
  "[žádná data]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 disk chybí",
  "$0 disky chybí",
  "$0 disků chybí"
 ],
 "key\u0004Control": [
  null,
  "Ovládání"
 ],
 "verb\u0004Empty": [
  null,
  "Prázdný"
 ],
 "verb\u0004Ready": [
  null,
  "Připraveno"
 ]
});
