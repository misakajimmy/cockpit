cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 jour",
  "$0 jours"
 ],
 "$0 disk is missing": [
  null,
  "$0 disque est manquant",
  "$0 disques sont manquants"
 ],
 "$0 hour": [
  null,
  "$0 heure",
  "$0 heures"
 ],
 "$0 minute": [
  null,
  "$0 minute",
  "$0 minutes"
 ],
 "$0 month": [
  null,
  "$0 mois",
  "$0 mois"
 ],
 "$0 week": [
  null,
  "$0 semaine",
  "$0 semaines"
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ans"
 ],
 "1 day": [
  null,
  "1 jour"
 ],
 "1 hour": [
  null,
  "1 heure"
 ],
 "1 week": [
  null,
  "1 semaine"
 ],
 "5 minutes": [
  null,
  "5 minutes"
 ],
 "6 hours": [
  null,
  "6 heures"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Control": [
  null,
  "Contrôle"
 ],
 "Create": [
  null,
  "Créer"
 ],
 "Development": [
  null,
  "Développement"
 ],
 "Empty": [
  null,
  "Vide"
 ],
 "Go to now": [
  null,
  "Aller à maintenant"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "No such file or directory": [
  null,
  "Aucun fichier ou répertoire de ce nom"
 ],
 "Not ready": [
  null,
  "Pas prêt"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Path to file": [
  null,
  "Chemin d’accès au fichier"
 ],
 "Ready": [
  null,
  "Prêt"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Unavailable": [
  null,
  "Non disponible"
 ],
 "View all logs": [
  null,
  "Voir tous les journaux"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[ $0 octets de données binaires]"
 ],
 "[binary data]": [
  null,
  "[données binaires]"
 ],
 "[no data]": [
  null,
  "[pas de données]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 disque est manquant",
  "$0 disques sont manquants"
 ],
 "key\u0004Control": [
  null,
  "Contrôle"
 ],
 "verb\u0004Empty": [
  null,
  "Vide"
 ],
 "verb\u0004Ready": [
  null,
  "Prêt"
 ]
});
