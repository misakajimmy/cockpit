cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 დღე",
  "დღეები: $0"
 ],
 "$0 disk is missing": [
  null,
  "$0 დისკი აკლია",
  "$0 ცალი დისკი აკლია"
 ],
 "$0 hour": [
  null,
  "$0 საათი",
  "საათი: $0"
 ],
 "$0 minute": [
  null,
  "$0 წუთი",
  "წუთი: $0"
 ],
 "$0 month": [
  null,
  "$0 თვე",
  "თვე: $0"
 ],
 "$0 week": [
  null,
  "$0 კვირა",
  "კვირა: $0"
 ],
 "$0 year": [
  null,
  "$0 წელი",
  "წელი: $0"
 ],
 "1 day": [
  null,
  "1 დღე"
 ],
 "1 hour": [
  null,
  "1 საათი"
 ],
 "1 week": [
  null,
  "1 კვირა"
 ],
 "5 minutes": [
  null,
  "5 წთ"
 ],
 "6 hours": [
  null,
  "5 სთ"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Control": [
  null,
  "კონტროლი"
 ],
 "Create": [
  null,
  "შექმნა"
 ],
 "Development": [
  null,
  "განვითარება"
 ],
 "Empty": [
  null,
  "ცარიელი"
 ],
 "Go to now": [
  null,
  "ახლავე გადასვლა"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "No such file or directory": [
  null,
  "ფაილი ან საქაღალდე არ არსებობს"
 ],
 "Not ready": [
  null,
  "მზად არაა"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "Path to file": [
  null,
  "ბილიკი ფაილამდე"
 ],
 "Ready": [
  null,
  "მზადაა"
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Unavailable": [
  null,
  "ხელმიუწვდომელია"
 ],
 "View all logs": [
  null,
  "ყველა ჟურნალის ნახვა"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[ბინარული მონაცემების $0 ბაიტი]"
 ],
 "[binary data]": [
  null,
  "[ბინარული მონაცემები]"
 ],
 "[no data]": [
  null,
  "[მონაცემების გარეშე]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 დისკი აკლია",
  "$0 ცალი დისკი აკლია"
 ],
 "key\u0004Control": [
  null,
  "კონტროლი"
 ],
 "verb\u0004Empty": [
  null,
  "ცარიელი"
 ],
 "verb\u0004Ready": [
  null,
  "მზადაა"
 ]
});
