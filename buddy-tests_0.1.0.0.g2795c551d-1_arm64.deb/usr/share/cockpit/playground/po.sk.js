cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 deň",
  "$0 dni",
  "$0 dní"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk chýba",
  "$0 disky chýbajú",
  "$0 diskov chýba"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodín"
 ],
 "$0 minute": [
  null,
  "$0 minúta",
  "$0 minúty",
  "$0 minút"
 ],
 "$0 month": [
  null,
  "$0 mesiac",
  "$0 mesiace",
  "$0 mesiacov"
 ],
 "$0 week": [
  null,
  "$0 týždeň",
  "$0 týždne",
  "$0 týždňov"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 rokov"
 ],
 "1 day": [
  null,
  "1 deň"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "1 week": [
  null,
  "1 týždeň"
 ],
 "5 minutes": [
  null,
  "5 minút"
 ],
 "6 hours": [
  null,
  "6 hodín"
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Control": [
  null,
  "Ovládanie"
 ],
 "Create": [
  null,
  "Vytvoriť"
 ],
 "Development": [
  null,
  "Vývoj"
 ],
 "Empty": [
  null,
  "Prázdny"
 ],
 "Go to now": [
  null,
  "Prejsť na súčasnosť"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "No such file or directory": [
  null,
  ""
 ],
 "Not ready": [
  null,
  "Nepripravené"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Path to file": [
  null,
  "Cesta k súboru"
 ],
 "Ready": [
  null,
  "Pripravené"
 ],
 "Reboot": [
  null,
  "Reštartovať"
 ],
 "Unavailable": [
  null,
  "Nedostupné"
 ],
 "[$0 bytes of binary data]": [
  null,
  ""
 ],
 "[binary data]": [
  null,
  "[binárne dáta]"
 ],
 "[no data]": [
  null,
  "[žiadne dáta]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 disk chýba",
  "$0 disky chýbajú",
  "$0 diskov chýba"
 ],
 "key\u0004Control": [
  null,
  "Ovládanie"
 ],
 "verb\u0004Empty": [
  null,
  "Vyprázdniť"
 ],
 "verb\u0004Ready": [
  null,
  "Pripraviť"
 ]
});
