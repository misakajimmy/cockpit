cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 день",
  "$0 дні",
  "$0 днів"
 ],
 "$0 disk is missing": [
  null,
  "Не вистачає $0 диска",
  "Не вистачає $0 дисків",
  "Не вистачає $0 дисків"
 ],
 "$0 hour": [
  null,
  "$0 година",
  "$0 години",
  "$0 годин"
 ],
 "$0 minute": [
  null,
  "$0 хвилина",
  "$0 хвилини",
  "$0 хвилин"
 ],
 "$0 month": [
  null,
  "$0 місяць",
  "$0 місяці",
  "$0 місяців"
 ],
 "$0 week": [
  null,
  "$0 тиждень",
  "$0 тижні",
  "$0 тижнів"
 ],
 "$0 year": [
  null,
  "$0 рік",
  "$0 роки",
  "$0 років"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 година"
 ],
 "1 week": [
  null,
  "1 тиждень"
 ],
 "5 minutes": [
  null,
  "5 хвилин"
 ],
 "6 hours": [
  null,
  "6 годин"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Control": [
  null,
  "Керування"
 ],
 "Create": [
  null,
  "Створити"
 ],
 "Development": [
  null,
  "Розробка"
 ],
 "Empty": [
  null,
  "Порожній"
 ],
 "Go to now": [
  null,
  "Перейти зараз"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "No such file or directory": [
  null,
  "Немає такого файла або каталогу"
 ],
 "Not ready": [
  null,
  "Не готовий"
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "Path to file": [
  null,
  "Шлях до файла"
 ],
 "Ready": [
  null,
  "Готовий"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Unavailable": [
  null,
  "Недоступний"
 ],
 "View all logs": [
  null,
  "Переглянути усі журнали"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 байтів двійкових даних]"
 ],
 "[binary data]": [
  null,
  "[двійкові дані]"
 ],
 "[no data]": [
  null,
  "[немає даних]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "Не вистачає $0 диска",
  "Не вистачає $0 дисків",
  "Не вистачає $0 дисків"
 ],
 "key\u0004Control": [
  null,
  "Ctrl"
 ],
 "verb\u0004Empty": [
  null,
  "Спорожнити"
 ],
 "verb\u0004Ready": [
  null,
  "Готово"
 ]
});
