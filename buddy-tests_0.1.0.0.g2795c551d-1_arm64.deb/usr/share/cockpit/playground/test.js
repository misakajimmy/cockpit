/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./pkg/lib/patternfly/patternfly-4-cockpit.scss":
/*!******************************************************!*\
  !*** ./pkg/lib/patternfly/patternfly-4-cockpit.scss ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./node_modules/@patternfly/patternfly/components/Button/button.css":
/*!**************************************************************************!*\
  !*** ./node_modules/@patternfly/patternfly/components/Button/button.css ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./node_modules/@patternfly/patternfly/components/Page/page.css":
/*!**********************************************************************!*\
  !*** ./node_modules/@patternfly/patternfly/components/Page/page.css ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "cockpit":
/*!**************************!*\
  !*** external "cockpit" ***!
  \**************************/
/***/ ((module) => {

module.exports = cockpit;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!********************************!*\
  !*** ./pkg/playground/test.js ***!
  \********************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var cockpit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cockpit */ "cockpit");
/* harmony import */ var cockpit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cockpit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_patternfly_patternfly_4_cockpit_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/patternfly/patternfly-4-cockpit.scss */ "./pkg/lib/patternfly/patternfly-4-cockpit.scss");
/* harmony import */ var _node_modules_patternfly_patternfly_components_Button_button_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/@patternfly/patternfly/components/Button/button.css */ "./node_modules/@patternfly/patternfly/components/Button/button.css");
/* harmony import */ var _node_modules_patternfly_patternfly_components_Page_page_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../node_modules/@patternfly/patternfly/components/Page/page.css */ "./node_modules/@patternfly/patternfly/components/Page/page.css");






document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("hammer").addEventListener("click", e => e.target.setAttribute("hidden", "hidden"));
  document.querySelector(".cockpit-internal-reauthorize .pf-c-button").addEventListener("click", () => {
    document.querySelector(".cockpit-internal-reauthorize span").textContent = "checking...";
    cockpit__WEBPACK_IMPORTED_MODULE_0___default().script("pkcheck --action-id org.freedesktop.policykit.exec --process $$ -u 2>&1", {
      superuser: "try"
    }).stream(data => console.debug(data)).then(() => {
      document.querySelector(".cockpit-internal-reauthorize span").textContent = "result: authorized";
    }).catch(() => {
      document.querySelector(".cockpit-internal-reauthorize span").textContent = "result: access-denied";
    });
  });
  document.querySelector(".super-channel .pf-c-button").addEventListener("click", () => {
    document.querySelector(".super-channel span").textContent = "checking...";
    cockpit__WEBPACK_IMPORTED_MODULE_0___default().spawn(["id"], {
      superuser: true
    }).then(data => {
      console.log("done");
      document.querySelector(".super-channel span").textContent = "result: " + data;
    }).catch(ex => {
      console.log("fail");
      document.querySelector(".super-channel span").textContent = "result: " + ex.problem;
    });
  });
  document.querySelector(".lock-channel .pf-c-button").addEventListener("click", () => {
    document.querySelector(".lock-channel span").textContent = "locking...";
    cockpit__WEBPACK_IMPORTED_MODULE_0___default().spawn(["flock", "-o", "/tmp/playground-test-lock", "-c", "echo locked; sleep infinity"], {
      superuser: "try",
      err: "message"
    }).stream(data => {
      document.querySelector(".lock-channel span").textContent = data;
    }).catch(ex => {
      document.querySelector(".lock-channel span").textContent = "failed: " + ex.toString();
    });
  });
  function update_nav() {
    document.getElementById("nav").innerHTML = '';
    const path = ["top"].concat((cockpit__WEBPACK_IMPORTED_MODULE_0___default().location.path));
    const e_nav = document.getElementById("nav");
    path.forEach((p, i) => {
      if (i < path.length - 1) {
        const e_link = document.createElement("a");
        e_link.setAttribute("tabindex", "0");
        e_link.textContent = p;
        e_link.addEventListener("click", () => cockpit__WEBPACK_IMPORTED_MODULE_0___default().location.go(path.slice(1, i + 1)));
        e_nav.append(e_link, " >> ");
      } else {
        const e_span = document.createElement("span");
        e_span.textContent = p;
        e_nav.appendChild(e_span);
      }
    });
  }
  cockpit__WEBPACK_IMPORTED_MODULE_0___default().addEventListener('locationchanged', update_nav);
  update_nav();
  document.getElementById('go-down').addEventListener("click", () => {
    const len = (cockpit__WEBPACK_IMPORTED_MODULE_0___default().location.path.length);
    cockpit__WEBPACK_IMPORTED_MODULE_0___default().location.go(cockpit__WEBPACK_IMPORTED_MODULE_0___default().location.path.concat(len.toString()), {
      length: len.toString()
    });
  });
  const counter = cockpit__WEBPACK_IMPORTED_MODULE_0___default().file("/tmp/counter", {
    syntax: JSON
  });
  function normalize_counter(obj) {
    obj = obj || {};
    obj.counter = obj.counter || 0;
    return obj;
  }
  function complain(error) {
    document.getElementById('file-error').textContent = error.toString();
  }
  function changed(content, tag, error) {
    if (error) return complain(error);
    document.getElementById('file-content').textContent = normalize_counter(content).counter;
    document.getElementById('file-error').innerHTML = "";
  }
  counter.watch(changed);
  document.getElementById('modify-file').addEventListener("click", () => {
    counter.modify(obj => {
      obj = normalize_counter(obj);
      obj.counter += 1;
      return obj;
    }).catch(complain);
  });
  function load_file() {
    cockpit__WEBPACK_IMPORTED_MODULE_0___default().file("/tmp/counter").read().then(content => {
      document.getElementById('edit-file').value = content;
    });
  }
  function save_file() {
    cockpit__WEBPACK_IMPORTED_MODULE_0___default().file("/tmp/counter").replace(document.getElementById('edit-file').value);
  }
  document.getElementById('load-file').addEventListener("click", load_file);
  document.getElementById('save-file').addEventListener("click", save_file);
  load_file();
  document.getElementById('delete-file').addEventListener("click", () => cockpit__WEBPACK_IMPORTED_MODULE_0___default().spawn(["rm", "-f", "/tmp/counter"]));
  document.body.removeAttribute("hidden");
  function show_hidden() {
    document.getElementById("hidden").textContent = (cockpit__WEBPACK_IMPORTED_MODULE_0___default().hidden) ? "hidden" : "visible";
  }
  cockpit__WEBPACK_IMPORTED_MODULE_0___default().addEventListener("visibilitychange", show_hidden);
  show_hidden();
});
})();

/******/ })()
;
//# sourceMappingURL=test.js.map