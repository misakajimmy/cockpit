cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagen"
 ],
 "$0 disk is missing": [
  null,
  "$0 schijf ontbreekt",
  "$0 schijven ontbreken"
 ],
 "$0 hour": [
  null,
  "$0 uur",
  "$0 uren"
 ],
 "$0 minute": [
  null,
  "$0 minuut",
  "$0 minuten"
 ],
 "$0 month": [
  null,
  "$0 maand",
  "$0 maanden"
 ],
 "$0 week": [
  null,
  "$0 week",
  "$0 weken"
 ],
 "$0 year": [
  null,
  "$0 jaar",
  "$0 jaren"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 uur"
 ],
 "1 week": [
  null,
  "1 week"
 ],
 "5 minutes": [
  null,
  "5 minuten"
 ],
 "6 hours": [
  null,
  "6 uren"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Control": [
  null,
  "Controle"
 ],
 "Create": [
  null,
  "Aanmaken"
 ],
 "Development": [
  null,
  "Ontwikkeling"
 ],
 "Empty": [
  null,
  "Leeg"
 ],
 "Go to now": [
  null,
  "Ga nu naar"
 ],
 "Learn more": [
  null,
  "Kom meer te weten"
 ],
 "No such file or directory": [
  null,
  "Bestand of map bestaat niet"
 ],
 "Not ready": [
  null,
  "Niet klaar"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Path to file": [
  null,
  "Pad naar bestand"
 ],
 "Ready": [
  null,
  "Klaar"
 ],
 "Reboot": [
  null,
  "Opnieuw opstarten"
 ],
 "Unavailable": [
  null,
  "Niet beschikbaar"
 ],
 "View all logs": [
  null,
  "Bekijk alle logboeken"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bytes binaire data]"
 ],
 "[binary data]": [
  null,
  "[binaire data]"
 ],
 "[no data]": [
  null,
  "[geen data]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 schijf ontbreekt",
  "$0 schijven ontbreken"
 ],
 "key\u0004Control": [
  null,
  "Controle"
 ],
 "verb\u0004Empty": [
  null,
  "Leegmaken"
 ],
 "verb\u0004Ready": [
  null,
  "Klaar"
 ]
});
