cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "$0 day": [
  null,
  "$0 gün",
  "$0 gün"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk eksik",
  "$0 disk eksik"
 ],
 "$0 hour": [
  null,
  "$0 saat",
  "$0 saat"
 ],
 "$0 minute": [
  null,
  "$0 dakika",
  "$0 dakika"
 ],
 "$0 month": [
  null,
  "$0 ay",
  "$0 ay"
 ],
 "$0 week": [
  null,
  "$0 hafta",
  "$0 hafta"
 ],
 "$0 year": [
  null,
  "$0 yıl",
  "$0 yıl"
 ],
 "1 day": [
  null,
  "1 gün"
 ],
 "1 hour": [
  null,
  "1 saat"
 ],
 "1 week": [
  null,
  "1 hafta"
 ],
 "5 minutes": [
  null,
  "5 dakika"
 ],
 "6 hours": [
  null,
  "6 saat"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Control": [
  null,
  "Denetim"
 ],
 "Create": [
  null,
  "Oluştur"
 ],
 "Development": [
  null,
  "Geliştirme"
 ],
 "Empty": [
  null,
  "Boş"
 ],
 "Go to now": [
  null,
  "Şimdiye git"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "No such file or directory": [
  null,
  "Böyle bir dosya ya da dizin yok"
 ],
 "Not ready": [
  null,
  "Hazır değil"
 ],
 "Ok": [
  null,
  "Tamam"
 ],
 "Path to file": [
  null,
  "Dosyanın yolu"
 ],
 "Ready": [
  null,
  "Hazır"
 ],
 "Reboot": [
  null,
  "Yeniden başlat"
 ],
 "Unavailable": [
  null,
  "Kullanılamıyor"
 ],
 "View all logs": [
  null,
  "Tüm günlükleri görüntüle"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bayt ikili veri]"
 ],
 "[binary data]": [
  null,
  "[ikili veri]"
 ],
 "[no data]": [
  null,
  "[veri yok]"
 ],
 "disk-non-rotational\u0004$0 disk is missing": [
  null,
  "$0 disk eksik",
  "$0 disk eksik"
 ],
 "key\u0004Control": [
  null,
  "Ctrl"
 ],
 "verb\u0004Empty": [
  null,
  "Boşalt"
 ],
 "verb\u0004Ready": [
  null,
  "Hazırla"
 ]
});
