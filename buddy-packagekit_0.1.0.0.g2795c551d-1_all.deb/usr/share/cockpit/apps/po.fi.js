cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Toimet"
 ],
 "Applications": [
  null,
  "Sovellukset"
 ],
 "Applications list": [
  null,
  "Sovellusten luettelo"
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Checking for new applications": [
  null,
  "Etsitään uusia sovelluksia"
 ],
 "Close": [
  null,
  "Sulje"
 ],
 "Error": [
  null,
  "Virhe"
 ],
 "Go to application": [
  null,
  "Siirry sovellukseen"
 ],
 "Install": [
  null,
  "Asennus"
 ],
 "Installing": [
  null,
  "Asennetaan"
 ],
 "Learn more": [
  null,
  "Opi lisää"
 ],
 "No applications installed or available.": [
  null,
  "Ei sovelluksia asennettuna tai saatavilla."
 ],
 "No description provided.": [
  null,
  "Kuvausta ei annettu."
 ],
 "No installation package found for this application.": [
  null,
  "Tälle sovellukselle ei löytynyt asennuspakettia."
 ],
 "Ok": [
  null,
  "OK"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kaatui"
 ],
 "Remove": [
  null,
  "Poista"
 ],
 "Removing": [
  null,
  "Poistetaan"
 ],
 "Unknown application": [
  null,
  "Tuntematon sovellus"
 ],
 "Update package information": [
  null,
  "Päivitä pakettitiedot"
 ],
 "View project website": [
  null,
  "Näytä projektin verkkosivusto"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Odotetaan muiden ohjelmien paketinhallinnan käyttämisen päättymistä..."
 ],
 "add-on": [
  null,
  "lisäosa"
 ],
 "addon": [
  null,
  "lisäosa"
 ],
 "apps": [
  null,
  "sovellukset"
 ],
 "extension": [
  null,
  "laajennus"
 ],
 "install": [
  null,
  "asenna"
 ],
 "plugin": [
  null,
  "kytkettävä"
 ]
});
