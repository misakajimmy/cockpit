cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Eylemler"
 ],
 "Applications": [
  null,
  "Uygulamalar"
 ],
 "Applications list": [
  null,
  "Uygulamalar listesi"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Checking for new applications": [
  null,
  "Yeni uygulamalar denetleniyor"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Error": [
  null,
  "Hata"
 ],
 "Go to application": [
  null,
  "Uygulamaya git"
 ],
 "Install": [
  null,
  "Yükle"
 ],
 "Installing": [
  null,
  "Yükleniyor"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "No applications installed or available.": [
  null,
  "Yüklü veya kullanılabilir uygulamalar yok."
 ],
 "No description provided.": [
  null,
  "Sağlanan açıklama yok."
 ],
 "No installation package found for this application.": [
  null,
  "Bu uygulama için kurulum paketi bulunamadı."
 ],
 "Ok": [
  null,
  "Tamam"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit çöktü"
 ],
 "Remove": [
  null,
  "Kaldır"
 ],
 "Removing": [
  null,
  "Kaldırılıyor"
 ],
 "Unknown application": [
  null,
  "Bilinmeyen uygulama"
 ],
 "Update package information": [
  null,
  "Paket bilgilerini güncelle"
 ],
 "View project website": [
  null,
  "Proje web sitesini görüntüle"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Diğer programların paket yöneticisini kullanmayı bitirmesi bekleniyor..."
 ],
 "add-on": [
  null,
  "eklenti"
 ],
 "addon": [
  null,
  "eklenti"
 ],
 "apps": [
  null,
  "uygulamalar"
 ],
 "extension": [
  null,
  "uzantı"
 ],
 "install": [
  null,
  "yükle"
 ],
 "plugin": [
  null,
  "eklenti"
 ]
});
