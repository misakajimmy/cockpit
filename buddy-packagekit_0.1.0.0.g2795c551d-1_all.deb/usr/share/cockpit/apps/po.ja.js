cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "動作"
 ],
 "Applications": [
  null,
  "アプリケーション"
 ],
 "Applications list": [
  null,
  "アプリケーションリスト"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Checking for new applications": [
  null,
  "新しいアプリケーションの確認中"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Error": [
  null,
  "エラー"
 ],
 "Go to application": [
  null,
  "アプリケーションへ移動"
 ],
 "Install": [
  null,
  "インストール"
 ],
 "Installing": [
  null,
  "インストール中"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "No applications installed or available.": [
  null,
  "アプリケーションがインストールされていないか、利用できません。"
 ],
 "No description provided.": [
  null,
  "説明が入力されていません。"
 ],
 "No installation package found for this application.": [
  null,
  "このアプリケーションのインストールパッケージが見つかりませんでした。"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit がクラッシュしました"
 ],
 "Remove": [
  null,
  "削除"
 ],
 "Removing": [
  null,
  "削除中"
 ],
 "Unknown application": [
  null,
  "不明なアプリケーション"
 ],
 "Update package information": [
  null,
  "パッケージ情報アップデート"
 ],
 "View project website": [
  null,
  "プロジェクト Web サイトの表示"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "パッケージマネージャーを使用して、その他のプログラムを終了するのを待機中..."
 ],
 "add-on": [
  null,
  "add-on"
 ],
 "addon": [
  null,
  "addon"
 ],
 "apps": [
  null,
  "apps"
 ],
 "extension": [
  null,
  "拡張"
 ],
 "install": [
  null,
  "インストール"
 ],
 "plugin": [
  null,
  "プラグイン"
 ]
});
