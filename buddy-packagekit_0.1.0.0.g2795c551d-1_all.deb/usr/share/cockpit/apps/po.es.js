cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Acciones"
 ],
 "Applications": [
  null,
  "Aplicaciones"
 ],
 "Applications list": [
  null,
  "Lista de aplicaciones"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Checking for new applications": [
  null,
  "Comprobando si hay nuevas aplicaciones"
 ],
 "Close": [
  null,
  "Cerrar"
 ],
 "Error": [
  null,
  "Error"
 ],
 "Go to application": [
  null,
  "Ir a la aplicación"
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Installing": [
  null,
  "Instalando"
 ],
 "Learn more": [
  null,
  "Aprenda más"
 ],
 "No applications installed or available.": [
  null,
  "No hay aplicaciones instaladas o disponibles."
 ],
 "No description provided.": [
  null,
  "No se ha suministrado una descripción."
 ],
 "No installation package found for this application.": [
  null,
  "No se ha encontrado el paquete de instalación para esta aplicación."
 ],
 "Ok": [
  null,
  "Aceptar"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit colapsó"
 ],
 "Remove": [
  null,
  "Eliminar"
 ],
 "Removing": [
  null,
  "Eliminando"
 ],
 "Unknown application": [
  null,
  "Aplicación desconocida"
 ],
 "Update package information": [
  null,
  "Actualizar la información de paquetes"
 ],
 "View project website": [
  null,
  "Sitio Web del proyecto"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Esperando que otros programas terminen de usar el gestor de paquetes..."
 ],
 "add-on": [
  null,
  "complemento"
 ],
 "addon": [
  null,
  "complemento"
 ],
 "apps": [
  null,
  "aplicaciones"
 ],
 "extension": [
  null,
  "extensión"
 ],
 "install": [
  null,
  "instalar"
 ],
 "plugin": [
  null,
  "plugin"
 ]
});
