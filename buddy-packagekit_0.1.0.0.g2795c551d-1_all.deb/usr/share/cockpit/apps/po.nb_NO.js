cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Handlinger"
 ],
 "Applications": [
  null,
  "Applikasjoner"
 ],
 "Applications list": [
  null,
  "Applikasjonsliste"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Checking for new applications": [
  null,
  "Ser etter nye applikasjoner"
 ],
 "Close": [
  null,
  "Lukk"
 ],
 "Error": [
  null,
  "Feil"
 ],
 "Go to application": [
  null,
  "Gå til applikasjon"
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Installing": [
  null,
  "Installerer"
 ],
 "Learn more": [
  null,
  "Lær mer"
 ],
 "No description provided.": [
  null,
  "Ingen beskrivelse gitt."
 ],
 "No installation package found for this application.": [
  null,
  "Ingen installasjonspakke funnet for dette programmet."
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit krasjet"
 ],
 "Remove": [
  null,
  "Fjern"
 ],
 "Removing": [
  null,
  "Fjerner"
 ],
 "Unknown application": [
  null,
  "Ukjent program"
 ],
 "Update package information": [
  null,
  "Oppdater pakkeinformasjon"
 ],
 "View project website": [
  null,
  "Vis prosjektets nettsted"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Venter på at andre programmer skal bli ferdige å bruke pakkebehandling..."
 ],
 "add-on": [
  null,
  "tillegg"
 ],
 "addon": [
  null,
  "tillegg"
 ],
 "apps": [
  null,
  "apper"
 ],
 "extension": [
  null,
  "utvidelse"
 ],
 "install": [
  null,
  "installer"
 ],
 "plugin": [
  null,
  "utvidelse"
 ]
});
