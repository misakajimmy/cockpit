cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Дії"
 ],
 "Applications": [
  null,
  "Програми"
 ],
 "Applications list": [
  null,
  "Список програм"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Checking for new applications": [
  null,
  "Шукаємо нові програми"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Error": [
  null,
  "Помилка"
 ],
 "Go to application": [
  null,
  "Перейти до програми"
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Installing": [
  null,
  "Встановлення"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "No applications installed or available.": [
  null,
  "Немає встановлених або доступних програм."
 ],
 "No description provided.": [
  null,
  "Опису не надано."
 ],
 "No installation package found for this application.": [
  null,
  "Для цієї програми не знайдено пакунка для встановлення."
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "PackageKit crashed": [
  null,
  "Аварійне завершення роботи PackageKit"
 ],
 "Remove": [
  null,
  "Вилучити"
 ],
 "Removing": [
  null,
  "Вилучаємо"
 ],
 "Unknown application": [
  null,
  "Невідома програма"
 ],
 "Update package information": [
  null,
  "Оновити дані щодо пакунків"
 ],
 "View project website": [
  null,
  "Переглянути сайт проєкту"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Очікуємо на завершення роботи з програмою для керування пакунками інших програм…"
 ],
 "add-on": [
  null,
  "додаток"
 ],
 "addon": [
  null,
  "addon"
 ],
 "apps": [
  null,
  "програми"
 ],
 "extension": [
  null,
  "розширення"
 ],
 "install": [
  null,
  "встановити"
 ],
 "plugin": [
  null,
  "додаток"
 ]
});
