cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Действия"
 ],
 "Applications": [
  null,
  "Приложения"
 ],
 "Applications list": [
  null,
  "Список приложений"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Checking for new applications": [
  null,
  "Проверка наличия новых приложений"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Error": [
  null,
  "Ошибка"
 ],
 "Go to application": [
  null,
  "Перейти к приложению"
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Installing": [
  null,
  "Установка"
 ],
 "Learn more": [
  null,
  "Подробнее..."
 ],
 "No description provided.": [
  null,
  "Описание отсутствует."
 ],
 "No installation package found for this application.": [
  null,
  "Пакет установки для данного приложения не найден."
 ],
 "Ok": [
  null,
  "OK"
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "Remove": [
  null,
  "Удалить"
 ],
 "Removing": [
  null,
  "Удаление"
 ],
 "Unknown application": [
  null,
  "Неизвестное приложение"
 ],
 "Update package information": [
  null,
  "Обновить сведения о пакете"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Ожидание завершения использования другими программами диспетчера пакетов..."
 ],
 "add-on": [
  null,
  "дополнение"
 ],
 "addon": [
  null,
  "дополнение"
 ],
 "apps": [
  null,
  "программы"
 ],
 "extension": [
  null,
  "расширение"
 ],
 "install": [
  null,
  "установить"
 ],
 "plugin": [
  null,
  "подключаемый модуль"
 ]
});
