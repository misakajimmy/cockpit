cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Actions"
 ],
 "Applications": [
  null,
  "Applications"
 ],
 "Applications list": [
  null,
  "Liste des applications"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Checking for new applications": [
  null,
  "Vérification de nouvelles applications"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Error": [
  null,
  "Erreur"
 ],
 "Go to application": [
  null,
  "Aller à l’application"
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Installing": [
  null,
  "Installation"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "No applications installed or available.": [
  null,
  "Aucune application installée ou disponible."
 ],
 "No description provided.": [
  null,
  "Aucune description fournie."
 ],
 "No installation package found for this application.": [
  null,
  "Aucun paquet d’installation n’a été trouvé pour cette application."
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "PackageKit crashed": [
  null,
  "Plantage de « PackageKit »"
 ],
 "Remove": [
  null,
  "Retirer"
 ],
 "Removing": [
  null,
  "Suppression"
 ],
 "Unknown application": [
  null,
  "Application inconnue"
 ],
 "Update package information": [
  null,
  "Mise à jour des informations sur le paquet"
 ],
 "View project website": [
  null,
  "Voir le site du projet"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "En attente d’autres programmes pour terminer l’utilisation du gestionnaire de paquets…"
 ],
 "add-on": [
  null,
  "greffon"
 ],
 "addon": [
  null,
  "greffon"
 ],
 "apps": [
  null,
  "applis"
 ],
 "extension": [
  null,
  "extension"
 ],
 "install": [
  null,
  "Installer"
 ],
 "plugin": [
  null,
  "plugin"
 ]
});
