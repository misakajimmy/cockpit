cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "Actions": [
  null,
  "פעולות"
 ],
 "Applications": [
  null,
  "יישומים"
 ],
 "Applications list": [
  null,
  "רשימת יישומים"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Checking for new applications": [
  null,
  "מתבצע איתור של יישומים חדשים"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Error": [
  null,
  "שגיאה"
 ],
 "Go to application": [
  null,
  "לעבור ליישום"
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Installing": [
  null,
  "בהתקנה"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "No description provided.": [
  null,
  "לא סופק תיאור."
 ],
 "No installation package found for this application.": [
  null,
  "לא נמצאה חבילת התקנה ליישום הזה."
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit קרס"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "Removing": [
  null,
  "בהסרה"
 ],
 "Unknown application": [
  null,
  "יישום לא ידוע"
 ],
 "Update package information": [
  null,
  "פרטי חבילת עדכון"
 ],
 "View project website": [
  null,
  "הצגת אתר המיזם"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "בהמתנה לתכניות אחרות שתסיימנה להשתמש במנהל החבילות…"
 ],
 "add-on": [
  null,
  "תוספת"
 ],
 "addon": [
  null,
  "תוספת"
 ],
 "apps": [
  null,
  "יישומים"
 ],
 "extension": [
  null,
  "הרחבה"
 ],
 "install": [
  null,
  "התקנה"
 ],
 "plugin": [
  null,
  "תוסף"
 ]
});
