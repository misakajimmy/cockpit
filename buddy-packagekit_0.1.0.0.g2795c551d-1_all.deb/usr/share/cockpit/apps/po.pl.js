cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Działania"
 ],
 "Applications": [
  null,
  "Aplikacje"
 ],
 "Applications list": [
  null,
  "Lista aplikacji"
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Checking for new applications": [
  null,
  "Wyszukiwanie nowych aplikacji"
 ],
 "Close": [
  null,
  "Zamknij"
 ],
 "Error": [
  null,
  "Błąd"
 ],
 "Go to application": [
  null,
  "Przejdź do aplikacji"
 ],
 "Install": [
  null,
  "Zainstaluj"
 ],
 "Installing": [
  null,
  "Instalowanie"
 ],
 "Learn more": [
  null,
  "Więcej informacji"
 ],
 "No applications installed or available.": [
  null,
  "Brak zainstalowanych lub dostępnych aplikacji."
 ],
 "No description provided.": [
  null,
  "Nie podano opisu."
 ],
 "No installation package found for this application.": [
  null,
  "Nie odnaleziono pakietu instalacji dla tego programu."
 ],
 "Ok": [
  null,
  "OK"
 ],
 "PackageKit crashed": [
  null,
  "Usługa PackageKit uległa awarii"
 ],
 "Remove": [
  null,
  "Usuń"
 ],
 "Removing": [
  null,
  "Usuwanie"
 ],
 "Unknown application": [
  null,
  "Nieznana aplikacja"
 ],
 "Update package information": [
  null,
  "Zaktualizuj informacje o pakiecie"
 ],
 "View project website": [
  null,
  "Strona projektu"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Oczekiwanie, aż inne programy skończą korzystać z menedżera pakietów…"
 ],
 "add-on": [
  null,
  "dodatek"
 ],
 "addon": [
  null,
  "dodatek"
 ],
 "apps": [
  null,
  "aplikacje"
 ],
 "extension": [
  null,
  "rozszerzenie"
 ],
 "install": [
  null,
  "zainstaluj"
 ],
 "plugin": [
  null,
  "wtyczka"
 ]
});
