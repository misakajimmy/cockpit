cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Acties"
 ],
 "Applications": [
  null,
  "Toepassingen"
 ],
 "Applications list": [
  null,
  "Toepassingenlijst"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Checking for new applications": [
  null,
  "Controleren op nieuwe toepassingen"
 ],
 "Close": [
  null,
  "Sluiten"
 ],
 "Error": [
  null,
  "Fout"
 ],
 "Go to application": [
  null,
  "Ga naar toepassing"
 ],
 "Install": [
  null,
  "Installeren"
 ],
 "Installing": [
  null,
  "Installeren"
 ],
 "Learn more": [
  null,
  "Kom meer te weten"
 ],
 "No applications installed or available.": [
  null,
  "Geen toepassingen geïnstalleerd of beschikbaar."
 ],
 "No description provided.": [
  null,
  "Geen beschrijving aangeboden."
 ],
 "No installation package found for this application.": [
  null,
  "Geen installatiepakket gevonden voor deze toepassing."
 ],
 "Ok": [
  null,
  "OK"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit is gecrasht"
 ],
 "Remove": [
  null,
  "Verwijderen"
 ],
 "Removing": [
  null,
  "Verwijderen"
 ],
 "Unknown application": [
  null,
  "Onbekende toepassing"
 ],
 "Update package information": [
  null,
  "Vernieuw pakketinformatie"
 ],
 "View project website": [
  null,
  "Bekijk projectwebsite"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Wachten op andere programma's om het gebruik van de pakketbeheerder te beëindigen..."
 ],
 "add-on": [
  null,
  "toevoeging"
 ],
 "addon": [
  null,
  "toevoeging"
 ],
 "apps": [
  null,
  "apps"
 ],
 "extension": [
  null,
  "extensie"
 ],
 "install": [
  null,
  "installeren"
 ],
 "plugin": [
  null,
  "plug-in"
 ]
});
