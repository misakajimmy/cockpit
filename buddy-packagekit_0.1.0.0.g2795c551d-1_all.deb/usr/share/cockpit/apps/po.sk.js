cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Akcie"
 ],
 "Applications": [
  null,
  "Aplikácie"
 ],
 "Applications list": [
  null,
  "Zoznam aplikácií"
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Checking for new applications": [
  null,
  "Hľadajú sa nové aplikácie"
 ],
 "Close": [
  null,
  "Zavrieť"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Go to application": [
  null,
  "Prejsť na aplikáciu"
 ],
 "Install": [
  null,
  "Inštalovať"
 ],
 "Installing": [
  null,
  "Inštaluje sa"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "No applications installed or available.": [
  null,
  "Nie sú nainštalované ani dostupné žiadne aplikácie."
 ],
 "No description provided.": [
  null,
  "Nie je poskytnutý žiaden popis."
 ],
 "No installation package found for this application.": [
  null,
  "Pre túto aplikáciu nebol nájdený žiaden inštalačný balíček."
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Remove": [
  null,
  "Odobrať"
 ],
 "Removing": [
  null,
  "Oboberá sa"
 ],
 "Unknown application": [
  null,
  "Neznáma aplikácia"
 ],
 "Update package information": [
  null,
  ""
 ],
 "View project website": [
  null,
  "Webové stránky projektu"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Čaká sa až ostatné programy dokončia používanie správcu balíčkov..."
 ],
 "add-on": [
  null,
  "doplnok"
 ],
 "addon": [
  null,
  "doplnok"
 ],
 "apps": [
  null,
  "aplikácie"
 ],
 "extension": [
  null,
  "rozšírenie"
 ],
 "install": [
  null,
  "inštalovať"
 ],
 "plugin": [
  null,
  "zásuvný model"
 ]
});
