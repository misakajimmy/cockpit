cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "操作"
 ],
 "Applications": [
  null,
  "应用"
 ],
 "Applications list": [
  null,
  "应用列表"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Checking for new applications": [
  null,
  "检查新的应用"
 ],
 "Close": [
  null,
  "关闭"
 ],
 "Error": [
  null,
  "错误"
 ],
 "Go to application": [
  null,
  "转到应用"
 ],
 "Install": [
  null,
  "安装"
 ],
 "Installing": [
  null,
  "正在安装"
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "No applications installed or available.": [
  null,
  "应用未安装或不可用."
 ],
 "No description provided.": [
  null,
  "没有提供说明。"
 ],
 "No installation package found for this application.": [
  null,
  "没有找到该应用的安装包。"
 ],
 "Ok": [
  null,
  "确认"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit 已崩溃"
 ],
 "Remove": [
  null,
  "删除"
 ],
 "Removing": [
  null,
  "正在移除"
 ],
 "Unknown application": [
  null,
  "未知应用"
 ],
 "Update package information": [
  null,
  "更新软件包信息"
 ],
 "View project website": [
  null,
  "查看项目网站"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "正在等待其他程序来结束使用软件包管理器..."
 ],
 "add-on": [
  null,
  "插件"
 ],
 "addon": [
  null,
  "插件"
 ],
 "apps": [
  null,
  "应用程序"
 ],
 "extension": [
  null,
  "扩展"
 ],
 "install": [
  null,
  "安装"
 ],
 "plugin": [
  null,
  "插件"
 ]
});
