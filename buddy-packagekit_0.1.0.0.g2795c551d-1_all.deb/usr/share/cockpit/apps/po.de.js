cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Aktionen"
 ],
 "Applications": [
  null,
  "Anwendungen"
 ],
 "Applications list": [
  null,
  "Anwendungsliste"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Checking for new applications": [
  null,
  "Auf neue Anwendungen wird geprüft"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Error": [
  null,
  "Fehler"
 ],
 "Go to application": [
  null,
  "Gehe zur Anwendung"
 ],
 "Install": [
  null,
  "Installation"
 ],
 "Installing": [
  null,
  "Wird installiert"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "No applications installed or available.": [
  null,
  "Keine Anwendungen installiert oder verfügbar."
 ],
 "No description provided.": [
  null,
  "Keine Beschreibung angegeben."
 ],
 "No installation package found for this application.": [
  null,
  "Kein Installationspaket für diese Anwendung gefunden."
 ],
 "Ok": [
  null,
  "OK"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ist abgestürzt"
 ],
 "Remove": [
  null,
  "Entfernen"
 ],
 "Removing": [
  null,
  "Entfernen"
 ],
 "Unknown application": [
  null,
  "Unbekannte Anwendung"
 ],
 "Update package information": [
  null,
  "Paket Informationen updaten"
 ],
 "View project website": [
  null,
  "Projekt-Webseite ansehen"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Warten, bis andere Programme mit dem Paketmanager fertig sind ..."
 ],
 "add-on": [
  null,
  "Add-on"
 ],
 "addon": [
  null,
  "AddOn"
 ],
 "apps": [
  null,
  "Programme"
 ],
 "extension": [
  null,
  "Erweiterung"
 ],
 "install": [
  null,
  "Installation"
 ],
 "plugin": [
  null,
  "Plugin"
 ]
});
