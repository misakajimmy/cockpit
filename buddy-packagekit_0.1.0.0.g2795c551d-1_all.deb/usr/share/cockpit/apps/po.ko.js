cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "동작"
 ],
 "Applications": [
  null,
  "응용프로그램"
 ],
 "Applications list": [
  null,
  "응용프로그램 목록"
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Checking for new applications": [
  null,
  "신규 응용프로그램 확인 중"
 ],
 "Close": [
  null,
  "닫기"
 ],
 "Error": [
  null,
  "오류"
 ],
 "Go to application": [
  null,
  "응용프로그램으로 이동"
 ],
 "Install": [
  null,
  "설치"
 ],
 "Installing": [
  null,
  "설치 중"
 ],
 "Learn more": [
  null,
  "더 알아보기"
 ],
 "No applications installed or available.": [
  null,
  "설치되거나 사용 가능한 응용프로그램이 없습니다."
 ],
 "No description provided.": [
  null,
  "설명이 없습니다."
 ],
 "No installation package found for this application.": [
  null,
  "이 꾸러미에 대한 설치 꾸러미를 찾을 수 없습니다."
 ],
 "Ok": [
  null,
  "확인"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit가 충돌했습니다"
 ],
 "Remove": [
  null,
  "제거"
 ],
 "Removing": [
  null,
  "삭제 중"
 ],
 "Unknown application": [
  null,
  "알 수 없는 응용프로그램"
 ],
 "Update package information": [
  null,
  "꾸러미 정보 최신화"
 ],
 "View project website": [
  null,
  "프로젝트 웹사이트 보기"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "꾸러미 관리자를 사용 중이어서 다른 프로그램이 종료 할 때까지 대기 중..."
 ],
 "add-on": [
  null,
  "add-on"
 ],
 "addon": [
  null,
  "addon"
 ],
 "apps": [
  null,
  "응용프로그램"
 ],
 "extension": [
  null,
  "확장"
 ],
 "install": [
  null,
  "설치"
 ],
 "plugin": [
  null,
  "플러그인"
 ]
});
