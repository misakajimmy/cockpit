cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Akce"
 ],
 "Applications": [
  null,
  "Aplikace"
 ],
 "Applications list": [
  null,
  "Seznam aplikací"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Checking for new applications": [
  null,
  "Hledají se nové aplikace"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Go to application": [
  null,
  "Přejít na aplikaci"
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Installing": [
  null,
  "Instaluje se"
 ],
 "Learn more": [
  null,
  "Další informace naleznete"
 ],
 "No applications installed or available.": [
  null,
  "Nejsou nainstalované ani dostupné žádné aplikace."
 ],
 "No description provided.": [
  null,
  "Není poskytnut žádný popis."
 ],
 "No installation package found for this application.": [
  null,
  "Pro tuto aplikaci nebyl nalezen žádný instalační balíček."
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "Remove": [
  null,
  "Odebrat"
 ],
 "Removing": [
  null,
  "Odebírá se"
 ],
 "Unknown application": [
  null,
  "Neznámá aplikace"
 ],
 "Update package information": [
  null,
  "Aktualizovat informace o balíčcích"
 ],
 "View project website": [
  null,
  "Webové stránky projektu"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Čeká se až ostatní programy dokončí použití správy balíčků…"
 ],
 "add-on": [
  null,
  "doplněk"
 ],
 "addon": [
  null,
  "doplněk"
 ],
 "apps": [
  null,
  "aplikace"
 ],
 "extension": [
  null,
  "rozšíření"
 ],
 "install": [
  null,
  "nainstalovat"
 ],
 "plugin": [
  null,
  "zásuvný modul"
 ]
});
