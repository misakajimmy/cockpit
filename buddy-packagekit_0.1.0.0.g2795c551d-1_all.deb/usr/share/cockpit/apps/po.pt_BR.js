cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Ações"
 ],
 "Applications": [
  null,
  "Aplicações"
 ],
 "Applications list": [
  null,
  "Lista de aplicações"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Checking for new applications": [
  null,
  "Verificando novos aplicativos"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Error": [
  null,
  "Erro"
 ],
 "Go to application": [
  null,
  "Vá para o aplicativo"
 ],
 "Install": [
  null,
  "Instale"
 ],
 "Installing": [
  null,
  "Instalando"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "No description provided.": [
  null,
  "Nenhuma descrição fornecida."
 ],
 "No installation package found for this application.": [
  null,
  "Nenhum pacote de instalação encontrado para este aplicativo."
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit caiu"
 ],
 "Remove": [
  null,
  "Remover"
 ],
 "Removing": [
  null,
  "Removendo"
 ],
 "Unknown application": [
  null,
  "Aplicação Desconhecida"
 ],
 "View project website": [
  null,
  "Ver site do projeto"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Aguardando outros programas terminarem de usar o gerenciador de pacotes ..."
 ],
 "add-on": [
  null,
  ""
 ],
 "addon": [
  null,
  ""
 ],
 "apps": [
  null,
  ""
 ],
 "extension": [
  null,
  "extensão"
 ],
 "install": [
  null,
  ""
 ],
 "plugin": [
  null,
  ""
 ]
});
