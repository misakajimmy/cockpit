cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Azioni"
 ],
 "Applications": [
  null,
  "Applicazioni"
 ],
 "Applications list": [
  null,
  "Lista applicazioni"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Checking for new applications": [
  null,
  "Verifica di nuove applicazioni"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Error": [
  null,
  "Errore"
 ],
 "Go to application": [
  null,
  "Vai all'applicazione"
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Installing": [
  null,
  "Installazione in corso"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "No applications installed or available.": [
  null,
  "Nessuna applicazione installata o disponibile."
 ],
 "No description provided.": [
  null,
  "Nessuna descrizione fornita."
 ],
 "No installation package found for this application.": [
  null,
  "Nessun pacchetto di installazione trovato per questa applicazione."
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit si è interrotto"
 ],
 "Remove": [
  null,
  "Elimina"
 ],
 "Removing": [
  null,
  "Rimozione"
 ],
 "Unknown application": [
  null,
  "Applicazione sconosciuta"
 ],
 "Update package information": [
  null,
  "Aggiorna informazioni sul pacchetto"
 ],
 "View project website": [
  null,
  "Visualizza il sito web del progetto"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "In attesa che altri programmi finiscano di usare il gestore di pacchetti..."
 ],
 "add-on": [
  null,
  "add-on"
 ],
 "addon": [
  null,
  "componente aggiuntivo"
 ],
 "apps": [
  null,
  "applicazioni"
 ],
 "extension": [
  null,
  "estensione"
 ],
 "install": [
  null,
  "installa"
 ],
 "plugin": [
  null,
  "plugin"
 ]
});
