cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "ქმედებები"
 ],
 "Applications": [
  null,
  "აპლიკაციები"
 ],
 "Applications list": [
  null,
  "აპების სია"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Checking for new applications": [
  null,
  "ახალ აპლიკაციებზე შემოწმება"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Error": [
  null,
  "შეცდომა"
 ],
 "Go to application": [
  null,
  "აპლიკაციაზე გადასვლა"
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Installing": [
  null,
  "მიმდინარეობს დაყენება"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "No applications installed or available.": [
  null,
  "დაყენებული ან ხელმისაწვდომი აპლიკაციების გარეშე."
 ],
 "No description provided.": [
  null,
  "აღწერის გარეშე."
 ],
 "No installation package found for this application.": [
  null,
  "აპლიკაციის შესაბამისი პაკეტი ვერ მოიძებნა."
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit-ის ავარია"
 ],
 "Remove": [
  null,
  "წაშლა"
 ],
 "Removing": [
  null,
  "წაშლა"
 ],
 "Unknown application": [
  null,
  "უცნობი აპლიკაცია"
 ],
 "Update package information": [
  null,
  "პაკეტების ინფორმაციის განახლება"
 ],
 "View project website": [
  null,
  "პროექტის ვებგვერდის ნახვა"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "სხვა პროგრამების მიერ პაკეტების მმართველის გამოყენების დასრულების მოლოდინი..."
 ],
 "add-on": [
  null,
  "დამატება"
 ],
 "addon": [
  null,
  "დამატება"
 ],
 "apps": [
  null,
  "აპები"
 ],
 "extension": [
  null,
  "გაფართოება"
 ],
 "install": [
  null,
  "დაყენება"
 ],
 "plugin": [
  null,
  "ჩადგმა"
 ]
});
