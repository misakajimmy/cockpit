cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "Actions": [
  null,
  "Åtgärder"
 ],
 "Applications": [
  null,
  "Program"
 ],
 "Applications list": [
  null,
  "Programlista"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Checking for new applications": [
  null,
  "Kontrollerar om det finns nya program"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Error": [
  null,
  "Fel"
 ],
 "Go to application": [
  null,
  "Gå till programmet"
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Installing": [
  null,
  "Installerar"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "No applications installed or available.": [
  null,
  "Inga program installerade eller tillgängliga."
 ],
 "No description provided.": [
  null,
  "Ingen beskrivning tillhandahållen."
 ],
 "No installation package found for this application.": [
  null,
  "Inget installationspaket hittat för detta program."
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kraschade"
 ],
 "Remove": [
  null,
  "Ta bort"
 ],
 "Removing": [
  null,
  "Tar bort"
 ],
 "Unknown application": [
  null,
  "Okänt program"
 ],
 "Update package information": [
  null,
  "Uppdatera paketinformation"
 ],
 "View project website": [
  null,
  "Visa projektwebbsajt"
 ],
 "Waiting for other programs to finish using the package manager...": [
  null,
  "Väntar på att andra program skall sluta använda pakethanteraren …"
 ],
 "add-on": [
  null,
  "tillägg"
 ],
 "addon": [
  null,
  "tillägg"
 ],
 "apps": [
  null,
  "program"
 ],
 "extension": [
  null,
  "tillägg"
 ],
 "install": [
  null,
  "installera"
 ],
 "plugin": [
  null,
  "insticksmodul"
 ]
});
