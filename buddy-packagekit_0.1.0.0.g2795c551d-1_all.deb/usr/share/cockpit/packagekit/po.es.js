cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "es",
  "language-direction": "ltr"
 },
 "$0 is not available from any repository.": [
  null,
  "$0 no está disponible en ningún repositorio."
 ],
 "$0 package": [
  null,
  "$0 paquete",
  "$0 paquetes"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 paquete necesita un reinicio del sistema",
  "$0 paquetes necesitan un reinicio del sistema"
 ],
 "$0 security fix available": [
  null,
  "$0 Actualización de seguridad disponible",
  "$0 Actualizaciones de seguridad disponibles"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 servicio necesita reiniciarse",
  "$0 servicios necesitan reiniciarse"
 ],
 "$0 update available": [
  null,
  "$0 Actualización disponible",
  "$0 Actualizaciones disponibles"
 ],
 "$0 will be installed.": [
  null,
  "Se instalará: $0."
 ],
 ", including $1 security fix": [
  null,
  ", incluyendo $1 corrección de seguridad",
  ", incluyendo $1 correcciones de seguridad"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "20 minutes": [
  null,
  "20 minutos"
 ],
 "40 minutes": [
  null,
  "40 minutos"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "60 minutes": [
  null,
  "60 minutos"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Un paquete necesita un reinicio del sistema para que la actualización surta efecto:",
  "Varios paquetes necesitan un reinicio del sistema para que las actualizaciones surtan efecto:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Un servicio necesita reiniciarse para que las actualizaciones surtan efecto:",
  "Varios servicios necesitan reiniciarse para que las actualizaciones surtan efecto:"
 ],
 "Additional packages:": [
  null,
  "Paquetes adicionales:"
 ],
 "All updates": [
  null,
  "Todas las actualizaciones"
 ],
 "Apply kernel live patches": [
  null,
  "Aplicar los parches en vivo del kernel"
 ],
 "Applying updates": [
  null,
  "Instalando las actualizaciones"
 ],
 "Applying updates failed": [
  null,
  "Fallo al instalar las actualizaciones"
 ],
 "Automatic updates": [
  null,
  "Actualizaciones automáticas"
 ],
 "Automatically using NTP": [
  null,
  "Utilizando NTP de forma automática"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Utilizando automáticamente servidores NTP específicos"
 ],
 "Available updates": [
  null,
  "Actualizaciones disponibles"
 ],
 "Bug fix updates available": [
  null,
  "Actualizaciones disponibles que corrigen errores"
 ],
 "Bugs": [
  null,
  "Errores"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cannot schedule event in the past": [
  null,
  "No se puede planificar un evento ocurrido en el pasado"
 ],
 "Change": [
  null,
  "Cambiar"
 ],
 "Change system time": [
  null,
  "Cambiar la hora del sistema"
 ],
 "Check for updates": [
  null,
  "Comprobar si hay actualizaciones"
 ],
 "Checking for package updates...": [
  null,
  "Comprobando si hay actualizaciones de paquetes..."
 ],
 "Checking installed software": [
  null,
  "Comprobando el software instalado"
 ],
 "Checking software status": [
  null,
  "Comprobando estado del software"
 ],
 "Continue": [
  null,
  "Continuar"
 ],
 "Danger alert:": [
  null,
  "Alerta de peligro:"
 ],
 "Delay": [
  null,
  "Retardo"
 ],
 "Details": [
  null,
  "Detalles"
 ],
 "Disabled": [
  null,
  "Deshabilitado"
 ],
 "Downloaded": [
  null,
  "Descargado"
 ],
 "Downloading": [
  null,
  "Descargando"
 ],
 "Downloading $0": [
  null,
  "Descargando $0"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Enable": [
  null,
  "Habilitar"
 ],
 "Enabled": [
  null,
  "Habilitado"
 ],
 "Enhancement updates available": [
  null,
  "Actualizaciones de mejora disponibles"
 ],
 "Errata": [
  null,
  "Errata"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "No se pudieron analizar los archivos de la unidad para dnf-automatic.timer o dnf-automatic-install.timer. Elimine las anulaciones personalizadas para configurar las actualizaciones automáticas."
 ],
 "Failed to restart service": [
  null,
  "Fallo al reiniciar el servicio"
 ],
 "Fridays": [
  null,
  "Los viernes"
 ],
 "History package count": [
  null,
  "Cuenta del histórico de paquetes"
 ],
 "Ignore": [
  null,
  "Ignorar"
 ],
 "Info": [
  null,
  "Información"
 ],
 "Initializing...": [
  null,
  "Inicializando..."
 ],
 "Install": [
  null,
  "Instalar"
 ],
 "Install all updates": [
  null,
  "Instalar todas las actualizaciones"
 ],
 "Install kpatch updates": [
  null,
  "Instalar todas las actualizaciones de kpatch"
 ],
 "Install security updates": [
  null,
  "Instalar las actualizaciones de seguridad"
 ],
 "Install software": [
  null,
  "Instalar software"
 ],
 "Installed": [
  null,
  "Instalado"
 ],
 "Installing": [
  null,
  "Instalando"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Invalid date format": [
  null,
  "Formato de fecha inválido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de fecha y hora inválidos"
 ],
 "Invalid time format": [
  null,
  "Formato de hora inválido"
 ],
 "Invalid timezone": [
  null,
  "Zona horaria no válida"
 ],
 "Kernel live patch $0 is active": [
  null,
  "El parche en vivo $0 del kernel está activo"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "El parche en vivo $0 del kernel está instalado"
 ],
 "Kernel live patch settings": [
  null,
  "Ajustes de los parches en vivo del kernel"
 ],
 "Kernel live patching": [
  null,
  "Aplicación de parches en vivo del kernel"
 ],
 "Last checked: $0": [
  null,
  "Última comprobación: $0"
 ],
 "Learn more": [
  null,
  "Aprenda más"
 ],
 "Loading available updates failed": [
  null,
  "Fallo al cargar las actualizaciones disponibles"
 ],
 "Loading available updates, please wait...": [
  null,
  "Cargando actualizaciones disponibles, por favor espere..."
 ],
 "Log messages": [
  null,
  "Mensajes de registro"
 ],
 "Managing software updates": [
  null,
  "Gestión de actualizaciones de software"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Message to logged in users": [
  null,
  "Mensaje para usuarios activos"
 ],
 "Mondays": [
  null,
  "Los lunes"
 ],
 "More info...": [
  null,
  "Más información..."
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Name": [
  null,
  "Nombre"
 ],
 "Need at least one NTP server": [
  null,
  "Se requiere al menos un servidor NTP"
 ],
 "No delay": [
  null,
  "Sin retardo"
 ],
 "No updates": [
  null,
  "No actualizar"
 ],
 "Not available": [
  null,
  "No está disponible"
 ],
 "Not installed": [
  null,
  "No instalado"
 ],
 "Not registered": [
  null,
  "No está registrado"
 ],
 "Not set up": [
  null,
  "Sin configurar"
 ],
 "Not synchronized": [
  null,
  "No está sincronizado"
 ],
 "Ok": [
  null,
  "Aceptar"
 ],
 "Package information": [
  null,
  "Información de paquetes"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit colapsó"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit no está instalado"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit reportó un error con código $0"
 ],
 "Packages": [
  null,
  "Paquetes"
 ],
 "Pick date": [
  null,
  "Selecciona una fecha"
 ],
 "Please reload the page after resolving the issue.": [
  null,
  "Por favor, recarga la página después de resolver el problema."
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Reboot after completion": [
  null,
  "Reiniciar al terminar"
 ],
 "Reboot recommended": [
  null,
  "Se recomienda reiniciar"
 ],
 "Reboot system...": [
  null,
  "Reiniciar el sistema..."
 ],
 "Refreshing package information": [
  null,
  "Actualizando la información de paquetes"
 ],
 "Register…": [
  null,
  "Registrar…"
 ],
 "Reloading the state of remaining services": [
  null,
  "Recargando el estado del resto de servicios"
 ],
 "Removals:": [
  null,
  "Borrados:"
 ],
 "Removing $0": [
  null,
  "Eliminando $0"
 ],
 "Restart services": [
  null,
  "Reiniciar servicios"
 ],
 "Restart services...": [
  null,
  "Reiniciar servicios..."
 ],
 "Restarting": [
  null,
  "Reiniciando"
 ],
 "Saturdays": [
  null,
  "Los sábados"
 ],
 "Save": [
  null,
  "Guardar"
 ],
 "Save changes": [
  null,
  "Guardar cambios"
 ],
 "Security updates available": [
  null,
  "Actualizaciones de seguridad disponibles"
 ],
 "Security updates only": [
  null,
  "Sólo actualizaciones de seguridad"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "Las actualizaciones de seguridad se aplicarán el $0 a las $1"
 ],
 "Set time": [
  null,
  "Establecer la hora"
 ],
 "Set up": [
  null,
  "Preparar"
 ],
 "Setting up": [
  null,
  "Configurar"
 ],
 "Settings": [
  null,
  "Ajustes"
 ],
 "Severity": [
  null,
  "Severidad"
 ],
 "Shut down": [
  null,
  "Apagar"
 ],
 "Software updates": [
  null,
  "Actualizaciones de software"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Algún otro programa está usando actualmente el gestor de paquetes, por favor espere..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "Parte del software necesita ser reiniciado manualmente"
 ],
 "Specific time": [
  null,
  "Hora específica"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Sundays": [
  null,
  "Los domingos"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizado con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "System is up to date": [
  null,
  "El sistema está actualizado"
 ],
 "The following service will be restarted:": [
  null,
  "El siguiente servicio será reiniciado:",
  "Los siguientes servicios serán reiniciados:"
 ],
 "This host will reboot after updates are installed.": [
  null,
  "El anfitrión se reiniciará cuando se hayan instalado las actualizaciones."
 ],
 "This system is not registered": [
  null,
  "Este sistema no está registrado"
 ],
 "Thursdays": [
  null,
  "Los jueves"
 ],
 "Time": [
  null,
  "Hora"
 ],
 "Time zone": [
  null,
  "Huso horario"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Para obtener actualizaciones de software, este sistema necesita registrarse en Red Hat, bien usando el portal cliente de Red Hat o un servidor de suscripción local."
 ],
 "Toggle date picker": [
  null,
  "Alternar el selector de fecha"
 ],
 "Total size: $0": [
  null,
  "Tamaño total: $0"
 ],
 "Trying to synchronize with $0": [
  null,
  "Intentando sincronizar con $0"
 ],
 "Tuesdays": [
  null,
  "Los martes"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Unavailable packages": [
  null,
  "Paquetes no disponibles"
 ],
 "Update Success Table": [
  null,
  "Tabla de actualización exitosa"
 ],
 "Update history": [
  null,
  "Histórico de actualización"
 ],
 "Update was successful": [
  null,
  "La actualización fue correcta"
 ],
 "Updated": [
  null,
  "Actualizado"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Los paquetes actualizados pueden necesitar un reinicio para tomar efecto."
 ],
 "Updates available": [
  null,
  "Actualizaciones disponibles"
 ],
 "Updates history": [
  null,
  "Histórico de actualizaciones"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "Las actualizaciones se aplicarán el $0 a las $1"
 ],
 "Updating": [
  null,
  "Actualizando"
 ],
 "Verified": [
  null,
  "Verificado"
 ],
 "Verifying": [
  null,
  "Verificando"
 ],
 "Version": [
  null,
  "Versión"
 ],
 "View update log": [
  null,
  "Ver registro de actualización"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Esperando a que finalicen otras operaciones de gestión de software"
 ],
 "Web Console will restart": [
  null,
  "La consola web se reiniciará"
 ],
 "Wednesdays": [
  null,
  "Los miércoles"
 ],
 "When": [
  null,
  "Intervalo"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Cuando se reinicie la consola Web, no podrás ver la información de progreso. Sin embargo, el proceso de actualización continuará de fondo. Reconéctate para continuar viendo el proceso de actualización."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Su servidor cerrará la conexión pronto. Usted se puede volver a conectar después de que se haya reiniciado."
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "at": [
  null,
  "en"
 ],
 "bug fix": [
  null,
  "correción del fallo"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "enhancement": [
  null,
  "mejora"
 ],
 "every Friday": [
  null,
  "cada viernes"
 ],
 "every Monday": [
  null,
  "cada lunes"
 ],
 "every Saturday": [
  null,
  "cada sábado"
 ],
 "every Sunday": [
  null,
  "cada domingo"
 ],
 "every Thursday": [
  null,
  "cada jueves"
 ],
 "every Tuesday": [
  null,
  "cada martes"
 ],
 "every Wednesday": [
  null,
  "cada miércoles"
 ],
 "every day": [
  null,
  "cada día"
 ],
 "for current and future kernels": [
  null,
  "para el actual y futuros kernels"
 ],
 "for current kernel only": [
  null,
  "sólo en el kernel actual"
 ],
 "package": [
  null,
  "paquete"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "patches": [
  null,
  "parches"
 ],
 "security": [
  null,
  "seguridad"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar más"
 ],
 "yum": [
  null,
  "yum"
 ]
});
