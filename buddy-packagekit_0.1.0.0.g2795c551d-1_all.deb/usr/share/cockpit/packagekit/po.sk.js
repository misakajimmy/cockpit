cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "$0 is not available from any repository.": [
  null,
  "$0 nie je k dispozícií v žiadom repozitári."
 ],
 "$0 package": [
  null,
  "$0 balíček",
  "$0 balíčky",
  "$0 balíčkov"
 ],
 "$0 package needs a system reboot": [
  null,
  "",
  "",
  ""
 ],
 "$0 security fix available": [
  null,
  "Je k dispozícií $0 oprava bezpečnosti",
  "Sú k dispozícií $0 opravy bezpečnosti",
  "Je k dispozícií $0 opráv bezpečnosti"
 ],
 "$0 update available": [
  null,
  "Je dostupné $0 aktualizácia",
  "Sú dostupné $0 aktualizácie",
  "Je dostupných $0 aktualizácií"
 ],
 "$0 will be installed.": [
  null,
  "$0 bude nainštalovaný."
 ],
 ", including $1 security fix": [
  null,
  ", vrátane $1 opravy zabezpečenia",
  ", vrátane $1 opráv zabezpečenia",
  ", vrátane $1 opráv zabezpečenia"
 ],
 "1 minute": [
  null,
  "1 minúta"
 ],
 "20 minutes": [
  null,
  "20 minút"
 ],
 "40 minutes": [
  null,
  "40 minút"
 ],
 "5 minutes": [
  null,
  "5 minút"
 ],
 "60 minutes": [
  null,
  "60 minút"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "",
  "",
  ""
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "",
  "",
  ""
 ],
 "Additional packages:": [
  null,
  "Ďalšie balíky:"
 ],
 "All updates": [
  null,
  "Všetky aktualizácie"
 ],
 "Applying updates": [
  null,
  "Aplikujú sa aktulizácie"
 ],
 "Applying updates failed": [
  null,
  "Aplikácia aktualizácií sa nepodarila"
 ],
 "Automatic updates": [
  null,
  "Automatické aktualizácie"
 ],
 "Automatically using NTP": [
  null,
  "Automaticky využitím NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticky využitím konkrétnych NTP serverov"
 ],
 "Available updates": [
  null,
  "Dostupné aktualizácie"
 ],
 "Bug fix updates available": [
  null,
  "Sú dostupné opravy chýb"
 ],
 "Bugs": [
  null,
  "Chyby"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nie je možné plánovať udalosti do minulosti"
 ],
 "Change": [
  null,
  "Zmeniť"
 ],
 "Change system time": [
  null,
  "Zmeniť systémový čas"
 ],
 "Check for updates": [
  null,
  "Skontrolovať aktualizácie"
 ],
 "Checking for package updates...": [
  null,
  "Kontrolujú sa aktualizácie..."
 ],
 "Checking installed software": [
  null,
  "Zisťuje sa nainštalovaný software"
 ],
 "Continue": [
  null,
  "Pokračovať"
 ],
 "Danger alert:": [
  null,
  ""
 ],
 "Delay": [
  null,
  "Omeškanie"
 ],
 "Details": [
  null,
  "Detaily"
 ],
 "Disabled": [
  null,
  "Vypnutá"
 ],
 "Downloaded": [
  null,
  "Stiahnuté"
 ],
 "Downloading": [
  null,
  "Sťahuje sa"
 ],
 "Downloading $0": [
  null,
  "Sťahuje sa $0"
 ],
 "Edit": [
  null,
  "Upraviť"
 ],
 "Enable": [
  null,
  "Povoliť"
 ],
 "Enabled": [
  null,
  "Povolená"
 ],
 "Enhancement updates available": [
  null,
  ""
 ],
 "Errata": [
  null,
  "Errata"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  ""
 ],
 "Fridays": [
  null,
  "Piatky"
 ],
 "History package count": [
  null,
  "Počet balíkov"
 ],
 "Ignore": [
  null,
  "Ignorovať"
 ],
 "Info": [
  null,
  ""
 ],
 "Initializing...": [
  null,
  "Inicializácia..."
 ],
 "Install": [
  null,
  "Inštalovať"
 ],
 "Install all updates": [
  null,
  "Nainštalovať všetky aktualizácie"
 ],
 "Install security updates": [
  null,
  "Nainštalovať bezpečnostné aktualizácie"
 ],
 "Install software": [
  null,
  "Inštalovať software"
 ],
 "Installed": [
  null,
  "Nainštalovaný"
 ],
 "Installing": [
  null,
  "Inštaluje sa"
 ],
 "Installing $0": [
  null,
  "Inštaluje sa $0"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát dátumu"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát dátumu a času"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát čase"
 ],
 "Invalid timezone": [
  null,
  "Neplatná časová zóna"
 ],
 "Last checked: $0": [
  null,
  "Naposledy skontrolované: $0"
 ],
 "Learn more": [
  null,
  "Zistiť viac"
 ],
 "Loading available updates failed": [
  null,
  ""
 ],
 "Loading available updates, please wait...": [
  null,
  ""
 ],
 "Log messages": [
  null,
  "Záznamy udalostí"
 ],
 "Managing software updates": [
  null,
  "Správa softvérových aktualizácií"
 ],
 "Manually": [
  null,
  "Ručne"
 ],
 "Message to logged in users": [
  null,
  ""
 ],
 "Mondays": [
  null,
  "Pondelky"
 ],
 "More info...": [
  null,
  "Viac _informácií..."
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Name": [
  null,
  "Názov"
 ],
 "Need at least one NTP server": [
  null,
  ""
 ],
 "No delay": [
  null,
  ""
 ],
 "No updates": [
  null,
  "Žiadne aktualizácie"
 ],
 "Not available": [
  null,
  "edostupné"
 ],
 "Not installed": [
  null,
  "Nenainštalovaný"
 ],
 "Not registered": [
  null,
  "Nezaregistrované"
 ],
 "Not synchronized": [
  null,
  "Nezosynchronizované"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Package information": [
  null,
  "Informácie o balíku"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit nie je nainštalovaný"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit ohlásil chybový kód $0"
 ],
 "Packages": [
  null,
  "Balíčky"
 ],
 "Pick date": [
  null,
  "Vybrať dátum"
 ],
 "Please reload the page after resolving the issue.": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "Reštartovať"
 ],
 "Reboot system...": [
  null,
  ""
 ],
 "Refreshing package information": [
  null,
  ""
 ],
 "Register…": [
  null,
  "Registrovať…"
 ],
 "Reloading the state of remaining services": [
  null,
  ""
 ],
 "Removals:": [
  null,
  "Odstránenia:"
 ],
 "Removing $0": [
  null,
  "Odstraňuje sa $0"
 ],
 "Restart services": [
  null,
  "Reštartovať služby"
 ],
 "Restart services...": [
  null,
  "Reštartovať služby..."
 ],
 "Restarting": [
  null,
  "Reštartuje sa"
 ],
 "Saturdays": [
  null,
  "Soboty"
 ],
 "Save": [
  null,
  "Uložiť"
 ],
 "Save changes": [
  null,
  "Uložiť zmeny"
 ],
 "Security updates available": [
  null,
  "Sú k dispozícií bezpečnostné aktualizácie"
 ],
 "Security updates only": [
  null,
  "Iba bezpečnostné aktualizácie"
 ],
 "Set time": [
  null,
  "Nastaviť čas"
 ],
 "Set up": [
  null,
  "Nastaviť"
 ],
 "Setting up": [
  null,
  "Nastavuje sa"
 ],
 "Settings": [
  null,
  "Nastavenia"
 ],
 "Severity": [
  null,
  "Závažnosť"
 ],
 "Shut down": [
  null,
  "Vypnúť"
 ],
 "Software updates": [
  null,
  "Aktualizácie software"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  ""
 ],
 "Some software needs to be restarted manually": [
  null,
  ""
 ],
 "Specific time": [
  null,
  "Konkrétny čas"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Sundays": [
  null,
  "Nedele"
 ],
 "Synchronized": [
  null,
  "Synchronizované"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizované s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizuje sa"
 ],
 "System is up to date": [
  null,
  "Systém je aktuálny"
 ],
 "The following service will be restarted:": [
  null,
  "",
  "",
  ""
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Tento stroj bude reštartovný keď budú aktualizácie nainštalované."
 ],
 "This system is not registered": [
  null,
  ""
 ],
 "Thursdays": [
  null,
  "štvrtky"
 ],
 "Time": [
  null,
  "Čas"
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  ""
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Total size: $0": [
  null,
  "Celková veľkosť: $0"
 ],
 "Trying to synchronize with $0": [
  null,
  ""
 ],
 "Tuesdays": [
  null,
  "utorky"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Update history": [
  null,
  "História aktualizácií"
 ],
 "Updated": [
  null,
  "Aktualizované"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  ""
 ],
 "Updates available": [
  null,
  "Sú dostupné aktualizácie"
 ],
 "Updates history": [
  null,
  "História aktualizácií"
 ],
 "Updates will be applied $0 at $1": [
  null,
  ""
 ],
 "Updating": [
  null,
  "Aktualizuje sa"
 ],
 "Verified": [
  null,
  "Overené"
 ],
 "Verifying": [
  null,
  "Overuje sa"
 ],
 "Version": [
  null,
  "Verzia"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čaká sa na dokončenie ostatných operácií správy balíčkov"
 ],
 "Wednesdays": [
  null,
  "Stredy"
 ],
 "When": [
  null,
  "Kedy"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  ""
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  ""
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "at": [
  null,
  "o"
 ],
 "bug fix": [
  null,
  "oprava chyby"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "enhancement": [
  null,
  "vylepšenie"
 ],
 "every day": [
  null,
  "každý deň"
 ],
 "for current and future kernels": [
  null,
  ""
 ],
 "package": [
  null,
  "balík"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "patches": [
  null,
  ""
 ],
 "security": [
  null,
  "bezpečnosť"
 ],
 "show less": [
  null,
  "ukázať menej"
 ],
 "show more": [
  null,
  "ukázať viac"
 ],
 "yum": [
  null,
  "yum"
 ]
});
