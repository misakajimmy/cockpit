cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "$0 is not available from any repository.": [
  null,
  "$0 är inte tillgängligt från något förråd."
 ],
 "$0 package": [
  null,
  "$0 paket",
  "$0 paket"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 paket behöver en omstart av systemet",
  "$0 paket behöver en omstart av systemet"
 ],
 "$0 security fix available": [
  null,
  "$0 säkerhetsuppdatering tillgänglig",
  "$0 säkerhetsuppdateringar tillgängliga"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 tjänst måste startas om",
  "$0 tjänster måste startas om"
 ],
 "$0 update available": [
  null,
  "$0 uppdatering tillgänglig",
  "$0 uppdateringar tillgängliga"
 ],
 "$0 will be installed.": [
  null,
  "$0 kommer att installeras."
 ],
 ", including $1 security fix": [
  null,
  ", inklusive $1 säkerhetsfix",
  ", inklusive $1 säkerhetsfixar"
 ],
 "1 minute": [
  null,
  "1 minut"
 ],
 "20 minutes": [
  null,
  "20 minuter"
 ],
 "40 minutes": [
  null,
  "40 minuter"
 ],
 "5 minutes": [
  null,
  "5 minuter"
 ],
 "60 minutes": [
  null,
  "60 minuter"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Ett paket behöver en systemomstart för att uppdateringen skall få effekt:",
  "Några paket behöver en systemomstart för att uppdateringen skall få effekt:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "En tjänst måste startas om för att uppdateringarna ska träda i kraft:",
  "Vissa tjänster måste startas om för att uppdateringarna ska träda i kraft:"
 ],
 "Additional packages:": [
  null,
  "Ytterligare paket:"
 ],
 "All updates": [
  null,
  "Alla uppdateringar"
 ],
 "Apply kernel live patches": [
  null,
  "Lägg på driftsuppdateringar av kärnan"
 ],
 "Applying updates": [
  null,
  "Lägger på uppdateringar"
 ],
 "Applying updates failed": [
  null,
  "Att lägga på uppdateringar misslyckades"
 ],
 "Automatic updates": [
  null,
  "Automatiska uppdateringar"
 ],
 "Automatically using NTP": [
  null,
  "Använder automatiskt NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Använder automatiskt specifika NTP-servrar"
 ],
 "Available updates": [
  null,
  "Tillgängliga uppdateringar"
 ],
 "Bug fix updates available": [
  null,
  "Felrättningsuppdateringar tillgängliga"
 ],
 "Bugs": [
  null,
  "Fel"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan inte schemalägga händelser som redan hänt"
 ],
 "Change": [
  null,
  "Ändra"
 ],
 "Change system time": [
  null,
  "Ändra systemtid"
 ],
 "Check for updates": [
  null,
  "Kontrollera om det finns uppdateringar"
 ],
 "Checking for package updates...": [
  null,
  "Söker efter programuppdateringar..."
 ],
 "Checking installed software": [
  null,
  "Kontrollerar installerad programvara"
 ],
 "Checking software status": [
  null,
  "Kontrollerar programvarustatus"
 ],
 "Continue": [
  null,
  "Fortsätt"
 ],
 "Danger alert:": [
  null,
  "Fara varning:"
 ],
 "Delay": [
  null,
  "Fördröjning"
 ],
 "Details": [
  null,
  "Detaljer"
 ],
 "Disabled": [
  null,
  "Avaktiverad"
 ],
 "Downloaded": [
  null,
  "Hämtat"
 ],
 "Downloading": [
  null,
  "Hämtar"
 ],
 "Downloading $0": [
  null,
  "Hämtar $0"
 ],
 "Edit": [
  null,
  "Redigera"
 ],
 "Enable": [
  null,
  "Aktivera"
 ],
 "Enabled": [
  null,
  "Aktiverad"
 ],
 "Enhancement updates available": [
  null,
  "Förbättringsuppdateringar är tillgängliga"
 ],
 "Errata": [
  null,
  "Errata"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "Det gick inte att analysera enhetsfiler för dnf-automatic.timer eller dnf-automatic-install.timer. Ta bort anpassade åsidosättningar för att konfigurera automatiska uppdateringar."
 ],
 "Failed to restart service": [
  null,
  "Misslyckades med att starta om tjänst"
 ],
 "Fridays": [
  null,
  "Fredagar"
 ],
 "History package count": [
  null,
  "Historiepaketantal"
 ],
 "Ignore": [
  null,
  "Ignorera"
 ],
 "Info": [
  null,
  "Information"
 ],
 "Initializing...": [
  null,
  "Initierar …"
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Install all updates": [
  null,
  "Installera alla uppdateringar"
 ],
 "Install kpatch updates": [
  null,
  "Installera kpatch uppdateringar"
 ],
 "Install security updates": [
  null,
  "Installera säkerhetsuppdateringar"
 ],
 "Install software": [
  null,
  "Installera programvara"
 ],
 "Installed": [
  null,
  "Installerad"
 ],
 "Installing": [
  null,
  "Installerar"
 ],
 "Installing $0": [
  null,
  "Installerar $0"
 ],
 "Invalid date format": [
  null,
  "Felaktigt datumformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Felaktigt datumformat och felaktigt tidsformat"
 ],
 "Invalid time format": [
  null,
  "Felaktigt tidsformat"
 ],
 "Invalid timezone": [
  null,
  "Felaktig tidszon"
 ],
 "Kernel live patch $0 is active": [
  null,
  "Kärn-live-patch $0 är aktiv"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "Kärn-live-patch $0 är installerad"
 ],
 "Kernel live patch settings": [
  null,
  "Kärn-live-patch-inställningar"
 ],
 "Kernel live patching": [
  null,
  "Kärn-live-patchning"
 ],
 "Last checked: $0": [
  null,
  "Senast kontrollerad: $0 sedan"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "Loading available updates failed": [
  null,
  "Inläsningen av tillgängliga uppdateringar misslyckades"
 ],
 "Loading available updates, please wait...": [
  null,
  "Läser in tillgängliga uppdateringar, var god dröj …"
 ],
 "Log messages": [
  null,
  "Loggmeddelanden"
 ],
 "Managing software updates": [
  null,
  "Hantera programuppdateringar"
 ],
 "Manually": [
  null,
  "Manuellt"
 ],
 "Message to logged in users": [
  null,
  "Meddelande till inloggade användare"
 ],
 "Mondays": [
  null,
  "Måndagar"
 ],
 "More info...": [
  null,
  "Mer information..."
 ],
 "NTP server": [
  null,
  "NTP-server"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Need at least one NTP server": [
  null,
  "Behöver åtminstone en NTP-server"
 ],
 "No delay": [
  null,
  "Ingen fördröjning"
 ],
 "No updates": [
  null,
  "Inga uppdateringar"
 ],
 "Not available": [
  null,
  "Inte tillgängligt"
 ],
 "Not installed": [
  null,
  "Inte installerad"
 ],
 "Not registered": [
  null,
  "Inte registrerad"
 ],
 "Not set up": [
  null,
  "Inte uppsatt"
 ],
 "Not synchronized": [
  null,
  "Inte synkroniserad"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Package information": [
  null,
  "Paketinformation"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kraschade"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit är inte installerat"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit rapporterade felkod $0"
 ],
 "Packages": [
  null,
  "Paket"
 ],
 "Pick date": [
  null,
  "Välj datum"
 ],
 "Please reload the page after resolving the issue.": [
  null,
  "Ladda om sidan när du har löst problemet."
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Reboot after completion": [
  null,
  "Starta om efteråt"
 ],
 "Reboot recommended": [
  null,
  "Omstart rekommenderas"
 ],
 "Reboot system...": [
  null,
  "Starta om system..."
 ],
 "Refreshing package information": [
  null,
  "Uppdaterar paketinformation"
 ],
 "Register…": [
  null,
  "Registrera …"
 ],
 "Reloading the state of remaining services": [
  null,
  "Laddar om tillståndet för återstående tjänster"
 ],
 "Removals:": [
  null,
  "Borttagningar:"
 ],
 "Removing $0": [
  null,
  "Tar bort $0"
 ],
 "Restart services": [
  null,
  "Starta om tjänster"
 ],
 "Restart services...": [
  null,
  "Starta om tjänster..."
 ],
 "Restarting": [
  null,
  "Startar om"
 ],
 "Saturdays": [
  null,
  "Lördagar"
 ],
 "Save": [
  null,
  "Spara"
 ],
 "Save changes": [
  null,
  "Spara ändringar"
 ],
 "Security updates available": [
  null,
  "Säkerhetsuppdateringar tillgängliga"
 ],
 "Security updates only": [
  null,
  "Säkerhetsuppdateringar endast"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "Säkerhetsuppdateringar kommer att tillämpas $0 vid $1"
 ],
 "Set time": [
  null,
  "Ställ in tiden"
 ],
 "Set up": [
  null,
  "Sätt upp"
 ],
 "Setting up": [
  null,
  "Sätter upp"
 ],
 "Settings": [
  null,
  "Inställningar"
 ],
 "Severity": [
  null,
  "Allvarsgrad"
 ],
 "Shut down": [
  null,
  "Stäng av"
 ],
 "Software updates": [
  null,
  "Programvaruuppdateringar"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Något annat program använder just nu pakethanteraren, var god dröj …"
 ],
 "Some software needs to be restarted manually": [
  null,
  "Vissa program måste startas om manuellt"
 ],
 "Specific time": [
  null,
  "Specifik tid"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Sundays": [
  null,
  "Söndagar"
 ],
 "Synchronized": [
  null,
  "Synkroniserad"
 ],
 "Synchronized with $0": [
  null,
  "Synkroniserad med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserar"
 ],
 "System is up to date": [
  null,
  "Systemet är uppdaterat"
 ],
 "The following service will be restarted:": [
  null,
  "Följande tjänst kommer att startas om:",
  "Följande tjänster kommer att startas om:"
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Denna värd kommer att starta om efter att uppdateringar har installerats."
 ],
 "This system is not registered": [
  null,
  "Detta system är inte registrerat"
 ],
 "Thursdays": [
  null,
  "Torsdagar"
 ],
 "Time": [
  null,
  "Tid"
 ],
 "Time zone": [
  null,
  "Tidszon"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "För att få programvaruuppdateringar behöver detta system registreras hos Red Hat, antingen genom att använda Red Hats kundportal eller en lokal prenumerationsserver."
 ],
 "Toggle date picker": [
  null,
  "Växla datumväljare"
 ],
 "Total size: $0": [
  null,
  "Total storlek: $0"
 ],
 "Trying to synchronize with $0": [
  null,
  "Försök att synkronisera med $0"
 ],
 "Tuesdays": [
  null,
  "Tisdagar"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unavailable packages": [
  null,
  "Otillgängliga paket"
 ],
 "Update Success Table": [
  null,
  "Uppdatera framgångstabell"
 ],
 "Update history": [
  null,
  "Uppdatera historiken"
 ],
 "Update was successful": [
  null,
  "Uppdateringen lyckades"
 ],
 "Updated": [
  null,
  "Uppdaterat"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Uppdaterade paket kan behöva en omstart för att få effekt."
 ],
 "Updates available": [
  null,
  "Uppdateringar tillgängliga"
 ],
 "Updates history": [
  null,
  "Uppdatera historik"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "Uppdateringar kommer att tillämpas $0 vid $1"
 ],
 "Updating": [
  null,
  "Uppdaterar"
 ],
 "Verified": [
  null,
  "Verifierad"
 ],
 "Verifying": [
  null,
  "Verifierar"
 ],
 "Version": [
  null,
  "Version"
 ],
 "View update log": [
  null,
  "Visa uppdateringsloggen"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Väntar på att andra programvaruhanteringsåtgärder skall bli klara"
 ],
 "Web Console will restart": [
  null,
  "Webbkonsolen kommer att starta om"
 ],
 "Wednesdays": [
  null,
  "Onsdagar"
 ],
 "When": [
  null,
  "När"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "När webbkonsolen startas om kommer man inte längre att se förloppsinformation. Dock kommer uppdateringsprocessen att fortsätta i bakgrunden. Återanslut för att fortsätta se uppdateringsprocessen."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Din server kommer stänga förbindelsen snart. Du kan återansluta efter att den har startat om."
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "at": [
  null,
  "klockan"
 ],
 "bug fix": [
  null,
  "felrättning"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "enhancement": [
  null,
  "förbättring"
 ],
 "every Friday": [
  null,
  "varje fredag"
 ],
 "every Monday": [
  null,
  "varje måndag"
 ],
 "every Saturday": [
  null,
  "varje lördag"
 ],
 "every Sunday": [
  null,
  "varje söndag"
 ],
 "every Thursday": [
  null,
  "varje torsdag"
 ],
 "every Tuesday": [
  null,
  "varje tisdag"
 ],
 "every Wednesday": [
  null,
  "varje onsdag"
 ],
 "every day": [
  null,
  "varje dag"
 ],
 "for current and future kernels": [
  null,
  "för nuvarande och framtida kärnor"
 ],
 "for current kernel only": [
  null,
  "för nuvarande kärna endast"
 ],
 "package": [
  null,
  "paket"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "patches": [
  null,
  "rättningar"
 ],
 "security": [
  null,
  "säkerhet"
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ],
 "yum": [
  null,
  "yum"
 ]
});
