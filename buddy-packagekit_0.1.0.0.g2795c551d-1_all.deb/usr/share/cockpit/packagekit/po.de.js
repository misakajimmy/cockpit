cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 is not available from any repository.": [
  null,
  "$0 ist in keinem Repository verfügbar."
 ],
 "$0 package": [
  null,
  "$0 Paket",
  "$0 Pakete"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 Paket benötigt einen Systemneustart",
  "$0 Pakete benötigen einen Systemneustart"
 ],
 "$0 security fix available": [
  null,
  "$0 Sicherheitsupdate verfügbar",
  "$0 Sicherheitsupdates verfügbar"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 Dienst muss neu gestartet werden",
  "$0 Dienste müssen neu gestartet werden"
 ],
 "$0 update available": [
  null,
  "$0 Aktualisierung verfügbar",
  "$0 Aktualisierungen verfügbar"
 ],
 "$0 will be installed.": [
  null,
  "$0 wird installiert."
 ],
 ", including $1 security fix": [
  null,
  ", einschließlich $1 Sicherheitsupdate",
  ", einschließlich $1 Sicherheitsupdates"
 ],
 "1 minute": [
  null,
  "1 Minute"
 ],
 "20 minutes": [
  null,
  "20 Minuten"
 ],
 "40 minutes": [
  null,
  "40 Minuten"
 ],
 "5 minutes": [
  null,
  "5 Minuten"
 ],
 "60 minutes": [
  null,
  "60 Minuten"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Ein Paket benötigt einen Neustart des Systems, damit die Aktualisierungen wirksam werden:",
  "Einige Pakete benötigen einen Neustart des Systems, damit die Aktualisierungen wirksam werden:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Ein Dienst muss neu gestartet werden, damit die Aktualisierungen wirksam werden:",
  "Einige Dienste müssen neu gestartet werden, damit die Aktualisierungen wirksam werden:"
 ],
 "Additional packages:": [
  null,
  "Zusatzpakete:"
 ],
 "All updates": [
  null,
  "Alle Updates"
 ],
 "Apply kernel live patches": [
  null,
  "Kernel-Live-Patches anwenden"
 ],
 "Applying updates": [
  null,
  "Aktualisierungen werden angewandt"
 ],
 "Applying updates failed": [
  null,
  "Das Anwenden der Updates ist fehlgeschlagen"
 ],
 "Automatic updates": [
  null,
  "Automatische Updates"
 ],
 "Automatically using NTP": [
  null,
  "Automatisch (NTP)"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisch (spezifische NTP-Server)"
 ],
 "Available updates": [
  null,
  "Verfügbare Updates"
 ],
 "Bug fix updates available": [
  null,
  "Bug Fix Updates verfügbar"
 ],
 "Bugs": [
  null,
  "Fehlermeldungen"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Cannot schedule event in the past": [
  null,
  "Vorgang kann nicht für die Vergangenheit geplant werden"
 ],
 "Change": [
  null,
  "Ändern"
 ],
 "Change system time": [
  null,
  "Systemzeit ändern"
 ],
 "Check for updates": [
  null,
  "Auf Aktualisierungen prüfen"
 ],
 "Checking for package updates...": [
  null,
  "Auf Paketaktualisierungen wird geprüft..."
 ],
 "Checking installed software": [
  null,
  "Installierte Software wird überprüft"
 ],
 "Checking software status": [
  null,
  "Software-Status wird überprüft"
 ],
 "Continue": [
  null,
  "Weiter"
 ],
 "Danger alert:": [
  null,
  "Gefahrenalarm:"
 ],
 "Delay": [
  null,
  "Verzögerung"
 ],
 "Details": [
  null,
  "Details"
 ],
 "Disabled": [
  null,
  "Deaktiviert"
 ],
 "Downloaded": [
  null,
  "Heruntergeladen"
 ],
 "Downloading": [
  null,
  "Herunterladen"
 ],
 "Downloading $0": [
  null,
  "wird heruntergeladen $0"
 ],
 "Edit": [
  null,
  "Bearbeiten"
 ],
 "Enable": [
  null,
  "Aktivieren"
 ],
 "Enabled": [
  null,
  "Aktiviert"
 ],
 "Enhancement updates available": [
  null,
  "Verbesserungsaktualisierungen verfügbar"
 ],
 "Errata": [
  null,
  "Errata"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "Das Parsen der Unit-Datein für dnf-automatic.timer oderr dnf-automatic-install.timer ist fehlgeschlagen. Bitte eigene Überschreibungen in der Konfigurationsautomatisierung entfernen."
 ],
 "Failed to restart service": [
  null,
  "Dienst konnte nicht neu gestartet werden"
 ],
 "Fridays": [
  null,
  "Freitags"
 ],
 "History package count": [
  null,
  "History Packet-Anzahl"
 ],
 "Ignore": [
  null,
  "Ignorieren"
 ],
 "Info": [
  null,
  "Info"
 ],
 "Initializing...": [
  null,
  "Initialisierung ..."
 ],
 "Install": [
  null,
  "Installation"
 ],
 "Install all updates": [
  null,
  "Alle Aktualisierungen installieren"
 ],
 "Install kpatch updates": [
  null,
  "kpatch-Aktualisierungen installieren"
 ],
 "Install security updates": [
  null,
  "Sicherheitsaktualisierungen installieren"
 ],
 "Install software": [
  null,
  "Software installieren"
 ],
 "Installed": [
  null,
  "Installiert"
 ],
 "Installing": [
  null,
  "Wird installiert"
 ],
 "Installing $0": [
  null,
  "$0 wird installiert"
 ],
 "Invalid date format": [
  null,
  "Ungültiges Datumsformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ungültiges Datumsformat und ungültiges Zeitformat"
 ],
 "Invalid time format": [
  null,
  "Ungültiges Zeitformat"
 ],
 "Invalid timezone": [
  null,
  "Ungültige Zeitzone"
 ],
 "Kernel live patch $0 is active": [
  null,
  "Kernel-Live-Patch $0 ist aktiv"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "Kernel-Live-Patch $0 ist installiert"
 ],
 "Kernel live patch settings": [
  null,
  "Kernel-Live-Patch-Einstellungen"
 ],
 "Kernel live patching": [
  null,
  "Kernel-Live-Patching"
 ],
 "Last checked: $0": [
  null,
  "Zuletzt geprüft: $0"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "Loading available updates failed": [
  null,
  "Laden verfügbarer Aktualisierungen fehlgeschlagen"
 ],
 "Loading available updates, please wait...": [
  null,
  "Verfügbare Aktualisierungen werden geladen, bitte warten ..."
 ],
 "Log messages": [
  null,
  "Nachrichten protokollieren"
 ],
 "Managing software updates": [
  null,
  "Software-Aktualisierungen verwalten"
 ],
 "Manually": [
  null,
  "Manuell"
 ],
 "Message to logged in users": [
  null,
  "Nachricht an angemeldete Benutzer"
 ],
 "Mondays": [
  null,
  "Montags"
 ],
 "More info...": [
  null,
  "Weitere Informationen..."
 ],
 "NTP server": [
  null,
  "NTP-Server"
 ],
 "Name": [
  null,
  "Name"
 ],
 "Need at least one NTP server": [
  null,
  "Benötigen Sie mindestens einen NTP-Server"
 ],
 "No delay": [
  null,
  "Keine Verzögerung"
 ],
 "No updates": [
  null,
  "Keine Aktualisierungen"
 ],
 "Not available": [
  null,
  "Nicht verfügbar"
 ],
 "Not installed": [
  null,
  "Nicht installiert"
 ],
 "Not registered": [
  null,
  "Nicht registriert"
 ],
 "Not set up": [
  null,
  "Nicht eingerichtet"
 ],
 "Not synchronized": [
  null,
  "Nicht synchronisiert"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Package information": [
  null,
  "Paket-Informationen"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit ist abgestürzt"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit ist nicht installiert"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit hat Fehlercode gemeldet $0"
 ],
 "Packages": [
  null,
  "Pakete"
 ],
 "Pick date": [
  null,
  "Datum auswählen"
 ],
 "Please reload the page after resolving the issue.": [
  null,
  "Bitte laden Sie die Seite neu, nachdem Sie das Problem behoben haben."
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Reboot recommended": [
  null,
  "Neustart empfohlen"
 ],
 "Reboot system...": [
  null,
  "System neu starten ..."
 ],
 "Refreshing package information": [
  null,
  "Paketinformationen aktualisieren"
 ],
 "Register…": [
  null,
  "Registrieren…"
 ],
 "Reloading the state of remaining services": [
  null,
  "Der Zustand der verbleibenden Dienste wird neu geladen"
 ],
 "Removals:": [
  null,
  "Umzüge:"
 ],
 "Removing $0": [
  null,
  "Entfernen $0"
 ],
 "Restart services": [
  null,
  "Dienste neu starten"
 ],
 "Restart services...": [
  null,
  "Dienste werden neu gestartet ..."
 ],
 "Restarting": [
  null,
  "Wird neu gestartet"
 ],
 "Saturdays": [
  null,
  "Samstags"
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "Save changes": [
  null,
  "Änderungen speichern"
 ],
 "Security updates available": [
  null,
  "Sicherheitsupdates verfügbar"
 ],
 "Security updates only": [
  null,
  "Nur Sicherheitsaktualisierungen"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "Sicherheitsaktualisierungen werden für $0 auf $1 angewandt"
 ],
 "Set time": [
  null,
  "Zeit setzen"
 ],
 "Set up": [
  null,
  "Konfiguration"
 ],
 "Setting up": [
  null,
  "Einrichten"
 ],
 "Settings": [
  null,
  "Einstellungen"
 ],
 "Severity": [
  null,
  "Schweregrad"
 ],
 "Shut down": [
  null,
  "Herunterfahren"
 ],
 "Software updates": [
  null,
  "Aktualisierungen"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Ein anderes Programm verwendet derzeit den Paketmanager, bitte warten Sie ..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "Manche Software muss manuell neu gestartet werden"
 ],
 "Specific time": [
  null,
  "Bestimmte Zeit"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Sundays": [
  null,
  "Sonntags"
 ],
 "Synchronized": [
  null,
  "Synchronisiert"
 ],
 "Synchronized with $0": [
  null,
  "Mit $0 synchronisiert"
 ],
 "Synchronizing": [
  null,
  "Wird synchronisiert"
 ],
 "System is up to date": [
  null,
  "System ist aktualisiert"
 ],
 "The following service will be restarted:": [
  null,
  "Der folgende Dienst wird neu gestartet:",
  "Die folgenden Dienste werden neu gestartet:"
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Dieser Host wird nach der Installation der Aktualisierungen neu gestartet."
 ],
 "This system is not registered": [
  null,
  "Dieses System ist nicht registriert"
 ],
 "Thursdays": [
  null,
  "Donnerstags"
 ],
 "Time": [
  null,
  "Zeit"
 ],
 "Time zone": [
  null,
  "Zeitzone"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Um Aktualisierungen zu erhalten, muss dieses System bei Red Hat registriert sein; entweder im Red Hat Customer Portal oder einem lokalen Subscription-Dienst."
 ],
 "Toggle date picker": [
  null,
  "Datumsauswahl umschalten"
 ],
 "Total size: $0": [
  null,
  "Gesamtgröße: $0"
 ],
 "Trying to synchronize with $0": [
  null,
  "Versuche mit {{Server}} zu synchronisieren"
 ],
 "Tuesdays": [
  null,
  "Dienstags"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Unavailable packages": [
  null,
  "Nicht verfügbare Pakete"
 ],
 "Update Success Table": [
  null,
  "Aktualisierungserfolgstabelle"
 ],
 "Update history": [
  null,
  "Update-Verlauf"
 ],
 "Update was successful": [
  null,
  "Aktualisierung war erfolgreich"
 ],
 "Updated": [
  null,
  "Aktualisiert"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Aktualisierte Pakete erfordern möglicherweise einen Neustart, um wirksam zu werden."
 ],
 "Updates available": [
  null,
  "Updates verfügbar"
 ],
 "Updates history": [
  null,
  "Aktualisierungsverlauf"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "Aktualisierungen werden $0 auf $1 angewandt"
 ],
 "Updating": [
  null,
  "Aktualisiere"
 ],
 "Verified": [
  null,
  "Verifiziert"
 ],
 "Verifying": [
  null,
  "Überprüfung läuft"
 ],
 "Version": [
  null,
  "Version"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Warten, bis andere Software-Verwaltungsvorgänge abgeschlossen sind"
 ],
 "Web Console will restart": [
  null,
  "Web-Konsole wird neu gestartet"
 ],
 "Wednesdays": [
  null,
  "Mittwochs"
 ],
 "When": [
  null,
  "Wenn"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Wenn die Web-Konsole neu gestartet wird, sehen Sie keine Fortschrittsinformationen mehr. Allerdings wird der Aktualisierungsprozess im Hintergrund fortgesetzt. Stellen Sie die Verbindung wieder her, um den Aktualisierungsprozess weiter zu verfolgen."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Ihr Server wird die Verbindung bald beenden. Sie können die Verbindung nach dem Neustart wiederherstellen."
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "at": [
  null,
  "um"
 ],
 "bug fix": [
  null,
  "Bug-Fix"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "enhancement": [
  null,
  "Verbesserung"
 ],
 "every Friday": [
  null,
  "jeden Freitag"
 ],
 "every Monday": [
  null,
  "jeden Montag"
 ],
 "every Saturday": [
  null,
  "jeden Samstag"
 ],
 "every Sunday": [
  null,
  "jeden Sonntag"
 ],
 "every Thursday": [
  null,
  "jeden Donnerstag"
 ],
 "every Tuesday": [
  null,
  "jeden Dienstag"
 ],
 "every Wednesday": [
  null,
  "jeden Mittwoch"
 ],
 "every day": [
  null,
  "jeden Tag"
 ],
 "for current and future kernels": [
  null,
  "für aktuelle und zukünftige Kernel"
 ],
 "for current kernel only": [
  null,
  "nur für den aktuellen Kernel"
 ],
 "package": [
  null,
  "Paket"
 ],
 "packagekit": [
  null,
  ""
 ],
 "patches": [
  null,
  "Patches"
 ],
 "security": [
  null,
  "Sicherheit"
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ],
 "yum": [
  null,
  "yum"
 ]
});
