cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 is not available from any repository.": [
  null,
  "$0 ხელმიუწვდომელია ყველა რეპოზიტორიიდან."
 ],
 "$0 package": [
  null,
  "$0 პაკეტი",
  "$0 ცალი პაკეტი"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 პაკეტს სჭირდება სისტემის გადატვირთვა",
  "$0 ცალ პაკეტს სჭირდება სისტემის გადატვირთვა"
 ],
 "$0 security fix available": [
  null,
  "ხელმისაწვდომია $0 უსაფრთხოების განახლება",
  "ხელმისაწვდომია $0 ცალი უსაფრთხოების განახლება"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 სერვისს სჭირდება სისტემის გადატვირთვა",
  "$0 ცალ სერვისს სჭირდება სისტემის გადატვირთვა"
 ],
 "$0 update available": [
  null,
  "ხელმისაწვდომია $0 განახლება",
  "ხელმისაწვდომია $0 ცალი განახლება"
 ],
 "$0 will be installed.": [
  null,
  "დაყენდება $0."
 ],
 ", including $1 security fix": [
  null,
  ", $1 უსაფრთხოების პაჩი",
  ", $1 ცალი უსაფრთხოების პაჩი"
 ],
 "1 minute": [
  null,
  "1 წთ"
 ],
 "20 minutes": [
  null,
  "20 წთ"
 ],
 "40 minutes": [
  null,
  "40 წთ"
 ],
 "5 minutes": [
  null,
  "5 წთ"
 ],
 "60 minutes": [
  null,
  "60 წთ"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "ცვლილებების სანახავად პაკეტს სისტემის გადატვირთვა სჭირდება:",
  "ზოგიერთ პაკეტს ცვლილებების სანახავად სისტემის გადატვირთვა სჭირდება:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "განსაახლებლად სერვისს სჭირდება სისტემის გადატვირთვა:",
  "განსაახლებლად სერვისებს სჭირდებათ სისტემის გადატვირთვა:"
 ],
 "Additional packages:": [
  null,
  "დამატებითი პაკეტები:"
 ],
 "All updates": [
  null,
  "ყველა განახლება"
 ],
 "Apply kernel live patches": [
  null,
  "გაშვებული ბირთვის პაჩების გადატარება"
 ],
 "Applying updates": [
  null,
  "განახლებების გადატარება"
 ],
 "Applying updates failed": [
  null,
  "განახლებების გადატარების შეცდომა"
 ],
 "Automatic updates": [
  null,
  "ავტომატური განახლებები"
 ],
 "Automatically using NTP": [
  null,
  "ავტომატურად, NTP-ით"
 ],
 "Automatically using specific NTP servers": [
  null,
  "მითითებული NTP სერვერების ავტომატური გამოყენება"
 ],
 "Available updates": [
  null,
  "ხელმისაწვდომი განახლებები"
 ],
 "Bug fix updates available": [
  null,
  "ხელმისაწვდომია შეცდომების გასწორებები"
 ],
 "Bugs": [
  null,
  "შეცდომები"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Cannot schedule event in the past": [
  null,
  "მოვლენის წარსულ დროში დანიშვნა შეუძლებელია"
 ],
 "Change": [
  null,
  "შეცვლა"
 ],
 "Change system time": [
  null,
  "სისტემური დროის შეცვლა"
 ],
 "Check for updates": [
  null,
  "განახლებების შემოწმება"
 ],
 "Checking for package updates...": [
  null,
  "პაკეტების განახლებების შემოწმება..."
 ],
 "Checking installed software": [
  null,
  "დაყენებული პროგრამული უზრუნველყოფის შემოწმება"
 ],
 "Checking software status": [
  null,
  "პროგრამის სტატუსის შემოწმება"
 ],
 "Continue": [
  null,
  "გაგრძელება"
 ],
 "Danger alert:": [
  null,
  "საშიშროების შეტყობინება:"
 ],
 "Delay": [
  null,
  "დაყოვნება"
 ],
 "Details": [
  null,
  "დეტალები"
 ],
 "Disabled": [
  null,
  "გათიშულია"
 ],
 "Downloaded": [
  null,
  "გადმოწერილია"
 ],
 "Downloading": [
  null,
  "გადმოწერა"
 ],
 "Downloading $0": [
  null,
  "$0-ის გადმოწერა"
 ],
 "Edit": [
  null,
  "ჩასწორება"
 ],
 "Enable": [
  null,
  "ჩართვა"
 ],
 "Enabled": [
  null,
  "ჩართულია"
 ],
 "Enhancement updates available": [
  null,
  "ხელმისაწვდომია განახლებები"
 ],
 "Errata": [
  null,
  "დამატებითი პაჩები"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "dnf-automatic.timer ან dnf-automatic-install.timer-ისთვის სერვისის ფაილების დამუშავება ვერ მოხერხდა. გთხოვთ, წაშალოთ მორგებული უგულებელყოფა ავტომატური განახლებების კონფიგურაციისთვის."
 ],
 "Failed to restart service": [
  null,
  "სერვისის რესტარტის შეცდომა"
 ],
 "Fridays": [
  null,
  "კვირაობით"
 ],
 "History package count": [
  null,
  "ისტორიის პაკეტის რიცხვი"
 ],
 "Ignore": [
  null,
  "იგნორი"
 ],
 "Info": [
  null,
  "ინფორმაცია"
 ],
 "Initializing...": [
  null,
  "ინიციალიზაცია..."
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Install all updates": [
  null,
  "ყველა განახლების დაყენება"
 ],
 "Install kpatch updates": [
  null,
  "Kpatch-ის განახლების დაყენება"
 ],
 "Install security updates": [
  null,
  "უსაფრთხოების განახლებების დაყენება"
 ],
 "Install software": [
  null,
  "პროგრამების დაყენება"
 ],
 "Installed": [
  null,
  "დაყენებული"
 ],
 "Installing": [
  null,
  "მიმდინარეობს დაყენება"
 ],
 "Installing $0": [
  null,
  "$0-ის დაყენება"
 ],
 "Invalid date format": [
  null,
  "თარიღის არასწორი ფორმატი"
 ],
 "Invalid date format and invalid time format": [
  null,
  "თარიღისა და დროის არასწორი ფორმატი"
 ],
 "Invalid time format": [
  null,
  "დროის არასწორი ფორმატი"
 ],
 "Invalid timezone": [
  null,
  "დროის არასწორი სარტყელი"
 ],
 "Kernel live patch $0 is active": [
  null,
  "ცოცხალი ბირთვის პაჩი $0 ახლა აქტიურია"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "ცოცხალი ბირთვის პაჩი $0 დაყენებულია"
 ],
 "Kernel live patch settings": [
  null,
  "ჩართული ბირთვის პაჩის მორგება"
 ],
 "Kernel live patching": [
  null,
  "ოპერაციული სისტემის გაშვებული ბირთვის ჩასწორება"
 ],
 "Last checked: $0": [
  null,
  "ბოლოს შემოწმდა: $0"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "Loading available updates failed": [
  null,
  "ხელმისაწვდომი განახლებების ჩატვირთვი შეცდომა"
 ],
 "Loading available updates, please wait...": [
  null,
  "მიმდინარეობს ხელისაწვდომი განახლებების ჩატვირთვა. გთხოვთ მოითმინოთ..."
 ],
 "Log messages": [
  null,
  "ჟურნალის შეტყობინებები"
 ],
 "Managing software updates": [
  null,
  "პროგრამული უზრუნველყოფის განახლების მართვა"
 ],
 "Manually": [
  null,
  "ხელით მითითებული"
 ],
 "Message to logged in users": [
  null,
  "შესული მომხმარებლებისთვის შეტყობინების გაგზავნა"
 ],
 "Mondays": [
  null,
  "ორშაბათობით"
 ],
 "More info...": [
  null,
  "მეტი ინფორმაცია..."
 ],
 "NTP server": [
  null,
  "NTP სერვერი"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Need at least one NTP server": [
  null,
  "საჭიროა ერთი NTP სერვერი მაინც"
 ],
 "No delay": [
  null,
  "დაყოვნების გარეშე"
 ],
 "No updates": [
  null,
  "განახლებების გარეშე"
 ],
 "Not available": [
  null,
  "ხელმიუწვდომელია"
 ],
 "Not installed": [
  null,
  "დაყენებული არაა"
 ],
 "Not registered": [
  null,
  "რეგისტრირებული არაა"
 ],
 "Not set up": [
  null,
  "მორგებული არაა"
 ],
 "Not synchronized": [
  null,
  "სინქრონიზებული არაა"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "Package information": [
  null,
  "ინფორმაცია პაკეტის შესახებ"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit-ის ავარია"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit დაყენებული არაა"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit-ის შეცდომის კოდი $0"
 ],
 "Packages": [
  null,
  "პაკეტები"
 ],
 "Pick date": [
  null,
  "აირჩიეთ თარიღი"
 ],
 "Please reload the page after resolving the issue.": [
  null,
  "პრობლემის გადაწყვეტის შემდეგ გთხოვთ განაახლოთ გვერდი."
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Reboot after completion": [
  null,
  "გადატვირთვა დასრულების შემდეგ"
 ],
 "Reboot recommended": [
  null,
  "რეკომენდებულია გადატვირთვა"
 ],
 "Reboot system...": [
  null,
  "სისტემის გადატვირთვა..."
 ],
 "Refreshing package information": [
  null,
  "პაკეტების ინფორმაციის განახლება"
 ],
 "Register…": [
  null,
  "რეგისტრაცია…"
 ],
 "Reloading the state of remaining services": [
  null,
  "დარჩენილი სერვისების მდგომარეობის გადატვირთვა"
 ],
 "Removals:": [
  null,
  "წაიშლება:"
 ],
 "Removing $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Restart services": [
  null,
  "სერვისების რესტარტი"
 ],
 "Restart services...": [
  null,
  "სერვისების რესტარტი..."
 ],
 "Restarting": [
  null,
  "გადატვირთვა"
 ],
 "Saturdays": [
  null,
  "შაბათობით"
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "Save changes": [
  null,
  "ცვლილებების შენახვა"
 ],
 "Security updates available": [
  null,
  "ხელმისაწვდომია უსაფრთოხების განახლებები"
 ],
 "Security updates only": [
  null,
  "მხოლოდ უსაფრთხოების განახლებები"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "უსაფრთხოების პაჩები გადატარდება $0-ზე $1-ზე"
 ],
 "Set time": [
  null,
  "დროის დაყენება"
 ],
 "Set up": [
  null,
  "მორგება"
 ],
 "Setting up": [
  null,
  "მორგება"
 ],
 "Settings": [
  null,
  "მორგება"
 ],
 "Severity": [
  null,
  "სიმძიმე"
 ],
 "Shut down": [
  null,
  "გამორთვა"
 ],
 "Software updates": [
  null,
  "პროგრამების განახლებები"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "პაკეტების მმართველს ამჟამად სხვა პროგრამა იყენებს. გთხოვთ, მოითმინოთ..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "ზოგიერთ პროგრამულ უზრუნველყოფას ხელით გადატვირთვა სჭირდება"
 ],
 "Specific time": [
  null,
  "მითითებული დრო"
 ],
 "Status": [
  null,
  "მდგომარეობა"
 ],
 "Sundays": [
  null,
  "კვირაობით"
 ],
 "Synchronized": [
  null,
  "სინქრონიზებულია"
 ],
 "Synchronized with $0": [
  null,
  "სინქრონიზებულია $0-თან"
 ],
 "Synchronizing": [
  null,
  "სინქრონიზაცია"
 ],
 "System is up to date": [
  null,
  "სისტემა განახლებულია"
 ],
 "The following service will be restarted:": [
  null,
  "დარესტარტდება შემდეგი სერვისი:",
  "დარესტარტდება შემდეგი სერვისები:"
 ],
 "This host will reboot after updates are installed.": [
  null,
  "განახლებების დაყენების შემდეგ სისტემა გადაიტვირთება."
 ],
 "This system is not registered": [
  null,
  "სისტემა რეგისტრირებული არაა"
 ],
 "Thursdays": [
  null,
  "ხუთშაბათობით"
 ],
 "Time": [
  null,
  "დრო"
 ],
 "Time zone": [
  null,
  "დროის სარტყელი"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "პროგრამების განახლებების მისაღებად საჭიროა სისტემის Red Hat-ში დარეგისტრირება RedHat-ის პორტალით ან გამოწერების ლოკალური სერვერით."
 ],
 "Toggle date picker": [
  null,
  "თარიღის ამრჩევის გადართვა"
 ],
 "Total size: $0": [
  null,
  "ჯამური ზომა: $0"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0-თან სინქრონიზაციის მცდელობა"
 ],
 "Tuesdays": [
  null,
  "სამშაბათობით"
 ],
 "Type": [
  null,
  "ტიპი"
 ],
 "Unavailable packages": [
  null,
  "ხელმიუწვდომელი პაკეტები"
 ],
 "Update Success Table": [
  null,
  "წარმატების ცხრილის განახლება"
 ],
 "Update history": [
  null,
  "ისტორიის განახლება"
 ],
 "Update was successful": [
  null,
  "განახლება წარმატებულად დასრულდა"
 ],
 "Updated": [
  null,
  "განახლებულია"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "განახლებული პაკეტების ძალაში შესასვლელად შეიძლება გადატვირთვა გახდეს საჭირო."
 ],
 "Updates available": [
  null,
  "ხელმისაწვდომია განახლება"
 ],
 "Updates history": [
  null,
  "განახლებების ისტორია"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "განახლებები გადატარდება $0 $1-ზე"
 ],
 "Updating": [
  null,
  "მიმდინარეობს განახლება"
 ],
 "Verified": [
  null,
  "შემოწმებული"
 ],
 "Verifying": [
  null,
  "შემოწმება"
 ],
 "Version": [
  null,
  "ვერსია"
 ],
 "View update log": [
  null,
  "განახლების ჟურნალის ნახვა"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "პროგრამების მართვის სხვა ოპერაციების დასრულების მოლოდინი"
 ],
 "Web Console will restart": [
  null,
  "ვებ კონსოლი დარესტარტდება"
 ],
 "Wednesdays": [
  null,
  "ოთხშაბათობით"
 ],
 "When": [
  null,
  "როდის"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "როცა ვებ კონსოლი გადაიტვირთება, თქვენ ვეღარ დაინახავთ ინფორმაციას მიმდინარეობის შესახებ. მაგრამ განახლების პროცესი ფონურად გაგრძელდება. მიმდინარეობის დასანახავად დაუკავშირდით თავიდან."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "თქვენი სერვერი მალე კავშირს დახურავს. გადატვირთვის შემდეგ შეგეძლებათ თავიდან დაუკავშირდეთ."
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "at": [
  null,
  "დრო"
 ],
 "bug fix": [
  null,
  "შეცდ. გასწ"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "enhancement": [
  null,
  "გაუმჯობესება"
 ],
 "every Friday": [
  null,
  "ყოველ პარასკევს"
 ],
 "every Monday": [
  null,
  "ყოველ ორშაბათს"
 ],
 "every Saturday": [
  null,
  "ყოველ შაბათს"
 ],
 "every Sunday": [
  null,
  "ყოველ კვირას"
 ],
 "every Thursday": [
  null,
  "ყოველ ხუთშაბათს"
 ],
 "every Tuesday": [
  null,
  "ყოველ სამშაბათს"
 ],
 "every Wednesday": [
  null,
  "ყოველ ოთხშაბათს"
 ],
 "every day": [
  null,
  "ყოველდღე"
 ],
 "for current and future kernels": [
  null,
  "მიმდინარე და მომავალი ბირთვებისთვის"
 ],
 "for current kernel only": [
  null,
  "მხოლოდ მიმდინარე ბირთვისთვის"
 ],
 "package": [
  null,
  "პაკეტი"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "patches": [
  null,
  "პაჩები"
 ],
 "security": [
  null,
  "უსაფრთხოება"
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ],
 "yum": [
  null,
  "yum"
 ]
});
