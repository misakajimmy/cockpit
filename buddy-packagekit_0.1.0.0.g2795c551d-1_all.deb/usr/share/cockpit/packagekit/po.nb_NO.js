cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nb_NO",
  "language-direction": "ltr"
 },
 "$0 is not available from any repository.": [
  null,
  "$0 er ikke tilgjengelig fra noe depot."
 ],
 "$0 package": [
  null,
  "$0 pakke",
  "$0 pakker"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 pakke trenger en omstart av systemet",
  "$0 pakker trenger en omstart av systemet"
 ],
 "$0 security fix available": [
  null,
  "$0 sikkerhetsrettelse tilgjengelig",
  "$0 sikkerhetsrettelser tilgjengelig"
 ],
 "$0 service needs to be restarted": [
  null,
  "$o tjeneste trenger omstart",
  "$o tjenester trenger omstart"
 ],
 "$0 update available": [
  null,
  "$0 oppdatering tilgjengelig",
  "$0 oppdateringer tilgjengelig"
 ],
 "$0 will be installed.": [
  null,
  "$0 vil bli installert."
 ],
 ", including $1 security fix": [
  null,
  ", inkludert $1 sikkerhetsrettelse",
  ", inkludert $1 sikkerhetsrettelser"
 ],
 "1 minute": [
  null,
  "1 minutt"
 ],
 "20 minutes": [
  null,
  "20 minutter"
 ],
 "40 minutes": [
  null,
  "40 minutter"
 ],
 "5 minutes": [
  null,
  "5 minutter"
 ],
 "60 minutes": [
  null,
  "60 minutter"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "En pakke trenger en omstart av systemet for at oppdateringene skal tre i kraft:",
  "Noen pakker trenger en omstart av systemet for at oppdateringene skal tre i kraft:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "En tjeneste må startes på nytt for at oppdateringene skal tre i kraft:",
  "Noen tjenester må startes på nytt for at oppdateringene skal tre i kraft:"
 ],
 "Additional packages:": [
  null,
  "Ekstra pakker:"
 ],
 "All updates": [
  null,
  "Alle oppdateringer"
 ],
 "Applying updates": [
  null,
  "Tar i bruk oppdateringer"
 ],
 "Applying updates failed": [
  null,
  "Å ta i bruk oppdateringer feilet"
 ],
 "Automatic updates": [
  null,
  "Automatiske oppdateringer"
 ],
 "Automatically using NTP": [
  null,
  "Automatisk med bruk av NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatisk med bruk av spesifikke NTP servere"
 ],
 "Available updates": [
  null,
  "Tilgjengelige oppdateringer"
 ],
 "Bug fix updates available": [
  null,
  "Feilrettingsoppdateringer tilgjengelig"
 ],
 "Bugs": [
  null,
  "Feil"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Cannot schedule event in the past": [
  null,
  "Kan ikke tidsplanlegge hendelse i fortiden"
 ],
 "Change": [
  null,
  "Endre"
 ],
 "Change system time": [
  null,
  "Endre systemtid"
 ],
 "Check for updates": [
  null,
  "Se etter oppdateringer"
 ],
 "Checking for package updates...": [
  null,
  "Ser etter pakkeoppdateringer ..."
 ],
 "Checking installed software": [
  null,
  "Kontrollerer installert programvare"
 ],
 "Checking software status": [
  null,
  "Kontrollerer programvarestatus"
 ],
 "Continue": [
  null,
  "Fortsett"
 ],
 "Danger alert:": [
  null,
  "Farevarsel:"
 ],
 "Delay": [
  null,
  "Forsinkelse"
 ],
 "Details": [
  null,
  "Detaljer"
 ],
 "Disabled": [
  null,
  "Deaktivert"
 ],
 "Downloaded": [
  null,
  "Nedlastet"
 ],
 "Downloading": [
  null,
  "Laster ned"
 ],
 "Downloading $0": [
  null,
  "Laster ned $0"
 ],
 "Edit": [
  null,
  "Rediger"
 ],
 "Enabled": [
  null,
  "Aktivert"
 ],
 "Enhancement updates available": [
  null,
  "Forbedringsoppdateringer tilgjengelig"
 ],
 "Errata": [
  null,
  ""
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  ""
 ],
 "Failed to restart service": [
  null,
  "Kan ikke omstarte tjenesten"
 ],
 "Fridays": [
  null,
  "Fredager"
 ],
 "History package count": [
  null,
  ""
 ],
 "Ignore": [
  null,
  "Ignorer"
 ],
 "Info": [
  null,
  "Info"
 ],
 "Initializing...": [
  null,
  "Initialiserer…"
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install all updates": [
  null,
  "Installer alle oppdateringer"
 ],
 "Install security updates": [
  null,
  "Installer sikkerhetsoppdateringer"
 ],
 "Install software": [
  null,
  "Installer programvare"
 ],
 "Installed": [
  null,
  "Installert"
 ],
 "Installing": [
  null,
  "Installerer"
 ],
 "Installing $0": [
  null,
  "Installerer $0"
 ],
 "Invalid date format": [
  null,
  "Ugyldig datoformat"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Ugyldig datoformat og ugyldig tidsformat"
 ],
 "Invalid time format": [
  null,
  "Ugyldig tidsformat"
 ],
 "Invalid timezone": [
  null,
  "Ugyldig tidssone"
 ],
 "Last checked: $0": [
  null,
  "Sist sjekket: $0"
 ],
 "Learn more": [
  null,
  "Lær mer"
 ],
 "Loading available updates failed": [
  null,
  "Lasting av tilgjengelige oppdateringer feilet"
 ],
 "Loading available updates, please wait...": [
  null,
  "Laster tilgjengelige oppdateringer, vent ..."
 ],
 "Log messages": [
  null,
  "Logg meldinger"
 ],
 "Managing software updates": [
  null,
  "Administrere programvareoppdateringer"
 ],
 "Manually": [
  null,
  "Manuelt"
 ],
 "Message to logged in users": [
  null,
  "Melding til innloggede brukere"
 ],
 "Mondays": [
  null,
  "Mandager"
 ],
 "More info...": [
  null,
  "Mer info..."
 ],
 "NTP server": [
  null,
  "NTP Server"
 ],
 "Name": [
  null,
  "Navn"
 ],
 "Need at least one NTP server": [
  null,
  "Trenger minst en NTP-server"
 ],
 "No delay": [
  null,
  "Ingen forsinkelse"
 ],
 "No updates": [
  null,
  "Ingen oppdateringer"
 ],
 "Not available": [
  null,
  "Ikke tilgjengelig"
 ],
 "Not registered": [
  null,
  "Ikke registrert"
 ],
 "Not synchronized": [
  null,
  "Ikke synkronisert"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Package information": [
  null,
  "Pakkeinformasjon"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit krasjet"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit er ikke installert"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit rapporterte feilkode $ 0"
 ],
 "Packages": [
  null,
  "Pakker"
 ],
 "Pick date": [
  null,
  "Velg dato"
 ],
 "Please reload the page after resolving the issue.": [
  null,
  "Last siden på nytt etter å ha løst problemet."
 ],
 "Reboot": [
  null,
  "Omstart"
 ],
 "Reboot recommended": [
  null,
  "Omstart anbefales"
 ],
 "Reboot system...": [
  null,
  "Omstart systemet..."
 ],
 "Refreshing package information": [
  null,
  "Oppdaterer pakkeinformasjon"
 ],
 "Register…": [
  null,
  "Registrer…"
 ],
 "Reloading the state of remaining services": [
  null,
  "Last inn tilstanden på gjenværende tjenestene"
 ],
 "Removals:": [
  null,
  ""
 ],
 "Removing $0": [
  null,
  "Fjerner $0"
 ],
 "Restart services": [
  null,
  "Omstart tjenester"
 ],
 "Restart services...": [
  null,
  "Omstart tjenester..."
 ],
 "Restarting": [
  null,
  "Omstarter"
 ],
 "Saturdays": [
  null,
  "Lørdager"
 ],
 "Save": [
  null,
  "Lagre"
 ],
 "Save changes": [
  null,
  "Lagre endringer"
 ],
 "Security updates available": [
  null,
  "Sikkerhetsoppdateringer tilgjengelig"
 ],
 "Security updates only": [
  null,
  "Bare sikkerhetsoppdateringer"
 ],
 "Set time": [
  null,
  "Sett tid"
 ],
 "Set up": [
  null,
  "Sett opp"
 ],
 "Setting up": [
  null,
  "Setter opp"
 ],
 "Severity": [
  null,
  "Alvorlighetsgrad"
 ],
 "Shut down": [
  null,
  "Slå av"
 ],
 "Software updates": [
  null,
  "Programvare oppdateringer"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Noen andre programmer bruker for øyeblikket pakkebehandling, vent ..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "Noe programvare må startes på nytt manuelt"
 ],
 "Specific time": [
  null,
  "Spesifikk tid"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Sundays": [
  null,
  "Søndager"
 ],
 "Synchronized": [
  null,
  "Synkronisert"
 ],
 "Synchronized with $0": [
  null,
  "Synkronisert med $0"
 ],
 "Synchronizing": [
  null,
  "Synkroniserer"
 ],
 "System is up to date": [
  null,
  "Systemet er oppdatert"
 ],
 "The following service will be restarted:": [
  null,
  "Følgende tjeneste startes på nytt:",
  "Følgende tjenester startes på nytt:"
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Denne verten vil starte på nytt etter at oppdateringer er installert."
 ],
 "This system is not registered": [
  null,
  "Dette systemet er ikke registrert"
 ],
 "Thursdays": [
  null,
  "Torsdager"
 ],
 "Time": [
  null,
  "Tid"
 ],
 "Time zone": [
  null,
  "Tidssone"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "For å få programvareoppdateringer, må dette systemet registreres hos Red Hat, enten ved hjelp av Red Hat Customer Portal eller en lokal abonnementsserver."
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Total size: $0": [
  null,
  "Total størrelse: $0"
 ],
 "Trying to synchronize with $0": [
  null,
  "Prøver å synkronisere med $0"
 ],
 "Tuesdays": [
  null,
  "Tirsdager"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Update Success Table": [
  null,
  ""
 ],
 "Update history": [
  null,
  "Oppdateringshistorikk"
 ],
 "Update was successful": [
  null,
  "Oppdateringen var vellykket"
 ],
 "Updated": [
  null,
  "Oppdatert"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Oppdaterte pakker kan kreve omstart for å tre i kraft."
 ],
 "Updates available": [
  null,
  "Oppdateringer tilgjengelig"
 ],
 "Updates history": [
  null,
  "Oppdateringshistorikk"
 ],
 "Updating": [
  null,
  "Oppdaterer"
 ],
 "Verified": [
  null,
  "Verifisert"
 ],
 "Verifying": [
  null,
  "Verifiserer"
 ],
 "Version": [
  null,
  "Versjon"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Venter på at andre programvareadministrasjons-operasjoner skal fullføres"
 ],
 "Web Console will restart": [
  null,
  "Web konsoll starter på nytt"
 ],
 "Wednesdays": [
  null,
  "Onsdager"
 ],
 "When": [
  null,
  "Når"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Når Web konsoll startes på nytt, vil du ikke lenger se fremdrifts-informasjon. Oppdateringsprosessen vil imidlertid fortsette i bakgrunnen. Koble til igjen for å fortsette å se oppdateringsprosessen."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Serveren din lukker tilkoblingen snart. Du kan koble til igjen etter at den har startet på nytt."
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "at": [
  null,
  ""
 ],
 "bug fix": [
  null,
  "feilretting"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "enhancement": [
  null,
  ""
 ],
 "every day": [
  null,
  "hver dag"
 ],
 "for current and future kernels": [
  null,
  ""
 ],
 "package": [
  null,
  "pakke"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "patches": [
  null,
  ""
 ],
 "security": [
  null,
  "sikkerhet"
 ],
 "show less": [
  null,
  "vis mindre"
 ],
 "show more": [
  null,
  "vis mer"
 ],
 "yum": [
  null,
  "yum"
 ]
});
