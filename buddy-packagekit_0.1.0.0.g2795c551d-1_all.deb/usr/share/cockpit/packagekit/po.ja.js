cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "$0 is not available from any repository.": [
  null,
  "$0 は、あらゆるリポジトリーから利用できません。"
 ],
 "$0 package": [
  null,
  "$0 パッケージ"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 パッケージにはシステムの再起動が必要です"
 ],
 "$0 security fix available": [
  null,
  "$0 セキュリティー修正が利用可能"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 サービスを再起動する必要があります"
 ],
 "$0 update available": [
  null,
  "$0 更新を利用できます"
 ],
 "$0 will be installed.": [
  null,
  "$0 がインストールされます。"
 ],
 ", including $1 security fix": [
  null,
  "セキュリティー修正を $1 個含む"
 ],
 "1 minute": [
  null,
  "1 分"
 ],
 "20 minutes": [
  null,
  "20 分"
 ],
 "40 minutes": [
  null,
  "40 分"
 ],
 "5 minutes": [
  null,
  "5 分"
 ],
 "60 minutes": [
  null,
  "60 分"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "パッケージの更新を有効にするには、システムを再起動する必要があります:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "更新を有効にするには、サービスを再起動する必要があります:"
 ],
 "Additional packages:": [
  null,
  "追加のパッケージ:"
 ],
 "All updates": [
  null,
  "すべてのアップデート"
 ],
 "Apply kernel live patches": [
  null,
  "カーネルライブパッチの適用"
 ],
 "Applying updates": [
  null,
  "アップデートの適用中"
 ],
 "Applying updates failed": [
  null,
  "アップデートの適用に失敗しました"
 ],
 "Automatic updates": [
  null,
  "自動アップデート"
 ],
 "Automatically using NTP": [
  null,
  "NTP を自動的に使用"
 ],
 "Automatically using specific NTP servers": [
  null,
  "特定の NTP サーバーを自動的に使用"
 ],
 "Available updates": [
  null,
  "利用可能なアップデート"
 ],
 "Bug fix updates available": [
  null,
  "バグ修正の更新が利用可能"
 ],
 "Bugs": [
  null,
  "バグ"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Cannot schedule event in the past": [
  null,
  "過去のイベントはスケジュールできません"
 ],
 "Change": [
  null,
  "変更"
 ],
 "Change system time": [
  null,
  "システム時間の変更"
 ],
 "Check for updates": [
  null,
  "更新の確認"
 ],
 "Checking for package updates...": [
  null,
  "パッケージの更新を確認しています..."
 ],
 "Checking installed software": [
  null,
  "インストールされたソフトウェアの確認中"
 ],
 "Checking software status": [
  null,
  "ソフトウェアステータスの確認"
 ],
 "Continue": [
  null,
  "続行"
 ],
 "Danger alert:": [
  null,
  "Danger アラート:"
 ],
 "Delay": [
  null,
  "遅延"
 ],
 "Details": [
  null,
  "詳細"
 ],
 "Disabled": [
  null,
  "無効"
 ],
 "Downloaded": [
  null,
  "ダウンロードされました"
 ],
 "Downloading": [
  null,
  "ダウンロード中"
 ],
 "Downloading $0": [
  null,
  "$0 をダウンロード中"
 ],
 "Edit": [
  null,
  "編集"
 ],
 "Enable": [
  null,
  "有効化"
 ],
 "Enabled": [
  null,
  "有効"
 ],
 "Enhancement updates available": [
  null,
  "機能拡張の更新を利用できます"
 ],
 "Errata": [
  null,
  "エラータ"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "dnf-automatic.timer または dnf-automatic-install.timer のユニットファイルの分析に失敗しました。カスタムオーバーライドを削除して、自動更新を設定してください。"
 ],
 "Failed to restart service": [
  null,
  "サービスの再起動に失敗しました"
 ],
 "Fridays": [
  null,
  "毎週金曜日"
 ],
 "History package count": [
  null,
  "履歴パッケージ数"
 ],
 "Ignore": [
  null,
  "無視"
 ],
 "Info": [
  null,
  "情報"
 ],
 "Initializing...": [
  null,
  "初期化中..."
 ],
 "Install": [
  null,
  "インストール"
 ],
 "Install all updates": [
  null,
  "すべてのアップデートをインストールする"
 ],
 "Install kpatch updates": [
  null,
  "kpatch の更新をインストールする"
 ],
 "Install security updates": [
  null,
  "セキュリティーアップデートをインストールする"
 ],
 "Install software": [
  null,
  "ソフトウェアをインストール"
 ],
 "Installed": [
  null,
  "インストール済み"
 ],
 "Installing": [
  null,
  "インストール中"
 ],
 "Installing $0": [
  null,
  "$0 をインストール中"
 ],
 "Invalid date format": [
  null,
  "無効な日付形式"
 ],
 "Invalid date format and invalid time format": [
  null,
  "無効な日付形式と無効な時間形式"
 ],
 "Invalid time format": [
  null,
  "無効な時間形式"
 ],
 "Invalid timezone": [
  null,
  "無効なタイムゾーン"
 ],
 "Kernel live patch $0 is active": [
  null,
  "カーネルライブパッチ $0 はアクティブです"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "カーネルライブパッチ $0 がインストールされています"
 ],
 "Kernel live patch settings": [
  null,
  "カーネルライブパッチの設定"
 ],
 "Kernel live patching": [
  null,
  "カーネルライブパッチ"
 ],
 "Last checked: $0": [
  null,
  "最終確認: $0"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "Loading available updates failed": [
  null,
  "利用可能なアップデートのロードに失敗しました"
 ],
 "Loading available updates, please wait...": [
  null,
  "利用可能なアップデートをロード中です。しばらくお待ちください..."
 ],
 "Log messages": [
  null,
  "ログメッセージ"
 ],
 "Managing software updates": [
  null,
  "ソフトウェアアップデート管理"
 ],
 "Manually": [
  null,
  "手動"
 ],
 "Message to logged in users": [
  null,
  "ログインしているユーザーへのメッセージ"
 ],
 "Mondays": [
  null,
  "毎週月曜日"
 ],
 "More info...": [
  null,
  "詳細..."
 ],
 "NTP server": [
  null,
  "NTP サーバー"
 ],
 "Name": [
  null,
  "名前"
 ],
 "Need at least one NTP server": [
  null,
  "少なくとも 1 つの NTP サーバーが必要です"
 ],
 "No delay": [
  null,
  "遅延なし"
 ],
 "No updates": [
  null,
  "更新なし"
 ],
 "Not available": [
  null,
  "利用できません"
 ],
 "Not installed": [
  null,
  "インストールされていません"
 ],
 "Not registered": [
  null,
  "登録されていません"
 ],
 "Not set up": [
  null,
  "設定されていません"
 ],
 "Not synchronized": [
  null,
  "同期されていません"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Package information": [
  null,
  "パッケージ情報"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit がクラッシュしました"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit はインストールされていません"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit が、エラーコード $0 を報告しました"
 ],
 "Packages": [
  null,
  "パッケージ"
 ],
 "Pick date": [
  null,
  "日付けの選択"
 ],
 "Please reload the page after resolving the issue.": [
  null,
  "問題の解決後にページをリロードしてください。"
 ],
 "Reboot": [
  null,
  "再起動"
 ],
 "Reboot after completion": [
  null,
  "完了後に再起動する"
 ],
 "Reboot recommended": [
  null,
  "再起動を推奨します"
 ],
 "Reboot system...": [
  null,
  "システムの再起動..."
 ],
 "Refreshing package information": [
  null,
  "パッケージ情報の更新中"
 ],
 "Register…": [
  null,
  "登録中…"
 ],
 "Reloading the state of remaining services": [
  null,
  "残りのサービス状態の再読み込み"
 ],
 "Removals:": [
  null,
  "削除:"
 ],
 "Removing $0": [
  null,
  "$0 を削除中"
 ],
 "Restart services": [
  null,
  "サービスの再起動"
 ],
 "Restart services...": [
  null,
  "サービスの再起動..."
 ],
 "Restarting": [
  null,
  "再起動中"
 ],
 "Saturdays": [
  null,
  "毎週土曜日"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Save changes": [
  null,
  "変更の保存"
 ],
 "Security updates available": [
  null,
  "セキュリティーの更新を利用できます"
 ],
 "Security updates only": [
  null,
  "セキュリティー更新のみ"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "$0 $1 にセキュリティーアップデートが適用されます"
 ],
 "Set time": [
  null,
  "時間の設定"
 ],
 "Set up": [
  null,
  "設定済み"
 ],
 "Setting up": [
  null,
  "設定中"
 ],
 "Settings": [
  null,
  "設定"
 ],
 "Severity": [
  null,
  "重大度"
 ],
 "Shut down": [
  null,
  "シャットダウン"
 ],
 "Software updates": [
  null,
  "ソフトウェア更新"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "別のプログラムがパッケージマネージャーを使用中です。しばらくお待ちください..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "一部のソフトウェアを手動で再起動する必要があります"
 ],
 "Specific time": [
  null,
  "特定の時間"
 ],
 "Status": [
  null,
  "ステータス"
 ],
 "Sundays": [
  null,
  "毎週日曜日"
 ],
 "Synchronized": [
  null,
  "同期済み"
 ],
 "Synchronized with $0": [
  null,
  "$0 と同期済み"
 ],
 "Synchronizing": [
  null,
  "同期中"
 ],
 "System is up to date": [
  null,
  "システムは最新の状態です"
 ],
 "The following service will be restarted:": [
  null,
  "以下のサービスが再起動します:"
 ],
 "This host will reboot after updates are installed.": [
  null,
  "このホストは、更新後に再起動します。"
 ],
 "This system is not registered": [
  null,
  "このシステムは登録されていません"
 ],
 "Thursdays": [
  null,
  "毎週木曜日"
 ],
 "Time": [
  null,
  "時間"
 ],
 "Time zone": [
  null,
  "タイムゾーン"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "ソフトウェアアップデートを取得するには、このシステムを Red Hat に登録する必要があります。登録には、Red Hat カスタマーポータルまたはローカルのサブスクリプションサーバーを使用します。"
 ],
 "Toggle date picker": [
  null,
  "日付選択の切り替え"
 ],
 "Total size: $0": [
  null,
  "合計サイズ: $0"
 ],
 "Trying to synchronize with $0": [
  null,
  "$0 との同期を試行中です"
 ],
 "Tuesdays": [
  null,
  "毎週火曜日"
 ],
 "Type": [
  null,
  "タイプ"
 ],
 "Unavailable packages": [
  null,
  "利用できないパッケージ"
 ],
 "Update Success Table": [
  null,
  "更新成功テーブル"
 ],
 "Update history": [
  null,
  "履歴の更新"
 ],
 "Update was successful": [
  null,
  "更新が正常に実行されました"
 ],
 "Updated": [
  null,
  "更新済み"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "パッケージの更新を反映するには、再起動が必要になる場合があります。"
 ],
 "Updates available": [
  null,
  "更新を利用できます"
 ],
 "Updates history": [
  null,
  "更新履歴"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "$0 $1 に更新が適用されます"
 ],
 "Updating": [
  null,
  "更新中"
 ],
 "Verified": [
  null,
  "検証済み"
 ],
 "Verifying": [
  null,
  "検証中"
 ],
 "Version": [
  null,
  "バージョン"
 ],
 "View update log": [
  null,
  "更新ログを表示する"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "他のソフトウェア管理オペレーションが終了するまで待機中"
 ],
 "Web Console will restart": [
  null,
  "Web コンソールが再起動します"
 ],
 "Wednesdays": [
  null,
  "毎週水曜日"
 ],
 "When": [
  null,
  "条件"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Web コンソールを再起動すると、進捗情報が表示されなくなります。ただし、更新プロセスはバックグラウンドで続行されます。更新プロセスの監視を継続するには、再接続します。"
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "サーバーがまもなく接続を閉じます。再起動したら再接続できます。"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "at": [
  null,
  "時間"
 ],
 "bug fix": [
  null,
  "バグ修正"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "enhancement": [
  null,
  "機能強化"
 ],
 "every Friday": [
  null,
  "毎週金曜日"
 ],
 "every Monday": [
  null,
  "毎週月曜日"
 ],
 "every Saturday": [
  null,
  "毎週土曜日"
 ],
 "every Sunday": [
  null,
  "毎週日曜日"
 ],
 "every Thursday": [
  null,
  "毎週木曜日"
 ],
 "every Tuesday": [
  null,
  "毎週火曜日"
 ],
 "every Wednesday": [
  null,
  "毎週水曜日"
 ],
 "every day": [
  null,
  "毎日"
 ],
 "for current and future kernels": [
  null,
  "現在のカーネルおよび将来のカーネルの場合"
 ],
 "for current kernel only": [
  null,
  "現在のカーネルのみの場合"
 ],
 "package": [
  null,
  "パッケージ"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "patches": [
  null,
  "パッチ"
 ],
 "security": [
  null,
  "セキュリティー"
 ],
 "show less": [
  null,
  "簡易表示"
 ],
 "show more": [
  null,
  "詳細表示"
 ],
 "yum": [
  null,
  "yum"
 ]
});
