cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 is not available from any repository.": [
  null,
  "$0 немає у жодному зі сховищ."
 ],
 "$0 package": [
  null,
  "$0 пакунок",
  "$0 пакунки",
  "$0 пакунків"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 пакунок потребує перезавантаження системи",
  "$0 пакунки потребують перезавантаження системи",
  "$0 пакунків потребують перезавантаження системи"
 ],
 "$0 security fix available": [
  null,
  "Доступне $0 оновлення захисту",
  "Доступні $0 оновлення захисту",
  "Доступні $0 оновлень захисту"
 ],
 "$0 service needs to be restarted": [
  null,
  "Слід перезапустити $0 службу",
  "Слід перезапустити $0 служби",
  "Слід перезапустити $0 служб"
 ],
 "$0 update available": [
  null,
  "Доступне $0 оновлення",
  "Доступні $0 оновлення",
  "Доступні $0 оновлень"
 ],
 "$0 will be installed.": [
  null,
  "Буде встановлено $0."
 ],
 ", including $1 security fix": [
  null,
  ", включно із $1 виправленням захисту",
  ", включно із $1 виправленнями захисту",
  ", включно із $1 виправленнями захисту"
 ],
 "1 minute": [
  null,
  "1 хвилина"
 ],
 "20 minutes": [
  null,
  "20 хвилин"
 ],
 "40 minutes": [
  null,
  "40 хвилин"
 ],
 "5 minutes": [
  null,
  "5 хвилин"
 ],
 "60 minutes": [
  null,
  "60 хвилин"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Для набуття оновленнями пакунків чинності слід перезапустити систему:",
  "Для набуття оновленнями пакунків чинності слід перезапустити систему:",
  "Для набуття оновленнями пакунків чинності слід перезапустити систему:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Для набуття оновленнями чинності слід перезапустити деякі служби:",
  "Для набуття оновленнями чинності слід перезапустити деякі служби:",
  "Для набуття оновленнями чинності слід перезапустити деякі служби:"
 ],
 "Additional packages:": [
  null,
  "Додаткові пакунки:"
 ],
 "All updates": [
  null,
  "Усі оновлення"
 ],
 "Apply kernel live patches": [
  null,
  "Застосувати інтерактивні латки до ядра"
 ],
 "Applying updates": [
  null,
  "Застосовуємо оновлення"
 ],
 "Applying updates failed": [
  null,
  "Не вдалося застосувати оновлення"
 ],
 "Automatic updates": [
  null,
  "Автоматичні оновлення"
 ],
 "Automatically using NTP": [
  null,
  "Автоматично на основі NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматично за допомогою певних серверів NTP"
 ],
 "Available updates": [
  null,
  "Доступні оновлення"
 ],
 "Bug fix updates available": [
  null,
  "Доступні оновлення із виправленнями вад"
 ],
 "Bugs": [
  null,
  "Вади"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Cannot schedule event in the past": [
  null,
  "Не можна планувати подію на минуле"
 ],
 "Change": [
  null,
  "Змінити"
 ],
 "Change system time": [
  null,
  "Змінити системний час"
 ],
 "Check for updates": [
  null,
  "Перевірити наявність оновлень"
 ],
 "Checking for package updates...": [
  null,
  "Шукаємо оновлення пакунків…"
 ],
 "Checking installed software": [
  null,
  "Перевіряємо встановлене програмне забезпечення"
 ],
 "Checking software status": [
  null,
  "Перевіряємо стан програмного забезпечення"
 ],
 "Continue": [
  null,
  "Продовжити"
 ],
 "Danger alert:": [
  null,
  "Попередження про небезпеку:"
 ],
 "Delay": [
  null,
  "Затримка"
 ],
 "Details": [
  null,
  "Подробиці"
 ],
 "Disabled": [
  null,
  "Вимкнено"
 ],
 "Downloaded": [
  null,
  "Отримано"
 ],
 "Downloading": [
  null,
  "Отримуємо"
 ],
 "Downloading $0": [
  null,
  "Отримуємо $0"
 ],
 "Edit": [
  null,
  "Змінити"
 ],
 "Enable": [
  null,
  "Увімкнути"
 ],
 "Enabled": [
  null,
  "Увімкнено"
 ],
 "Enhancement updates available": [
  null,
  "Доступні оновлення із поліпшеннями"
 ],
 "Errata": [
  null,
  "Відомі помилки"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "Не вдалося обробити файли модулів для dnf-automatic.timer або dnf-automatic-install.timer. Будь ласка, вилучіть нетипові перевизначення, щоб налаштувати автоматичні оновлення."
 ],
 "Failed to restart service": [
  null,
  "Не вдалося перезапустити службу"
 ],
 "Fridays": [
  null,
  "П'ятниці"
 ],
 "History package count": [
  null,
  "Кількість пакунків у журналі"
 ],
 "Ignore": [
  null,
  "Ігнорувати"
 ],
 "Info": [
  null,
  "Інформація"
 ],
 "Initializing...": [
  null,
  "Ініціалізація…"
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Install all updates": [
  null,
  "Встановити усі оновлення"
 ],
 "Install kpatch updates": [
  null,
  "Встановити оновлення kpatch"
 ],
 "Install security updates": [
  null,
  "Встановити оновлення захисту"
 ],
 "Install software": [
  null,
  "Встановити програмне забезпечення"
 ],
 "Installed": [
  null,
  "Встановлено"
 ],
 "Installing": [
  null,
  "Встановлення"
 ],
 "Installing $0": [
  null,
  "Встановлюємо $0"
 ],
 "Invalid date format": [
  null,
  "Некоректний формат дати"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Некоректний формат дати і часу"
 ],
 "Invalid time format": [
  null,
  "Некоректний формат визначення часу"
 ],
 "Invalid timezone": [
  null,
  "Некоректний часовий пояс"
 ],
 "Kernel live patch $0 is active": [
  null,
  "Активною є інтерактивна латка до ядра $0"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "Встановлено інтерактивну латку до ядра $0"
 ],
 "Kernel live patch settings": [
  null,
  "Параметри інтерактивних латок до ядра"
 ],
 "Kernel live patching": [
  null,
  "Інтерактивне латання ядра"
 ],
 "Last checked: $0": [
  null,
  "Востаннє перевірено: $0"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "Loading available updates failed": [
  null,
  "Не вдалося завантажити список доступних оновлень"
 ],
 "Loading available updates, please wait...": [
  null,
  "Завантажуємо доступні оновлення, зачекайте…"
 ],
 "Log messages": [
  null,
  "Повідомлення журналу"
 ],
 "Managing software updates": [
  null,
  "Керування оновленням програм"
 ],
 "Manually": [
  null,
  "Вручну"
 ],
 "Message to logged in users": [
  null,
  "Повідомлення користувачам, які увійшли"
 ],
 "Mondays": [
  null,
  "Понеділки"
 ],
 "More info...": [
  null,
  "Докладніше…"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Need at least one NTP server": [
  null,
  "Потрібен принаймні один сервер NTP"
 ],
 "No delay": [
  null,
  "Без затримки"
 ],
 "No updates": [
  null,
  "Немає оновлень"
 ],
 "Not available": [
  null,
  "Недоступний"
 ],
 "Not installed": [
  null,
  "Не встановлено"
 ],
 "Not registered": [
  null,
  "Не зареєстровано"
 ],
 "Not set up": [
  null,
  "Не налаштовано"
 ],
 "Not synchronized": [
  null,
  "Не синхронізовано"
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "Package information": [
  null,
  "Дані щодо пакунка"
 ],
 "PackageKit crashed": [
  null,
  "Аварійне завершення роботи PackageKit"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit не встановлено"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit повідомлено про помилку із кодом $0"
 ],
 "Packages": [
  null,
  "Пакунки"
 ],
 "Pick date": [
  null,
  "Вибрати дату"
 ],
 "Please reload the page after resolving the issue.": [
  null,
  "Будь ласка, перезавантажте сторінку після усування проблеми."
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Reboot after completion": [
  null,
  "Перезавантажити після завершення"
 ],
 "Reboot recommended": [
  null,
  "Рекомендовано перезавантажити"
 ],
 "Reboot system...": [
  null,
  "Перезавантажити систему…"
 ],
 "Refreshing package information": [
  null,
  "Оновлюємо дані щодо пакунків"
 ],
 "Register…": [
  null,
  "Зареєструвати…"
 ],
 "Reloading the state of remaining services": [
  null,
  "Перезавантажуємо стан решти служб"
 ],
 "Removals:": [
  null,
  "Вилучення:"
 ],
 "Removing $0": [
  null,
  "Вилучаємо $0"
 ],
 "Restart services": [
  null,
  "Перезапустити служби"
 ],
 "Restart services...": [
  null,
  "Перезапустити служби…"
 ],
 "Restarting": [
  null,
  "Перезапускаємо"
 ],
 "Saturdays": [
  null,
  "Суботи"
 ],
 "Save": [
  null,
  "Зберегти"
 ],
 "Save changes": [
  null,
  "Зберегти зміни"
 ],
 "Security updates available": [
  null,
  "Доступні оновлення захисту"
 ],
 "Security updates only": [
  null,
  "Лише оновлення захисту"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "Оновлення безпеки буде застосовано $0 о $1"
 ],
 "Set time": [
  null,
  "Встановити час"
 ],
 "Set up": [
  null,
  "Налаштувати"
 ],
 "Setting up": [
  null,
  "Налаштовуємо"
 ],
 "Settings": [
  null,
  "Параметри"
 ],
 "Severity": [
  null,
  "Важливість"
 ],
 "Shut down": [
  null,
  "Вимкнути"
 ],
 "Software updates": [
  null,
  "Оновлення програм"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Програмою для керування пакунків користується якась інша програма, будь ласка, зачекайте…"
 ],
 "Some software needs to be restarted manually": [
  null,
  "Частину програмного забезпечення доведеться перезавантажити вручну"
 ],
 "Specific time": [
  null,
  "У визначений час"
 ],
 "Status": [
  null,
  "Стан"
 ],
 "Sundays": [
  null,
  "Неділі"
 ],
 "Synchronized": [
  null,
  "Синхронізовано"
 ],
 "Synchronized with $0": [
  null,
  "Синхронізовано із $0"
 ],
 "Synchronizing": [
  null,
  "Синхронізація"
 ],
 "System is up to date": [
  null,
  "Система не потребує оновлення"
 ],
 "The following service will be restarted:": [
  null,
  "Буде перезавантажено такі служби:",
  "Буде перезавантажено такі служби:",
  "Буде перезавантажено такі служби:"
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Цей вузол буде перезавантажено після встановлення оновлень."
 ],
 "This system is not registered": [
  null,
  "Цю систему не зареєстровано"
 ],
 "Thursdays": [
  null,
  "Четверги"
 ],
 "Time": [
  null,
  "Час"
 ],
 "Time zone": [
  null,
  "Часовий пояс"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Щоб отримувати оновлення програмного забезпечення, цю систему слід зареєструвати у Red Hat або за допомогою порталу клієнтів Red Hat, або за допомогою локального сервера передплати."
 ],
 "Toggle date picker": [
  null,
  "Перемкнути засіб вибору дати"
 ],
 "Total size: $0": [
  null,
  "Загальний розмір: $0"
 ],
 "Trying to synchronize with $0": [
  null,
  "Намагаємося синхронізуватися з $0"
 ],
 "Tuesdays": [
  null,
  "Вівторки"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Unavailable packages": [
  null,
  "Недоступні пакунки"
 ],
 "Update Success Table": [
  null,
  "Таблиця успіху оновлення"
 ],
 "Update history": [
  null,
  "Історія оновлень"
 ],
 "Update was successful": [
  null,
  "Успішне оновлення"
 ],
 "Updated": [
  null,
  "Оновлено"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Використання оновлених пакунків може потребувати перезапуску."
 ],
 "Updates available": [
  null,
  "Доступні оновлення"
 ],
 "Updates history": [
  null,
  "Журнал оновлень"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "Оновлення буде застосовано $0 о $1"
 ],
 "Updating": [
  null,
  "Оновлення"
 ],
 "Verified": [
  null,
  "Перевірено"
 ],
 "Verifying": [
  null,
  "Перевіряємо"
 ],
 "Version": [
  null,
  "Версія"
 ],
 "View update log": [
  null,
  "Переглянути журнал оновлення"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Очікуємо на завершення інших дій із програмним забезпеченням"
 ],
 "Web Console will restart": [
  null,
  "Вебконсоль буде перезапущено"
 ],
 "Wednesdays": [
  null,
  "Середи"
 ],
 "When": [
  null,
  "Якщо"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Після перезапуску вебконсолі ви не зможете більше бачити даних щодо поступу. Втім, процес оновлення триватиме у фоновому режимі. Встановіть з'єднання повторно, щоб продовжити спостереження за процесом оновлення."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Невдовзі ваш сервер розірве з’єднання. Ви можете відновити це з’єднання, щойно сервер буде перезапущено."
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "at": [
  null,
  "на"
 ],
 "bug fix": [
  null,
  "виправлення вад"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "enhancement": [
  null,
  "поліпшення"
 ],
 "every Friday": [
  null,
  "кожної п'ятниці"
 ],
 "every Monday": [
  null,
  "кожного понеділка"
 ],
 "every Saturday": [
  null,
  "кожної суботи"
 ],
 "every Sunday": [
  null,
  "кожної неділі"
 ],
 "every Thursday": [
  null,
  "кожного четверга"
 ],
 "every Tuesday": [
  null,
  "кожного вівторка"
 ],
 "every Wednesday": [
  null,
  "кожної середи"
 ],
 "every day": [
  null,
  "кожного дня"
 ],
 "for current and future kernels": [
  null,
  "для поточного і майбутніх ядер"
 ],
 "for current kernel only": [
  null,
  "лише для поточного ядра"
 ],
 "package": [
  null,
  "пакунок"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "patches": [
  null,
  "латки"
 ],
 "security": [
  null,
  "безпека"
 ],
 "show less": [
  null,
  "показати менше"
 ],
 "show more": [
  null,
  "показати більше"
 ],
 "yum": [
  null,
  "yum"
 ]
});
