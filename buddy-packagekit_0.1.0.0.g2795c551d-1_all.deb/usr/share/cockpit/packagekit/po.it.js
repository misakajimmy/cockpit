cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "$0 is not available from any repository.": [
  null,
  "$0 non è disponibile in nessun archivio web."
 ],
 "$0 package": [
  null,
  "$0 pacchetto",
  "$0 pacchetti"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 pacchetto richiede un riavvio di sistema",
  "$0 pacchetti richiedono un riavvio di sistema"
 ],
 "$0 security fix available": [
  null,
  "Aggiornamento di sicurezza disponibile",
  "Aggiornamenti di sicurezza disponibili"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 servizio deve essere riavviato",
  "$0 servizi devono essere riavviati"
 ],
 "$0 update available": [
  null,
  "$0 aggiornamento disponibile",
  "$0 aggiornamenti disponibili"
 ],
 "$0 will be installed.": [
  null,
  "$0 sarà installato."
 ],
 ", including $1 security fix": [
  null,
  ", compresa $1 correzione di sicurezza",
  ", comprese $1 correzioni di sicurezza"
 ],
 "1 minute": [
  null,
  "1 minuto"
 ],
 "20 minutes": [
  null,
  "20 minuti"
 ],
 "40 minutes": [
  null,
  "40 minuti"
 ],
 "5 minutes": [
  null,
  "5 minuti"
 ],
 "60 minutes": [
  null,
  "60 minuti"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Un pacchetto richiede un riavvio di sistema perché gli aggiornamenti prendano effetto:",
  "Alcuni pacchietti richiedono un riavvio di sistema perché gli aggiornamenti prendano effetto:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Un servizio deve essere riavviato perché gli aggiornamenti prendano effetto:",
  "Alcuni servizi devono essere riavviati perché gli aggiornamenti prendano effetto:"
 ],
 "Additional packages:": [
  null,
  "Pacchetti aggiuntivi:"
 ],
 "All updates": [
  null,
  "Tutti gli aggiornamenti"
 ],
 "Apply kernel live patches": [
  null,
  "Applicare le patch live del kernel"
 ],
 "Applying updates": [
  null,
  "Sto installando gli aggiornamenti"
 ],
 "Applying updates failed": [
  null,
  "Impossibile installare gli aggiornamenti"
 ],
 "Automatic updates": [
  null,
  "Aggiornamenti automatici"
 ],
 "Automatically using NTP": [
  null,
  "Automaticamente utilizzando NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automaticamente utilizzando server NTP specifici"
 ],
 "Available updates": [
  null,
  "Aggiornamenti disponibili"
 ],
 "Bug fix updates available": [
  null,
  "Aggiornamenti per bug fix disponibili"
 ],
 "Bugs": [
  null,
  "Bug"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Cannot schedule event in the past": [
  null,
  "Non è possibile programmare eventi del passato"
 ],
 "Change": [
  null,
  "Cambia"
 ],
 "Change system time": [
  null,
  "Modifica dell'ora di sistema"
 ],
 "Check for updates": [
  null,
  "Controlla gli aggiornamenti"
 ],
 "Checking for package updates...": [
  null,
  "Verifica aggiornamento pacchetti..."
 ],
 "Checking installed software": [
  null,
  "Verifica del software installato"
 ],
 "Checking software status": [
  null,
  "Controllo stato software"
 ],
 "Continue": [
  null,
  "Continua"
 ],
 "Danger alert:": [
  null,
  "Avviso di pericolo:"
 ],
 "Delay": [
  null,
  "Ritardo"
 ],
 "Details": [
  null,
  "Dettagli"
 ],
 "Disabled": [
  null,
  "Disabilitato"
 ],
 "Downloaded": [
  null,
  "Scaricato"
 ],
 "Downloading": [
  null,
  "Download in corso"
 ],
 "Downloading $0": [
  null,
  "Download di $0"
 ],
 "Edit": [
  null,
  "Modifica"
 ],
 "Enable": [
  null,
  "Abilita"
 ],
 "Enabled": [
  null,
  "Attivato"
 ],
 "Enhancement updates available": [
  null,
  "Aggiornamenti disponibili"
 ],
 "Errata": [
  null,
  "Errata"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "Impossibile analizzare i file dell'unità per dnf-automatic.timer o dnf-automatic-install.timer. Rimuovi le impostazioni personalizzate per configurare gli aggiornamenti automatici."
 ],
 "Failed to restart service": [
  null,
  "Impossibile riavviare il servizio"
 ],
 "Fridays": [
  null,
  "Venerdì"
 ],
 "History package count": [
  null,
  "Conteggio pacchetti cronologia"
 ],
 "Ignore": [
  null,
  "Ignora"
 ],
 "Info": [
  null,
  "Info"
 ],
 "Initializing...": [
  null,
  "Inizializzazione..."
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Install all updates": [
  null,
  "Installa tutti gli aggiornamenti"
 ],
 "Install kpatch updates": [
  null,
  "Installa gli aggiornamenti kpatch"
 ],
 "Install security updates": [
  null,
  "Installa gli aggiornamenti di sicurezza"
 ],
 "Install software": [
  null,
  "Installa il software"
 ],
 "Installed": [
  null,
  "Installato"
 ],
 "Installing": [
  null,
  "Installazione in corso"
 ],
 "Installing $0": [
  null,
  "Installazione di $0"
 ],
 "Invalid date format": [
  null,
  "Formato data non valido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato data non valido e formato ora non valido"
 ],
 "Invalid time format": [
  null,
  "Formato ora non valido"
 ],
 "Invalid timezone": [
  null,
  "Fuso orario non valido"
 ],
 "Kernel live patch $0 is active": [
  null,
  "La patch live Kernel $0 è attiva"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "La patch live Kernel $0 è installata"
 ],
 "Kernel live patch settings": [
  null,
  "Impostazioni della patch live del kernel"
 ],
 "Kernel live patching": [
  null,
  "Patch live del kernel"
 ],
 "Last checked: $0": [
  null,
  "Ultimo controllo: $0"
 ],
 "Learn more": [
  null,
  "Per saperne di più"
 ],
 "Loading available updates failed": [
  null,
  "Caricamento degli aggiornamenti disponibili non riuscito"
 ],
 "Loading available updates, please wait...": [
  null,
  "Caricamento degli aggiornamenti disponibili, attendere....."
 ],
 "Log messages": [
  null,
  "Messaggi di log"
 ],
 "Managing software updates": [
  null,
  "Gestione degli aggiornamenti software"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Message to logged in users": [
  null,
  "Messaggio agli utenti autenticati"
 ],
 "Mondays": [
  null,
  "Lunedì"
 ],
 "More info...": [
  null,
  "Più informazioni..."
 ],
 "NTP server": [
  null,
  "Server NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Need at least one NTP server": [
  null,
  "E' necessario almeno un server NTP"
 ],
 "No delay": [
  null,
  "Nessun ritardo"
 ],
 "No updates": [
  null,
  "Nessun aggiornamento"
 ],
 "Not available": [
  null,
  "Non disponibile"
 ],
 "Not registered": [
  null,
  "Non Registrato"
 ],
 "Not synchronized": [
  null,
  "Non sincronizzato"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Package information": [
  null,
  "Informazioni sul pacchetto"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit si è interrotto"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit non è installato"
 ],
 "PackageKit reported error code $0": [
  null,
  "Codice di errore segnalato da PackageKit $0"
 ],
 "Packages": [
  null,
  "Pacchetti"
 ],
 "Pick date": [
  null,
  "Scegli una data"
 ],
 "Please reload the page after resolving the issue.": [
  null,
  "Per favore ricarica la pagina dopo aver risolto il problema."
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Reboot recommended": [
  null,
  "Riavvio consigliato"
 ],
 "Reboot system...": [
  null,
  "Riavvio del sistema..."
 ],
 "Refreshing package information": [
  null,
  "Aggiorno le informazioni sul pacchetto"
 ],
 "Register…": [
  null,
  "Registrati…"
 ],
 "Reloading the state of remaining services": [
  null,
  "Ricaricare lo stato dei servizi rimanenti"
 ],
 "Removals:": [
  null,
  "Rimozioni:"
 ],
 "Removing $0": [
  null,
  "Rimozione $0"
 ],
 "Restarting": [
  null,
  "Riavvio"
 ],
 "Saturdays": [
  null,
  "Sabati"
 ],
 "Save": [
  null,
  "Salva"
 ],
 "Save changes": [
  null,
  "Salva modifiche"
 ],
 "Security updates available": [
  null,
  "Aggiornamenti di sicurezza disponibili"
 ],
 "Security updates only": [
  null,
  "Solo aggiornamenti di sicurezza"
 ],
 "Set time": [
  null,
  "Imposta tempo"
 ],
 "Set up": [
  null,
  "Configura"
 ],
 "Setting up": [
  null,
  "Impostazione"
 ],
 "Severity": [
  null,
  "Severità"
 ],
 "Shut down": [
  null,
  "Arresto"
 ],
 "Software updates": [
  null,
  "Aggiornamenti software"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Qualche altro programma sta attualmente utilizzando il gestore di pacchetti, si prega di attendere..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "Alcuni software devono essere riavviati manualmente"
 ],
 "Specific time": [
  null,
  "Tempo specifico"
 ],
 "Status": [
  null,
  "Stato"
 ],
 "Sundays": [
  null,
  "Domeniche"
 ],
 "Synchronized": [
  null,
  "Sincronizzato"
 ],
 "Synchronized with $0": [
  null,
  "Sincronizzato con $0"
 ],
 "Synchronizing": [
  null,
  "Sincronizzazione"
 ],
 "System is up to date": [
  null,
  "Il sistema è aggiornato"
 ],
 "The following service will be restarted:": [
  null,
  "Verrà riavviato il seguente servizio:",
  "Verranno riavviati i seguenti servizi:"
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Questo host verrà riavviato quando gli aggiornamenti saranno installati."
 ],
 "This system is not registered": [
  null,
  "Questo sistema non è registrato"
 ],
 "Thursdays": [
  null,
  "Giovedì"
 ],
 "Time": [
  null,
  "Ora"
 ],
 "Time zone": [
  null,
  "Fuso Orario"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Per ottenere gli aggiornamenti software, questo sistema deve essere registrato con Red Hat, utilizzando il portale clienti Red Hat o un server locale in abbonamento."
 ],
 "Toggle date picker": [
  null,
  "Attiva/disattiva la selezione della data"
 ],
 "Total size: $0": [
  null,
  "Dimensione totale: $0"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentativo di sincronizzazione con $0"
 ],
 "Tuesdays": [
  null,
  "Martedì"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Update history": [
  null,
  "Cronologia degli aggiornamenti"
 ],
 "Updated": [
  null,
  "Aggiornato"
 ],
 "Updates available": [
  null,
  "Aggiornamenti disponibili"
 ],
 "Updates history": [
  null,
  "Cronologia degli aggiornamenti"
 ],
 "Updating": [
  null,
  "Aggiornamento"
 ],
 "Verified": [
  null,
  "Verificato"
 ],
 "Verifying": [
  null,
  "Verifica"
 ],
 "Version": [
  null,
  "Versione"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "In attesa che finiscano le altre operazioni di gestione del software"
 ],
 "Wednesdays": [
  null,
  "Mercoledì"
 ],
 "When": [
  null,
  "Quando"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Quando la console Web viene riavviata, non vedrai più le informazioni sullo stato di avanzamento. Tuttavia, il processo di aggiornamento continuerà in background. Riconnettiti per continuare a monitorare il processo di aggiornamento."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Il server chiuderà presto la connessione. È possibile riconnettersi dopo che è stato riavviato."
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "at": [
  null,
  "a"
 ],
 "bug fix": [
  null,
  "bug fix"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "enhancement": [
  null,
  "miglioramento"
 ],
 "every day": [
  null,
  "quotidianamente"
 ],
 "for current and future kernels": [
  null,
  "per kernel attuali e futuri"
 ],
 "package": [
  null,
  "pacchetto"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "patches": [
  null,
  "patch"
 ],
 "security": [
  null,
  "sicurezza"
 ],
 "show less": [
  null,
  "mostra meno"
 ],
 "show more": [
  null,
  "mostra di più"
 ],
 "yum": [
  null,
  "yum"
 ]
});
