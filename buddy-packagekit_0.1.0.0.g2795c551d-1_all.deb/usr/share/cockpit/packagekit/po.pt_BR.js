cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "$0 is not available from any repository.": [
  null,
  "$0 não está disponível em nenhum repositório."
 ],
 "$0 package": [
  null,
  "$0 pacote",
  "$0 pacotes"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 pacote precisa de uma reinicialização do sistema",
  "$0 pacotes precisam de uma reinicialização do sistema"
 ],
 "$0 security fix available": [
  null,
  "$0 correção de segurança disponível",
  "$0 correções de segurança disponíveis"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 serviço precisa ser reiniciado",
  "$0 serviços precisam ser reiniciados"
 ],
 "$0 update available": [
  null,
  "$0 atualização disponível",
  "$0 atualizações disponíveis"
 ],
 "$0 will be installed.": [
  null,
  "$0 será instalado."
 ],
 ", including $1 security fix": [
  null,
  ", incluindo $1 correção de segurança",
  ", incluindo $1 correções de segurança"
 ],
 "1 minute": [
  null,
  "1 Minuto"
 ],
 "20 minutes": [
  null,
  "20 Minutos"
 ],
 "40 minutes": [
  null,
  "40 Minutos"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "60 minutes": [
  null,
  "60 Minutos"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Um pacote precisa de uma reinicialização do sistema para que as atualizações tenham efeito:",
  "Alguns pacotes precisam de uma reinicialização do sistema para que as atualizações tenham efeito:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Um serviço precisa ser reiniciado para que as atualizações tenham efeito:",
  "Alguns serviços precisam ser reiniciados para que as atualizações tenham efeito:"
 ],
 "Additional packages:": [
  null,
  "Pacotes adicionais:"
 ],
 "All updates": [
  null,
  "Todas as atualizações"
 ],
 "Applying updates": [
  null,
  "Aplicando atualizações"
 ],
 "Applying updates failed": [
  null,
  "A aplicação de atualizações falhou"
 ],
 "Automatic updates": [
  null,
  "Atualizações automáticas"
 ],
 "Automatically using NTP": [
  null,
  "Usando automaticamente o NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Usando automaticamente servidores NTP específicos"
 ],
 "Available updates": [
  null,
  "Atualizações Disponíveis"
 ],
 "Bug fix updates available": [
  null,
  "Atualizações de correção de bug disponíveis"
 ],
 "Bugs": [
  null,
  "Bugs"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Cannot schedule event in the past": [
  null,
  "Não é possível agendar eventos no passado"
 ],
 "Change": [
  null,
  "Alterar"
 ],
 "Change system time": [
  null,
  "Alterar Horário do Sistema"
 ],
 "Check for updates": [
  null,
  "Verificar Atualizações"
 ],
 "Checking for package updates...": [
  null,
  "Verificando atualizações de pacote..."
 ],
 "Checking installed software": [
  null,
  "Verificando o software instalado"
 ],
 "Continue": [
  null,
  "Continuar"
 ],
 "Danger alert:": [
  null,
  ""
 ],
 "Delay": [
  null,
  "Atraso"
 ],
 "Details": [
  null,
  "Detalhes"
 ],
 "Disabled": [
  null,
  "Desabilitado"
 ],
 "Downloaded": [
  null,
  "Baixado"
 ],
 "Downloading": [
  null,
  "Baixando"
 ],
 "Downloading $0": [
  null,
  "Baixando $0"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Enable": [
  null,
  "Habilitar"
 ],
 "Enabled": [
  null,
  "Habilitado"
 ],
 "Enhancement updates available": [
  null,
  "Atualizações de aprimoramento disponíveis"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  ""
 ],
 "Fridays": [
  null,
  "Sextas"
 ],
 "Ignore": [
  null,
  "Ignorar"
 ],
 "Info": [
  null,
  "Info"
 ],
 "Initializing...": [
  null,
  "Inicializando ..."
 ],
 "Install": [
  null,
  "Instale"
 ],
 "Install all updates": [
  null,
  "Instalar todas as atualizações"
 ],
 "Install security updates": [
  null,
  "Instalar atualizações de segurança"
 ],
 "Install software": [
  null,
  "Instale Software"
 ],
 "Installed": [
  null,
  "Instalado"
 ],
 "Installing": [
  null,
  "Instalando"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Invalid date format": [
  null,
  "Formato de data inválido"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Formato de data inválido e formato de tempo inválido"
 ],
 "Invalid time format": [
  null,
  "Formato de tempo inválido"
 ],
 "Invalid timezone": [
  null,
  "Fuso horário inválido"
 ],
 "Last checked: $0": [
  null,
  "Última verificação: $0"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "Loading available updates failed": [
  null,
  "Falha ao carregar atualizações disponíveis"
 ],
 "Loading available updates, please wait...": [
  null,
  "Carregando as atualizações disponíveis, por favor aguarde ..."
 ],
 "Log messages": [
  null,
  "Mensagens de Log"
 ],
 "Manually": [
  null,
  "Manualmente"
 ],
 "Message to logged in users": [
  null,
  "Mensagem para usuários logados"
 ],
 "Mondays": [
  null,
  "Segundas"
 ],
 "More info...": [
  null,
  "Mais info..."
 ],
 "NTP server": [
  null,
  "Servidor NTP"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Need at least one NTP server": [
  null,
  "Precisa de pelo menos um servidor NTP"
 ],
 "No delay": [
  null,
  "Sem Atraso"
 ],
 "No updates": [
  null,
  "Sem atualizações"
 ],
 "Not available": [
  null,
  "Indisponível"
 ],
 "Not installed": [
  null,
  "Não instalado"
 ],
 "Not registered": [
  null,
  "Não registrado"
 ],
 "Not synchronized": [
  null,
  "Não sincronizado"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Package information": [
  null,
  "Informações do pacote"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit caiu"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit não está instalado"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit reportou código de erro $0"
 ],
 "Packages": [
  null,
  "Pacotes"
 ],
 "Pick date": [
  null,
  ""
 ],
 "Please reload the page after resolving the issue.": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Reboot recommended": [
  null,
  "Recomenda-se reiniciar"
 ],
 "Reboot system...": [
  null,
  ""
 ],
 "Refreshing package information": [
  null,
  "Atualizando informações do pacote"
 ],
 "Register…": [
  null,
  "Registro…"
 ],
 "Reloading the state of remaining services": [
  null,
  ""
 ],
 "Removals:": [
  null,
  "Remoções:"
 ],
 "Removing $0": [
  null,
  "Removendo $0"
 ],
 "Restarting": [
  null,
  "Reiniciando"
 ],
 "Saturdays": [
  null,
  "Sábados"
 ],
 "Save": [
  null,
  "Salvar"
 ],
 "Save changes": [
  null,
  "Salvar Mudanças"
 ],
 "Security updates available": [
  null,
  "Atualizações de segurança disponíveis"
 ],
 "Set time": [
  null,
  "Definir Tempo"
 ],
 "Set up": [
  null,
  "Configuração"
 ],
 "Setting up": [
  null,
  "Configurando"
 ],
 "Settings": [
  null,
  "Configurações"
 ],
 "Severity": [
  null,
  "Gravidade"
 ],
 "Shut down": [
  null,
  "Encerrar"
 ],
 "Software updates": [
  null,
  "Atualizações de Software"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Algum outro programa está atualmente usando o gerenciador de pacotes, por favor aguarde ..."
 ],
 "Some software needs to be restarted manually": [
  null,
  ""
 ],
 "Specific time": [
  null,
  "Tempo Específico"
 ],
 "Status": [
  null,
  "Estado"
 ],
 "Sundays": [
  null,
  "Domingos"
 ],
 "Synchronized": [
  null,
  "Sincronizado"
 ],
 "Synchronizing": [
  null,
  "Sincronizando"
 ],
 "System is up to date": [
  null,
  "O sistema está atualizado"
 ],
 "The following service will be restarted:": [
  null,
  "O seguinte serviço será reiniciado:",
  "Os seguintes serviços serão reiniciados:"
 ],
 "This host will reboot after updates are installed.": [
  null,
  ""
 ],
 "This system is not registered": [
  null,
  "Este sistema não está registrado"
 ],
 "Thursdays": [
  null,
  "Quintas"
 ],
 "Time": [
  null,
  "Tempo"
 ],
 "Time zone": [
  null,
  "Fuso Horário"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Para obter atualizações de software, este sistema precisa ser registrado na Red Hat, usando o Portal do Cliente Red Hat ou um servidor de assinatura local."
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Total size: $0": [
  null,
  "Tamanho total: $0"
 ],
 "Trying to synchronize with $0": [
  null,
  "Tentando sincronizar com $0"
 ],
 "Tuesdays": [
  null,
  "Terças"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Update history": [
  null,
  "Atualizar histórico"
 ],
 "Update was successful": [
  null,
  "A atualização foi bem sucedida"
 ],
 "Updated": [
  null,
  "Atualizado"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Os pacotes atualizados podem exigir uma reinicialização para ter efeito."
 ],
 "Updates available": [
  null,
  "Atualizações disponíveis"
 ],
 "Updates history": [
  null,
  "Histórico de atualizações"
 ],
 "Updates will be applied $0 at $1": [
  null,
  ""
 ],
 "Updating": [
  null,
  "Atualizando"
 ],
 "Verified": [
  null,
  "Verificado"
 ],
 "Verifying": [
  null,
  "Verificando"
 ],
 "Version": [
  null,
  "Versão"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Aguardando que outras operações de gerenciamento de software terminem"
 ],
 "Wednesdays": [
  null,
  "Quartas"
 ],
 "When": [
  null,
  "Quando"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  ""
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Seu servidor fechará a conexão em breve. Você pode reconectar depois de ter reiniciado."
 ],
 "apt-get": [
  null,
  ""
 ],
 "at": [
  null,
  "no"
 ],
 "bug fix": [
  null,
  "correção de bug"
 ],
 "dnf": [
  null,
  ""
 ],
 "enhancement": [
  null,
  "Aprimoramento"
 ],
 "every day": [
  null,
  "todo dia"
 ],
 "for current and future kernels": [
  null,
  ""
 ],
 "package": [
  null,
  "pacote"
 ],
 "packagekit": [
  null,
  ""
 ],
 "patches": [
  null,
  ""
 ],
 "security": [
  null,
  "segurança"
 ],
 "show less": [
  null,
  "mostrar menos"
 ],
 "show more": [
  null,
  "mostrar mais"
 ],
 "yum": [
  null,
  "yum"
 ]
});
