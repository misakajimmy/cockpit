cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 is not available from any repository.": [
  null,
  "$0 není k dispozici z žádného z repozitářů."
 ],
 "$0 package": [
  null,
  "$0 balíček",
  "$0 balíčky",
  "$0 balíčků"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 balíček vyžaduje restart systému",
  "$0 balíčky vyžadují restart systému",
  "$0 balíčků vyžaduje restart systému"
 ],
 "$0 security fix available": [
  null,
  "Je k dispozici $0 oprava zabezpečení",
  "Jsou k dispozici $0 opravy zabezpečení",
  "Je k dispozici $0 oprav zabezpečení"
 ],
 "$0 service needs to be restarted": [
  null,
  "Je třeba zrestartovat $0 službu",
  "Je třeba zrestartovat $0 služby",
  "Je třeba zrestartovat $0 služeb"
 ],
 "$0 update available": [
  null,
  "Je k dispozici $0 aktualizace",
  "Jsou k dispozici $0 aktualizace",
  "Je k dispozici $0 aktualizací"
 ],
 "$0 will be installed.": [
  null,
  "$0 bude nainstalováno."
 ],
 ", including $1 security fix": [
  null,
  ", včetně $1 opravy zabezpečení",
  ", včetně $1 oprav zabezpečení",
  ", včetně $1 oprav zabezpečení"
 ],
 "1 minute": [
  null,
  "1 minuta"
 ],
 "20 minutes": [
  null,
  "20 minut"
 ],
 "40 minutes": [
  null,
  "40 minut"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "60 minutes": [
  null,
  "60 minut"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Aby se uplatnil, aktualizovaný balíček potřebuje restart systému:",
  "Aby se uplatnily, aktualizované balíčky potřebují restart systému:",
  "Aby se uplatnily, aktualizované balíčky potřebují restart systému:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Aby se aktualizace uplatnily, je třeba restartovat službu:",
  "Aby se aktualizace uplatnily, je třeba restartovat některé služby:",
  "Aby se aktualizace uplatnily, je třeba restartovat některé služby:"
 ],
 "Additional packages:": [
  null,
  "Další balíčky:"
 ],
 "All updates": [
  null,
  "Všechny aktualizace"
 ],
 "Apply kernel live patches": [
  null,
  "Aplikovat záplaty pro jádro systému za chodu"
 ],
 "Applying updates": [
  null,
  "Aplikují se aktualizace"
 ],
 "Applying updates failed": [
  null,
  "Aplikace aktualizací se nezdařila"
 ],
 "Automatic updates": [
  null,
  "Automatické aktualizace"
 ],
 "Automatically using NTP": [
  null,
  "Automatické použití NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Automatické použití uvedených NTP serverů"
 ],
 "Available updates": [
  null,
  "Dostupné aktualizace"
 ],
 "Bug fix updates available": [
  null,
  "Jsou k dispozici aktualizace opravující zabezpečení"
 ],
 "Bugs": [
  null,
  "Chyby"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Cannot schedule event in the past": [
  null,
  "Nelze naplánovat událost v minulosti"
 ],
 "Change": [
  null,
  "Změnit"
 ],
 "Change system time": [
  null,
  "Změnit systémový čas"
 ],
 "Check for updates": [
  null,
  "Zkontrolovat aktualizace"
 ],
 "Checking for package updates...": [
  null,
  "Zjišťování aktualizací balíčků…"
 ],
 "Checking installed software": [
  null,
  "Zjišťuje se nainstalovaný sofware"
 ],
 "Checking software status": [
  null,
  "Kontroluje se stav software"
 ],
 "Continue": [
  null,
  "Pokračovat"
 ],
 "Danger alert:": [
  null,
  "Výstraha na nebezpečí:"
 ],
 "Delay": [
  null,
  "Prodleva"
 ],
 "Details": [
  null,
  "Podrobnosti"
 ],
 "Disabled": [
  null,
  "Vypnuto"
 ],
 "Downloaded": [
  null,
  "Staženo"
 ],
 "Downloading": [
  null,
  "Stahuje se"
 ],
 "Downloading $0": [
  null,
  "Stahuje se $0"
 ],
 "Edit": [
  null,
  "Upravit"
 ],
 "Enable": [
  null,
  "Povolit"
 ],
 "Enabled": [
  null,
  "Povoleno"
 ],
 "Enhancement updates available": [
  null,
  "Jsou k dispozici vylepšující aktualizace"
 ],
 "Errata": [
  null,
  "Errata"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "Nepodařilo se zpracovat jednotkové soubory pro dnf-automatic.timer nebo dnf-automatic-install.timer. Pokud chcete nastavit automatické aktualizace, odeberte uživatelsky určená přepsání."
 ],
 "Failed to restart service": [
  null,
  "Službu se nepodařilo restartovat"
 ],
 "Fridays": [
  null,
  "Pátky"
 ],
 "History package count": [
  null,
  "Počet historie balíčku"
 ],
 "Ignore": [
  null,
  "Ignorovat"
 ],
 "Info": [
  null,
  "Informace"
 ],
 "Initializing...": [
  null,
  "Inicializace…"
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Install all updates": [
  null,
  "Nainstalovat všechny aktualizace"
 ],
 "Install security updates": [
  null,
  "Nainstalovat aktualizace zabezpečení"
 ],
 "Install software": [
  null,
  "Nainstalovat software"
 ],
 "Installed": [
  null,
  "Nainstalováno"
 ],
 "Installing": [
  null,
  "Instaluje se"
 ],
 "Installing $0": [
  null,
  "Instaluje se $0"
 ],
 "Invalid date format": [
  null,
  "Neplatný formát data"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Neplatný formát data a času"
 ],
 "Invalid time format": [
  null,
  "Neplatný formát času"
 ],
 "Invalid timezone": [
  null,
  "Neplatné časové pásmo"
 ],
 "Last checked: $0": [
  null,
  "Naposledy zkontrolováno: $0"
 ],
 "Learn more": [
  null,
  "Další informace naleznete"
 ],
 "Loading available updates failed": [
  null,
  "Načtení dostupných aktualizací se nezdařilo"
 ],
 "Loading available updates, please wait...": [
  null,
  "Načítání dostupných aktualizací, čekejte…"
 ],
 "Log messages": [
  null,
  "Zprávy záznamu událostí"
 ],
 "Managing software updates": [
  null,
  "Správa aktualizací software"
 ],
 "Manually": [
  null,
  "Ručně"
 ],
 "Message to logged in users": [
  null,
  "Zpráva přihlášeným uživatelům"
 ],
 "Mondays": [
  null,
  "Pondělky"
 ],
 "More info...": [
  null,
  "Více informací…"
 ],
 "NTP server": [
  null,
  "NTP server"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Need at least one NTP server": [
  null,
  "Je třeba alespoň jeden NTP server"
 ],
 "No delay": [
  null,
  "Bez prodlevy"
 ],
 "No updates": [
  null,
  "Žádné aktualizace"
 ],
 "Not available": [
  null,
  "Není k dispozici"
 ],
 "Not installed": [
  null,
  "Nenainstalováno"
 ],
 "Not registered": [
  null,
  "Nezaregistrováno"
 ],
 "Not set up": [
  null,
  "Nenastaveno"
 ],
 "Not synchronized": [
  null,
  "Nesynchronizováno"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Package information": [
  null,
  "Informace o balíčku"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit zhavaroval"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit není nainstalovaný"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit ohlásilo chybový kód $0"
 ],
 "Packages": [
  null,
  "Balíčky"
 ],
 "Pick date": [
  null,
  "Vyberte datum"
 ],
 "Please reload the page after resolving the issue.": [
  null,
  "Po vyřešení problému stránku načtěte znovu."
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Reboot recommended": [
  null,
  "Doporučen restart"
 ],
 "Reboot system...": [
  null,
  "Restartovat systém…"
 ],
 "Refreshing package information": [
  null,
  "Obnovují se informace o balíčcích"
 ],
 "Register…": [
  null,
  "Zaregistrovat…"
 ],
 "Reloading the state of remaining services": [
  null,
  "Znovunačítání stavu zbývajících služeb"
 ],
 "Removals:": [
  null,
  "Odebrání:"
 ],
 "Removing $0": [
  null,
  "Odebírá se $0"
 ],
 "Restart services": [
  null,
  "Restartovat služby"
 ],
 "Restart services...": [
  null,
  "Restartovat služby…"
 ],
 "Restarting": [
  null,
  "Restartuje se"
 ],
 "Saturdays": [
  null,
  "Soboty"
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "Save changes": [
  null,
  "Uložit změny"
 ],
 "Security updates available": [
  null,
  "Jsou k dispozici aktualizace zabezpečení"
 ],
 "Security updates only": [
  null,
  "Pouze aktualizace zabezpečení"
 ],
 "Set time": [
  null,
  "Nastavit čas"
 ],
 "Set up": [
  null,
  "Nastavit"
 ],
 "Setting up": [
  null,
  "Nastavování"
 ],
 "Settings": [
  null,
  "Nastavení"
 ],
 "Severity": [
  null,
  "Závažnost"
 ],
 "Shut down": [
  null,
  "Vypnout"
 ],
 "Software updates": [
  null,
  "Aktualizace software"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Správa balíčků je v tuto chvíli používána nějakým jiným programem, vyčkejte…"
 ],
 "Some software needs to be restarted manually": [
  null,
  "Některý software je třeba restartovat ručně"
 ],
 "Specific time": [
  null,
  "Konkrétní čas"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Sundays": [
  null,
  "Neděle"
 ],
 "Synchronized": [
  null,
  "Synchronizováno"
 ],
 "Synchronized with $0": [
  null,
  "Synchronizováno s $0"
 ],
 "Synchronizing": [
  null,
  "Synchronizuje se"
 ],
 "System is up to date": [
  null,
  "Systém je aktuální"
 ],
 "The following service will be restarted:": [
  null,
  "Je třeba restartovat následující službu:",
  "Je třeba restartovat následující služby:",
  "Je třeba restartovat následující služby:"
 ],
 "This host will reboot after updates are installed.": [
  null,
  "Tento hostitel se po instalaci aktualizací restartuje."
 ],
 "This system is not registered": [
  null,
  "Tento systém není zaregistrován"
 ],
 "Thursdays": [
  null,
  "Čtvrtky"
 ],
 "Time": [
  null,
  "Čas"
 ],
 "Time zone": [
  null,
  "Časová zóna"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Pro získávání aktualizací software je třeba systém zaregistrovat u Red Hat, buď pomocí Red Hat portálu pro zákazníky nebo místního serveru předplatného."
 ],
 "Toggle date picker": [
  null,
  "Přepnout volič datumů"
 ],
 "Total size: $0": [
  null,
  "Celková velikost: $0"
 ],
 "Trying to synchronize with $0": [
  null,
  "Pokus o synchronizaci se $0"
 ],
 "Tuesdays": [
  null,
  "Úterky"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Update Success Table": [
  null,
  "Tabulka úspěchů aktualizací"
 ],
 "Update history": [
  null,
  "Historie aktualizací"
 ],
 "Update was successful": [
  null,
  "Aktualizace byla úspěšná"
 ],
 "Updated": [
  null,
  "Aktualizováno"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "Aby se uplatnily, aktualizovaný balíček může vyžadovat restart."
 ],
 "Updates available": [
  null,
  "Jsou k dispozici aktualizace"
 ],
 "Updates history": [
  null,
  "Historie aktualizací"
 ],
 "Updating": [
  null,
  "Aktualizuje se"
 ],
 "Verified": [
  null,
  "Ověřeno"
 ],
 "Verifying": [
  null,
  "Ověřuje se"
 ],
 "Version": [
  null,
  "Verze"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Čeká se na dokončení ostatních operací správy balíčků"
 ],
 "Web Console will restart": [
  null,
  "Webová konzole se restartuje"
 ],
 "Wednesdays": [
  null,
  "Středy"
 ],
 "When": [
  null,
  "Když"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "Když je webová konzole restartována, už neuvidíte informaci o průběhu. Nicméně aktualizační proces bude pokračovat na pozadí. Pokud chcete sledovat proces aktualizace, znovu se připojte."
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Server brzy zavře spojení. Po dokončení jeho restartu se budete moci opět připojit."
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "at": [
  null,
  "v"
 ],
 "bug fix": [
  null,
  "oprava chyby"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "enhancement": [
  null,
  "vylepšení"
 ],
 "every Friday": [
  null,
  "každý pátek"
 ],
 "every Monday": [
  null,
  "každé pondělí"
 ],
 "every Saturday": [
  null,
  "každý úterý"
 ],
 "every Sunday": [
  null,
  "každou neděli"
 ],
 "every Thursday": [
  null,
  "každý čtvrtek"
 ],
 "every Tuesday": [
  null,
  "každé úterý"
 ],
 "every Wednesday": [
  null,
  "každou středu"
 ],
 "every day": [
  null,
  "každý den"
 ],
 "for current and future kernels": [
  null,
  "pro stávající a budoucí jádra systému"
 ],
 "for current kernel only": [
  null,
  "pouze pro stávající jádro systému"
 ],
 "package": [
  null,
  "balíček"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "patches": [
  null,
  "záplaty"
 ],
 "security": [
  null,
  "zabezpečení"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "yum": [
  null,
  "yum"
 ]
});
