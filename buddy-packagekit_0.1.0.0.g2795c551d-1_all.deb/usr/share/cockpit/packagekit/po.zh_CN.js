cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "$0 is not available from any repository.": [
  null,
  "所有仓库都不提供 $0。"
 ],
 "$0 package": [
  null,
  "$0 软件包"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 软件包需要重启系统"
 ],
 "$0 security fix available": [
  null,
  "$0 可用的安全修复"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 服务需要重启"
 ],
 "$0 update available": [
  null,
  "$0 更新可用"
 ],
 "$0 will be installed.": [
  null,
  "将安装 $0。"
 ],
 ", including $1 security fix": [
  null,
  "， 包括 $1 安全修复"
 ],
 "1 minute": [
  null,
  "1 分钟"
 ],
 "20 minutes": [
  null,
  "20 分钟"
 ],
 "40 minutes": [
  null,
  "40 分钟"
 ],
 "5 minutes": [
  null,
  "5 分钟"
 ],
 "60 minutes": [
  null,
  "60 分钟"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "软件包需要重启系统才能使更新生效："
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "需要重启服务才能使更新生效："
 ],
 "Additional packages:": [
  null,
  "额外的软件包："
 ],
 "All updates": [
  null,
  "所有更新"
 ],
 "Apply kernel live patches": [
  null,
  "应用内核实时补丁"
 ],
 "Applying updates": [
  null,
  "正在应用更新"
 ],
 "Applying updates failed": [
  null,
  "应用更新失败"
 ],
 "Automatic updates": [
  null,
  "自动更新"
 ],
 "Automatically using NTP": [
  null,
  "自动使用 NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "自动使用指定的 NTP 服务器"
 ],
 "Available updates": [
  null,
  "可用的更新"
 ],
 "Bug fix updates available": [
  null,
  "错误修复的更新可以使用"
 ],
 "Bugs": [
  null,
  "程序错误"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Cannot schedule event in the past": [
  null,
  "无法调度以前的事件"
 ],
 "Change": [
  null,
  "变更"
 ],
 "Change system time": [
  null,
  "修改系统时间"
 ],
 "Check for updates": [
  null,
  "检查更新"
 ],
 "Checking for package updates...": [
  null,
  "正在检查软件包更新..."
 ],
 "Checking installed software": [
  null,
  "检查安装的软件"
 ],
 "Checking software status": [
  null,
  "检查软件状态"
 ],
 "Continue": [
  null,
  "继续"
 ],
 "Danger alert:": [
  null,
  "危险警报："
 ],
 "Delay": [
  null,
  "延时"
 ],
 "Details": [
  null,
  "详情"
 ],
 "Disabled": [
  null,
  "禁用"
 ],
 "Downloaded": [
  null,
  "已下载"
 ],
 "Downloading": [
  null,
  "正在下载"
 ],
 "Downloading $0": [
  null,
  "正在下载 $0"
 ],
 "Edit": [
  null,
  "编辑"
 ],
 "Enable": [
  null,
  "启用"
 ],
 "Enabled": [
  null,
  "启用"
 ],
 "Enhancement updates available": [
  null,
  "可用的功能增强更新"
 ],
 "Errata": [
  null,
  "勘误"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  "为 dnf-automatic.timer 或 dnf-automatic-install.timer 解析单元文件失败。请删除自定义覆盖来配置自动更新。"
 ],
 "Failed to restart service": [
  null,
  "重启服务失败"
 ],
 "Fridays": [
  null,
  "周五"
 ],
 "History package count": [
  null,
  "历史软件包数量"
 ],
 "Ignore": [
  null,
  "忽略"
 ],
 "Info": [
  null,
  "信息"
 ],
 "Initializing...": [
  null,
  "初始化中..."
 ],
 "Install": [
  null,
  "安装"
 ],
 "Install all updates": [
  null,
  "安装所有更新"
 ],
 "Install kpatch updates": [
  null,
  "安装 kpatch 更新"
 ],
 "Install security updates": [
  null,
  "安装安全更新"
 ],
 "Install software": [
  null,
  "安装软件"
 ],
 "Installed": [
  null,
  "已安装"
 ],
 "Installing": [
  null,
  "正在安装"
 ],
 "Installing $0": [
  null,
  "正在安装 $0"
 ],
 "Invalid date format": [
  null,
  "无效的日期格式"
 ],
 "Invalid date format and invalid time format": [
  null,
  "无效的日期格式和时间格式"
 ],
 "Invalid time format": [
  null,
  "无效的时间格式"
 ],
 "Invalid timezone": [
  null,
  "无效的时区"
 ],
 "Kernel live patch $0 is active": [
  null,
  "内核实时补丁 $0 处于活跃状态"
 ],
 "Kernel live patch $0 is installed": [
  null,
  "内核实时补丁 $0 已安装"
 ],
 "Kernel live patch settings": [
  null,
  "内核实时补丁设置"
 ],
 "Kernel live patching": [
  null,
  "内核实时补丁"
 ],
 "Last checked: $0": [
  null,
  "最后检查于： $0"
 ],
 "Learn more": [
  null,
  "了解更多"
 ],
 "Loading available updates failed": [
  null,
  "加载可用的更新失败"
 ],
 "Loading available updates, please wait...": [
  null,
  "正在加载可用的更新，请等待..."
 ],
 "Log messages": [
  null,
  "日志消息"
 ],
 "Managing software updates": [
  null,
  "管理软件更新"
 ],
 "Manually": [
  null,
  "手动的"
 ],
 "Message to logged in users": [
  null,
  "发送给已登录用户的信息"
 ],
 "Mondays": [
  null,
  "周一"
 ],
 "More info...": [
  null,
  "更多信息..."
 ],
 "NTP server": [
  null,
  "NTP 服务器"
 ],
 "Name": [
  null,
  "名称"
 ],
 "Need at least one NTP server": [
  null,
  "至少需要一个 NTP 服务器"
 ],
 "No delay": [
  null,
  "无延时"
 ],
 "No updates": [
  null,
  "没有更新"
 ],
 "Not available": [
  null,
  "不可用"
 ],
 "Not installed": [
  null,
  "未安装"
 ],
 "Not registered": [
  null,
  "没有注册"
 ],
 "Not set up": [
  null,
  "未设置"
 ],
 "Not synchronized": [
  null,
  "未同步"
 ],
 "Ok": [
  null,
  "确认"
 ],
 "Package information": [
  null,
  "软件包信息"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit 已崩溃"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit 未安装"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit 已报告错误码 $0"
 ],
 "Packages": [
  null,
  "软件包"
 ],
 "Pick date": [
  null,
  "选择日期"
 ],
 "Please reload the page after resolving the issue.": [
  null,
  "在解决这个问题后重新载入页面。"
 ],
 "Reboot": [
  null,
  "重启"
 ],
 "Reboot after completion": [
  null,
  "完成后重启"
 ],
 "Reboot recommended": [
  null,
  "推荐重新引导"
 ],
 "Reboot system...": [
  null,
  "重新引导系统......"
 ],
 "Refreshing package information": [
  null,
  "刷新软件包信息"
 ],
 "Register…": [
  null,
  "注册…"
 ],
 "Reloading the state of remaining services": [
  null,
  "重新载入剩余的服务状态"
 ],
 "Removals:": [
  null,
  "移除："
 ],
 "Removing $0": [
  null,
  "正在删除 $0"
 ],
 "Restart services": [
  null,
  "重启服务"
 ],
 "Restart services...": [
  null,
  "重启服务......"
 ],
 "Restarting": [
  null,
  "正在重启"
 ],
 "Saturdays": [
  null,
  "周六"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Save changes": [
  null,
  "保存更改"
 ],
 "Security updates available": [
  null,
  "可用的错误修复更新"
 ],
 "Security updates only": [
  null,
  "只包括安全更新"
 ],
 "Security updates will be applied $0 at $1": [
  null,
  "安全更新将在 $1 应用 $0"
 ],
 "Set time": [
  null,
  "设置时间"
 ],
 "Set up": [
  null,
  "设置"
 ],
 "Setting up": [
  null,
  "设置"
 ],
 "Settings": [
  null,
  "设置"
 ],
 "Severity": [
  null,
  "严重性"
 ],
 "Shut down": [
  null,
  "关机"
 ],
 "Software updates": [
  null,
  "软件更新"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "某些其他程序正在使用软件包管理器，请等待..."
 ],
 "Some software needs to be restarted manually": [
  null,
  "有些软件需要手动重启"
 ],
 "Specific time": [
  null,
  "指定时间"
 ],
 "Status": [
  null,
  "状态"
 ],
 "Sundays": [
  null,
  "周日"
 ],
 "Synchronized": [
  null,
  "已同步"
 ],
 "Synchronized with $0": [
  null,
  "与 $0 同步"
 ],
 "Synchronizing": [
  null,
  "同步"
 ],
 "System is up to date": [
  null,
  "系统已更新到最新"
 ],
 "The following service will be restarted:": [
  null,
  "以下服务将会被重启："
 ],
 "This host will reboot after updates are installed.": [
  null,
  "安装更新后此主机将重启。"
 ],
 "This system is not registered": [
  null,
  "该系统未注册"
 ],
 "Thursdays": [
  null,
  "周四"
 ],
 "Time": [
  null,
  "时间"
 ],
 "Time zone": [
  null,
  "时区"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "为了获取软件更新，该系统需要通过红帽客户门户网站或本地订阅服务器注册到红帽。"
 ],
 "Toggle date picker": [
  null,
  "切换日期选择器"
 ],
 "Total size: $0": [
  null,
  "总大小：$0"
 ],
 "Trying to synchronize with $0": [
  null,
  "正在尝试与 $0 同步"
 ],
 "Tuesdays": [
  null,
  "周二"
 ],
 "Type": [
  null,
  "类型"
 ],
 "Unavailable packages": [
  null,
  "不可用的软件包"
 ],
 "Update Success Table": [
  null,
  "更新成功表"
 ],
 "Update history": [
  null,
  "更新历史"
 ],
 "Update was successful": [
  null,
  "更新成功"
 ],
 "Updated": [
  null,
  "已更新"
 ],
 "Updated packages may require a reboot to take effect.": [
  null,
  "已更新的软件包可能需要重启生效。"
 ],
 "Updates available": [
  null,
  "可用的更新"
 ],
 "Updates history": [
  null,
  "更新历史"
 ],
 "Updates will be applied $0 at $1": [
  null,
  "更新将在$1 应用 $0"
 ],
 "Updating": [
  null,
  "更新"
 ],
 "Verified": [
  null,
  "已验证"
 ],
 "Verifying": [
  null,
  "正在验证"
 ],
 "Version": [
  null,
  "版本"
 ],
 "View update log": [
  null,
  "查看更新日志"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "等待其他软件管理操作完成"
 ],
 "Web Console will restart": [
  null,
  "Web 控制台将重启"
 ],
 "Wednesdays": [
  null,
  "周三"
 ],
 "When": [
  null,
  "当"
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  "当 Web 控制台重启时，将不再能够看到进度信息。但是，更新过程会继续在后台进行。重新连接以继续监视更新过程。"
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "您的服务器将要关闭连接。您可以在其重启后重新连接。"
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "at": [
  null,
  "在"
 ],
 "bug fix": [
  null,
  "程序漏洞修复"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "enhancement": [
  null,
  "性能强化"
 ],
 "every Friday": [
  null,
  "每周五"
 ],
 "every Monday": [
  null,
  "每周一"
 ],
 "every Saturday": [
  null,
  "每周六"
 ],
 "every Sunday": [
  null,
  "每周日"
 ],
 "every Thursday": [
  null,
  "每周四"
 ],
 "every Tuesday": [
  null,
  "每周二"
 ],
 "every Wednesday": [
  null,
  "没周三"
 ],
 "every day": [
  null,
  "每天"
 ],
 "for current and future kernels": [
  null,
  "对于当前和将来的内核"
 ],
 "for current kernel only": [
  null,
  "只对于当前的内核"
 ],
 "package": [
  null,
  "软件包"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "patches": [
  null,
  "补丁"
 ],
 "security": [
  null,
  "安全"
 ],
 "show less": [
  null,
  "显示更少"
 ],
 "show more": [
  null,
  "显示更多"
 ],
 "yum": [
  null,
  "yum"
 ]
});
