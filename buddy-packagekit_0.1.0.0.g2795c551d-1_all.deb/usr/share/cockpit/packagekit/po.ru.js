cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "$0 is not available from any repository.": [
  null,
  "Компонент $0 недоступен в репозиториях."
 ],
 "$0 package": [
  null,
  "$0 пакет",
  "$0 пакета",
  "$0 пакетов"
 ],
 "$0 package needs a system reboot": [
  null,
  "$0 пакет требует перезагрузки системы",
  "$0 пакета требуют перезагрузки системы",
  "$0 пакетов требуют перезагрузки системы"
 ],
 "$0 security fix available": [
  null,
  "Доступно $0 обновление безопасности",
  "Доступно $0 обновления безопасности",
  "Доступно $0 обновлений безопасности"
 ],
 "$0 service needs to be restarted": [
  null,
  "$0 служба требует перезапуска",
  "$0 службы требуют перезапуска",
  "$0 служб требуют перезапуска"
 ],
 "$0 update available": [
  null,
  "Доступно $0 обновление",
  "Доступно $0 обновления",
  "Доступно $0 обновлений"
 ],
 "$0 will be installed.": [
  null,
  "Будет выполнена установка $0."
 ],
 ", including $1 security fix": [
  null,
  ", в том числе $1 исправление безопасности",
  ", в том числе $1 исправления безопасности",
  ", в том числе $1 исправлений безопасности"
 ],
 "1 minute": [
  null,
  "1 минута"
 ],
 "20 minutes": [
  null,
  "20 минут"
 ],
 "40 minutes": [
  null,
  "40 минут"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "60 minutes": [
  null,
  "60 минут"
 ],
 "A package needs a system reboot for the updates to take effect:": [
  null,
  "Чтобы обновления вступили в силу, пакету требуется перезагрузка системы:",
  "Чтобы обновления вступили в силу, некоторым пакетам требуется перезагрузка системы:",
  "Чтобы обновления вступили в силу, некоторым пакетам требуется перезагрузка системы:"
 ],
 "A service needs to be restarted for the updates to take effect:": [
  null,
  "Чтобы изменения вступили в силу, необходимо перезапустить службу:",
  "Чтобы изменения вступили в силу, необходимо перезапустить некоторые службы:",
  "Чтобы изменения вступили в силу, необходимо перезапустить некоторые службы:"
 ],
 "Additional packages:": [
  null,
  "Дополнительные пакеты:"
 ],
 "All updates": [
  null,
  "Все обновления"
 ],
 "Apply kernel live patches": [
  null,
  "Применить интерактивные исправления ядра"
 ],
 "Applying updates": [
  null,
  "Применение обновлений"
 ],
 "Applying updates failed": [
  null,
  "Не удалось применить обновления"
 ],
 "Automatic updates": [
  null,
  "Автоматическое обновление"
 ],
 "Automatically using NTP": [
  null,
  "Автоматически с использованием серверов NTP"
 ],
 "Automatically using specific NTP servers": [
  null,
  "Автоматически с использованием определённых серверов NTP"
 ],
 "Available updates": [
  null,
  "Доступные обновления"
 ],
 "Bug fix updates available": [
  null,
  "Доступны исправления ошибок"
 ],
 "Bugs": [
  null,
  "Ошибки"
 ],
 "CVE": [
  null,
  "CVE"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Cannot schedule event in the past": [
  null,
  "Невозможно запланировать событие в прошлом"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Change system time": [
  null,
  "Изменить системное время"
 ],
 "Check for updates": [
  null,
  "Проверить наличие обновлений"
 ],
 "Checking for package updates...": [
  null,
  "Проверка наличия обновлений пакетов..."
 ],
 "Checking installed software": [
  null,
  "Проверка установленного программного обеспечения"
 ],
 "Checking software status": [
  null,
  "Проверка состояния программного обеспечения"
 ],
 "Continue": [
  null,
  "Дальше"
 ],
 "Danger alert:": [
  null,
  ""
 ],
 "Delay": [
  null,
  "Задержка"
 ],
 "Details": [
  null,
  "Подробности"
 ],
 "Disabled": [
  null,
  "Отключено"
 ],
 "Downloaded": [
  null,
  "Загружено"
 ],
 "Downloading": [
  null,
  "Загрузка"
 ],
 "Downloading $0": [
  null,
  "Загрузка $0"
 ],
 "Edit": [
  null,
  "Изменить"
 ],
 "Enabled": [
  null,
  "Включено"
 ],
 "Enhancement updates available": [
  null,
  "Доступны улучшения"
 ],
 "Failed to parse unit files for dnf-automatic.timer or dnf-automatic-install.timer. Please remove custom overrides to configure automatic updates.": [
  null,
  ""
 ],
 "Fridays": [
  null,
  "По пятницам"
 ],
 "Ignore": [
  null,
  "Игнорировать"
 ],
 "Info": [
  null,
  ""
 ],
 "Initializing...": [
  null,
  "Инициализация..."
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Install all updates": [
  null,
  "Установить все обновления"
 ],
 "Install security updates": [
  null,
  "Установить обновления безопасности"
 ],
 "Install software": [
  null,
  "Установка программного обеспечения"
 ],
 "Installed": [
  null,
  "Установлено"
 ],
 "Installing": [
  null,
  "Установка"
 ],
 "Installing $0": [
  null,
  "Установка $0"
 ],
 "Invalid date format": [
  null,
  "Недопустимый формат даты"
 ],
 "Invalid date format and invalid time format": [
  null,
  "Недопустимый формат даты и недопустимый формат времени"
 ],
 "Invalid time format": [
  null,
  "Недопустимый формат времени"
 ],
 "Last checked: $0": [
  null,
  "Последняя проверка: $0"
 ],
 "Learn more": [
  null,
  "Подробнее..."
 ],
 "Loading available updates failed": [
  null,
  "Загрузка доступных обновлений не удалась"
 ],
 "Loading available updates, please wait...": [
  null,
  "Загрузка доступных обновлений..."
 ],
 "Log messages": [
  null,
  "Сообщения журнала"
 ],
 "Managing software updates": [
  null,
  "Управление обновлениями программного обеспечения"
 ],
 "Manually": [
  null,
  "Вручную"
 ],
 "Message to logged in users": [
  null,
  "Сообщение для вошедших пользователей"
 ],
 "Mondays": [
  null,
  "По понедельникам"
 ],
 "NTP server": [
  null,
  "Сервер NTP"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Need at least one NTP server": [
  null,
  "Требуется по крайней мере один сервер NTP"
 ],
 "No delay": [
  null,
  "Без задержки"
 ],
 "Not available": [
  null,
  "Недоступно"
 ],
 "Not registered": [
  null,
  "Не зарегистрировано"
 ],
 "Not synchronized": [
  null,
  "Не синхронизировано"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Package information": [
  null,
  "Сведения о пакете"
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "PackageKit is not installed": [
  null,
  "PackageKit не установлен"
 ],
 "PackageKit reported error code $0": [
  null,
  "PackageKit передал код ошибки $0"
 ],
 "Please reload the page after resolving the issue.": [
  null,
  ""
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Reboot system...": [
  null,
  ""
 ],
 "Refreshing package information": [
  null,
  "Обновление сведений о пакете"
 ],
 "Register…": [
  null,
  "Зарегистрировать…"
 ],
 "Reloading the state of remaining services": [
  null,
  ""
 ],
 "Removals:": [
  null,
  "Для удаления:"
 ],
 "Removing $0": [
  null,
  "Удаление $0"
 ],
 "Restarting": [
  null,
  "Перезапуск"
 ],
 "Saturdays": [
  null,
  "По субботам"
 ],
 "Save": [
  null,
  "Сохранить"
 ],
 "Security updates available": [
  null,
  "Доступны обновления безопасности"
 ],
 "Set time": [
  null,
  "Настроить время"
 ],
 "Set up": [
  null,
  "Настроено"
 ],
 "Setting up": [
  null,
  "Настройка"
 ],
 "Severity": [
  null,
  "Серьёзность"
 ],
 "Shut down": [
  null,
  "Завершение работы"
 ],
 "Software updates": [
  null,
  "Обновления программного обеспечения"
 ],
 "Some other program is currently using the package manager, please wait...": [
  null,
  "Диспетчер пакетов в настоящее время используется другой программой. Подождите..."
 ],
 "Some software needs to be restarted manually": [
  null,
  ""
 ],
 "Specific time": [
  null,
  "Определённое время"
 ],
 "Status": [
  null,
  "Состояние"
 ],
 "Sundays": [
  null,
  "По воскресеньям"
 ],
 "Synchronized": [
  null,
  "Синхронизировано"
 ],
 "System is up to date": [
  null,
  "Система не нуждается в обновлении"
 ],
 "The following service will be restarted:": [
  null,
  "",
  "",
  ""
 ],
 "This host will reboot after updates are installed.": [
  null,
  ""
 ],
 "This system is not registered": [
  null,
  "Эта система не зарегистрирована"
 ],
 "Thursdays": [
  null,
  "По четвергам"
 ],
 "Time zone": [
  null,
  "Часовой пояс"
 ],
 "To get software updates, this system needs to be registered with Red Hat, either using the Red Hat Customer Portal or a local subscription server.": [
  null,
  "Для получения обновлений программного обеспечения система должна быть зарегистрирована Red Hat с использованием либо клиентского портала Red Hat, либо локального сервера подписки."
 ],
 "Toggle date picker": [
  null,
  ""
 ],
 "Total size: $0": [
  null,
  "Общий размер: $0"
 ],
 "Tuesdays": [
  null,
  "По вторникам"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Update history": [
  null,
  "История обновлений"
 ],
 "Updated": [
  null,
  "Обновлено"
 ],
 "Updates available": [
  null,
  "Доступны обновления"
 ],
 "Updates will be applied $0 at $1": [
  null,
  ""
 ],
 "Updating": [
  null,
  "Обновление"
 ],
 "Verified": [
  null,
  "Проверено"
 ],
 "Verifying": [
  null,
  "Проверка"
 ],
 "Version": [
  null,
  "Версия"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Ожидание завершения других операций управления программным обеспечением"
 ],
 "Wednesdays": [
  null,
  "По средам"
 ],
 "When": [
  null,
  ""
 ],
 "When the Web Console is restarted, you will no longer see progress information. However, the update process will continue in the background. Reconnect to continue watching the update process.": [
  null,
  ""
 ],
 "Your server will close the connection soon. You can reconnect after it has restarted.": [
  null,
  "Ваш сервер скоро закроет соединение. После его перезапуска вы сможете подключиться повторно."
 ],
 "apt-get": [
  null,
  "apt-get"
 ],
 "at": [
  null,
  "в"
 ],
 "bug fix": [
  null,
  "исправление ​​ошибки"
 ],
 "dnf": [
  null,
  "dnf"
 ],
 "enhancement": [
  null,
  "улучшение"
 ],
 "every day": [
  null,
  "ежедневно"
 ],
 "for current and future kernels": [
  null,
  ""
 ],
 "package": [
  null,
  "пакет"
 ],
 "packagekit": [
  null,
  "packagekit"
 ],
 "patches": [
  null,
  ""
 ],
 "security": [
  null,
  "безопасность"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "yum": [
  null,
  "yum"
 ]
});
