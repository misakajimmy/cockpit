cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "$0 active zone": [
  null,
  "$0 aktywna strefa",
  "$0 aktywne strefy",
  "$0 aktywnych stref"
 ],
 "$0 day": [
  null,
  "$0 dzień",
  "$0 dni",
  "$0 dni"
 ],
 "$0 hour": [
  null,
  "$0 godzina",
  "$0 godziny",
  "$0 godzin"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "$0 month": [
  null,
  "$0 miesiąc",
  "$0 miesiące",
  "$0 miesięcy"
 ],
 "$0 week": [
  null,
  "$0 tydzień",
  "$0 tygodnie",
  "$0 tygodni"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 lata",
  "$0 lat"
 ],
 "$0 zone": [
  null,
  "Strefa $0"
 ],
 "1 day": [
  null,
  "1 dzień"
 ],
 "1 hour": [
  null,
  "1 godzina"
 ],
 "1 week": [
  null,
  "1 tydzień"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "6 hours": [
  null,
  "6 godzin"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "LACP 802.3ad"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Wiązanie sieciowe łączy wiele interfejsów sieciowych w jeden interfejs logiczny o wyższej przepustowości lub redundancji."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "Monitorowanie ARP"
 ],
 "ARP ping": [
  null,
  "Ping ARP"
 ],
 "Active": [
  null,
  "Aktywne"
 ],
 "Active backup": [
  null,
  "Aktywna kopia zapasowa"
 ],
 "Adaptive load balancing": [
  null,
  "Adaptacyjne równoważenie obciążenia"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Adaptacyjne równoważenie obciążenia przesyłu"
 ],
 "Add $0": [
  null,
  "Dodaj $0"
 ],
 "Add VLAN": [
  null,
  "Dodaj VLAN"
 ],
 "Add a new zone": [
  null,
  "Dodaj nową strefę"
 ],
 "Add bond": [
  null,
  "Dodaj wiązanie"
 ],
 "Add bridge": [
  null,
  "Dodaj mostek"
 ],
 "Add item": [
  null,
  "Dodaj element"
 ],
 "Add member": [
  null,
  "Dodaj element"
 ],
 "Add new zone": [
  null,
  "Dodaj nową strefę"
 ],
 "Add ports": [
  null,
  "Dodaj porty"
 ],
 "Add ports to $0 zone": [
  null,
  "Dodaj porty do strefy $0"
 ],
 "Add services": [
  null,
  "Dodaj usługi"
 ],
 "Add services to $0 zone": [
  null,
  "Dodaj usługi do strefy $0"
 ],
 "Add services to zone $0": [
  null,
  "Dodaj usługi do strefy $0"
 ],
 "Add team": [
  null,
  "Dodaj zespół"
 ],
 "Add zone": [
  null,
  "Dodaj strefę"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Dodanie $0 zerwie połączenie z serwerem i uniemożliwi korzystanie z interfejsu administracji."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Dodanie niestandardowych portów spowoduje ponowne wczytanie zapory sieciowej. Ponowne wczytanie spowoduje utratę całej konfiguracji tylko dla obecnej sesji."
 ],
 "Additional DNS $val": [
  null,
  "Dodatkowy DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Dodatkowe domeny wyszukiwania DNS $val"
 ],
 "Additional address $val": [
  null,
  "Dodatkowy adres $val"
 ],
 "Additional ports": [
  null,
  "Dodatkowe porty"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "Address $val": [
  null,
  "Adres $val"
 ],
 "Addresses": [
  null,
  "Adresy"
 ],
 "Allowed addresses": [
  null,
  "Dozwolone adresy"
 ],
 "Authenticating": [
  null,
  "Uwierzytelnianie"
 ],
 "Automatic": [
  null,
  "Automatyczne"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatyczne (tylko DHCP)"
 ],
 "Automatic (DHCP)": [
  null,
  "Automatyczne (DHCP)"
 ],
 "Balancer": [
  null,
  "Równoważenie"
 ],
 "Bond": [
  null,
  "Wiązanie"
 ],
 "Bond settings": [
  null,
  "Ustawienia wiązania"
 ],
 "Bridge": [
  null,
  "Mostek"
 ],
 "Bridge port": [
  null,
  "Port mostku"
 ],
 "Bridge port settings": [
  null,
  "Ustawienia portu mostku"
 ],
 "Bridge settings": [
  null,
  "Ustawienia mostka"
 ],
 "Broadcast": [
  null,
  "Broadcast"
 ],
 "Broken configuration": [
  null,
  "Uszkodzona konfiguracja"
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Carrier": [
  null,
  "Operator"
 ],
 "Change the settings": [
  null,
  "Zmień ustawienia"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Zmiana ustawień zerwie połączenie z serwerem i uniemożliwi korzystanie z interfejsu administracji."
 ],
 "Checking IP": [
  null,
  "Sprawdzanie IP"
 ],
 "Close": [
  null,
  "Zamknij"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Przyjmowane są porty, zakresy i usługi oddzielone przecinkami"
 ],
 "Configuring": [
  null,
  "Konfigurowanie"
 ],
 "Configuring IP": [
  null,
  "Konfigurowanie IP"
 ],
 "Confirm removal of $0": [
  null,
  "Potwierdź usunięcie $0"
 ],
 "Connect automatically": [
  null,
  "Łączenie automatyczne"
 ],
 "Connection will be lost": [
  null,
  "Połączenie zostanie utracone"
 ],
 "Create it": [
  null,
  "Utwórz"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Utworzenie tej sieci $0 zerwie połączenie z serwerem i uniemożliwi korzystanie z interfejsu administracji."
 ],
 "Custom ports": [
  null,
  "Niestandardowe porty"
 ],
 "Custom zones": [
  null,
  "Niestandardowe strefy"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "Domeny wyszukiwania DNS"
 ],
 "DNS search domains $val": [
  null,
  "Domeny wyszukiwania DNS $val"
 ],
 "Deactivating": [
  null,
  "Dezaktywowanie"
 ],
 "Delete": [
  null,
  "Usuń"
 ],
 "Delete $0": [
  null,
  "Usuń $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Usunięcie $0 zerwie połączenie z serwerem i uniemożliwi korzystanie z interfejsu administracji."
 ],
 "Description": [
  null,
  "Opis"
 ],
 "Disable the firewall": [
  null,
  "Wyłącz zaporę sieciową"
 ],
 "Disabled": [
  null,
  "Wyłączone"
 ],
 "Edit": [
  null,
  "Modyfikuj"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Modyfikuj niestandardową usługę w strefie $0"
 ],
 "Edit rules and zones": [
  null,
  "Modyfikuj reguły i strefy"
 ],
 "Edit service": [
  null,
  "Modyfikuj usługę"
 ],
 "Edit service $0": [
  null,
  "Modyfikuj usługę $0"
 ],
 "Enable or disable the device": [
  null,
  "Włącz lub wyłącz urządzenie"
 ],
 "Enable service": [
  null,
  "Włącz usługę"
 ],
 "Enable the firewall": [
  null,
  "Włącz zaporę sieciową"
 ],
 "Enabled": [
  null,
  "Włączone"
 ],
 "Enter a valid MAC address": [
  null,
  "Proszę podać prawidłowy adres MAC"
 ],
 "Entire subnet": [
  null,
  "Cała podsieć"
 ],
 "Ethernet MAC": [
  null,
  "MAC ethernetu"
 ],
 "Ethernet MTU": [
  null,
  "MTU ethernetu"
 ],
 "Ethtool": [
  null,
  "ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Przykład: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Przykład: 88,2019,nfs,rsync"
 ],
 "Failed": [
  null,
  "Niepowodzenie"
 ],
 "Failed to add port": [
  null,
  "Dodanie portu się nie powiodło"
 ],
 "Failed to add service": [
  null,
  "Dodanie usługi się nie powiodło"
 ],
 "Failed to add zone": [
  null,
  "Dodanie strefy się nie powiodło"
 ],
 "Failed to edit service": [
  null,
  "Modyfikacja usługi się nie powiodła"
 ],
 "Failed to save settings": [
  null,
  "Zapisanie ustawień się nie powiodło"
 ],
 "Filter services": [
  null,
  "Filtrowanie usług"
 ],
 "Firewall": [
  null,
  "Zapora sieciowa"
 ],
 "Firewall is not available": [
  null,
  "Zapora sieciowa jest niedostępna"
 ],
 "Forward delay $forward_delay": [
  null,
  "Opóźnienie w przód $forward_delay"
 ],
 "Gateway": [
  null,
  "Brama"
 ],
 "General": [
  null,
  "Ogólne"
 ],
 "Go to now": [
  null,
  "Przejdź teraz"
 ],
 "Group": [
  null,
  "Grupa"
 ],
 "Hair pin mode": [
  null,
  "Tryb Hairpin"
 ],
 "Hairpin mode": [
  null,
  "Tryb Hairpin"
 ],
 "Hello time $hello_time": [
  null,
  "Czas powitania $hello_time"
 ],
 "ID": [
  null,
  "Identyfikator"
 ],
 "ID $id": [
  null,
  "Identyfikator $id"
 ],
 "IP address": [
  null,
  "Adres IP"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "Adres IP z przedrostkiem trasowania. Wiele wartości należy oddzielić przecinkiem. Przykład: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "Ustawienia IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "Ustawienia IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Jeśli zostanie pozostawione puste, to identyfikator zostanie utworzony na podstawie powiązanych usług portu i numerów portów"
 ],
 "Ignore": [
  null,
  "Ignorowanie"
 ],
 "Inactive": [
  null,
  "Nieaktywne"
 ],
 "Included services": [
  null,
  "Dołączone usługi"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Żądania przychodzące są domyślnie blokowane. Żądania wychodzące nie są blokowane."
 ],
 "Interface": [
  null,
  "Interfejs",
  "Interfejsy",
  "Interfejsy"
 ],
 "Interface members": [
  null,
  "Elementy interfejsu"
 ],
 "Interfaces": [
  null,
  "Interfejsy"
 ],
 "Invalid address $0": [
  null,
  "Nieprawidłowy adres $0"
 ],
 "Invalid metric $0": [
  null,
  "Nieprawidłowe parametry $0"
 ],
 "Invalid port number": [
  null,
  "Nieprawidłowy numer portu"
 ],
 "Invalid prefix $0": [
  null,
  "Nieprawidłowy przedrostek $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Nieprawidłowy przedrostek lub maska sieci $0"
 ],
 "Invalid range": [
  null,
  "Nieprawidłowy zakres"
 ],
 "Keep connection": [
  null,
  "Utrzymywanie połączenia"
 ],
 "LACP key": [
  null,
  "Klucz LACP"
 ],
 "Learn more": [
  null,
  "Więcej informacji"
 ],
 "Link down delay": [
  null,
  "Opóźnienie łącza w dół"
 ],
 "Link local": [
  null,
  "Link-local"
 ],
 "Link monitoring": [
  null,
  "Monitorowanie łącza"
 ],
 "Link up delay": [
  null,
  "Opóźnienie łącza w górę"
 ],
 "Link watch": [
  null,
  "Obserwacja łącza"
 ],
 "Load balancing": [
  null,
  "Równoważenie obciążenia"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (zalecane)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU musi być liczbą dodatnią"
 ],
 "Managed interfaces": [
  null,
  "Zarządzane interfejsy"
 ],
 "Managing VLANs": [
  null,
  "Zarządzanie VLAN"
 ],
 "Managing firewall": [
  null,
  "Zarządzanie zaporą sieciową"
 ],
 "Managing networking bonds": [
  null,
  "Zarządzanie wiązaniami sieciowymi"
 ],
 "Managing networking bridges": [
  null,
  "Zarządzanie mostkami sieciowymi"
 ],
 "Managing networking teams": [
  null,
  "Zarządzanie zespołami sieciowymi"
 ],
 "Manual": [
  null,
  "Ręczne"
 ],
 "Maximum message age $max_age": [
  null,
  "Maksymalny wiek komunikatu $max_age"
 ],
 "Metric": [
  null,
  "Statystyki"
 ],
 "Mode": [
  null,
  "Tryb"
 ],
 "Monitoring interval": [
  null,
  "Odstęp monitorowania"
 ],
 "Monitoring targets": [
  null,
  "Cele monitorowania"
 ],
 "NSNA ping": [
  null,
  "Ping NSNA"
 ],
 "Name": [
  null,
  "Nazwa"
 ],
 "Network bond": [
  null,
  "Wiązanie sieciowe"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Urządzenia i wykresy sieciowe wymagają usługi NetworkManager"
 ],
 "Network logs": [
  null,
  "Dzienniki sieci"
 ],
 "NetworkManager is not installed": [
  null,
  "Usługa NetworkManager nie jest zainstalowana"
 ],
 "NetworkManager is not running": [
  null,
  "Usługa NetworkManager nie jest uruchomiona"
 ],
 "Networking": [
  null,
  "Sieć"
 ],
 "No": [
  null,
  "Nie"
 ],
 "No carrier": [
  null,
  "Brak operatora"
 ],
 "No description available": [
  null,
  "Brak dostępnego opisu"
 ],
 "None": [
  null,
  "Brak"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Brak upoważnienia do wyłączenia zapory sieciowej"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Brak upoważnienia do włączenia zapory sieciowej"
 ],
 "Not available": [
  null,
  "Niedostępne"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Options": [
  null,
  "Opcje"
 ],
 "Parent": [
  null,
  "Nadrzędne"
 ],
 "Parent $parent": [
  null,
  "Nadrzędne $parent"
 ],
 "Part of $0": [
  null,
  "Część $0"
 ],
 "Passive": [
  null,
  "Pasywnie"
 ],
 "Path cost": [
  null,
  "Koszt ścieżki"
 ],
 "Path cost $path_cost": [
  null,
  "Koszt ścieżki $path_cost"
 ],
 "Permanent": [
  null,
  "Trwałe"
 ],
 "Ping interval": [
  null,
  "Odstęp między pingami"
 ],
 "Ping target": [
  null,
  "Cel pingu"
 ],
 "Please install the $0 package": [
  null,
  "Proszę zainstalować pakiet $0"
 ],
 "Port number and type do not match": [
  null,
  "Numer i typ portu się nie zgadzają"
 ],
 "Ports": [
  null,
  "Porty"
 ],
 "Prefix length": [
  null,
  "Długość przedrostka"
 ],
 "Prefix length or netmask": [
  null,
  "Długość przedrostka lub maska sieci"
 ],
 "Preparing": [
  null,
  "Przygotowywanie"
 ],
 "Preserve": [
  null,
  "Zachowanie"
 ],
 "Primary": [
  null,
  "Główne"
 ],
 "Priority": [
  null,
  "Priorytet"
 ],
 "Priority $priority": [
  null,
  "Priorytet $priority"
 ],
 "Random": [
  null,
  "Losowo"
 ],
 "Range": [
  null,
  "Zakres"
 ],
 "Range must be strictly ordered": [
  null,
  "Zakres musi być w ścisłej kolejności"
 ],
 "Reboot": [
  null,
  "Uruchom ponownie"
 ],
 "Receiving": [
  null,
  "Odbieranie"
 ],
 "Remove $0": [
  null,
  "Usuń $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Usuń usługę $0 ze strefy $1"
 ],
 "Remove item": [
  null,
  "Usuń element"
 ],
 "Remove service $0": [
  null,
  "Usuń usługę $0"
 ],
 "Remove zone $0": [
  null,
  "Usuń strefę $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Usunięcie $0 zerwie połączenie z serwerem i uniemożliwi korzystanie z interfejsu administracji."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Usunięcie usługi Cockpit może spowodować niedostępność konsoli internetowej. Proszę się upewnić, że ta strefa nie ma zastosowania do obecnego połączenia konsoli internetowej."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Usunięcie strefy usunie wszystkie zawarte w niej usługi."
 ],
 "Restoring connection": [
  null,
  "Przywracanie połączenia"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Routes": [
  null,
  "Trasy"
 ],
 "Runner": [
  null,
  "Uruchamianie"
 ],
 "STP forward delay": [
  null,
  "Opóźnienie w przód STP"
 ],
 "STP hello time": [
  null,
  "Czas powitania STP"
 ],
 "STP maximum message age": [
  null,
  "Maksymalny wiek komunikatu STP"
 ],
 "STP priority": [
  null,
  "Priorytet STP"
 ],
 "Save": [
  null,
  "Zapisz"
 ],
 "Search domain": [
  null,
  "Domena wyszukiwania"
 ],
 "Select method": [
  null,
  "Wybierz metodę"
 ],
 "Sending": [
  null,
  "Wysyłanie"
 ],
 "Server": [
  null,
  "Serwer"
 ],
 "Service": [
  null,
  "Usługa"
 ],
 "Services": [
  null,
  "Usługi"
 ],
 "Set to": [
  null,
  "Ustaw na"
 ],
 "Shared": [
  null,
  "Współdzielone"
 ],
 "Sorted from least to most trusted": [
  null,
  "Uporządkowane od najmniej do najbardziej zaufanych"
 ],
 "Spanning tree protocol": [
  null,
  "Protokół STP"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Protokół STP"
 ],
 "Stable": [
  null,
  "Stabilna"
 ],
 "Start service": [
  null,
  "Uruchom usługę"
 ],
 "Status": [
  null,
  "Stan"
 ],
 "Sticky": [
  null,
  "Lepkie"
 ],
 "Switch of $0": [
  null,
  "Wyłącz $0"
 ],
 "Switch off $0": [
  null,
  "Wyłącz $0"
 ],
 "Switch on $0": [
  null,
  "Włącz $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Wyłączenie $0 zerwie połączenie z serwerem i uniemożliwi korzystanie z interfejsu administracji."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Włączenie $0 zerwie połączenie z serwerem i uniemożliwi korzystanie z interfejsu administracji."
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Team": [
  null,
  "Zespół"
 ],
 "Team port": [
  null,
  "Port zespołu"
 ],
 "Team port settings": [
  null,
  "Ustawienia portu zespołu"
 ],
 "Team settings": [
  null,
  "Ustawienia zespołu"
 ],
 "Testing connection": [
  null,
  "Testowanie połączenia"
 ],
 "The cockpit service is automatically included": [
  null,
  "Usługa Cockpit jest automatycznie dołączana"
 ],
 "There are no active services in this zone": [
  null,
  "Brak aktywnych usług w tej strefie"
 ],
 "This device cannot be managed here.": [
  null,
  "Tutaj nie można zarządzać tym urządzeniem."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Ta strefa zawiera usługę Cockpit. Proszę się upewnić, że ta strefa nie ma zastosowania do obecnego połączenia konsoli internetowej."
 ],
 "Transmitting": [
  null,
  "Przesyłanie"
 ],
 "Troubleshoot…": [
  null,
  "Rozwiąż problem…"
 ],
 "Trust level": [
  null,
  "Poziom zaufania"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unexpected error": [
  null,
  "Nieoczekiwany błąd"
 ],
 "Unknown": [
  null,
  "Nieznane"
 ],
 "Unknown \"$0\"": [
  null,
  "Nieznane „$0”"
 ],
 "Unknown configuration": [
  null,
  "Nieznana konfiguracja"
 ],
 "Unknown service name": [
  null,
  "Nieznana nazwa usługi"
 ],
 "Unmanaged interfaces": [
  null,
  "Niezarządzane interfejsy"
 ],
 "Use": [
  null,
  "Użyj"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "Identyfikator VLAN"
 ],
 "VLAN settings": [
  null,
  "Ustawienia VLAN"
 ],
 "View all logs": [
  null,
  "Wszystkie dzienniki"
 ],
 "Waiting": [
  null,
  "Oczekiwanie"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Tak"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Brak upoważnienia do modyfikacji zapory sieciowej."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 B danych binarnych]"
 ],
 "[binary data]": [
  null,
  "[dane binarne]"
 ],
 "[no data]": [
  null,
  "[brak danych]"
 ],
 "bond": [
  null,
  "wiązanie"
 ],
 "bridge": [
  null,
  "mostek"
 ],
 "edit": [
  null,
  "modyfikuj"
 ],
 "firewall": [
  null,
  "zapora sieciowa"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "interfejs"
 ],
 "ipv4": [
  null,
  "IPv4"
 ],
 "ipv6": [
  null,
  "IPv6"
 ],
 "mac": [
  null,
  "MAC"
 ],
 "network": [
  null,
  "sieć"
 ],
 "port": [
  null,
  "port"
 ],
 "show less": [
  null,
  "wyświetl mniej"
 ],
 "show more": [
  null,
  "wyświetl więcej"
 ],
 "tcp": [
  null,
  "TCP"
 ],
 "team": [
  null,
  "zespołowe"
 ],
 "udp": [
  null,
  "UDP"
 ],
 "vlan": [
  null,
  "VLAN"
 ],
 "zone": [
  null,
  "strefa"
 ]
});
