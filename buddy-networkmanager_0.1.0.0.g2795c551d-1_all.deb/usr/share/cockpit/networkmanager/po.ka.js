cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 active zone": [
  null,
  "$0 აქტიური ზონა",
  "$0 ცალი აქტიური ზონა"
 ],
 "$0 day": [
  null,
  "$0 დღე",
  "დღეები: $0"
 ],
 "$0 hour": [
  null,
  "$0 საათი",
  "საათი: $0"
 ],
 "$0 minute": [
  null,
  "$0 წუთი",
  "წუთი: $0"
 ],
 "$0 month": [
  null,
  "$0 თვე",
  "თვე: $0"
 ],
 "$0 week": [
  null,
  "$0 კვირა",
  "კვირა: $0"
 ],
 "$0 year": [
  null,
  "$0 წელი",
  "წელი: $0"
 ],
 "$0 zone": [
  null,
  "$0 ზონა"
 ],
 "1 day": [
  null,
  "1 დღე"
 ],
 "1 hour": [
  null,
  "1 საათი"
 ],
 "1 week": [
  null,
  "1 კვირა"
 ],
 "5 minutes": [
  null,
  "5 წთ"
 ],
 "6 hours": [
  null,
  "5 სთ"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "ქსელური bond აერთიანებს ქსელის მრავალ ინტერფეისს ერთ ლოგიკურ ინტერფეისში უფრო მაღალი გამტარობის ან წვდომადომის მისაღებად."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP-ის მონიტორინგი"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "Active": [
  null,
  "აქტიური"
 ],
 "Active backup": [
  null,
  "აქტიური მარქაფი"
 ],
 "Adaptive load balancing": [
  null,
  "დატვირთვის ადაპტიური გადანაწილება"
 ],
 "Adaptive transmit load balancing": [
  null,
  "გადაცემის დატვირთვის ადაპტაციური გადანაწილება"
 ],
 "Add $0": [
  null,
  "$0-ის დამატება"
 ],
 "Add VLAN": [
  null,
  "VLAN-ის დამატება"
 ],
 "Add a new zone": [
  null,
  "ახალი ზონის დამატება"
 ],
 "Add bond": [
  null,
  "Bond-ის დამატება"
 ],
 "Add bridge": [
  null,
  "ხიდის დამატება"
 ],
 "Add item": [
  null,
  "ელემენტის დამატება"
 ],
 "Add member": [
  null,
  "წევრის დამატება"
 ],
 "Add new zone": [
  null,
  "ახალი ზონის დამატება"
 ],
 "Add ports": [
  null,
  "პორტების დამატება"
 ],
 "Add ports to $0 zone": [
  null,
  "პორტების დამატება ზონაში $0"
 ],
 "Add services": [
  null,
  "სერვისების დამატება"
 ],
 "Add services to $0 zone": [
  null,
  "სერვისების დამატება ზონაში $0"
 ],
 "Add services to zone $0": [
  null,
  "სერვისების დამატება ზონაში $0"
 ],
 "Add team": [
  null,
  "გუნდის დამატება"
 ],
 "Add zone": [
  null,
  "ზონის დამატება"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის დამატება გაწყვეტს კავშირს სერვერთან და ადმინისტრირების ინტერფეისს ხელმიუწვდომელს გახდის."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "მითითებული პორტების დაატება იწვევს firewalld-ის გადატვირთვას. ეს კი იწვევს გაშვებული კონფიგურაციის(ინახება მეხსიერებაში) დაკარგვას!"
 ],
 "Additional DNS $val": [
  null,
  "დამატებითი DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "DNS-ის დამატებითი საძებნი დომენები $val"
 ],
 "Additional address $val": [
  null,
  "დამატებითი მისამართი $val"
 ],
 "Additional ports": [
  null,
  "დამატებითი პორტები"
 ],
 "Address": [
  null,
  "მისამართი"
 ],
 "Address $val": [
  null,
  "მისამართი $val"
 ],
 "Addresses": [
  null,
  "მისამართები"
 ],
 "Allowed addresses": [
  null,
  "ნებადართული მისამართები"
 ],
 "Authenticating": [
  null,
  "ავთენტიკაცია"
 ],
 "Automatic": [
  null,
  "ავტომატური"
 ],
 "Automatic (DHCP only)": [
  null,
  "ავტომატური (მხოლოდ DHCP)"
 ],
 "Automatic (DHCP)": [
  null,
  "ავტომატური (DHCP)"
 ],
 "Balancer": [
  null,
  "ბალანსერი"
 ],
 "Bond": [
  null,
  "ინტერფეისების გადაბმა"
 ],
 "Bond settings": [
  null,
  "Bond-ის მორგება"
 ],
 "Bridge": [
  null,
  "ხიდი"
 ],
 "Bridge port": [
  null,
  "ხიდის პორტი"
 ],
 "Bridge port settings": [
  null,
  "ხიდის პორტის მორგება"
 ],
 "Bridge settings": [
  null,
  "ხიდის მორგება"
 ],
 "Broadcast": [
  null,
  "გადაცემა"
 ],
 "Broken configuration": [
  null,
  "გაფუჭებული კონფიგურაცია"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Carrier": [
  null,
  "გადამზიდი"
 ],
 "Change the settings": [
  null,
  "პარამეტრების შეცვლა"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "ამ პარამეტრის ცვლილებები გამოიწვევს კავშირის წვეტას და გათიშავს ადმინისტრირების ინტერფეისს."
 ],
 "Checking IP": [
  null,
  "IP-ის შემოწმება"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "შესაძლო მნიშვნელობებია მძიმით გამოყოფილი პორტები, დიაპაზონები და სერვისები"
 ],
 "Configuring": [
  null,
  "მორგება"
 ],
 "Configuring IP": [
  null,
  "IP-ის მორგება"
 ],
 "Confirm removal of $0": [
  null,
  "დაადასტურეთ $0-ის წაშლა"
 ],
 "Connect automatically": [
  null,
  "ავტომატურად დაკავშირება"
 ],
 "Connection will be lost": [
  null,
  "კავშირი დაიკარგება"
 ],
 "Create it": [
  null,
  "შექმნა"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის შექმნა გაწყვეტს სერვერთან კავშირს. ადმინისტრირების ინტერფეისი მიუწვდომელი გახდება."
 ],
 "Custom ports": [
  null,
  "ხელით მითითებული პორტები"
 ],
 "Custom zones": [
  null,
  "ხელით მითითებული ზონები"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS-ში საძებნი დომენები"
 ],
 "DNS search domains $val": [
  null,
  "DNS-ში საძებნი დომენები $val"
 ],
 "Deactivating": [
  null,
  "დეაქტივაცია"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Delete $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის წაშლა შეწყვეტს კავშირს სერვერთან და ადმინისტრაციის ინტერფეისს მიუწვდომელს გახდის."
 ],
 "Description": [
  null,
  "აღწერა"
 ],
 "Disable the firewall": [
  null,
  "ბრანდმაუერის გამორთვა"
 ],
 "Disabled": [
  null,
  "გათიშულია"
 ],
 "Edit": [
  null,
  "ჩასწორება"
 ],
 "Edit custom service in $0 zone": [
  null,
  "ხელით მითითებული სერვისის ჩასწორება ზონაში $0"
 ],
 "Edit rules and zones": [
  null,
  "წესებისა და ზონების ჩასწორება"
 ],
 "Edit service": [
  null,
  "სერვისის ჩასწორება"
 ],
 "Edit service $0": [
  null,
  "სერვისის ჩასწორება: $0"
 ],
 "Enable or disable the device": [
  null,
  "მოწყობილობის ჩართვა ან გამორთვა"
 ],
 "Enable service": [
  null,
  "სერვისის ჩართვა"
 ],
 "Enable the firewall": [
  null,
  "ბრანდმაუერის ჩართვა"
 ],
 "Enabled": [
  null,
  "ჩართულია"
 ],
 "Enter a valid MAC address": [
  null,
  "შეიყვანეთ სწორი MAC მისამართი"
 ],
 "Entire subnet": [
  null,
  "მთელი ქვექსელი"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet-ის MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet-ის MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "მაგალითად: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "მაგალითად: 88,2019,nfs,rsync"
 ],
 "Failed": [
  null,
  "შეცდომით"
 ],
 "Failed to add port": [
  null,
  "პორტის დამატების შეცდომა"
 ],
 "Failed to add service": [
  null,
  "სერვისის დამატების შეცდომა"
 ],
 "Failed to add zone": [
  null,
  "ზონის დამატების შეცდომა"
 ],
 "Failed to edit service": [
  null,
  "სერვისის ჩასწორების შეცდომა"
 ],
 "Failed to save settings": [
  null,
  "პარამეტრების შენახვის შეცდომა"
 ],
 "Filter services": [
  null,
  "სერვისების ფილტრი"
 ],
 "Firewall": [
  null,
  "ბრანდმაუერი"
 ],
 "Firewall is not available": [
  null,
  "ბრანდმაუერი ხელმიუწვდომელია"
 ],
 "Forward delay $forward_delay": [
  null,
  "გადაგზავნის დაყოვნება $forward_delay"
 ],
 "Gateway": [
  null,
  "რაუტერი"
 ],
 "General": [
  null,
  "საერთო"
 ],
 "Go to now": [
  null,
  "ახლავე გადასვლა"
 ],
 "Group": [
  null,
  "ჯგუფი"
 ],
 "Hair pin mode": [
  null,
  "NAT Hairpin-ის რეჟიმი"
 ],
 "Hairpin mode": [
  null,
  "NAT hairpin რეჟიმი"
 ],
 "Hello time $hello_time": [
  null,
  "მისალმების დრო $hello_time"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "IP მისამართი"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP მისამართი რაუტინგის პრეფიქსით. ერთმანეთისგან გამოიყოფა მძიმით. მაგ: 192.0.2.0, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "IPv4-ის მორგება"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "IPv6-ის მორგება"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "თუ ცარიელია, ID დაგენერირდება შესაბამისი პორტის სერვისებისა და პორტის ნომრებისგან"
 ],
 "Ignore": [
  null,
  "იგნორი"
 ],
 "Inactive": [
  null,
  "არააქტიური"
 ],
 "Included services": [
  null,
  "მოყოლილი სერვისები"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "შემომავალი მოთხოვნები ნაგულისხმებად იბლოკება. გამავალი მოთხოვნები არ იბლოკება."
 ],
 "Interface": [
  null,
  "ცალი ინტერფეისი",
  "ინტერფეისი"
 ],
 "Interface members": [
  null,
  "ინტერფეისის წევრები"
 ],
 "Interfaces": [
  null,
  "ინტერფეისები"
 ],
 "Invalid address $0": [
  null,
  "არასწორი მისამართი: $0"
 ],
 "Invalid metric $0": [
  null,
  "არასწორი მეტრიკა $0"
 ],
 "Invalid port number": [
  null,
  "პორტის არასწორი ნომერი"
 ],
 "Invalid prefix $0": [
  null,
  "არასწორი პრეფიქსი $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "არასწორი პრეფიქსი ან ქსელის მასკა $0"
 ],
 "Invalid range": [
  null,
  "არასწორი დიაპაზონი"
 ],
 "Keep connection": [
  null,
  "კავშირის შენარჩუნება"
 ],
 "LACP key": [
  null,
  "LACP გასაღები"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "Link down delay": [
  null,
  "კავშირის გათიშვის დაყოვნება"
 ],
 "Link local": [
  null,
  "ლოკალური ბმის მისამართი"
 ],
 "Link monitoring": [
  null,
  "კავშირის მონიტორინგი"
 ],
 "Link up delay": [
  null,
  "კავშირის აღდგენის დაყოვნება"
 ],
 "Link watch": [
  null,
  "კავშირის თვალყურმდევნი"
 ],
 "Load balancing": [
  null,
  "დატვირთვის გადანაწილება"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (რეკომენდებულია)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU დადებითი რიცხვი უნდა იყოს"
 ],
 "Managed interfaces": [
  null,
  "მართული ინტერფეისები"
 ],
 "Managing VLANs": [
  null,
  "VLAN-ის მართვა"
 ],
 "Managing firewall": [
  null,
  "ბრანდმაუერის მართვა"
 ],
 "Managing networking bonds": [
  null,
  "ქსელის ბარათების გაერთიანების მართვა"
 ],
 "Managing networking bridges": [
  null,
  "ქსელური ხიდების მართვა"
 ],
 "Managing networking teams": [
  null,
  "ქსელური ბარათების გუნდების მართვა"
 ],
 "Manual": [
  null,
  "ხელით მითითება"
 ],
 "Maximum message age $max_age": [
  null,
  "შეტყობინების მაქს. ვადა $max_age"
 ],
 "Metric": [
  null,
  "მეტრული"
 ],
 "Mode": [
  null,
  "რეჟიმი"
 ],
 "Monitoring interval": [
  null,
  "მონიტორინგის ინტერვალი"
 ],
 "Monitoring targets": [
  null,
  "სამიზნეების მონიტორინგი"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Network bond": [
  null,
  "ქსელის ბარათების გაერთიანება"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "ქსელურ მოწყობილობებს და გრაფიკებს NetworkManager-ი ესაჭიროებათ"
 ],
 "Network logs": [
  null,
  "ქსელის ჟურნალი"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager დაყენებული არაა"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager გაშვებული არაა"
 ],
 "Networking": [
  null,
  "ქსელი"
 ],
 "No": [
  null,
  "არა"
 ],
 "No carrier": [
  null,
  "შეამოწმეთ კავშირი"
 ],
 "No description available": [
  null,
  "აღწერა ხელმიუწვდომელია"
 ],
 "None": [
  null,
  "არცერთი"
 ],
 "Not authorized to disable the firewall": [
  null,
  "ბრანდმაუერის გამოსართავად საჭიროა ავტორიზაცია"
 ],
 "Not authorized to enable the firewall": [
  null,
  "ბრანდმაუერის ჩასართავად საჭიროა ავტორიზაცია"
 ],
 "Not available": [
  null,
  "ხელმიუწვდომელია"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "Options": [
  null,
  "პარამეტრები"
 ],
 "Parent": [
  null,
  "მშობელი"
 ],
 "Parent $parent": [
  null,
  "მშობელი $parent"
 ],
 "Part of $0": [
  null,
  "$0-ის ნაწილი"
 ],
 "Passive": [
  null,
  "პასიური"
 ],
 "Path cost": [
  null,
  "ბილიკის ღირებულება"
 ],
 "Path cost $path_cost": [
  null,
  "ბილიკის ფასი $path_cost"
 ],
 "Permanent": [
  null,
  "მუდმივი"
 ],
 "Ping interval": [
  null,
  "Ping-ის დაყოვნება"
 ],
 "Ping target": [
  null,
  "მიზნის დაპინგვა"
 ],
 "Please install the $0 package": [
  null,
  "დააყენეთ პაკეტი $0"
 ],
 "Port number and type do not match": [
  null,
  "პორტის ნომერი და ტიპი არ ემთხვევა"
 ],
 "Ports": [
  null,
  "პორტები"
 ],
 "Prefix length": [
  null,
  "პრეფიქსის სიგრძე"
 ],
 "Prefix length or netmask": [
  null,
  "პრეფიქსის სიგრძე ან ნეტმასკა"
 ],
 "Preparing": [
  null,
  "მომზადება"
 ],
 "Preserve": [
  null,
  "არ შეცვალო"
 ],
 "Primary": [
  null,
  "ძირითადი"
 ],
 "Priority": [
  null,
  "პრიორიტეტი"
 ],
 "Priority $priority": [
  null,
  "$priority პრიორიტეტი"
 ],
 "Random": [
  null,
  "შემთხვევითი"
 ],
 "Range": [
  null,
  "დიაპაზონი"
 ],
 "Range must be strictly ordered": [
  null,
  "დიაპაზონი მკაცრად უნდა იყოს განსაზღვრული"
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Receiving": [
  null,
  "მიღება"
 ],
 "Remove $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "$1 ზონიდან $0 სერვისის წაშლა"
 ],
 "Remove item": [
  null,
  "ელემენტის წაშლა"
 ],
 "Remove service $0": [
  null,
  "სერვისის წაშლა: $0"
 ],
 "Remove zone $0": [
  null,
  "ზონის წაშლა: $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის წაშლა გაწყვეტს კავშირს სერვერთან და შეუძლებელს გახდის ადმინისტრირების ინტერფეისთან წვდომას."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "cockpit-ის სერვისის წაშლამ შეიძლება ვებ კონსოლი მიუწვდომელი გახადოს. დარწმუნდით, რომ ზონის ცვლილება ვებ კონსოლთან კავშირს არ გაწყვეტს."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "ზონის წაშლა მასში მყოფი სერვისების წაშლასაც გამოიწევევს."
 ],
 "Restoring connection": [
  null,
  "კავშირის აღდგენა"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Routes": [
  null,
  "მარშრუტები"
 ],
 "Runner": [
  null,
  "გამშვები"
 ],
 "STP forward delay": [
  null,
  "STP გადამისამართების დაყოვნება"
 ],
 "STP hello time": [
  null,
  "STP hello-ის დრო"
 ],
 "STP maximum message age": [
  null,
  "STP შეტყობინების მაქსიმალური ასაკი"
 ],
 "STP priority": [
  null,
  "STP პრიორიტეტი"
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "Search domain": [
  null,
  "ძებნის დომენი"
 ],
 "Select method": [
  null,
  "აირჩიეთ მეთოდი"
 ],
 "Sending": [
  null,
  "გაგზავნა"
 ],
 "Server": [
  null,
  "სერვერი"
 ],
 "Service": [
  null,
  "სერვისი"
 ],
 "Services": [
  null,
  "სერვისები"
 ],
 "Set to": [
  null,
  "გაგზავნის მიმღები"
 ],
 "Shared": [
  null,
  "ზიარი"
 ],
 "Sorted from least to most trusted": [
  null,
  "დალაგებულია ყველაზე ნაკლებიდან ყველაზე მეტად სანდომდე"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "Stable": [
  null,
  "სტაბილური"
 ],
 "Start service": [
  null,
  "სერვისის გაშვება"
 ],
 "Status": [
  null,
  "მდგომარეობა"
 ],
 "Sticky": [
  null,
  "წებოვანი"
 ],
 "Switch of $0": [
  null,
  "$0-ის გამორთვა"
 ],
 "Switch off $0": [
  null,
  "$0-ის გამორთვა"
 ],
 "Switch on $0": [
  null,
  "$0-ის ჩართვა"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის გათიშვა დაარღვევს სერვერთან კავშირს და შეუძლებელს გახდის ადმინისტრირების ინტერფეისთან წვდომას."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "$0-ის ჩართვა დაარღვევს სერვერთან კავშირს და შეუძლებელს გახდის ადმინისტრირების ინტერფეისთან წვდომას."
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Team": [
  null,
  "გუნდი"
 ],
 "Team port": [
  null,
  "Team-ის პორტები"
 ],
 "Team port settings": [
  null,
  "გუნდური პორტის მორგება"
 ],
 "Team settings": [
  null,
  "Team-ის მორგება"
 ],
 "Testing connection": [
  null,
  "კავშირის შემოწმება"
 ],
 "The cockpit service is automatically included": [
  null,
  "Cocpit-ის სერვისი ავტომატურად მოჰყვება"
 ],
 "There are no active services in this zone": [
  null,
  "ამ ზონაში აქტიური სერვისები არ არსებობს"
 ],
 "This device cannot be managed here.": [
  null,
  "მოწყობილობა აქედან ვერ იმართება."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "ზონა შეიცავს cockpit-ის სერვისს. დარწმუნდით, რომ ზონის ცვლილება ვებ კონსოლის თქვენს მიმდინარე სესიას არ ბლოკავს."
 ],
 "Transmitting": [
  null,
  "გადაცემა"
 ],
 "Troubleshoot…": [
  null,
  "პრობლემების გადაწყვეტა…"
 ],
 "Trust level": [
  null,
  "ნდობის დონე"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unexpected error": [
  null,
  "მოულოდნელი შეცდომა"
 ],
 "Unknown": [
  null,
  "უცნობი"
 ],
 "Unknown \"$0\"": [
  null,
  "უცნობი \"$0\""
 ],
 "Unknown configuration": [
  null,
  "უცნობი კონფიგურაცია"
 ],
 "Unknown service name": [
  null,
  "სერვისის უცნობი სახელი"
 ],
 "Unmanaged interfaces": [
  null,
  "უმართავი ინტერფეისები"
 ],
 "Use": [
  null,
  "გამოყენება"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "VLAN settings": [
  null,
  "VLAN-ის მორგება"
 ],
 "View all logs": [
  null,
  "ყველა ჟურნალის ნახვა"
 ],
 "Waiting": [
  null,
  "მოლოდინი"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "დიახ"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "ბრანდმაუერის ჩასწორების წვდომა აკრძალულია."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[ბინარული მონაცემების $0 ბაიტი]"
 ],
 "[binary data]": [
  null,
  "[ბინარული მონაცემები]"
 ],
 "[no data]": [
  null,
  "[მონაცემების გარეშე]"
 ],
 "bond": [
  null,
  "გადაბმა"
 ],
 "bridge": [
  null,
  "ხიდი"
 ],
 "edit": [
  null,
  "ჩასწორება"
 ],
 "firewall": [
  null,
  "ბრანდმაუერი"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "ინტერფეისი"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "ქსელი"
 ],
 "port": [
  null,
  "პორტი"
 ],
 "show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "show more": [
  null,
  "მეტის ჩვენება"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "გუნდი"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "ზონა"
 ]
});
