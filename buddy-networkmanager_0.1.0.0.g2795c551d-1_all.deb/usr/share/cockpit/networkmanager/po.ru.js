cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "$0 active zone": [
  null,
  "$0 активная зона",
  "$0 активных зоны",
  "$0 активных зон"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дня",
  "$0 дней"
 ],
 "$0 hour": [
  null,
  "$0 час",
  "$0 часа",
  "$0 часов"
 ],
 "$0 minute": [
  null,
  "$0 минута",
  "$0 минуты",
  "$0 минут"
 ],
 "$0 month": [
  null,
  "$0 месяц",
  "$0 месяца",
  "$0 месяцев"
 ],
 "$0 week": [
  null,
  "$0 неделя",
  "$0 недели",
  "$0 недель"
 ],
 "$0 year": [
  null,
  "$0 год",
  "$0 года",
  "$0 лет"
 ],
 "$0 zone": [
  null,
  "Зона $0"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 час"
 ],
 "1 week": [
  null,
  "1 неделя"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "6 hours": [
  null,
  "6 часов"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Сетевое объединение сливает несколько сетевых интерфейсов в один логический интерфейс с увеличенной пропускной способностью или с избыточностью."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "Мониторинг ARP"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "Active": [
  null,
  "Активно"
 ],
 "Active backup": [
  null,
  "Активное резервирование"
 ],
 "Adaptive load balancing": [
  null,
  "Адаптивная балансировка нагрузки"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Адаптивная балансировка нагрузки передачи"
 ],
 "Add $0": [
  null,
  "Добавить $0"
 ],
 "Add VLAN": [
  null,
  "Добавить VLAN"
 ],
 "Add a new zone": [
  null,
  "Добавить новую зону"
 ],
 "Add bond": [
  null,
  "Добавить Bond"
 ],
 "Add bridge": [
  null,
  "Добавить Bridge"
 ],
 "Add item": [
  null,
  "Добавить элемент"
 ],
 "Add member": [
  null,
  "Добавить участник"
 ],
 "Add new zone": [
  null,
  "Добавить новую зону"
 ],
 "Add ports": [
  null,
  "Добавить порты"
 ],
 "Add ports to $0 zone": [
  null,
  "Добавить порты в зону $0"
 ],
 "Add services": [
  null,
  "Добавить службы"
 ],
 "Add services to $0 zone": [
  null,
  "Добавить сервисы в зону $0"
 ],
 "Add services to zone $0": [
  null,
  "Добавить службы в зону $0"
 ],
 "Add team": [
  null,
  "Добавить Team"
 ],
 "Add zone": [
  null,
  "Добавить зону"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Добавление $0 приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Добавление пользовательских портов приведёт к перезагрузке firewalld. При этом будет утеряна любая конфигурация среды выполнения."
 ],
 "Additional DNS $val": [
  null,
  "Дополнительный DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Дополнительные домены поиска DNS $val"
 ],
 "Additional address $val": [
  null,
  "Дополнительный адрес $val"
 ],
 "Additional ports": [
  null,
  "Дополнительные порты"
 ],
 "Address": [
  null,
  "Адрес"
 ],
 "Address $val": [
  null,
  "Адрес $val"
 ],
 "Addresses": [
  null,
  "Адреса"
 ],
 "Allowed addresses": [
  null,
  "Разрешённые адреса"
 ],
 "Authenticating": [
  null,
  "Проверка подлинности"
 ],
 "Automatic": [
  null,
  "Автоматически"
 ],
 "Automatic (DHCP only)": [
  null,
  "Автоматически (только DHCP)"
 ],
 "Automatic (DHCP)": [
  null,
  "Автоматически (DHCP)"
 ],
 "Balancer": [
  null,
  "Подсистема балансировки"
 ],
 "Bond": [
  null,
  "Объединение"
 ],
 "Bond settings": [
  null,
  "Параметры соединения"
 ],
 "Bridge": [
  null,
  "Мост"
 ],
 "Bridge port": [
  null,
  "Порт моста"
 ],
 "Bridge port settings": [
  null,
  "Параметры порта моста"
 ],
 "Bridge settings": [
  null,
  "Параметры моста"
 ],
 "Broadcast": [
  null,
  "Трансляция"
 ],
 "Broken configuration": [
  null,
  "Неверная конфигурация"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Carrier": [
  null,
  "Несущая частота"
 ],
 "Change the settings": [
  null,
  "Изменить параметры"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Изменение параметров приведёт к разрыву соединения с сервером и недоступности интерфейса администратора."
 ],
 "Checking IP": [
  null,
  "Проверка IP-адреса"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Допустимы порты, диапазоны и службы с запятыми в качестве разделителей"
 ],
 "Configuring": [
  null,
  "Настройка"
 ],
 "Configuring IP": [
  null,
  "Настройка IP-адреса"
 ],
 "Confirm removal of $0": [
  null,
  "Подтвердите удаление $0"
 ],
 "Connect automatically": [
  null,
  "Подключаться автоматически"
 ],
 "Connection will be lost": [
  null,
  "Подключение будет прервано"
 ],
 "Create it": [
  null,
  "Создать"
 ],
 "Custom ports": [
  null,
  "Настраиваемые порты"
 ],
 "Custom zones": [
  null,
  "Настраиваемые зоны"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "Домены поиска DNS"
 ],
 "DNS search domains $val": [
  null,
  "Домены поиска DNS $val"
 ],
 "Deactivating": [
  null,
  "Отключение"
 ],
 "Delete": [
  null,
  "Удалить"
 ],
 "Delete $0": [
  null,
  "Удалить $0"
 ],
 "Description": [
  null,
  "Описание"
 ],
 "Disable the firewall": [
  null,
  "Отключить межсетевой экран"
 ],
 "Disabled": [
  null,
  "Отключено"
 ],
 "Edit": [
  null,
  "Изменить"
 ],
 "Edit rules and zones": [
  null,
  ""
 ],
 "Enable service": [
  null,
  "Включить службу"
 ],
 "Enable the firewall": [
  null,
  "Включить межсетевой экран"
 ],
 "Enabled": [
  null,
  "Включено"
 ],
 "Entire subnet": [
  null,
  "Адрес всей подсети"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Пример: 22, ssh, 8080, 5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Пример: 88, 2019, nfs, rsync"
 ],
 "Failed": [
  null,
  "Сбой"
 ],
 "Failed to add port": [
  null,
  "Не удалось добавить порт"
 ],
 "Failed to add service": [
  null,
  "Не удалось добавить службу"
 ],
 "Failed to add zone": [
  null,
  "Не удалось добавить зону"
 ],
 "Filter services": [
  null,
  "Фильтровать службы"
 ],
 "Firewall": [
  null,
  "Межсетевой экран"
 ],
 "Firewall is not available": [
  null,
  "Межсетевой экран недоступен"
 ],
 "Forward delay $forward_delay": [
  null,
  "Задержка смены состояний $forward_delay"
 ],
 "General": [
  null,
  "Общее"
 ],
 "Go to now": [
  null,
  "Текущий момент"
 ],
 "Group": [
  null,
  ""
 ],
 "Hair pin mode": [
  null,
  "Режим NAT loopback"
 ],
 "Hairpin mode": [
  null,
  "Режим NAT loopback"
 ],
 "Hello time $hello_time": [
  null,
  "Время приветствия $hello_time"
 ],
 "ID": [
  null,
  "Идентификатор"
 ],
 "IP address": [
  null,
  "IP-адрес"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-адрес с префиксом маршрутизации. Несколько значений нужно разделять запятой. Например: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "Параметры IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "Параметры IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  ""
 ],
 "Ignore": [
  null,
  "Игнорировать"
 ],
 "Inactive": [
  null,
  "Неактивно"
 ],
 "Included services": [
  null,
  "Включённые службы"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  ""
 ],
 "Interfaces": [
  null,
  "Интерфейсы"
 ],
 "Invalid address $0": [
  null,
  "Недопустимый адрес $0"
 ],
 "Invalid metric $0": [
  null,
  "Недопустимая метрика $0"
 ],
 "Invalid port number": [
  null,
  "Недопустимый номер порта"
 ],
 "Invalid prefix $0": [
  null,
  "Недопустимый префикс $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Недопустимый префикс или сетевая маска $0"
 ],
 "Invalid range": [
  null,
  "Недопустимый диапазон"
 ],
 "Keep connection": [
  null,
  "Сохранить подключение"
 ],
 "LACP key": [
  null,
  "Ключ LACP"
 ],
 "Learn more": [
  null,
  "Подробнее..."
 ],
 "Link down delay": [
  null,
  "Задержка разрыва соединения"
 ],
 "Link local": [
  null,
  "Локальный адрес канала"
 ],
 "Link monitoring": [
  null,
  "Мониторинг ссылок"
 ],
 "Link up delay": [
  null,
  "Задержка установки соединения"
 ],
 "Link watch": [
  null,
  "Просмотр ссылок"
 ],
 "Load balancing": [
  null,
  "Балансировка нагрузки"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (рекомендуется)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "Значение MTU должно быть положительным числом"
 ],
 "Managing firewall": [
  null,
  "Управление межсетевым экраном"
 ],
 "Manual": [
  null,
  "Вручную"
 ],
 "Maximum message age $max_age": [
  null,
  "Максимальное время жизни сообщения $max_age"
 ],
 "Mode": [
  null,
  "Режим"
 ],
 "Monitoring interval": [
  null,
  "Интервал мониторинга"
 ],
 "Monitoring targets": [
  null,
  "Цели мониторинга"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Network bond": [
  null,
  "Сетевое объединение"
 ],
 "Networking": [
  null,
  "Сеть"
 ],
 "No": [
  null,
  "Нет"
 ],
 "No carrier": [
  null,
  "Нет несущей частоты"
 ],
 "No description available": [
  null,
  "Описание отсутствует"
 ],
 "None": [
  null,
  "Нет"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Нет прав для отключения межсетевого экрана"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Нет прав для включения межсетевого экрана"
 ],
 "Not available": [
  null,
  "Недоступно"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Options": [
  null,
  "Параметры"
 ],
 "Parent": [
  null,
  "Родительский элемент"
 ],
 "Parent $parent": [
  null,
  "Родительский элемент $parent"
 ],
 "Passive": [
  null,
  "Пассивно"
 ],
 "Path cost": [
  null,
  "Стоимость пути"
 ],
 "Path cost $path_cost": [
  null,
  "Стоимость пути $path_cost"
 ],
 "Permanent": [
  null,
  "Постоянный"
 ],
 "Ping interval": [
  null,
  "Интервал команды ping"
 ],
 "Ping target": [
  null,
  "Цель команды ping"
 ],
 "Please install the $0 package": [
  null,
  "Установите пакет $0"
 ],
 "Port number and type do not match": [
  null,
  "Номер и тип порта не совпадают"
 ],
 "Ports": [
  null,
  "Порты"
 ],
 "Prefix length": [
  null,
  "Длина префикса"
 ],
 "Prefix length or netmask": [
  null,
  "Длина префикса или маска сети"
 ],
 "Preparing": [
  null,
  "Подготовка"
 ],
 "Primary": [
  null,
  "Первичный интерфейс"
 ],
 "Priority": [
  null,
  "Приоритет"
 ],
 "Priority $priority": [
  null,
  "Приоритет $priority"
 ],
 "Random": [
  null,
  "Случайный"
 ],
 "Range": [
  null,
  "Диапазон"
 ],
 "Range must be strictly ordered": [
  null,
  "Диапазон должен быть строго упорядочен"
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Receiving": [
  null,
  "Приём"
 ],
 "Remove $0": [
  null,
  "Удалить $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Удалить службу $0 из зоны $1"
 ],
 "Remove service $0": [
  null,
  "Удалить службу $0"
 ],
 "Remove zone $0": [
  null,
  "Удалить зону $0"
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Удаление службы cockpit может привести к недоступности веб-консоли. Убедитесь, что эта зона не относится к вашему текущему подключению к веб-консоли."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Удаление зоны приведет к удалению всех служб в ней."
 ],
 "Restoring connection": [
  null,
  "Восстановление подключения"
 ],
 "Round robin": [
  null,
  "Циклический перебор"
 ],
 "Routes": [
  null,
  "Маршруты"
 ],
 "Runner": [
  null,
  "Средство запуска"
 ],
 "STP forward delay": [
  null,
  "Задержка смены состояний"
 ],
 "STP hello time": [
  null,
  "Время приветствия"
 ],
 "STP maximum message age": [
  null,
  "Максимальное время жизни сообщения"
 ],
 "STP priority": [
  null,
  "Приоритет"
 ],
 "Save": [
  null,
  "Сохранить"
 ],
 "Sending": [
  null,
  "Передача"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Service": [
  null,
  "Служба"
 ],
 "Services": [
  null,
  "Службы"
 ],
 "Set to": [
  null,
  "Установлено на"
 ],
 "Shared": [
  null,
  "С общим доступом"
 ],
 "Spanning tree protocol": [
  null,
  "Протокол связующего дерева"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Протокол связующего дерева (STP)"
 ],
 "Stable": [
  null,
  "Стабильный"
 ],
 "Start service": [
  null,
  "Запустить службу"
 ],
 "Status": [
  null,
  "Состояние"
 ],
 "Sticky": [
  null,
  "Закреплено"
 ],
 "Switch off $0": [
  null,
  "Отключить $0"
 ],
 "Switch on $0": [
  null,
  "Включить $0"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Team": [
  null,
  "Сопряжение"
 ],
 "Team port": [
  null,
  "Порт сопряжения"
 ],
 "Team port settings": [
  null,
  "Параметры порта сопряжения"
 ],
 "Team settings": [
  null,
  "Параметры сопряжения"
 ],
 "Testing connection": [
  null,
  "Проверка подключения"
 ],
 "The cockpit service is automatically included": [
  null,
  "Служба cockpit автоматически входит в состав"
 ],
 "There are no active services in this zone": [
  null,
  "В этой зоне нет активных служб"
 ],
 "This device cannot be managed here.": [
  null,
  "Этим устройством невозможно управлять здесь."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Эта зона содержит службу cockpit. Убедитесь, что эта зона не относится к текущему соединению веб-консоли."
 ],
 "Trust level": [
  null,
  "Уровень доверия"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unexpected error": [
  null,
  "Непредвиденная ошибка"
 ],
 "Unknown": [
  null,
  "Неизвестно"
 ],
 "Unknown \"$0\"": [
  null,
  "Неизвестно «$0»"
 ],
 "Unknown configuration": [
  null,
  "Неизвестная конфигурация"
 ],
 "Unknown service name": [
  null,
  "Неизвестное название службы"
 ],
 "Unmanaged interfaces": [
  null,
  "Неуправляемые интерфейсы"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN settings": [
  null,
  "Настройка VLAN"
 ],
 "View all logs": [
  null,
  ""
 ],
 "Waiting": [
  null,
  "Ожидание"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Да"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "У вас нет прав на изменение брандмауэра."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 байтов двоичных данных]"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "bond": [
  null,
  "привязка"
 ],
 "bridge": [
  null,
  "мост"
 ],
 "edit": [
  null,
  "редактировать"
 ],
 "firewall": [
  null,
  "Межсетевой экран"
 ],
 "interface": [
  null,
  "интерфейс"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "сеть"
 ],
 "port": [
  null,
  "порт"
 ],
 "show less": [
  null,
  "показать меньше"
 ],
 "show more": [
  null,
  "показать больше"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "команда"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "зона"
 ]
});
