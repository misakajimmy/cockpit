cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "$0 active zone": [
  null,
  "אזור פעיל",
  "שני אזורים פעילים",
  "$0 אזורים פעילים",
  "$0 אזורים פעילים"
 ],
 "$0 day": [
  null,
  "יום",
  "יומיים",
  "$0 ימים",
  "$0 ימים"
 ],
 "$0 hour": [
  null,
  "שעה",
  "שעתיים",
  "$0 שעות",
  "$0 שעות"
 ],
 "$0 minute": [
  null,
  "דקה",
  "$0 דקות",
  "$0 דקות",
  "$0 דקות"
 ],
 "$0 month": [
  null,
  "חודש",
  "חודשיים",
  "$0 חודשים",
  "$0 חודשים"
 ],
 "$0 week": [
  null,
  "שבוע",
  "שבועיים",
  "$0 שבועות",
  "$0 שבועות"
 ],
 "$0 year": [
  null,
  "שנה",
  "שנתיים",
  "$0 שנים",
  "$0 שנים"
 ],
 "$0 zone": [
  null,
  "אזור $0"
 ],
 "1 day": [
  null,
  "יום"
 ],
 "1 hour": [
  null,
  "שעה"
 ],
 "1 week": [
  null,
  "שבוע"
 ],
 "5 minutes": [
  null,
  "5 דקות"
 ],
 "6 hours": [
  null,
  "6 שעות"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "מאגד רשת משלב מספר מנשקי רשת למנשק לוגי אחד עם קצב העברה גבוה יותר או יתירות."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "מעקב אחר ARP"
 ],
 "ARP ping": [
  null,
  "פינג ARP"
 ],
 "Active": [
  null,
  "פעיל"
 ],
 "Active backup": [
  null,
  "גיבוי פעיל"
 ],
 "Adaptive load balancing": [
  null,
  "איזון עומס מסתגל"
 ],
 "Adaptive transmit load balancing": [
  null,
  "איזון עומס העברה מסתגל"
 ],
 "Add $0": [
  null,
  "הוספת $0"
 ],
 "Add VLAN": [
  null,
  "הוספת VLAN"
 ],
 "Add a new zone": [
  null,
  "הוספת אזור חדש"
 ],
 "Add bond": [
  null,
  "הוספת מאגד"
 ],
 "Add bridge": [
  null,
  "הוספת גשר"
 ],
 "Add item": [
  null,
  "הוספת פריט"
 ],
 "Add member": [
  null,
  "הוספת חבר"
 ],
 "Add new zone": [
  null,
  "הוספת אזור חדש"
 ],
 "Add ports": [
  null,
  "הוספת פתחות"
 ],
 "Add ports to $0 zone": [
  null,
  "הוספת פתחות לאזור $0"
 ],
 "Add services": [
  null,
  "הוספת שירותים"
 ],
 "Add services to $0 zone": [
  null,
  "הוספת שירותים לאזור $0"
 ],
 "Add services to zone $0": [
  null,
  "הוספת שירותים לאזור $0"
 ],
 "Add team": [
  null,
  "הוספת צוות"
 ],
 "Add zone": [
  null,
  "הוספת אזור"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "הוספת $0 תקטע את החיבור לשרת ותגרום לכך שמנשק הניהול לא יהיה זמין."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "הוספת פתחות מותאמות אישית תטען מחדש את firewalld. טעינה מחדש תגרום לאבדן של הגדרות שנקבעו לזמן הריצה בלבד!"
 ],
 "Additional DNS $val": [
  null,
  "$val נוסף ב־DNS"
 ],
 "Additional DNS search domains $val": [
  null,
  "חיפוש שמות תחום DNS נוספים $val"
 ],
 "Additional address $val": [
  null,
  "כתובת נוספת $val"
 ],
 "Additional ports": [
  null,
  "פתחות נוספות"
 ],
 "Address": [
  null,
  "כתובת"
 ],
 "Address $val": [
  null,
  "כתובת $val"
 ],
 "Addresses": [
  null,
  "כתובות"
 ],
 "Allowed addresses": [
  null,
  "כתובות מורשות"
 ],
 "Authenticating": [
  null,
  "מתבצע אימות"
 ],
 "Automatic": [
  null,
  "אוטומטית"
 ],
 "Automatic (DHCP only)": [
  null,
  "אוטומטית (DHCP בלבד)"
 ],
 "Automatic (DHCP)": [
  null,
  "אוטומטית (DHCP)"
 ],
 "Balancer": [
  null,
  "מאזן"
 ],
 "Bond": [
  null,
  "מאגד"
 ],
 "Bond settings": [
  null,
  "הגדרות מאגד"
 ],
 "Bridge": [
  null,
  "גשר"
 ],
 "Bridge port": [
  null,
  "פתחת גשר"
 ],
 "Bridge port settings": [
  null,
  "הגדרות פתחת גשר"
 ],
 "Bridge settings": [
  null,
  "הגדרות גשר"
 ],
 "Broadcast": [
  null,
  "שידור"
 ],
 "Broken configuration": [
  null,
  "הגדרות פגומות"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Carrier": [
  null,
  "ספקית"
 ],
 "Change the settings": [
  null,
  "שינוי ההגדרות"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "שינוי ההגדרות יפגע בחיבור לשרת וימנע את הגישה למנשק הניהול."
 ],
 "Checking IP": [
  null,
  "ה־IP נבדק"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "פתחות, טווחים ושירותים מופרדים בפסיקים יתקבלו"
 ],
 "Configuring": [
  null,
  "מתבצעת הגדרה"
 ],
 "Configuring IP": [
  null,
  "מוגדרת כתובת IP"
 ],
 "Confirm removal of $0": [
  null,
  "אישור הסרת $0"
 ],
 "Connect automatically": [
  null,
  "התחברות אוטומטית"
 ],
 "Connection will be lost": [
  null,
  "החיבור יאבד"
 ],
 "Create it": [
  null,
  "ליצור אותו"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "יצירת ה־$0 הזה תקטע את החיבור לשרת ותמנע את הגישה למנשק הניהול."
 ],
 "Custom ports": [
  null,
  "פתחות מותאמות אישית"
 ],
 "Custom zones": [
  null,
  "אזורים מותאמים אישית"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "חיפוש שמות תחום DNS"
 ],
 "DNS search domains $val": [
  null,
  "חיפוש שמות תחום DNS‏ $val"
 ],
 "Deactivating": [
  null,
  "מתבצעת השבתה"
 ],
 "Delete": [
  null,
  "מחיקה"
 ],
 "Delete $0": [
  null,
  "מחיקת $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "מחיקת $0 תקטע את החיבור לשרת ותמנע את הגישה למנשק הניהול."
 ],
 "Description": [
  null,
  "תיאור"
 ],
 "Disable the firewall": [
  null,
  "השבתת חומת האש"
 ],
 "Disabled": [
  null,
  "מושבת"
 ],
 "Edit": [
  null,
  "עריכה"
 ],
 "Edit rules and zones": [
  null,
  "עריכת כללים ואזורים"
 ],
 "Edit service": [
  null,
  "עריכת שירות"
 ],
 "Edit service $0": [
  null,
  "עריכת השירות $0"
 ],
 "Enable or disable the device": [
  null,
  "להפעיל או להשבית את ההתקן"
 ],
 "Enable service": [
  null,
  "הפעלת שירות"
 ],
 "Enable the firewall": [
  null,
  "הפעלת חומת האש"
 ],
 "Enabled": [
  null,
  "מופעל"
 ],
 "Enter a valid MAC address": [
  null,
  "נא למלא כתובת MAC תקנית"
 ],
 "Entire subnet": [
  null,
  "כל תת־הרשת"
 ],
 "Ethernet MAC": [
  null,
  "כתובת חומרת אתרנט"
 ],
 "Ethernet MTU": [
  null,
  "יחידת העברה מרבית של אתרנט"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "לדוגמה: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "לדוגמה: 88,2019,nfs,rsync"
 ],
 "Failed": [
  null,
  "נכשל"
 ],
 "Failed to add port": [
  null,
  "הוספת הפתחה נכשלה"
 ],
 "Failed to add service": [
  null,
  "הוספת השירות נכשל"
 ],
 "Failed to add zone": [
  null,
  "הוספת האזור נכשלה"
 ],
 "Failed to edit service": [
  null,
  "עריכת השירות נכשלה"
 ],
 "Failed to save settings": [
  null,
  "שמירת ההגדרות נכשלה"
 ],
 "Filter services": [
  null,
  "סינון שירותים"
 ],
 "Firewall": [
  null,
  "חומת אש"
 ],
 "Firewall is not available": [
  null,
  "חומת האש אינה זמינה"
 ],
 "Forward delay $forward_delay": [
  null,
  "השהיית העברה $forward_delay"
 ],
 "Gateway": [
  null,
  "שער גישה"
 ],
 "General": [
  null,
  "כללי"
 ],
 "Go to now": [
  null,
  "לעבור כעת"
 ],
 "Group": [
  null,
  "קבוצה"
 ],
 "Hair pin mode": [
  null,
  "מצב סיכת שיער"
 ],
 "Hairpin mode": [
  null,
  "מצב סיכת שיער"
 ],
 "Hello time $hello_time": [
  null,
  "זמן Hello‏ $hello_time"
 ],
 "ID": [
  null,
  "מזהה"
 ],
 "ID $id": [
  null,
  "מזהה $id"
 ],
 "IP address": [
  null,
  "כתובת IP"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "כתובת IP עם קידומת ניתוב. יש להפריד בין ערכים בפסיק. למשל: 192.0.2.0/24, ‎2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "הגדרות IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "הגדרות IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  ""
 ],
 "Ignore": [
  null,
  "התעלמות"
 ],
 "Inactive": [
  null,
  "לא פעיל"
 ],
 "Included services": [
  null,
  "שירותים כלולים"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "בקשות נכנסות נחסמות כברירת מחדל. בקשות יוצאות לא נחסמות."
 ],
 "Interface": [
  null,
  "מנשק",
  "מנשקים",
  "מנשקים",
  "מנשקים"
 ],
 "Interface members": [
  null,
  "חברים במנשק"
 ],
 "Interfaces": [
  null,
  "מנשקים"
 ],
 "Invalid address $0": [
  null,
  "כתובת שגויה $0"
 ],
 "Invalid metric $0": [
  null,
  "מדד שגוי $0"
 ],
 "Invalid port number": [
  null,
  "מספר הפתחה שגוי"
 ],
 "Invalid prefix $0": [
  null,
  "קידומת שגויה $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "קידומת או מסכת רשת שגויה $0"
 ],
 "Invalid range": [
  null,
  "טווח שגוי"
 ],
 "Keep connection": [
  null,
  "לשמור על החיבור"
 ],
 "LACP key": [
  null,
  "מפתח LACP"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "Link down delay": [
  null,
  "השהיית קטיעת קישור"
 ],
 "Link local": [
  null,
  "קישור מקומי"
 ],
 "Link monitoring": [
  null,
  "מעקב אחר קישורים"
 ],
 "Link up delay": [
  null,
  "השהיית חיבור קישור"
 ],
 "Link watch": [
  null,
  "עקיבה אחר קישורים"
 ],
 "Load balancing": [
  null,
  "איזון עומס"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (מומלץ)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU חייב להיות מספר חיובי"
 ],
 "Managed interfaces": [
  null,
  "מנשקים מנוהלים"
 ],
 "Managing VLANs": [
  null,
  "ניהול VLANים"
 ],
 "Managing firewall": [
  null,
  "ניהול חומת אש"
 ],
 "Managing networking bonds": [
  null,
  "ניהול מאגדי רשת"
 ],
 "Managing networking bridges": [
  null,
  "ניהול גישורי רשת"
 ],
 "Managing networking teams": [
  null,
  "ניהול ציוותי רשת"
 ],
 "Manual": [
  null,
  "ידני"
 ],
 "Maximum message age $max_age": [
  null,
  "גיל הודעה מרבי $max_age"
 ],
 "Metric": [
  null,
  "מדד"
 ],
 "Mode": [
  null,
  "מצב"
 ],
 "Monitoring interval": [
  null,
  "הפרש בין דגימות מעקב"
 ],
 "Monitoring targets": [
  null,
  "יעדי מעקב"
 ],
 "NSNA ping": [
  null,
  "פינג מסוג NSNA"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Network bond": [
  null,
  "מאגד רשת"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "התקני רשת ותרשימים דורשים NetworkManager"
 ],
 "Network logs": [
  null,
  "יומני תקשורת"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager אינו מותקן"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager אינו פעיל"
 ],
 "Networking": [
  null,
  "תקשורת"
 ],
 "No": [
  null,
  "לא"
 ],
 "No carrier": [
  null,
  "אין ספקית"
 ],
 "No description available": [
  null,
  "אין תיאור זמין"
 ],
 "None": [
  null,
  "אין"
 ],
 "Not authorized to disable the firewall": [
  null,
  "לא מורשה להשבית את חומת האש"
 ],
 "Not authorized to enable the firewall": [
  null,
  "לא מורשה להפעיל את חומת האש"
 ],
 "Not available": [
  null,
  "לא זמין"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "Options": [
  null,
  "אפשרויות"
 ],
 "Parent": [
  null,
  "הורה"
 ],
 "Parent $parent": [
  null,
  "$parent הורה"
 ],
 "Part of $0": [
  null,
  "חלק מתוך $0"
 ],
 "Passive": [
  null,
  "סביל"
 ],
 "Path cost": [
  null,
  "עלות נתיב"
 ],
 "Path cost $path_cost": [
  null,
  "עלות הנתיב $path_cost"
 ],
 "Permanent": [
  null,
  "קבוע"
 ],
 "Ping interval": [
  null,
  "הפרש בין פינגים"
 ],
 "Ping target": [
  null,
  "יעד פינג"
 ],
 "Please install the $0 package": [
  null,
  "נא להתקין את החבילה $0"
 ],
 "Port number and type do not match": [
  null,
  "מספר הפתחה והסוג אינם תואמים"
 ],
 "Ports": [
  null,
  "פתחות"
 ],
 "Prefix length": [
  null,
  "אורך קידומת"
 ],
 "Prefix length or netmask": [
  null,
  "אורך קידומת או מסכת רשת"
 ],
 "Preparing": [
  null,
  "בהכנה"
 ],
 "Primary": [
  null,
  "עיקרי"
 ],
 "Priority": [
  null,
  "עדיפות"
 ],
 "Priority $priority": [
  null,
  "עדיפות $priority"
 ],
 "Random": [
  null,
  "אקראי"
 ],
 "Range": [
  null,
  "טווח"
 ],
 "Range must be strictly ordered": [
  null,
  "הטווח חייב להיות מסודר בקפידה"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Receiving": [
  null,
  "קבלה"
 ],
 "Remove $0": [
  null,
  "הסרת $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "הסרת השירות $0 מהאזור $1"
 ],
 "Remove service $0": [
  null,
  "הסרת השירות $0"
 ],
 "Remove zone $0": [
  null,
  "הסרת האזור $0"
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "הסרת השירות cockpit עלול לגרום לקטיעת שירות המסוף המקוון. נא לוודא שאזור זה אינו חל על חיבור המסוף המקוון הנוכחי שלך."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "הסרת האזור תסיר את כל השירותים שבו."
 ],
 "Restoring connection": [
  null,
  "החיבור משוחזר"
 ],
 "Round robin": [
  null,
  "ראונד-רובין"
 ],
 "Routes": [
  null,
  "ניתובים"
 ],
 "Runner": [
  null,
  "שליח"
 ],
 "STP forward delay": [
  null,
  "השהיית העברת STP"
 ],
 "STP hello time": [
  null,
  "זמן Hello של STP"
 ],
 "STP maximum message age": [
  null,
  "גיל ההודעה המרבי של STP"
 ],
 "STP priority": [
  null,
  "עדיפות STP"
 ],
 "Save": [
  null,
  "שמירה"
 ],
 "Sending": [
  null,
  "שליחה"
 ],
 "Server": [
  null,
  "שרת"
 ],
 "Service": [
  null,
  "שירות"
 ],
 "Services": [
  null,
  "שירותים"
 ],
 "Set to": [
  null,
  "הגדרה לכדי"
 ],
 "Shared": [
  null,
  "משותף"
 ],
 "Sorted from least to most trusted": [
  null,
  "מסודר מהכי מהימן להכי פחות"
 ],
 "Spanning tree protocol": [
  null,
  "פרוטוקול העץ הפורש"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "פרוטוקול העץ הפורש (STP)"
 ],
 "Stable": [
  null,
  "יציב"
 ],
 "Start service": [
  null,
  "התחלת שירות"
 ],
 "Status": [
  null,
  "מצב"
 ],
 "Sticky": [
  null,
  "דביק"
 ],
 "Switch of $0": [
  null,
  "כיבוי $0"
 ],
 "Switch off $0": [
  null,
  "כיבוי $0"
 ],
 "Switch on $0": [
  null,
  "הדלקת $0"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Team": [
  null,
  "ציוות"
 ],
 "Team port": [
  null,
  "פתחת ציוות"
 ],
 "Team port settings": [
  null,
  "הגדרות פתחת ציוות"
 ],
 "Team settings": [
  null,
  "הגדרות ציוות"
 ],
 "Testing connection": [
  null,
  "החיבור נבדק"
 ],
 "The cockpit service is automatically included": [
  null,
  "שירות ה־cockpit נכלל אוטומטית"
 ],
 "There are no active services in this zone": [
  null,
  "אין שירותים פעילים באזור הזה"
 ],
 "This device cannot be managed here.": [
  null,
  "לא ניתן לנהל את ההתקן הזה כאן."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "אזור זה מכיל את שירות ה־Cockpit. נא לוודא שאזור זה אינו חל על חיבור המסוף המקוון הנוכחי שלך."
 ],
 "Troubleshoot…": [
  null,
  "פתרון תקלות…"
 ],
 "Trust level": [
  null,
  "רמת אמון"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unexpected error": [
  null,
  "שגיאה בלתי צפויה"
 ],
 "Unknown": [
  null,
  "לא ידוע"
 ],
 "Unknown \"$0\"": [
  null,
  "„$0” לא ידוע"
 ],
 "Unknown configuration": [
  null,
  "הגדרות לא ידועות"
 ],
 "Unknown service name": [
  null,
  "שם השירות לא ידוע"
 ],
 "Unmanaged interfaces": [
  null,
  "מנשקים לא מנוהלים"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "מזהה VLAN"
 ],
 "VLAN settings": [
  null,
  "הגדרות VLAN"
 ],
 "Waiting": [
  null,
  "בהמתנה"
 ],
 "XOR": [
  null,
  "XOR (קסור)"
 ],
 "Yes": [
  null,
  "כן"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "אין לך הרשאה לשנות את חומת האש."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 בתים של נתונים בינריים]"
 ],
 "[binary data]": [
  null,
  "[נתונים בינריים]"
 ],
 "[no data]": [
  null,
  "[אין נתונים]"
 ],
 "bond": [
  null,
  "מאגד"
 ],
 "bridge": [
  null,
  "גשר"
 ],
 "edit": [
  null,
  "עריכה"
 ],
 "firewall": [
  null,
  "חומת אש"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "מנשק"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "רשת"
 ],
 "port": [
  null,
  "פתחה"
 ],
 "show less": [
  null,
  "להציג פחות"
 ],
 "show more": [
  null,
  "להציג יותר"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "ציוות"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "אזור"
 ]
});
