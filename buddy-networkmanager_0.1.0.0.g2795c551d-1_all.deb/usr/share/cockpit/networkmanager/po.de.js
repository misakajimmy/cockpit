cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 active zone": [
  null,
  "$0 aktive Zone",
  "$0 aktive Zonen"
 ],
 "$0 day": [
  null,
  "$0 Tag",
  "$0 Tage"
 ],
 "$0 hour": [
  null,
  "$0 Stunde",
  "$0 Stunden"
 ],
 "$0 minute": [
  null,
  "$0 Minute",
  "$0 Minuten"
 ],
 "$0 month": [
  null,
  "$0 Monat",
  "$0 Monate"
 ],
 "$0 week": [
  null,
  "$0 Woche",
  "$0 Wochen"
 ],
 "$0 year": [
  null,
  "$0 Jahr",
  "$0 Jahre"
 ],
 "$0 zone": [
  null,
  "$0 Zone"
 ],
 "1 day": [
  null,
  "1 Tag"
 ],
 "1 hour": [
  null,
  "1 Stunde"
 ],
 "1 week": [
  null,
  "1 Woche"
 ],
 "5 minutes": [
  null,
  "5 Minuten"
 ],
 "6 hours": [
  null,
  "6 Stunden"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Ein gebündelter Netzwerkadapter kombiniert mehrere Netzweradapter zu einem logischen Netzwerkadapter mit mehr Durchsatz und Redundanz."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP-Überwachung"
 ],
 "ARP ping": [
  null,
  "ARP-Ping"
 ],
 "Active": [
  null,
  "Aktiv"
 ],
 "Active backup": [
  null,
  "Aktive Sicherung"
 ],
 "Adaptive load balancing": [
  null,
  "Adaptiver Lastausgleich (alb)"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Adaptiver Sendeausgleich (tlb)"
 ],
 "Add $0": [
  null,
  "$0 hinzufügen"
 ],
 "Add VLAN": [
  null,
  "VLAN hinzufügen"
 ],
 "Add a new zone": [
  null,
  "Neue Zone hinzufügen"
 ],
 "Add bond": [
  null,
  "Bündelung hinzufügen"
 ],
 "Add bridge": [
  null,
  "Bridge hinzufügen"
 ],
 "Add item": [
  null,
  "Element hinzufügen"
 ],
 "Add member": [
  null,
  "Mitglied hinzufügen"
 ],
 "Add new zone": [
  null,
  "Neue Zone hinzufügen"
 ],
 "Add ports": [
  null,
  "Ports hinzufügen"
 ],
 "Add ports to $0 zone": [
  null,
  "Ports zu Zone $0 hinzufügen"
 ],
 "Add services": [
  null,
  "Dienste hinzufügen"
 ],
 "Add services to $0 zone": [
  null,
  "Services zu Zone $0 hinzufügen"
 ],
 "Add services to zone $0": [
  null,
  "Services zu Zone $0 hinzufügen"
 ],
 "Add team": [
  null,
  "Team hinzufügen"
 ],
 "Add zone": [
  null,
  "Zone hinzufügen"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Hinzufügen von $0 unterbricht die Verbindung zum Server und macht die Administrationsoberfläche nicht mehr verfügbar."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Das Hinzufügen von eigenen Ports wird firewalld neu starten. Ein Neustart setzt alle Freischaltungen auf Laufzeitebene zurück!"
 ],
 "Additional DNS $val": [
  null,
  "Zusätzliches DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Zusätzliche DNS-Suchdomänen $val"
 ],
 "Additional address $val": [
  null,
  "Zusätzliche Adresse $val"
 ],
 "Additional ports": [
  null,
  "Mehr Ports"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "Address $val": [
  null,
  "Adresse $val"
 ],
 "Addresses": [
  null,
  "Adressen"
 ],
 "Allowed addresses": [
  null,
  "Erlaubte Adressen"
 ],
 "Authenticating": [
  null,
  "Authentifiziere"
 ],
 "Automatic": [
  null,
  "Automatisch"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatisch (nur DHCP)"
 ],
 "Automatic (DHCP)": [
  null,
  "Automatisch (DHCP)"
 ],
 "Balancer": [
  null,
  "Balancer"
 ],
 "Bond": [
  null,
  "Bond"
 ],
 "Bond settings": [
  null,
  "Bond-Einstellungen"
 ],
 "Bridge": [
  null,
  "Netzwerkbrücke"
 ],
 "Bridge port": [
  null,
  "Netzwerkbrücken-Port"
 ],
 "Bridge port settings": [
  null,
  "Netzwerkbrücke-Port-Einstellungen"
 ],
 "Bridge settings": [
  null,
  "Netzwerkbrücke-Einstellungen"
 ],
 "Broadcast": [
  null,
  "Broadcast"
 ],
 "Broken configuration": [
  null,
  "Fehlerhafte Konfiguration"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Carrier": [
  null,
  "Träger"
 ],
 "Change the settings": [
  null,
  "Bridge Port-Einstellungen"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Ändern der Einstellungen wird die Verbindung zum Server unterbrechen und damit den Zugriff auf die Benutzeroberfläche unmöglich machen."
 ],
 "Checking IP": [
  null,
  "IP wird überprüft"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Komma-separierte Ports, Bereiche und Dienste sind erlaubt"
 ],
 "Configuring": [
  null,
  "Konfiguriere"
 ],
 "Configuring IP": [
  null,
  "Konfiguriere IP"
 ],
 "Confirm removal of $0": [
  null,
  "Betätigen sie das entfernen von $0"
 ],
 "Connect automatically": [
  null,
  "Verbindung automatisch herstellen"
 ],
 "Connection will be lost": [
  null,
  "Verbindung geht verloren"
 ],
 "Create it": [
  null,
  "Anlegen"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Die Erstellung dieser $0 unterbricht die Verbindung zum Server und macht die Administrationsoberfläche nicht mehr erreichbar."
 ],
 "Custom ports": [
  null,
  "Eigene Ports"
 ],
 "Custom zones": [
  null,
  "Eigene Zonen"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS Suchdomänen"
 ],
 "DNS search domains $val": [
  null,
  "DNS-Suchdomänen $val"
 ],
 "Deactivating": [
  null,
  "Wird deaktiviert"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Delete $0": [
  null,
  "$0 löschen"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Löschen von $0 unterbricht die Verbindung zum Server und macht die Administrationsoberfläche nicht mehr erreichbar."
 ],
 "Description": [
  null,
  "Beschreibung"
 ],
 "Disable the firewall": [
  null,
  "Firewall deaktivieren"
 ],
 "Disabled": [
  null,
  "Deaktiviert"
 ],
 "Edit": [
  null,
  "Bearbeiten"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Bearbeiten des eigenen Service in Zone $0"
 ],
 "Edit rules and zones": [
  null,
  "Regeln und Zonen bearbeiten"
 ],
 "Edit service": [
  null,
  "Dienst bearbeiten"
 ],
 "Edit service $0": [
  null,
  "Dienst $0 bearbeiten"
 ],
 "Enable or disable the device": [
  null,
  "Gerät aktivieren oder deaktivieren"
 ],
 "Enable service": [
  null,
  "Service aktivieren"
 ],
 "Enable the firewall": [
  null,
  "Firewall aktivieren"
 ],
 "Enabled": [
  null,
  "Aktiviert"
 ],
 "Enter a valid MAC address": [
  null,
  "Geben Sie eine gültige MAC-Adresse ein"
 ],
 "Entire subnet": [
  null,
  "Gesamtes Subnetzwerk"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet-MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet-MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Beispiel: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Beispiel: 88,2019,nfs,rsync"
 ],
 "Failed": [
  null,
  "Fehlgeschlagen"
 ],
 "Failed to add port": [
  null,
  "Hinzufügen des Portes fehlgeschlagen"
 ],
 "Failed to add service": [
  null,
  "Hinzufügen des Services fehlgeschlagen"
 ],
 "Failed to add zone": [
  null,
  "Hinzufügen der Zone fehlgeschlagen"
 ],
 "Failed to edit service": [
  null,
  "Fehler bei der Bearbeitung des Dienstes"
 ],
 "Failed to save settings": [
  null,
  "Fehler beim Speichern der Einstellungen"
 ],
 "Filter services": [
  null,
  "Filterdienste"
 ],
 "Firewall": [
  null,
  "Firewall"
 ],
 "Firewall is not available": [
  null,
  "Firewall ist nicht verfügbar"
 ],
 "Forward delay $forward_delay": [
  null,
  "Weiterleitungsverzögerung $forward_delay"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "General": [
  null,
  "Allgemein"
 ],
 "Go to now": [
  null,
  "Zu 'Jetzt' gehen"
 ],
 "Group": [
  null,
  "Gruppe"
 ],
 "Hair pin mode": [
  null,
  "Hairpin Modus"
 ],
 "Hairpin mode": [
  null,
  "Hairpin-Modus"
 ],
 "Hello time $hello_time": [
  null,
  "Hello-Zeit $hello_time"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP address": [
  null,
  "IP-Adresse"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-Adresse mit Routing-Präfix. Trennen Sie mehrere Werte mit einem Komma. Beispiel: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "IPv4-Einstellungen"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "IPv6-Einstellungen"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Wenn leer, wird die Kennung auf Basis der zugehörigen Port-Dienste und Port-Nummern generiert"
 ],
 "Ignore": [
  null,
  "Ignorieren"
 ],
 "Inactive": [
  null,
  "Inaktiv"
 ],
 "Included services": [
  null,
  "Enthaltene Dienste"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Eingehende Anfragen werden standardmäßig blockiert. Ausgehende Anfragen werden nicht blockiert."
 ],
 "Interface": [
  null,
  "Schnittstelle",
  "Schnittstellen"
 ],
 "Interface members": [
  null,
  "Schnittstellenmitglieder"
 ],
 "Interfaces": [
  null,
  "Schnittstellen"
 ],
 "Invalid address $0": [
  null,
  "Ungültige Adresse $0"
 ],
 "Invalid metric $0": [
  null,
  "Ungültige Metrik $0"
 ],
 "Invalid port number": [
  null,
  "Ungültige Port-Nummer"
 ],
 "Invalid prefix $0": [
  null,
  "Ungültiger Prefix $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Port"
 ],
 "Invalid range": [
  null,
  "Ungültiger Bereich"
 ],
 "Keep connection": [
  null,
  "Verbindung halten"
 ],
 "LACP key": [
  null,
  "LACP-Schlüssel"
 ],
 "Learn more": [
  null,
  "Mehr erfahren"
 ],
 "Link down delay": [
  null,
  "Verzögerung bei der Deaktivierung einer Verbindung"
 ],
 "Link local": [
  null,
  "Link local"
 ],
 "Link monitoring": [
  null,
  "Verbindungsüberwachung"
 ],
 "Link up delay": [
  null,
  "Verzögerung bei der Aktivierung einer Verbindung"
 ],
 "Link watch": [
  null,
  "Link beobachten"
 ],
 "Load balancing": [
  null,
  "Lastverteilung"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (empfohlen)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU muss eine positive Zahl sein"
 ],
 "Managed interfaces": [
  null,
  "Verwaltete Schnittstellen"
 ],
 "Managing VLANs": [
  null,
  "VLANs verwalten"
 ],
 "Managing firewall": [
  null,
  "Firewall verwalten"
 ],
 "Managing networking bonds": [
  null,
  ""
 ],
 "Managing networking bridges": [
  null,
  "Netzwerkbrücken verwalten"
 ],
 "Managing networking teams": [
  null,
  ""
 ],
 "Manual": [
  null,
  "Manuell"
 ],
 "Maximum message age $max_age": [
  null,
  "Maximales Alter der Nachrichten $max_age"
 ],
 "Metric": [
  null,
  "Kennzahlen"
 ],
 "Mode": [
  null,
  "Modus"
 ],
 "Monitoring interval": [
  null,
  "Überwachungsintervall"
 ],
 "Monitoring targets": [
  null,
  "Überwachungsziele"
 ],
 "NSNA ping": [
  null,
  "NSNA-Ping"
 ],
 "Name": [
  null,
  "Name"
 ],
 "Network bond": [
  null,
  ""
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Netzwerkgeräte und -diagramme erfordern NetworkManager"
 ],
 "Network logs": [
  null,
  "Netzwerkprotokolle"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager ist nicht installiert"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager wird nicht ausgeführt"
 ],
 "Networking": [
  null,
  "Netzwerk"
 ],
 "No": [
  null,
  "Nein"
 ],
 "No carrier": [
  null,
  "Kein Träger"
 ],
 "No description available": [
  null,
  "Keine Beschreibung verfügbar"
 ],
 "None": [
  null,
  "Kein"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Keine Berechtigung, die Firewall zu deaktivieren"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Keine Berechtigung, die Firewall zu aktivieren"
 ],
 "Not available": [
  null,
  "Nicht verfügbar"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Options": [
  null,
  "Einstellungen"
 ],
 "Parent": [
  null,
  "Parent"
 ],
 "Parent $parent": [
  null,
  "Parent $parent"
 ],
 "Part of $0": [
  null,
  "Teil von $0"
 ],
 "Passive": [
  null,
  "Passiv"
 ],
 "Path cost": [
  null,
  "Pfadkosten"
 ],
 "Path cost $path_cost": [
  null,
  "Pfadkosten $path_cost"
 ],
 "Permanent": [
  null,
  "Permanent"
 ],
 "Ping interval": [
  null,
  "Ping-Intervall"
 ],
 "Ping target": [
  null,
  "Ping-Ziel"
 ],
 "Please install the $0 package": [
  null,
  "Bitte installieren Sie die $0 Paket"
 ],
 "Port number and type do not match": [
  null,
  "Portnummer und -typ passen nicht zusammen"
 ],
 "Ports": [
  null,
  "Ports"
 ],
 "Prefix length": [
  null,
  "Präfixlänge"
 ],
 "Prefix length or netmask": [
  null,
  "Präfix oder Netzmaske"
 ],
 "Preparing": [
  null,
  "Vorbereitung läuft"
 ],
 "Preserve": [
  null,
  "Beibehalten"
 ],
 "Primary": [
  null,
  "Primär"
 ],
 "Priority": [
  null,
  "Priorität"
 ],
 "Priority $priority": [
  null,
  "Priorität $priority"
 ],
 "Random": [
  null,
  "Zufällig"
 ],
 "Range": [
  null,
  "Bereich"
 ],
 "Range must be strictly ordered": [
  null,
  "Bereich muss strikt geordnet sein"
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Receiving": [
  null,
  "Empfangen"
 ],
 "Remove $0": [
  null,
  "Entferne $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Dienst $0 aus der Zone $1 entfernen"
 ],
 "Remove item": [
  null,
  "Element entfernen"
 ],
 "Remove service $0": [
  null,
  "Service $0 entfernen"
 ],
 "Remove zone $0": [
  null,
  "Zone $0 entfernen"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Entfernen von $0 wird die Verbindung zum Server unterbrechen und damit den Zugriff auf die Benutzeroberfläche unmöglich machen."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Das entfernen des Cockpit-Services kann die Web Konsole nicht mehr erreichbar machen. Stelen sie sicher, dass die Zone keine Auswirkungen auf ihre aktuelle Web Konsolen Verbindung hat."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Das entfernen der Zone wird alle Service in ihr entfernen."
 ],
 "Restoring connection": [
  null,
  "Verbindung wird wiederhergestellt"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Routes": [
  null,
  "Routen"
 ],
 "Runner": [
  null,
  "Runner"
 ],
 "STP forward delay": [
  null,
  "STP Forward Delay"
 ],
 "STP hello time": [
  null,
  "STP Hello-Zeitintervall"
 ],
 "STP maximum message age": [
  null,
  "STP Maximum Message Age"
 ],
 "STP priority": [
  null,
  "STP-Priorität"
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "Search domain": [
  null,
  "Suchdomäne"
 ],
 "Select method": [
  null,
  "Methode auswählen"
 ],
 "Sending": [
  null,
  "Senden"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Service": [
  null,
  "Dienst"
 ],
 "Services": [
  null,
  "Dienste"
 ],
 "Set to": [
  null,
  "Einstellen"
 ],
 "Shared": [
  null,
  "Geteilt"
 ],
 "Sorted from least to most trusted": [
  null,
  "Sortiert von am wenigsten bis am meisten vertrauenswürdig"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "Stable": [
  null,
  "Stabil"
 ],
 "Start service": [
  null,
  "Dienst starten"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Sticky": [
  null,
  "Sticky"
 ],
 "Switch of $0": [
  null,
  ""
 ],
 "Switch off $0": [
  null,
  "$0 ausschalten"
 ],
 "Switch on $0": [
  null,
  "$0 anschalten"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Ausschalten von $0 wird die Verbindung zum Server unterbrechen und damit den Zugriff auf die Benutzeroberfläche unmöglich machen."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Das Einschalten von $0 wird die Verbindung zum Server unterbrechen und damit den Zugriff auf die Benutzeroberfläche unmöglich machen."
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Team": [
  null,
  "Team"
 ],
 "Team port": [
  null,
  "Netzwerk-Team Anschluss"
 ],
 "Team port settings": [
  null,
  "Team port Einstellungen"
 ],
 "Team settings": [
  null,
  "Team Einstellungen"
 ],
 "Testing connection": [
  null,
  "Prüfe Verbindung"
 ],
 "The cockpit service is automatically included": [
  null,
  "Der Cockpit-Dienst ist automatisch enthalten"
 ],
 "There are no active services in this zone": [
  null,
  "In dieser Zone gibt es keine aktiven Dienste"
 ],
 "This device cannot be managed here.": [
  null,
  "Dieses Gerät kann hier nicht verwaltet werden."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Diese Zone enthält den Cockpit-Dienst. Stellen Sie sicher, dass diese Zone nicht auf Ihre aktuelle Web-Konsolenverbindung angewendet wird."
 ],
 "Transmitting": [
  null,
  "Wird übertragen"
 ],
 "Troubleshoot…": [
  null,
  "Fehlerbehebung…"
 ],
 "Trust level": [
  null,
  "Vertrauensstufe"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unexpected error": [
  null,
  "Unerwarteter Fehler"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ],
 "Unknown \"$0\"": [
  null,
  "Unbekannte \"$0\""
 ],
 "Unknown configuration": [
  null,
  "Unbekannte Konfiguration"
 ],
 "Unknown service name": [
  null,
  "Unbekannten Servicename"
 ],
 "Unmanaged interfaces": [
  null,
  "Unverwaltete Schnittstellen"
 ],
 "Use": [
  null,
  "Verwenden"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN-Kennung"
 ],
 "VLAN settings": [
  null,
  "VLAN Einstellungen"
 ],
 "View all logs": [
  null,
  "Alle Protokolle ansehen"
 ],
 "Waiting": [
  null,
  "Wartet"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Ja"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Sie sind nicht berechtigt, die Firewall zu ändern."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bytes Binäredaten]"
 ],
 "[binary data]": [
  null,
  "[Binärdaten]"
 ],
 "[no data]": [
  null,
  "[keine Daten]"
 ],
 "bond": [
  null,
  ""
 ],
 "bridge": [
  null,
  "Brücke"
 ],
 "edit": [
  null,
  "bearbeiten"
 ],
 "firewall": [
  null,
  "Firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "Schnittstelle"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "Netzwerk"
 ],
 "port": [
  null,
  "Port"
 ],
 "show less": [
  null,
  "zeige weniger"
 ],
 "show more": [
  null,
  "Zeig mehr"
 ],
 "tcp": [
  null,
  "TCP"
 ],
 "team": [
  null,
  "Team"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "VLan"
 ],
 "zone": [
  null,
  "Zone"
 ]
});
