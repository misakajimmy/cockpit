cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "$0 active zone": [
  null,
  "$0 zone active",
  "$0 zones actives"
 ],
 "$0 day": [
  null,
  "$0 jour",
  "$0 jours"
 ],
 "$0 hour": [
  null,
  "$0 heure",
  "$0 heures"
 ],
 "$0 minute": [
  null,
  "$0 minute",
  "$0 minutes"
 ],
 "$0 month": [
  null,
  "$0 mois",
  "$0 mois"
 ],
 "$0 week": [
  null,
  "$0 semaine",
  "$0 semaines"
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ans"
 ],
 "$0 zone": [
  null,
  "$0 zone"
 ],
 "1 day": [
  null,
  "1 jour"
 ],
 "1 hour": [
  null,
  "1 heure"
 ],
 "1 week": [
  null,
  "1 semaine"
 ],
 "5 minutes": [
  null,
  "5 minutes"
 ],
 "6 hours": [
  null,
  "6 heures"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Une agrégation réseau combine plusieurs interfaces réseau en une seule interface logique avec un débit plus élevé ou une redondance."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "Surveillance ARP"
 ],
 "ARP ping": [
  null,
  "Ping ARP"
 ],
 "Active": [
  null,
  "Actif"
 ],
 "Active backup": [
  null,
  "Sauvegarde active"
 ],
 "Adaptive load balancing": [
  null,
  "Répartition adaptative de la charge"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Répartition adaptative de la charge d’émission"
 ],
 "Add $0": [
  null,
  "Ajouter $0"
 ],
 "Add VLAN": [
  null,
  "Ajouter un VLAN"
 ],
 "Add a new zone": [
  null,
  "Ajouter une nouvelle zone"
 ],
 "Add bond": [
  null,
  "Ajouter un lien"
 ],
 "Add bridge": [
  null,
  "Ajouter un pont"
 ],
 "Add item": [
  null,
  "Ajouter un élément"
 ],
 "Add member": [
  null,
  "Ajouter un membre"
 ],
 "Add new zone": [
  null,
  "Ajouter une nouvelle zone"
 ],
 "Add ports": [
  null,
  "Ajouter des ports"
 ],
 "Add ports to $0 zone": [
  null,
  "Ajouter des ports à la zone $0"
 ],
 "Add services": [
  null,
  "Ajouter des services"
 ],
 "Add services to $0 zone": [
  null,
  "Ajouter des services à la zone $0"
 ],
 "Add services to zone $0": [
  null,
  "Ajouter des services à la zone $0"
 ],
 "Add team": [
  null,
  "Ajouter une équipe"
 ],
 "Add zone": [
  null,
  "Ajouter une zone"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "L’ajout de $0 interrompra la connexion au serveur et rendra l’interface d’administration indisponible."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Ajouter des ports personnalisés rechargera firewalld. Le rechargement de la configuration entraînera la perte de celle en cours d’exécution !"
 ],
 "Additional DNS $val": [
  null,
  "DNS supplémentaire $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Domaines de recherche DNS supplémentaires $val"
 ],
 "Additional address $val": [
  null,
  "Adresse supplémentaire $val"
 ],
 "Additional ports": [
  null,
  "Ports additionnels"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "Address $val": [
  null,
  "Adresse $val"
 ],
 "Addresses": [
  null,
  "Adresses"
 ],
 "Allowed addresses": [
  null,
  "Adresses autorisées"
 ],
 "Authenticating": [
  null,
  "Authentification"
 ],
 "Automatic": [
  null,
  "Automatique"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatique (DHCP uniquement)"
 ],
 "Automatic (DHCP)": [
  null,
  "Automatique (DHCP)"
 ],
 "Balancer": [
  null,
  "Répartiteur de charge"
 ],
 "Bond": [
  null,
  "Liaison"
 ],
 "Bond settings": [
  null,
  "Paramètres de liaison"
 ],
 "Bridge": [
  null,
  "Pont"
 ],
 "Bridge port": [
  null,
  "Port du pont"
 ],
 "Bridge port settings": [
  null,
  "Paramètres du port du pont"
 ],
 "Bridge settings": [
  null,
  "Paramètres du pont"
 ],
 "Broadcast": [
  null,
  "Diffuser"
 ],
 "Broken configuration": [
  null,
  "Configuration endommagée"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Carrier": [
  null,
  "Opérateur"
 ],
 "Change the settings": [
  null,
  "Modifier les paramètres"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La modification des paramètres interrompt la connexion au serveur et rend l’interface utilisateur d’administration indisponible."
 ],
 "Checking IP": [
  null,
  "Vérification de l’adresse IP"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Les ports, les plages et les services séparés par des virgules sont acceptés"
 ],
 "Configuring": [
  null,
  "Configuration en cours"
 ],
 "Configuring IP": [
  null,
  "Configuration de l’adresse IP"
 ],
 "Confirm removal of $0": [
  null,
  "Confirmer la suppression de $0"
 ],
 "Connect automatically": [
  null,
  "Connecter automatiquement"
 ],
 "Connection will be lost": [
  null,
  "La connexion sera perdue"
 ],
 "Create it": [
  null,
  "Créez-le"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La création de $0 interrompra la connexion au serveur et rendra l’interface d’administration indisponible."
 ],
 "Custom ports": [
  null,
  "Ports personnalisés"
 ],
 "Custom zones": [
  null,
  "Zones personnalisées"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "Domaines de recherche DNS"
 ],
 "DNS search domains $val": [
  null,
  "Domaines de recherche DNS $val"
 ],
 "Deactivating": [
  null,
  "Désactivation en cours"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Delete $0": [
  null,
  "Supprimer $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La suppression de $0 interrompra la connexion au serveur et rendra l’interface d’administration indisponible."
 ],
 "Description": [
  null,
  "Description"
 ],
 "Disable the firewall": [
  null,
  "Désactiver le pare-feu"
 ],
 "Disabled": [
  null,
  "Désactivé"
 ],
 "Edit": [
  null,
  "Modifier"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Modifier le service personnalisé dans la zone $0"
 ],
 "Edit rules and zones": [
  null,
  "Modifier les règles et les zones"
 ],
 "Edit service": [
  null,
  "Modifier le service"
 ],
 "Edit service $0": [
  null,
  "Service d'édition $0"
 ],
 "Enable or disable the device": [
  null,
  "Activer ou désactiver le périphérique"
 ],
 "Enable service": [
  null,
  "Activer le service"
 ],
 "Enable the firewall": [
  null,
  "Activer le pare-feu"
 ],
 "Enabled": [
  null,
  "Activée"
 ],
 "Enter a valid MAC address": [
  null,
  "Entrez une adresse MAC valide"
 ],
 "Entire subnet": [
  null,
  "Ensemble du sous-réseau"
 ],
 "Ethernet MAC": [
  null,
  "MAC Ethernet"
 ],
 "Ethernet MTU": [
  null,
  "MTU Ethernet"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Exemple : 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Exemple : 88,2019,nfs,rsync"
 ],
 "Failed": [
  null,
  "Échoué"
 ],
 "Failed to add port": [
  null,
  "Échec de l’ajout du port"
 ],
 "Failed to add service": [
  null,
  "Échec de l’ajout du service"
 ],
 "Failed to add zone": [
  null,
  "Échec de l’ajout de la zone"
 ],
 "Failed to edit service": [
  null,
  "Échec de la modification du service"
 ],
 "Failed to save settings": [
  null,
  "Échec de l’enregistrement des paramètres"
 ],
 "Filter services": [
  null,
  "Services de filtrage"
 ],
 "Firewall": [
  null,
  "Pare-feu"
 ],
 "Firewall is not available": [
  null,
  "Le pare-feu n’est pas disponible"
 ],
 "Forward delay $forward_delay": [
  null,
  "Délai d’attente de redirection $forward_delay"
 ],
 "Gateway": [
  null,
  "Passerelle"
 ],
 "General": [
  null,
  "Général"
 ],
 "Go to now": [
  null,
  "Aller à maintenant"
 ],
 "Group": [
  null,
  "Groupe"
 ],
 "Hair pin mode": [
  null,
  "Mode Hair Pin"
 ],
 "Hairpin mode": [
  null,
  "Mode Hair Pin"
 ],
 "Hello time $hello_time": [
  null,
  "Bonjour $hello_time"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "Adresse IP"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "Adresse IP avec préfixe de routage. Séparez les valeurs multiples par une virgule. Exemple : 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "Paramètres IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "Paramètres IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "S’il est laissé vide, l’ID sera généré sur la base des services et des numéros de port associés"
 ],
 "Ignore": [
  null,
  "Ignorer"
 ],
 "Inactive": [
  null,
  "Inactif"
 ],
 "Included services": [
  null,
  "services inclus"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Les requêtes entrantes sont bloquées par défaut. Les requêtes sortantes ne sont pas bloquées."
 ],
 "Interface": [
  null,
  "Interface",
  "Interfaces"
 ],
 "Interface members": [
  null,
  "Membres de l’interface"
 ],
 "Interfaces": [
  null,
  "Interfaces"
 ],
 "Invalid address $0": [
  null,
  "Adresse non valide $0"
 ],
 "Invalid metric $0": [
  null,
  "Métrique non valide $0"
 ],
 "Invalid port number": [
  null,
  "Numéro de port invalide"
 ],
 "Invalid prefix $0": [
  null,
  "Préfixe non valide $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Préfixe ou masque de réseau non valide $0"
 ],
 "Invalid range": [
  null,
  "Plage invalide"
 ],
 "Keep connection": [
  null,
  "Gardez la connexion"
 ],
 "LACP key": [
  null,
  "Clé LACP"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "Link down delay": [
  null,
  "Délai de chute de lien"
 ],
 "Link local": [
  null,
  "Lien local"
 ],
 "Link monitoring": [
  null,
  "Surveillance du lien"
 ],
 "Link up delay": [
  null,
  "Délai d’activation de lien"
 ],
 "Link watch": [
  null,
  "Link Watch"
 ],
 "Load balancing": [
  null,
  "L’équilibrage de charge"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (recommandé)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU doit être un nombre positif"
 ],
 "Managed interfaces": [
  null,
  "Interfaces non gérées"
 ],
 "Managing VLANs": [
  null,
  "Gestion des réseaux locaux virtuels (VLAN)"
 ],
 "Managing firewall": [
  null,
  "Gestion du pare-feu"
 ],
 "Managing networking bonds": [
  null,
  "Gestion des liens de réseau"
 ],
 "Managing networking bridges": [
  null,
  "Gérer les ponts de mise en réseau"
 ],
 "Managing networking teams": [
  null,
  "Gestion du réseau"
 ],
 "Manual": [
  null,
  "Manuel"
 ],
 "Maximum message age $max_age": [
  null,
  "Âge maximal du message $max_age"
 ],
 "Metric": [
  null,
  "Métrique"
 ],
 "Mode": [
  null,
  "Mode"
 ],
 "Monitoring interval": [
  null,
  "Intervalle de surveillance"
 ],
 "Monitoring targets": [
  null,
  "Objectifs de surveillance"
 ],
 "NSNA ping": [
  null,
  "Ping NSNA"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Network bond": [
  null,
  "Agrégation de réseau"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Les périphériques réseau et les graphiques nécessitent NetworkManager"
 ],
 "Network logs": [
  null,
  "Journaux du réseau"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager n’est pas installé"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager n’est pas en cours d’exécution"
 ],
 "Networking": [
  null,
  "Réseau"
 ],
 "No": [
  null,
  "Non"
 ],
 "No carrier": [
  null,
  "Pas de transporteur"
 ],
 "No description available": [
  null,
  "Aucune description disponible"
 ],
 "None": [
  null,
  "Aucun"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Non autorisé à désactiver le pare-feu"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Non autorisé à activer le pare-feu"
 ],
 "Not available": [
  null,
  "Indisponible"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Options": [
  null,
  "Options"
 ],
 "Parent": [
  null,
  "Parent"
 ],
 "Parent $parent": [
  null,
  "Parent $parent"
 ],
 "Part of $0": [
  null,
  "Partie de $0"
 ],
 "Passive": [
  null,
  "Passif"
 ],
 "Path cost": [
  null,
  "Coût du chemin"
 ],
 "Path cost $path_cost": [
  null,
  "Coût du chemin $path_cost"
 ],
 "Permanent": [
  null,
  "Permanent"
 ],
 "Ping interval": [
  null,
  "Intervalle de ping"
 ],
 "Ping target": [
  null,
  "Cible de ping"
 ],
 "Please install the $0 package": [
  null,
  "Veuillez installer le paquet $0"
 ],
 "Port number and type do not match": [
  null,
  "Le numéro de port et son type ne correspondent pas"
 ],
 "Ports": [
  null,
  "Ports"
 ],
 "Prefix length": [
  null,
  "Longueur du préfixe"
 ],
 "Prefix length or netmask": [
  null,
  "Longueur du préfixe ou masque de réseau"
 ],
 "Preparing": [
  null,
  "Préparation en cours"
 ],
 "Preserve": [
  null,
  "Préserver"
 ],
 "Primary": [
  null,
  "Primaire"
 ],
 "Priority": [
  null,
  "Priorité"
 ],
 "Priority $priority": [
  null,
  "Priorité $priority"
 ],
 "Random": [
  null,
  "Aléatoire"
 ],
 "Range": [
  null,
  "Gamme"
 ],
 "Range must be strictly ordered": [
  null,
  "La plage doit être strictement ordonnée"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Receiving": [
  null,
  "Réception"
 ],
 "Remove $0": [
  null,
  "Supprimer $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Supprimer le service $0 de la zone $1"
 ],
 "Remove item": [
  null,
  "Supprimer l’élément"
 ],
 "Remove service $0": [
  null,
  "Supprimer le service $0"
 ],
 "Remove zone $0": [
  null,
  "Supprimer la zone $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La suppression de $0 interrompra la connexion au serveur et rendra l’interface utilisateur d’administration indisponible."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "La suppression du service de cockpit pourrait rendre la console Web inaccessible. Assurez-vous que cette zone ne s’applique pas à votre connexion actuelle à la console Web."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "La suppression de la zone supprime tous les services qui s’y trouvent."
 ],
 "Restoring connection": [
  null,
  "Restauration de la connexion"
 ],
 "Round robin": [
  null,
  "Round-robin"
 ],
 "Routes": [
  null,
  "Routes"
 ],
 "Runner": [
  null,
  "Exécuteur"
 ],
 "STP forward delay": [
  null,
  "Délai de réacheminement STP"
 ],
 "STP hello time": [
  null,
  "Durée Hello STP"
 ],
 "STP maximum message age": [
  null,
  "Âge maximal de message STP"
 ],
 "STP priority": [
  null,
  "Priorité STP"
 ],
 "Save": [
  null,
  "Enregistrer"
 ],
 "Search domain": [
  null,
  "Domaine de recherche"
 ],
 "Select method": [
  null,
  "Sélectionnez la méthode"
 ],
 "Sending": [
  null,
  "Envoi"
 ],
 "Server": [
  null,
  "Serveur"
 ],
 "Service": [
  null,
  "Service"
 ],
 "Services": [
  null,
  "Services"
 ],
 "Set to": [
  null,
  "Mis à"
 ],
 "Shared": [
  null,
  "Partagé"
 ],
 "Sorted from least to most trusted": [
  null,
  "Trié du moins fiable au plus fiable"
 ],
 "Spanning tree protocol": [
  null,
  "Protocole Spanning Tree"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Protocole Spanning Tree (STP)"
 ],
 "Stable": [
  null,
  "Stable"
 ],
 "Start service": [
  null,
  "Démarrer le service"
 ],
 "Status": [
  null,
  "État"
 ],
 "Sticky": [
  null,
  "Persistant"
 ],
 "Switch of $0": [
  null,
  "Éteindre $0"
 ],
 "Switch off $0": [
  null,
  "Éteindre $0"
 ],
 "Switch on $0": [
  null,
  "Allumer $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "La désactivation de $0 interrompra la connexion au serveur et rendra l’interface utilisateur d’administration indisponible."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "L’activation de $0 interrompra la connexion au serveur et rendra l’interface utilisateur d’administration indisponible."
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Team": [
  null,
  "Équipe"
 ],
 "Team port": [
  null,
  "Port de l’équipe"
 ],
 "Team port settings": [
  null,
  "Paramètres du port de l’équipe"
 ],
 "Team settings": [
  null,
  "Paramètres de l’équipe"
 ],
 "Testing connection": [
  null,
  "Test de connexion"
 ],
 "The cockpit service is automatically included": [
  null,
  "Le service de cockpit est automatiquement inclus"
 ],
 "There are no active services in this zone": [
  null,
  "Il n’y a pas de services actifs dans cette zone"
 ],
 "This device cannot be managed here.": [
  null,
  "Ce périphérique ne peut pas être géré ici."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Cette zone contient le service du cockpit. Assurez-vous que cette zone ne s’applique pas à votre connexion actuelle à la console Web."
 ],
 "Transmitting": [
  null,
  "Transmettre"
 ],
 "Troubleshoot…": [
  null,
  "Dépannage…"
 ],
 "Trust level": [
  null,
  "Niveau de confiance"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unexpected error": [
  null,
  "Erreur inattendue"
 ],
 "Unknown": [
  null,
  "Inconnu"
 ],
 "Unknown \"$0\"": [
  null,
  "Inconnu « $0 »"
 ],
 "Unknown configuration": [
  null,
  "Configuration inconnue"
 ],
 "Unknown service name": [
  null,
  "Nom de service inconnu"
 ],
 "Unmanaged interfaces": [
  null,
  "Interfaces non gérées"
 ],
 "Use": [
  null,
  "Utiliser"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN ID"
 ],
 "VLAN settings": [
  null,
  "Paramètres VLAN"
 ],
 "View all logs": [
  null,
  "Voir tous les journaux"
 ],
 "Waiting": [
  null,
  "Attente"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Oui"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Vous n’êtes pas autorisé à modifier le pare-feu."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[ $0 octets de données binaires]"
 ],
 "[binary data]": [
  null,
  "[données binaires]"
 ],
 "[no data]": [
  null,
  "[pas de données]"
 ],
 "bond": [
  null,
  "bond"
 ],
 "bridge": [
  null,
  "pont"
 ],
 "edit": [
  null,
  "modifier"
 ],
 "firewall": [
  null,
  "pare-feu"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "Interface"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "réseau"
 ],
 "port": [
  null,
  "port"
 ],
 "show less": [
  null,
  "montrer moins"
 ],
 "show more": [
  null,
  "montrer plus"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "équipe"
 ],
 "udp": [
  null,
  "UDP"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "zone"
 ]
});
