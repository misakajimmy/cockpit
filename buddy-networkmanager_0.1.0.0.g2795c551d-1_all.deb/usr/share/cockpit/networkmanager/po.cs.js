cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 active zone": [
  null,
  "$0 aktivní zóna",
  "$0 aktivní zóny",
  "$0 aktivních zón"
 ],
 "$0 day": [
  null,
  "$0 den",
  "$0 dny",
  "$0 dnů"
 ],
 "$0 hour": [
  null,
  "$0 hodina",
  "$0 hodiny",
  "$0 hodin"
 ],
 "$0 minute": [
  null,
  "$0 minuta",
  "$0 minuty",
  "$0 minut"
 ],
 "$0 month": [
  null,
  "$0 měsíc",
  "$0 měsíce",
  "$0 měsíců"
 ],
 "$0 week": [
  null,
  "$0 týden",
  "$0 týdny",
  "$0 týdnů"
 ],
 "$0 year": [
  null,
  "$0 rok",
  "$0 roky",
  "$0 let"
 ],
 "$0 zone": [
  null,
  "zóna $0"
 ],
 "1 day": [
  null,
  "1 den"
 ],
 "1 hour": [
  null,
  "1 hodina"
 ],
 "1 week": [
  null,
  "1 týden"
 ],
 "5 minutes": [
  null,
  "5 minut"
 ],
 "6 hours": [
  null,
  "6 hodin"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "Síťové spřažení spojuje vícero síťových rozhraní do jednoho logického rozhraní s vyšší propustností nebo odolností proti výpadku."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP monitorování"
 ],
 "ARP ping": [
  null,
  "ARP ping"
 ],
 "Active": [
  null,
  "Aktivní"
 ],
 "Active backup": [
  null,
  "Aktivní záloha"
 ],
 "Adaptive load balancing": [
  null,
  "Přizpůsobující se rozkládání zátěže"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Přizpůsobující se rozkládání přenosové zátěže odesílání"
 ],
 "Add $0": [
  null,
  "Přidat $0"
 ],
 "Add VLAN": [
  null,
  "Přidat VLAN"
 ],
 "Add a new zone": [
  null,
  "Přidat novou zónu"
 ],
 "Add bond": [
  null,
  "Přidat sloučení linek"
 ],
 "Add bridge": [
  null,
  "Přidat síťový most"
 ],
 "Add item": [
  null,
  "Přidat položku"
 ],
 "Add member": [
  null,
  "Přidat člena"
 ],
 "Add new zone": [
  null,
  "Přidat novou zónu"
 ],
 "Add ports": [
  null,
  "Přidat porty"
 ],
 "Add ports to $0 zone": [
  null,
  "Přidat porty do zóny $0"
 ],
 "Add services": [
  null,
  "Přidat služby"
 ],
 "Add services to $0 zone": [
  null,
  "Přidat služby do zóny $0"
 ],
 "Add services to zone $0": [
  null,
  "Přidat služby do zóny $0"
 ],
 "Add team": [
  null,
  "Přidat tým"
 ],
 "Add zone": [
  null,
  "Přidat zónu"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Přidání $0 přeruší spojení se serverem a znepřístupní tak rozhraní pro jeho správu."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Přidání uživatelsky určených portů znovunačte firewalld. To povede ke ztrátě jakéhokoli nastavení, které bylo učiněno za běhu a neuloženo!"
 ],
 "Additional DNS $val": [
  null,
  "Další DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Další DNS domény k prohledávání $val"
 ],
 "Additional address $val": [
  null,
  "Další adresa $val"
 ],
 "Additional ports": [
  null,
  "Další porty"
 ],
 "Address": [
  null,
  "Adresa"
 ],
 "Address $val": [
  null,
  "Adresa $val"
 ],
 "Addresses": [
  null,
  "Adresy"
 ],
 "Allowed addresses": [
  null,
  "Adresy, které umožněny"
 ],
 "Authenticating": [
  null,
  "Ověřování"
 ],
 "Automatic": [
  null,
  "Automaticky"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automaticky (pouze DHCP)"
 ],
 "Automatic (DHCP)": [
  null,
  "Automaticky (DHCP)"
 ],
 "Balancer": [
  null,
  "Rozkládání zátěže"
 ],
 "Bond": [
  null,
  "Vazba"
 ],
 "Bond settings": [
  null,
  "Nastavení spřažení"
 ],
 "Bridge": [
  null,
  "Most"
 ],
 "Bridge port": [
  null,
  "Port mostu"
 ],
 "Bridge port settings": [
  null,
  "Nastavení portu mostu"
 ],
 "Bridge settings": [
  null,
  "Nastavení mostu"
 ],
 "Broadcast": [
  null,
  "Vysílání"
 ],
 "Broken configuration": [
  null,
  "Chybné nastavení"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Carrier": [
  null,
  "Nosný signál"
 ],
 "Change the settings": [
  null,
  "Změnit nastavení"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Změna nastavení přeruší spojení se serverem a znepřístupní tak uživatelské rozhraní pro jeho správu."
 ],
 "Checking IP": [
  null,
  "Ověřuje se IP adresa"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Configuring": [
  null,
  "Nastavuje se"
 ],
 "Configuring IP": [
  null,
  "Nastavuje se IP adresa"
 ],
 "Confirm removal of $0": [
  null,
  "Potvrdit odebrání $0"
 ],
 "Connect automatically": [
  null,
  "Připojit se automaticky"
 ],
 "Connection will be lost": [
  null,
  "Spojení bude ztraceno"
 ],
 "Create it": [
  null,
  "Vytvořit to"
 ],
 "Custom ports": [
  null,
  "Uživatelsky určené porty"
 ],
 "Custom zones": [
  null,
  "Uživatelsky určené zóny"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS prohledávané domény"
 ],
 "DNS search domains $val": [
  null,
  "Prohledávat DNS domény $val"
 ],
 "Deactivating": [
  null,
  "Deaktivuje se"
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Delete $0": [
  null,
  "Smazat $0"
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Disable the firewall": [
  null,
  "Vypnout bránu firewall"
 ],
 "Disabled": [
  null,
  "Vypnuto"
 ],
 "Edit": [
  null,
  "Upravit"
 ],
 "Edit rules and zones": [
  null,
  "Upravit pravidla a zóny"
 ],
 "Enable or disable the device": [
  null,
  "Povolit nebo zakázat zařízení"
 ],
 "Enable service": [
  null,
  "Zapnout službu"
 ],
 "Enable the firewall": [
  null,
  "Zapnout bránu firewall"
 ],
 "Enabled": [
  null,
  "Povoleno"
 ],
 "Entire subnet": [
  null,
  "Celá podsíť"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet MAC adresa"
 ],
 "Ethernet MTU": [
  null,
  "MTU ethernetu"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Příklad: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Příkaz: 88,2019,nfs,rsync"
 ],
 "Failed": [
  null,
  "Neúspěšné"
 ],
 "Failed to add port": [
  null,
  "Přidání portu se nezdařilo"
 ],
 "Failed to add service": [
  null,
  "Službu se nepodařilo přidat"
 ],
 "Failed to add zone": [
  null,
  "Zónu se nepodařilo přidat"
 ],
 "Filter services": [
  null,
  "Filtrovat služby"
 ],
 "Firewall": [
  null,
  "Brána firewall"
 ],
 "Firewall is not available": [
  null,
  "Brána firewall není k dispozici"
 ],
 "Forward delay $forward_delay": [
  null,
  "Prodleva přeposlání $forward_delay"
 ],
 "Gateway": [
  null,
  "Brána"
 ],
 "General": [
  null,
  "Obecné"
 ],
 "Go to now": [
  null,
  "Přejít na nyní"
 ],
 "Group": [
  null,
  "Skupina"
 ],
 "Hair pin mode": [
  null,
  "Hair Pin režim"
 ],
 "Hairpin mode": [
  null,
  "Hair Pin režim"
 ],
 "Hello time $hello_time": [
  null,
  "Oznamovací čas $hello_time"
 ],
 "ID": [
  null,
  "Identif."
 ],
 "ID $id": [
  null,
  "Identif. $id"
 ],
 "IP address": [
  null,
  "IP adresa"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP adresa se směrovací předponou (prefix). Vícero hodnot oddělujte čárkou. Příklad: 192.0.2.0/24, 2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "Nastavení IPv4"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "Nastavení IPv6"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  ""
 ],
 "Ignore": [
  null,
  "Ignorovat"
 ],
 "Inactive": [
  null,
  "Neaktivní"
 ],
 "Included services": [
  null,
  "Obsažené služby"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  ""
 ],
 "Interface members": [
  null,
  "Čísla rozhraní"
 ],
 "Interfaces": [
  null,
  "Rozhraní"
 ],
 "Invalid address $0": [
  null,
  "Neplatná adresa $0"
 ],
 "Invalid metric $0": [
  null,
  "Neplatná metrika $0"
 ],
 "Invalid port number": [
  null,
  "Neplatné číslo portu"
 ],
 "Invalid prefix $0": [
  null,
  "Neplatná předpona $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Neplatná předpona nebo maska sítě $0"
 ],
 "Invalid range": [
  null,
  "Neplatný rozsah"
 ],
 "Keep connection": [
  null,
  "Zachovat spojení"
 ],
 "LACP key": [
  null,
  "LACP klíč"
 ],
 "Learn more": [
  null,
  "Další informace naleznete"
 ],
 "Link down delay": [
  null,
  "Prodleva neaktivní linky"
 ],
 "Link local": [
  null,
  "Lokální propoj"
 ],
 "Link monitoring": [
  null,
  "Monitorování linky"
 ],
 "Link up delay": [
  null,
  "Prodleva aktivní linky"
 ],
 "Link watch": [
  null,
  "Hlídání linky"
 ],
 "Load balancing": [
  null,
  "Rozkládání zátěže"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (doporučeno)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "Je třeba, aby MTU bylo kladné číslo"
 ],
 "Managed interfaces": [
  null,
  "Spravovaná rozhraní"
 ],
 "Managing VLANs": [
  null,
  "Správa VLAN sítí"
 ],
 "Managing firewall": [
  null,
  "Správa brány firewall"
 ],
 "Managing networking bonds": [
  null,
  "Správa síťových spřažení"
 ],
 "Managing networking bridges": [
  null,
  "Správa síťových mostů"
 ],
 "Managing networking teams": [
  null,
  "Správa sdružených síťových připojení"
 ],
 "Manual": [
  null,
  "Ruční"
 ],
 "Maximum message age $max_age": [
  null,
  "Maximální stáří zpráv $max_age"
 ],
 "Mode": [
  null,
  "Režim"
 ],
 "Monitoring interval": [
  null,
  "Interval monitorování"
 ],
 "Monitoring targets": [
  null,
  "Cíle monitorování"
 ],
 "NSNA ping": [
  null,
  "NSNA ping"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Network bond": [
  null,
  "Síťová spřažení"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Síťová zařízení a grafy vyžadují NetworkManager"
 ],
 "Network logs": [
  null,
  "Záznamy událostí sítě"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager není nainstalovaný"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager není spuštěný"
 ],
 "Networking": [
  null,
  "Síť"
 ],
 "No": [
  null,
  "Ne"
 ],
 "No carrier": [
  null,
  "Bez signálu"
 ],
 "No description available": [
  null,
  "Není k dispozici žádný popis"
 ],
 "None": [
  null,
  "Žádný"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Nemáte oprávnění pro vypnutí brány firewall"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Nemáte oprávnění pro zapnutí brány firewall"
 ],
 "Not available": [
  null,
  "Není k dispozici"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Options": [
  null,
  "Přepínače"
 ],
 "Parent": [
  null,
  "Nadřazené"
 ],
 "Parent $parent": [
  null,
  "Nadřazené $parent"
 ],
 "Part of $0": [
  null,
  "Součástí $0"
 ],
 "Passive": [
  null,
  "Pasivní"
 ],
 "Path cost": [
  null,
  "Náklady trasy"
 ],
 "Path cost $path_cost": [
  null,
  "Náklady trasy $path_cost"
 ],
 "Permanent": [
  null,
  "Trvalá"
 ],
 "Ping interval": [
  null,
  "Interval pro ping"
 ],
 "Ping target": [
  null,
  "Cíl pro ping"
 ],
 "Please install the $0 package": [
  null,
  "Nainstalujte balíček $0"
 ],
 "Port number and type do not match": [
  null,
  "Číslo a typ portu si neodpovídají"
 ],
 "Ports": [
  null,
  "Porty"
 ],
 "Prefix length": [
  null,
  "Délka předpony"
 ],
 "Prefix length or netmask": [
  null,
  "Délka předpony nebo maska sítě"
 ],
 "Preparing": [
  null,
  "Příprava"
 ],
 "Primary": [
  null,
  "Primární"
 ],
 "Priority": [
  null,
  "Priorita"
 ],
 "Priority $priority": [
  null,
  "Priorita $priority"
 ],
 "Random": [
  null,
  "Náhodné"
 ],
 "Range": [
  null,
  "Rozsah"
 ],
 "Range must be strictly ordered": [
  null,
  "Je třeba, aby rozsah byl striktně řazený"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Receiving": [
  null,
  "Příchozí"
 ],
 "Remove $0": [
  null,
  "Odebrat $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Odebrat službu $0 ze zóny $1"
 ],
 "Remove service $0": [
  null,
  "Odebrat službu $0"
 ],
 "Remove zone $0": [
  null,
  "Odebrat zónu $0"
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Odebrání služby cockpit může vést k tomu, že webová konzole přestane být dostupná. Ověřte, že se tato zóna nevztahuje na vaše stávající spojení s touto webovou konzolí."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Odebrání zóny odebere také všechny služby, které obsahuje."
 ],
 "Restoring connection": [
  null,
  "Obnovování spojení"
 ],
 "Round robin": [
  null,
  "Round robin"
 ],
 "Routes": [
  null,
  "Trasy"
 ],
 "Runner": [
  null,
  "Spouštěč"
 ],
 "STP forward delay": [
  null,
  "STP prodleva přeposílání"
 ],
 "STP hello time": [
  null,
  "STP uvítací doba"
 ],
 "STP maximum message age": [
  null,
  "STP maximální stáří zprávy"
 ],
 "STP priority": [
  null,
  "STP priorita"
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "Sending": [
  null,
  "Odchozí"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Service": [
  null,
  "Služba"
 ],
 "Services": [
  null,
  "Služby"
 ],
 "Set to": [
  null,
  "Nastavit na"
 ],
 "Shared": [
  null,
  "Sdílené"
 ],
 "Sorted from least to most trusted": [
  null,
  "Seřazeno od nejméně po nejvíce důvěryhodné"
 ],
 "Spanning tree protocol": [
  null,
  "Spanning tree protocol"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Spanning tree protocol (STP)"
 ],
 "Stable": [
  null,
  "Stabilní"
 ],
 "Start service": [
  null,
  "Spustit službu"
 ],
 "Status": [
  null,
  "Stav"
 ],
 "Sticky": [
  null,
  "Lepkavé"
 ],
 "Switch of $0": [
  null,
  "Vypnout $0"
 ],
 "Switch off $0": [
  null,
  "Vypnout $0"
 ],
 "Switch on $0": [
  null,
  "Zapnout $0"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Team": [
  null,
  "Tým"
 ],
 "Team port": [
  null,
  "Port týmu"
 ],
 "Team port settings": [
  null,
  "Nastavení portu týmu"
 ],
 "Team settings": [
  null,
  "Nastavení týmu"
 ],
 "Testing connection": [
  null,
  "Zkouška spojení"
 ],
 "The cockpit service is automatically included": [
  null,
  "Služba cockpit je obsažena automaticky"
 ],
 "There are no active services in this zone": [
  null,
  "V této zóně se nenacházejí žádné aktivní služby"
 ],
 "This device cannot be managed here.": [
  null,
  "Toto zařízení zde nelze spravovat."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Tato zóna obsahuje službu cockpit. Ověřte, že se tato zóna nevztahuje na vaše stávající spojení s touto webovou konzolí."
 ],
 "Troubleshoot…": [
  null,
  "Řešit potíže…"
 ],
 "Trust level": [
  null,
  "Stupeň důvěryhodnosti"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unexpected error": [
  null,
  "Neočekávaná chyba"
 ],
 "Unknown": [
  null,
  "Neznámé"
 ],
 "Unknown \"$0\"": [
  null,
  "Neznámé „$0“"
 ],
 "Unknown configuration": [
  null,
  "Neznámé nastavení"
 ],
 "Unknown service name": [
  null,
  "Neznámý název služby"
 ],
 "Unmanaged interfaces": [
  null,
  "Nespravovaná rozhraní"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "Identif. VLAN"
 ],
 "VLAN settings": [
  null,
  "Nastavení VLAN"
 ],
 "View all logs": [
  null,
  "Zobrazit všechny záznamy událostí"
 ],
 "Waiting": [
  null,
  "Čeká se"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Ano"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Nemáte oprávnění upravovat bránu firewall."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bajtů binárních dat]"
 ],
 "[binary data]": [
  null,
  "[binarní data]"
 ],
 "[no data]": [
  null,
  "[žádná data]"
 ],
 "bond": [
  null,
  "spřažení"
 ],
 "bridge": [
  null,
  "most"
 ],
 "edit": [
  null,
  "upravit"
 ],
 "firewall": [
  null,
  "brána firewall"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "rozhraní"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac adresa"
 ],
 "network": [
  null,
  "síť"
 ],
 "port": [
  null,
  "port"
 ],
 "show less": [
  null,
  "zobrazit méně"
 ],
 "show more": [
  null,
  "zobrazit více"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "team"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "zóna"
 ]
});
