cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "$0 active zone": [
  null,
  "$0 Aktiv zon",
  "$0 Aktiva zoner"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagar"
 ],
 "$0 hour": [
  null,
  "$0 timme",
  "$0 timmar"
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minuter"
 ],
 "$0 month": [
  null,
  "$0 månad",
  "$0 månader"
 ],
 "$0 week": [
  null,
  "$0 vecka",
  "$0 veckor"
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "$0 zone": [
  null,
  "zon $0"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 timme"
 ],
 "1 week": [
  null,
  "1 vecka"
 ],
 "5 minutes": [
  null,
  "5 minuter"
 ],
 "6 hours": [
  null,
  "6 timmar"
 ],
 "802.3ad": [
  null,
  "802.3ad"
 ],
 "802.3ad LACP": [
  null,
  "802.3ad LACP"
 ],
 "A network bond combines multiple network interfaces into one logical interface with higher throughput or redundancy.": [
  null,
  "En bindning kombinerar flera nätverksportar till en logisk port med högre hastighet eller tillförlitlighet."
 ],
 "ARP": [
  null,
  "ARP"
 ],
 "ARP monitoring": [
  null,
  "ARP-övervakning"
 ],
 "ARP ping": [
  null,
  "ARP-ping"
 ],
 "Active": [
  null,
  "Aktivt"
 ],
 "Active backup": [
  null,
  "Aktiv reserv"
 ],
 "Adaptive load balancing": [
  null,
  "Adaptiv lastbalansering"
 ],
 "Adaptive transmit load balancing": [
  null,
  "Adaptiv lastbalansering av sändning"
 ],
 "Add $0": [
  null,
  "Lägg till $0"
 ],
 "Add VLAN": [
  null,
  "Lägg till VLAN"
 ],
 "Add a new zone": [
  null,
  "Lägg till zon"
 ],
 "Add bond": [
  null,
  "Lägg till bindning"
 ],
 "Add bridge": [
  null,
  "Lägg till brygga"
 ],
 "Add item": [
  null,
  "Lägg till post"
 ],
 "Add member": [
  null,
  "Lägg till medlem"
 ],
 "Add new zone": [
  null,
  "Lägg till ny zon"
 ],
 "Add ports": [
  null,
  "Lägg till portar"
 ],
 "Add ports to $0 zone": [
  null,
  "Lägg till portar till zonen $0"
 ],
 "Add services": [
  null,
  "Lägg till tjänster"
 ],
 "Add services to $0 zone": [
  null,
  "Lägg till tjänster till zonen $0"
 ],
 "Add services to zone $0": [
  null,
  "Lägg till tjänster till zon $0"
 ],
 "Add team": [
  null,
  "Lägg till team"
 ],
 "Add zone": [
  null,
  "Lägg till zon"
 ],
 "Adding $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att lägga till $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Adding custom ports will reload firewalld. A reload will result in the loss of any runtime-only configuration!": [
  null,
  "Att lägga till egna portar startar om firewalld . En omstart gör att osparade ändringar försvinner!"
 ],
 "Additional DNS $val": [
  null,
  "Ytterligare DNS $val"
 ],
 "Additional DNS search domains $val": [
  null,
  "Ytterligare DNS-sökdomäner $val"
 ],
 "Additional address $val": [
  null,
  "Ytterligare adress $val"
 ],
 "Additional ports": [
  null,
  "Ytterligare portar"
 ],
 "Address": [
  null,
  "Adress"
 ],
 "Address $val": [
  null,
  "Adress $val"
 ],
 "Addresses": [
  null,
  "Adresser"
 ],
 "Allowed addresses": [
  null,
  "Tillåtna adresser"
 ],
 "Authenticating": [
  null,
  "Autentiserar"
 ],
 "Automatic": [
  null,
  "Automatisk"
 ],
 "Automatic (DHCP only)": [
  null,
  "Automatiskt (endast DHCP)"
 ],
 "Automatic (DHCP)": [
  null,
  "Automatiskt (DHCP)"
 ],
 "Balancer": [
  null,
  "Balanserare"
 ],
 "Bond": [
  null,
  "Binda"
 ],
 "Bond settings": [
  null,
  "Bindinställningar"
 ],
 "Bridge": [
  null,
  "Brygga"
 ],
 "Bridge port": [
  null,
  "Bryggport"
 ],
 "Bridge port settings": [
  null,
  "Bryggportinställningar"
 ],
 "Bridge settings": [
  null,
  "Brygginställningar"
 ],
 "Broadcast": [
  null,
  "Utsändning"
 ],
 "Broken configuration": [
  null,
  "Trasig konfiguration"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Carrier": [
  null,
  "Transport"
 ],
 "Change the settings": [
  null,
  "Ändra inställningarna"
 ],
 "Changing the settings will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att ändra inställningarna kommer bryta förbindelsen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Checking IP": [
  null,
  "Kontrollerar IP"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Comma-separated ports, ranges, and services are accepted": [
  null,
  "Kommaseparerade portar, intervall och tjänster accepteras"
 ],
 "Configuring": [
  null,
  "Konfigurerar"
 ],
 "Configuring IP": [
  null,
  "Konfigurerar IP"
 ],
 "Confirm removal of $0": [
  null,
  "Bekräfta borttagning av $0"
 ],
 "Connect automatically": [
  null,
  "Anslut automatiskt"
 ],
 "Connection will be lost": [
  null,
  "Anslutningen kommer gå förlorad"
 ],
 "Create it": [
  null,
  "Skapa den"
 ],
 "Creating this $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att skapa detta $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Custom ports": [
  null,
  "Egna portar"
 ],
 "Custom zones": [
  null,
  "Egna zoner"
 ],
 "DNS": [
  null,
  "DNS"
 ],
 "DNS $val": [
  null,
  "DNS $val"
 ],
 "DNS search domains": [
  null,
  "DNS-sökdomäner"
 ],
 "DNS search domains $val": [
  null,
  "DNS-sökdomäner $val"
 ],
 "Deactivating": [
  null,
  "Avaktiverar"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Delete $0": [
  null,
  "Ta bort $0"
 ],
 "Deleting $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att ta bort $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Description": [
  null,
  "Beskrivning"
 ],
 "Disable the firewall": [
  null,
  "Stäng av brandväggen"
 ],
 "Disabled": [
  null,
  "Avaktiverad"
 ],
 "Edit": [
  null,
  "Redigera"
 ],
 "Edit custom service in $0 zone": [
  null,
  "Redigera anpassad tjänst i $0 zon"
 ],
 "Edit rules and zones": [
  null,
  "Redigera regler och zoner"
 ],
 "Edit service": [
  null,
  "Redigera tjänst"
 ],
 "Edit service $0": [
  null,
  "Redigera tjänst $0"
 ],
 "Enable or disable the device": [
  null,
  "Aktivera eller avaktivera denna enhet"
 ],
 "Enable service": [
  null,
  "Aktivera tjänst"
 ],
 "Enable the firewall": [
  null,
  "Slå på brandväggen"
 ],
 "Enabled": [
  null,
  "Aktiverad"
 ],
 "Enter a valid MAC address": [
  null,
  "Ange en giltig MAC-adress"
 ],
 "Entire subnet": [
  null,
  "Hela subnätet"
 ],
 "Ethernet MAC": [
  null,
  "Ethernet-MAC"
 ],
 "Ethernet MTU": [
  null,
  "Ethernet-MTU"
 ],
 "Ethtool": [
  null,
  "Ethtool"
 ],
 "Example: 22,ssh,8080,5900-5910": [
  null,
  "Exempel: 22,ssh,8080,5900-5910"
 ],
 "Example: 88,2019,nfs,rsync": [
  null,
  "Exempel: 88,2019,nfs,rsync"
 ],
 "Failed": [
  null,
  "Misslyckades"
 ],
 "Failed to add port": [
  null,
  "Kunde inte lägga till port"
 ],
 "Failed to add service": [
  null,
  "Kunde inte lägga till tjänst"
 ],
 "Failed to add zone": [
  null,
  "Kunde inte lägga till zon"
 ],
 "Failed to edit service": [
  null,
  "Kunde inte redigera tjänst"
 ],
 "Failed to save settings": [
  null,
  "Misslyckades att spara inställningarna"
 ],
 "Filter services": [
  null,
  "Filtrera tjänster"
 ],
 "Firewall": [
  null,
  "Brandvägg"
 ],
 "Firewall is not available": [
  null,
  "Brandväggen är inte tillgänglig"
 ],
 "Forward delay $forward_delay": [
  null,
  "Fördröjning framåt $forward_delay"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "General": [
  null,
  "Allmänt"
 ],
 "Go to now": [
  null,
  "Gå till nu"
 ],
 "Group": [
  null,
  "Grupp"
 ],
 "Hair pin mode": [
  null,
  "Hårnålsläge"
 ],
 "Hairpin mode": [
  null,
  "Hårnålsläge"
 ],
 "Hello time $hello_time": [
  null,
  "Hälsningstid $hello_time"
 ],
 "ID": [
  null,
  "ID"
 ],
 "ID $id": [
  null,
  "ID $id"
 ],
 "IP address": [
  null,
  "IP-adress"
 ],
 "IP address with routing prefix. Separate multiple values with a comma. Example: 192.0.2.0/24, 2001:db8::/32": [
  null,
  "IP-adress med prefix. Separera flera adresser med komma. Exempel: 192.0.2.0/24,2001:db8::/32"
 ],
 "IPv4": [
  null,
  "IPv4"
 ],
 "IPv4 settings": [
  null,
  "IPv4-inställningar"
 ],
 "IPv6": [
  null,
  "IPv6"
 ],
 "IPv6 settings": [
  null,
  "IPv6-inställningar"
 ],
 "If left empty, ID will be generated based on associated port services and port numbers": [
  null,
  "Om det lämnas tomt kommer ett ID att genereras baserat på associerade porttjänster och portnummer"
 ],
 "Ignore": [
  null,
  "Ignorera"
 ],
 "Inactive": [
  null,
  "Inaktiv"
 ],
 "Included services": [
  null,
  "Inkluderade tjänster"
 ],
 "Incoming requests are blocked by default. Outgoing requests are not blocked.": [
  null,
  "Inkommande förfrågningar blockeras som standard. Utgående förfrågningar blockeras inte."
 ],
 "Interface": [
  null,
  "Gränssnitt",
  "Gränssnitt"
 ],
 "Interface members": [
  null,
  "Gränssnittsmedlemmar"
 ],
 "Interfaces": [
  null,
  "Gränssnitt"
 ],
 "Invalid address $0": [
  null,
  "Felaktig adress $0"
 ],
 "Invalid metric $0": [
  null,
  "Felaktigt mått $0"
 ],
 "Invalid port number": [
  null,
  "Felaktigt portnummer"
 ],
 "Invalid prefix $0": [
  null,
  "Felaktigt prefix $0"
 ],
 "Invalid prefix or netmask $0": [
  null,
  "Felaktigt prefix eller nätmask $0"
 ],
 "Invalid range": [
  null,
  "Felaktigt område"
 ],
 "Keep connection": [
  null,
  "Behåll förbindelsen"
 ],
 "LACP key": [
  null,
  "LACP-nyckel"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "Link down delay": [
  null,
  "Fördröjning när länk nere"
 ],
 "Link local": [
  null,
  "Länklokal"
 ],
 "Link monitoring": [
  null,
  "Länkövervakning"
 ],
 "Link up delay": [
  null,
  "Fördröjning när länk uppe"
 ],
 "Link watch": [
  null,
  "Länkbetraktelse"
 ],
 "Load balancing": [
  null,
  "Lastbalansering"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MII (recommended)": [
  null,
  "MII (Rekommenderas)"
 ],
 "MTU": [
  null,
  "MTU"
 ],
 "MTU must be a positive number": [
  null,
  "MTU måste vara ett positivt tal"
 ],
 "Managed interfaces": [
  null,
  "Hanterade gränssnitt"
 ],
 "Managing VLANs": [
  null,
  "Hantera VLAN"
 ],
 "Managing firewall": [
  null,
  "Hantera brandvägg"
 ],
 "Managing networking bonds": [
  null,
  "Hantera nätverksbindningar"
 ],
 "Managing networking bridges": [
  null,
  "Hantera nätverksbryggor"
 ],
 "Managing networking teams": [
  null,
  "Hantera nätverksteam"
 ],
 "Manual": [
  null,
  "Manuell"
 ],
 "Maximum message age $max_age": [
  null,
  "Maximal meddelandeålder $max_age"
 ],
 "Metric": [
  null,
  "Mått"
 ],
 "Mode": [
  null,
  "Läge"
 ],
 "Monitoring interval": [
  null,
  "Övervakningsintervall"
 ],
 "Monitoring targets": [
  null,
  "Övervakningsmål"
 ],
 "NSNA ping": [
  null,
  "NSNA-ping"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Network bond": [
  null,
  "Nätverksbindning"
 ],
 "Network devices and graphs require NetworkManager": [
  null,
  "Nätverksenheter och -grafer behöver NetworkManager"
 ],
 "Network logs": [
  null,
  "Nätverksloggar"
 ],
 "NetworkManager is not installed": [
  null,
  "NetworkManager är inte installerad"
 ],
 "NetworkManager is not running": [
  null,
  "NetworkManager kör inte"
 ],
 "Networking": [
  null,
  "Nätverk"
 ],
 "No": [
  null,
  "Nej"
 ],
 "No carrier": [
  null,
  "Ingen bärvåg"
 ],
 "No description available": [
  null,
  "Ingen beskrivning finns"
 ],
 "None": [
  null,
  "Inga"
 ],
 "Not authorized to disable the firewall": [
  null,
  "Inte behörig att inaktivera brandväggen"
 ],
 "Not authorized to enable the firewall": [
  null,
  "Inte behörig att aktivera brandväggen"
 ],
 "Not available": [
  null,
  "Inte tillgängligt"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Options": [
  null,
  "Alternativ"
 ],
 "Parent": [
  null,
  "Förälder"
 ],
 "Parent $parent": [
  null,
  "Förälder $parent"
 ],
 "Part of $0": [
  null,
  "Del av $0"
 ],
 "Passive": [
  null,
  "Passiv"
 ],
 "Path cost": [
  null,
  "Sökvägskostnad"
 ],
 "Path cost $path_cost": [
  null,
  "Sökvägskostnad $path_cost"
 ],
 "Permanent": [
  null,
  "Permanent"
 ],
 "Ping interval": [
  null,
  "Ping-intervall"
 ],
 "Ping target": [
  null,
  "Ping-mål"
 ],
 "Please install the $0 package": [
  null,
  "Installera paketet $0"
 ],
 "Port number and type do not match": [
  null,
  "Portnummer och typ matchar inte"
 ],
 "Ports": [
  null,
  "Portar"
 ],
 "Prefix length": [
  null,
  "Prefixlängd"
 ],
 "Prefix length or netmask": [
  null,
  "Prefixlängd eller nätmask"
 ],
 "Preparing": [
  null,
  "Förbereder"
 ],
 "Preserve": [
  null,
  "Bevara"
 ],
 "Primary": [
  null,
  "Primär"
 ],
 "Priority": [
  null,
  "Prioritet"
 ],
 "Priority $priority": [
  null,
  "Prioritet $priority"
 ],
 "Random": [
  null,
  "Slumpvis"
 ],
 "Range": [
  null,
  "Räckvidd"
 ],
 "Range must be strictly ordered": [
  null,
  "Räckvidden måste vara strikt ordnad"
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Receiving": [
  null,
  "Tar emot"
 ],
 "Remove $0": [
  null,
  "Ta bort $0"
 ],
 "Remove $0 service from $1 zone": [
  null,
  "Ta bort tjänsten $0 från zon $1"
 ],
 "Remove item": [
  null,
  "Ta bort post"
 ],
 "Remove service $0": [
  null,
  "Ta bort tjänst $0"
 ],
 "Remove zone $0": [
  null,
  "Ta bort zon $0"
 ],
 "Removing $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att ta bort $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Removing the cockpit service might result in the web console becoming unreachable. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Att ta bort cockpittjänsten kan leda till att webbkonsolen blir oåtkomlig. Se till att den här zonen inte gäller din nuvarande webbkonsolanslutning."
 ],
 "Removing the zone will remove all services within it.": [
  null,
  "Om du tar bort zonen tas alla tjänster inom den bort."
 ],
 "Restoring connection": [
  null,
  "Återställer förbindelsen"
 ],
 "Round robin": [
  null,
  "Turas om"
 ],
 "Routes": [
  null,
  "Rutter"
 ],
 "Runner": [
  null,
  "Körare"
 ],
 "STP forward delay": [
  null,
  "Fördröjning av STP-vidarebefordran"
 ],
 "STP hello time": [
  null,
  "STP Hello-tid"
 ],
 "STP maximum message age": [
  null,
  "STP maximal meddelandeålder"
 ],
 "STP priority": [
  null,
  "STP-prioritet"
 ],
 "Save": [
  null,
  "Spara"
 ],
 "Search domain": [
  null,
  "Sökdomäner"
 ],
 "Select method": [
  null,
  "Välj metod"
 ],
 "Sending": [
  null,
  "Skickar"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Service": [
  null,
  "Tjänst"
 ],
 "Services": [
  null,
  "Tjänster"
 ],
 "Set to": [
  null,
  "Sätt till"
 ],
 "Shared": [
  null,
  "Delad"
 ],
 "Sorted from least to most trusted": [
  null,
  "Sorterad från minst till mest betrodd"
 ],
 "Spanning tree protocol": [
  null,
  "Uppspännande-träd-protokollet"
 ],
 "Spanning tree protocol (STP)": [
  null,
  "Uppspännande-träd-protokollet (STP)"
 ],
 "Stable": [
  null,
  "Stabilt"
 ],
 "Start service": [
  null,
  "Starta tjänst"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Sticky": [
  null,
  "Fast"
 ],
 "Switch of $0": [
  null,
  "Ändra till $0"
 ],
 "Switch off $0": [
  null,
  "Stäng av $0"
 ],
 "Switch on $0": [
  null,
  "Sätt på $0"
 ],
 "Switching off $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att slå av $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "Switching on $0 will break the connection to the server, and will make the administration UI unavailable.": [
  null,
  "Att sätta på $0 kommer bryta anslutningen till servern, och kommer göra administrationsgränssnittet otillgängligt."
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Team": [
  null,
  "Team"
 ],
 "Team port": [
  null,
  "Team-port"
 ],
 "Team port settings": [
  null,
  "Team-portsinställningar"
 ],
 "Team settings": [
  null,
  "Team-inställningar"
 ],
 "Testing connection": [
  null,
  "Testar anslutningen"
 ],
 "The cockpit service is automatically included": [
  null,
  "Cockpit tjänsten ingår automatiskt"
 ],
 "There are no active services in this zone": [
  null,
  "Det finns inga aktiva tjänster i denna zon"
 ],
 "This device cannot be managed here.": [
  null,
  "Denna enhet kan inte hanteras här."
 ],
 "This zone contains the cockpit service. Make sure that this zone does not apply to your current web console connection.": [
  null,
  "Denna zon innehåller cockpit-tjänsten. Se till att denna zon inte gäller din aktuella webbkonsolanslutning."
 ],
 "Transmitting": [
  null,
  "Överföring"
 ],
 "Troubleshoot…": [
  null,
  "Felsök…"
 ],
 "Trust level": [
  null,
  "Tillitsnivå"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unexpected error": [
  null,
  "Oväntat fel"
 ],
 "Unknown": [
  null,
  "Okänd"
 ],
 "Unknown \"$0\"": [
  null,
  "Okänt ”$0”"
 ],
 "Unknown configuration": [
  null,
  "Okänd konfiguration"
 ],
 "Unknown service name": [
  null,
  "Okänt tjänstnamn"
 ],
 "Unmanaged interfaces": [
  null,
  "Ej hanterade gränssnitt"
 ],
 "Use": [
  null,
  "Använd"
 ],
 "VLAN": [
  null,
  "VLAN"
 ],
 "VLAN ID": [
  null,
  "VLAN-ID"
 ],
 "VLAN settings": [
  null,
  "VLAN-inställningar"
 ],
 "View all logs": [
  null,
  "Visa alla loggar"
 ],
 "Waiting": [
  null,
  "Väntar"
 ],
 "XOR": [
  null,
  "XOR"
 ],
 "Yes": [
  null,
  "Ja"
 ],
 "You are not authorized to modify the firewall.": [
  null,
  "Du har inte rättigheter att ändra brandväggen."
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 byte med binärdata]"
 ],
 "[binary data]": [
  null,
  "[binärdata]"
 ],
 "[no data]": [
  null,
  "[inga data]"
 ],
 "bond": [
  null,
  "bindning"
 ],
 "bridge": [
  null,
  "brygga"
 ],
 "edit": [
  null,
  "redigera"
 ],
 "firewall": [
  null,
  "brandvägg"
 ],
 "firewalld": [
  null,
  "firewalld"
 ],
 "interface": [
  null,
  "gränssnitt"
 ],
 "ipv4": [
  null,
  "ipv4"
 ],
 "ipv6": [
  null,
  "ipv6"
 ],
 "mac": [
  null,
  "mac"
 ],
 "network": [
  null,
  "nätverk"
 ],
 "port": [
  null,
  "port"
 ],
 "show less": [
  null,
  "visa mindre"
 ],
 "show more": [
  null,
  "visa mer"
 ],
 "tcp": [
  null,
  "tcp"
 ],
 "team": [
  null,
  "team"
 ],
 "udp": [
  null,
  "udp"
 ],
 "vlan": [
  null,
  "vlan"
 ],
 "zone": [
  null,
  "zon"
 ]
});
