cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "$0 (encrypted)": [
  null,
  "$0 (şifrelenmiş)"
 ],
 "$0 Stratis pool": [
  null,
  "$0 Stratis havuzu"
 ],
 "$0 block device": [
  null,
  "$0 blok aygıtı"
 ],
 "$0 cache": [
  null,
  "$0 önbelleği"
 ],
 "$0 chunk size": [
  null,
  "$0 parça boyutu"
 ],
 "$0 data": [
  null,
  "$0 verisi"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 veri + $1 ek yük kullanıldı, toplam $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 gün",
  "$0 gün"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk eksik",
  "$0 disk eksik"
 ],
 "$0 disks": [
  null,
  "$0 disk"
 ],
 "$0 filesystems can not be made larger.": [
  null,
  "$0 dosya sistemleri genişletilemez."
 ],
 "$0 filesystems can not be made smaller.": [
  null,
  "$0 dosya sistemleri küçültülemez."
 ],
 "$0 filesystems can not be resized here.": [
  null,
  "$0 dosya sistemleri burada yeniden boyutlandırılamaz."
 ],
 "$0 hour": [
  null,
  "$0 saat",
  "$0 saat"
 ],
 "$0 is in use": [
  null,
  "$0 kullanımda"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0, hiçbir depoda yok."
 ],
 "$0 minute": [
  null,
  "$0 dakika",
  "$0 dakika"
 ],
 "$0 month": [
  null,
  "$0 ay",
  "$0 ay"
 ],
 "$0 of unknown tier": [
  null,
  "$0 bilinmeyen katmanı"
 ],
 "$0 slot remains": [
  null,
  "$0 yuva kaldı",
  "$0 yuva kaldı"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 kullanıldı, toplam $1 ($2 tasarruf edildi)"
 ],
 "$0 week": [
  null,
  "$0 hafta",
  "$0 hafta"
 ],
 "$0 will be installed.": [
  null,
  "$0 yüklenecektir."
 ],
 "$0 year": [
  null,
  "$0 yıl",
  "$0 yıl"
 ],
 "$0, $1 free": [
  null,
  "$0, $1 boş"
 ],
 "$name (from $host)": [
  null,
  "$name ($host cihazından)"
 ],
 "(recommended)": [
  null,
  "(önerilir)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 gün"
 ],
 "1 hour": [
  null,
  "1 saat"
 ],
 "1 week": [
  null,
  "1 hafta"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "5 minutes": [
  null,
  "5 dakika"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 saat"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Bu havuzda bu adda bir dosya sistemi zaten var."
 ],
 "A pool with this name exists already.": [
  null,
  "Bu adda bir havuz zaten var."
 ],
 "A spare disk needs to be added first before this disk can be removed.": [
  null,
  "Bu diskin kaldırılabilmesi için önce yedek bir diskin eklenmesi gerekir."
 ],
 "Action": [
  null,
  "Eylem"
 ],
 "Activate": [
  null,
  "Etkinleştir"
 ],
 "Activating $target": [
  null,
  "$target etkinleştiriliyor"
 ],
 "Add": [
  null,
  "Ekle"
 ],
 "Add block devices": [
  null,
  "Blok aygıtlarını ekle"
 ],
 "Add disks": [
  null,
  "Diskleri ekle"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI portalı ekle"
 ],
 "Add key": [
  null,
  "Anahtar ekle"
 ],
 "Adding physical volume to $target": [
  null,
  "$target aygıtına fiziksel birim ekleniyor"
 ],
 "Additional packages:": [
  null,
  "Ek paketler:"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "Address cannot be empty": [
  null,
  "Adres boş olamaz"
 ],
 "Address is not a valid URL": [
  null,
  "Adres geçerli bir URL değil"
 ],
 "At least $0 disk is needed.": [
  null,
  "En az $0 disk gerekli.",
  "En az $0 disk gerekli."
 ],
 "At least one block device is needed.": [
  null,
  "En az bir blok aygıtı gerekli."
 ],
 "At least one disk is needed.": [
  null,
  "En az bir disk gerekli."
 ],
 "Authentication required": [
  null,
  "Kimlik doğrulaması gerekli"
 ],
 "Available targets on $0": [
  null,
  "$0 üzerindeki kullanılabilir hedefler"
 ],
 "Backing device": [
  null,
  "Yedeklenen aygıt"
 ],
 "Block": [
  null,
  "Blok"
 ],
 "Block device for filesystems": [
  null,
  "Dosya sistemleri için blok aygıtı"
 ],
 "Block devices": [
  null,
  "Blok aygıtlar"
 ],
 "Blocked": [
  null,
  "Engellendi"
 ],
 "Cache": [
  null,
  "Önbellek"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Change": [
  null,
  "Değiştir"
 ],
 "Change iSCSI initiator name": [
  null,
  "iSCSI başlatıcı adını değiştir"
 ],
 "Change passphrase": [
  null,
  "Parolayı değiştir"
 ],
 "Checking $target": [
  null,
  "$target denetleniyor"
 ],
 "Checking RAID device $target": [
  null,
  "RAID aygıtı $target denetleniyor"
 ],
 "Checking and repairing RAID device $target": [
  null,
  "RAID aygıtı $target denetleniyor ve onarılıyor"
 ],
 "Checking installed software": [
  null,
  "Yüklü yazılımlar denetleniyor"
 ],
 "Checking related processes": [
  null,
  "İlgili işlemler denetleniyor"
 ],
 "Chunk size": [
  null,
  "Öbek boyutu"
 ],
 "Cleaning up for $target": [
  null,
  "$target temizleniyor"
 ],
 "Cleartext device": [
  null,
  "Metin temizleme aygıtı"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Command": [
  null,
  "Komut"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Tüm sistem ve aygıtlarla uyumlu (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Modern sistem ve 2TB'tan büyük sabit disklerle uyumlu (GPT)"
 ],
 "Compression": [
  null,
  "Sıkıştırma"
 ],
 "Confirm": [
  null,
  "Onayla"
 ],
 "Confirm deletion of $0": [
  null,
  "$0 aygıtının silinmesini onayla"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Kaldırmayı alternatif bir parola ile onayla"
 ],
 "Confirm stopping of $0": [
  null,
  "$0 aygıtının durdurulmasını onaylayın"
 ],
 "Content": [
  null,
  "İçerik"
 ],
 "Copy to clipboard": [
  null,
  "Panoya kopyala"
 ],
 "Create": [
  null,
  "Oluştur"
 ],
 "Create LVM2 volume group": [
  null,
  "LVM2 birim grubu oluştur"
 ],
 "Create RAID device": [
  null,
  "RAID aygıtı oluştur"
 ],
 "Create Stratis pool": [
  null,
  "Stratis havuzu oluştur"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "$0 dosya sistemi için anlık görüntü oluştur"
 ],
 "Create devices": [
  null,
  "Aygıtları oluştur"
 ],
 "Create filesystem": [
  null,
  "Dosya sistemi oluştur"
 ],
 "Create logical volume": [
  null,
  "Mantıksal birim oluştur"
 ],
 "Create new filesystem": [
  null,
  "Yeni dosya sistemi oluştur"
 ],
 "Create new logical volume": [
  null,
  "Yeni mantıksal birim oluştur"
 ],
 "Create partition": [
  null,
  "Bölüm oluştur"
 ],
 "Create partition on $0": [
  null,
  "$0 üzerinde bölüm oluştur"
 ],
 "Create partition table": [
  null,
  "Bölüm tablosu oluştur"
 ],
 "Create snapshot": [
  null,
  "Anlık görüntü oluştur"
 ],
 "Create thin volume": [
  null,
  "İnce birim oluştur"
 ],
 "Create volume group": [
  null,
  "Birim grubu oluştur"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "$target LVM2 birim grubu oluşturuluyor"
 ],
 "Creating RAID device $target": [
  null,
  "RAID aygıtı $target oluşturuluyor"
 ],
 "Creating VDO device": [
  null,
  "VDO aygıtı oluşturuluyor"
 ],
 "Creating filesystem on $target": [
  null,
  "$target üzerinde dosya sistemi oluşturuluyor"
 ],
 "Creating logical volume $target": [
  null,
  "$target mantıksal birimi oluşturuluyor"
 ],
 "Creating partition $target": [
  null,
  "$target bölümü oluşturuluyor"
 ],
 "Creating snapshot of $target": [
  null,
  "$target için anlık görüntü oluşturuluyor"
 ],
 "Currently in use": [
  null,
  "Şu an kullanımda"
 ],
 "Custom mount options": [
  null,
  "Özel bağlama seçenekleri"
 ],
 "Data": [
  null,
  "Veri"
 ],
 "Data used": [
  null,
  "Kullanılan veri"
 ],
 "Deactivate": [
  null,
  "Devre dışı bırak"
 ],
 "Deactivating $target": [
  null,
  "$target devre dışı bırakılıyor"
 ],
 "Deduplication": [
  null,
  "Tekilleştirme"
 ],
 "Delete": [
  null,
  "Sil"
 ],
 "Deleting $target": [
  null,
  "$target siliniyor"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "$target LVM2 birim grubu siliniyor"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Bir Stratis havuzunu silmek içerdiği tüm verileri silecek."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Bir dosya sistemini silmek, içindeki tüm verileri silecek."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Mantıksal bir birimi silmek, içindeki tüm verileri silecektir."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Bir bölümü silmek, içindeki tüm verileri silecektir."
 ],
 "Deleting erases all data on a RAID device.": [
  null,
  "Silme, bir RAID aygıtı üzerindeki tüm verileri siler."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Silme, bir VDO aygıtı üzerindeki tüm verileri siler."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Silme, bir birim grubu üzerindeki tüm verileri siler."
 ],
 "Description": [
  null,
  "Açıklama"
 ],
 "Device": [
  null,
  "Aygıt"
 ],
 "Device file": [
  null,
  "Aygıt dosyası"
 ],
 "Device is read-only": [
  null,
  "Aygıt salt-okunur"
 ],
 "Devices": [
  null,
  "Aygıtlar"
 ],
 "Disk is OK": [
  null,
  "Disk TAMAM"
 ],
 "Disk is failing": [
  null,
  "Disk bozuluyor"
 ],
 "Disk passphrase": [
  null,
  "Disk parolası"
 ],
 "Disks": [
  null,
  "Diskler"
 ],
 "Do not mount automatically on boot": [
  null,
  "Önyüklemede otomatik olarak bağlama"
 ],
 "Downloading $0": [
  null,
  "$0 indiriliyor"
 ],
 "Drive": [
  null,
  "Sürücü"
 ],
 "Drives": [
  null,
  "Sürücüler"
 ],
 "Edit": [
  null,
  "Düzenle"
 ],
 "Edit Tang keyserver": [
  null,
  "Tang anahtar sunucusunu düzenle"
 ],
 "Editing a key requires a free slot": [
  null,
  "Bir anahtarı düzenlemek, boş bir yuva gerektirir"
 ],
 "Ejecting $target": [
  null,
  "$target çıkarılıyor"
 ],
 "Emptying $target": [
  null,
  "$target boşaltılıyor"
 ],
 "Encrypt data": [
  null,
  "Verileri şifrele"
 ],
 "Encrypted $0": [
  null,
  "Şifrelenmiş $0"
 ],
 "Encrypted Stratis pool $0": [
  null,
  "Şifrelenmiş $0 Stratis havuzu"
 ],
 "Encrypted logical volume of $0": [
  null,
  "$0 aygıtının şifrelenmiş mantıksal birimi"
 ],
 "Encrypted partition of $0": [
  null,
  "$0 aygıtının şifrelenmiş bölümü"
 ],
 "Encrypted volumes can not be resized here.": [
  null,
  "Şifrelenmiş birimler burada yeniden boyutlandırılamaz."
 ],
 "Encrypted volumes need to be unlocked before they can be resized.": [
  null,
  "Şifrelenmiş birimlerin yeniden boyutlandırılabilmeleri için kilidinin açılması gerekir."
 ],
 "Encryption": [
  null,
  "Şifreleme"
 ],
 "Encryption options": [
  null,
  "Şifreleme seçenekleri"
 ],
 "Encryption type": [
  null,
  "Şifreleme türü"
 ],
 "Erasing $target": [
  null,
  "$target siliniyor"
 ],
 "Error": [
  null,
  "Hata"
 ],
 "Extended partition": [
  null,
  "Genişletilmiş bölüm"
 ],
 "Failed": [
  null,
  "Başarısız oldu"
 ],
 "Filesystem": [
  null,
  "Dosya sistemi"
 ],
 "Filesystem is locked": [
  null,
  "Dosya sistemi kilitli"
 ],
 "Filesystem name": [
  null,
  "Dosya sistemi adı"
 ],
 "Filesystems": [
  null,
  "Dosya sistemleri"
 ],
 "Format": [
  null,
  "Biçimlendir"
 ],
 "Format $0": [
  null,
  "$0 biçimlendir"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Biçimlendirme, depolama aygıtı üzerindeki tüm verileri siler."
 ],
 "Free": [
  null,
  "Boş"
 ],
 "Free space": [
  null,
  "Boş alan"
 ],
 "Free up space in this group: Shrink or delete other logical volumes or add another physical volume.": [
  null,
  "Bu grupta yer açın: Diğer mantıksal birimleri küçültün veya silin ya da başka bir fiziksel birim ekleyin."
 ],
 "Go to now": [
  null,
  "Şimdiye git"
 ],
 "Grow": [
  null,
  "Büyüt"
 ],
 "Grow content": [
  null,
  "İçeriği büyüt"
 ],
 "Grow logical size of $0": [
  null,
  "$0'ın mantıksal boyutunu büyüt"
 ],
 "Grow logical volume": [
  null,
  "Mantıksal birimi büyüt"
 ],
 "Grow to take all space": [
  null,
  "Tüm alanı kaplayacak şekilde büyüt"
 ],
 "If this option is checked, the filesystem will not be mounted during the next boot even if it was mounted before it.  This is useful if mounting during boot is not possible, such as when a passphrase is required to unlock the filesystem but booting is unattended.": [
  null,
  "Eğer bu seçenek işaretlenirse, dosya sistemi bir sonraki önyükleme sırasında, önüne bağlanmış olsa bile bağlanmayacaktır. Bu, önyükleme sırasında bağlama mümkün değilse , örneğin dosya sisteminin kilidini açmak için bir parola gerektiğinde, ancak önyüklemenin katılımsız olmasında yararlıdır."
 ],
 "In sync": [
  null,
  "Eşitleme durumunda"
 ],
 "Inactive volume": [
  null,
  "Etkin olmayan birim"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Tutarsız dosya sistemi bağlama"
 ],
 "Index memory": [
  null,
  "İndeks belleği"
 ],
 "Initialize": [
  null,
  "Başlat"
 ],
 "Initialize disk $0": [
  null,
  "$0 diskini başlat"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Başlatma, disk üzerindeki tüm verileri siler."
 ],
 "Install": [
  null,
  "Yükle"
 ],
 "Install NFS support": [
  null,
  "NFS desteğini yükle"
 ],
 "Install Stratis support": [
  null,
  "Stratis desteğini yükle"
 ],
 "Install software": [
  null,
  "Yazılım yükle"
 ],
 "Installing $0": [
  null,
  "$0 yükleniyor"
 ],
 "Installing $0 would remove $1.": [
  null,
  "$0 paketini yüklemek $1 paketini kaldırır."
 ],
 "Installing packages": [
  null,
  "Paketler yükleniyor"
 ],
 "Invalid username or password": [
  null,
  "Geçersiz kullanıcı adı veya parola"
 ],
 "Jobs": [
  null,
  "İşler"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Bilinmeyen türlere sahip anahtar yuvaları burada düzenlenemez"
 ],
 "Key source": [
  null,
  "Anahtar kaynağı"
 ],
 "Keys": [
  null,
  "Anahtarlar"
 ],
 "Keyserver": [
  null,
  "Anahtar sunucusu"
 ],
 "Keyserver address": [
  null,
  "Anahtar sunucusu adresi"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Anahtar sunucusu kaldırma, $0 kilidini açmayı engelleyebilir."
 ],
 "LVM2 member": [
  null,
  "LVM2 üyesi"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 birimi grubu"
 ],
 "LVM2 volume group $0": [
  null,
  "$0 LVM2 birimi grubu"
 ],
 "Last modified: $0": [
  null,
  "Son değiştirilme: $0"
 ],
 "Learn more": [
  null,
  "Daha fazla bilgi edinin"
 ],
 "Loading...": [
  null,
  "Yükleniyor..."
 ],
 "Local mount point": [
  null,
  "Yerel bağlama noktası"
 ],
 "Location": [
  null,
  "Konum"
 ],
 "Lock": [
  null,
  "Kilitle"
 ],
 "Locked devices": [
  null,
  "Kilitli aygıtlar"
 ],
 "Locked encrypted Stratis pool": [
  null,
  "Kilitli şifrelenmiş Stratis havuzu"
 ],
 "Locking $target": [
  null,
  "$target kilitleniyor"
 ],
 "Logical": [
  null,
  "Mantıksal"
 ],
 "Logical size": [
  null,
  "Mantıksal boyut"
 ],
 "Logical volume": [
  null,
  "Mantıksal birim"
 ],
 "Logical volume (snapshot)": [
  null,
  "Mantıksal birim (anlık görüntü)"
 ],
 "Logical volume of $0": [
  null,
  "$0 bölümünün mantıksal birimi"
 ],
 "Logical volumes": [
  null,
  "Mantıksal birimler"
 ],
 "Make sure the key hash from the Tang server matches one of the following:": [
  null,
  "Tang sunucusundaki anahtar adreslemesinin aşağıdakilerden biriyle eşleştiğinden emin olun:"
 ],
 "Managing LVMs": [
  null,
  "LVM'leri yönetme"
 ],
 "Managing NFS mounts": [
  null,
  "NFS bağlamalarını yönetme"
 ],
 "Managing RAIDs": [
  null,
  "RAID'leri yönetme"
 ],
 "Managing VDOs": [
  null,
  "VDO'ları yönetme"
 ],
 "Managing partitions": [
  null,
  "Bölümleri yönetme"
 ],
 "Managing physical drives": [
  null,
  "Fiziksel sürücüleri yönetme"
 ],
 "Manually check with SSH: ": [
  null,
  "SSH ile elle denetleyin: "
 ],
 "Marking $target as faulty": [
  null,
  "$target hatalı olarak işaretleniyor"
 ],
 "Metadata used": [
  null,
  "Kullanılan üst veri"
 ],
 "Modifying $target": [
  null,
  "$target değiştiriliyor"
 ],
 "Mount": [
  null,
  "Bağla"
 ],
 "Mount also automatically on boot": [
  null,
  "Önyüklemede de otomatik olarak bağla"
 ],
 "Mount at boot": [
  null,
  "Önyüklemede bağla"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Önyüklemede $0 noktasına otomatik olarak bağla"
 ],
 "Mount configuration": [
  null,
  "Bağlama yapılandırması"
 ],
 "Mount filesystem": [
  null,
  "Dosya sistemini bağla"
 ],
 "Mount now": [
  null,
  "Şimdi bağla"
 ],
 "Mount on $0 now": [
  null,
  "Şimdi $0 noktasına bağla"
 ],
 "Mount options": [
  null,
  "Bağlama seçenekleri"
 ],
 "Mount point": [
  null,
  "Bağlama noktası"
 ],
 "Mount point cannot be empty": [
  null,
  "Bağlama noktası boş olamaz"
 ],
 "Mount point cannot be empty.": [
  null,
  "Bağlama noktası boş olamaz."
 ],
 "Mount point is already used for $0": [
  null,
  "Bağlama noktası zaten $0 için kullanılıyor"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Bağlama noktası \"/\" ile başlamak zorundadır."
 ],
 "Mount read only": [
  null,
  "Salt okunur bağla"
 ],
 "Mounting $target": [
  null,
  "$target bağlanıyor"
 ],
 "NFS mount": [
  null,
  "NFS bağlama noktası"
 ],
 "NFS mounts": [
  null,
  "NFS bağlama noktaları"
 ],
 "NFS support not installed": [
  null,
  "NFS desteği yüklü değil"
 ],
 "Name": [
  null,
  "Ad"
 ],
 "Name can not be empty.": [
  null,
  "Ad boş olamaz."
 ],
 "Name cannot be empty.": [
  null,
  "Ad boş olamaz."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Ad $0 bayt'tan uzun olamaz"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Ad $0 karakterden uzun olamaz"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Ad 127 karakterden uzun olamaz."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Ad '$0' karakterini içeremez."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Ad boşluk karakterleri içeremez."
 ],
 "Never mount at boot": [
  null,
  "Önyüklemede asla bağlama"
 ],
 "New NFS mount": [
  null,
  "Yeni NFS bağlama noktası"
 ],
 "New passphrase": [
  null,
  "Yeni parola"
 ],
 "Next": [
  null,
  "Sonraki"
 ],
 "No NFS mounts set up": [
  null,
  "NFS bağlama noktası ayarlanmadı"
 ],
 "No available slots": [
  null,
  "Kullanılabilir yuvalar yok"
 ],
 "No block devices are available.": [
  null,
  "Kullanılabilir blok aygıtlar yok."
 ],
 "No devices": [
  null,
  "Aygıtlar yok"
 ],
 "No disks are available.": [
  null,
  "Kullanılabilir diskler yok."
 ],
 "No drives attached": [
  null,
  "Bağlı sürücüler yok"
 ],
 "No encryption": [
  null,
  "Şifreleme yok"
 ],
 "No filesystem": [
  null,
  "Dosya sistemi yok"
 ],
 "No filesystems": [
  null,
  "Dosya sistemleri yok"
 ],
 "No free key slots": [
  null,
  "Boş anahtar yuvaları yok"
 ],
 "No free space": [
  null,
  "Boş alan yok"
 ],
 "No iSCSI targets set up": [
  null,
  "iSCSI hedefleri ayarlanmadı"
 ],
 "No keys added": [
  null,
  "Eklenen anahtarlar yok"
 ],
 "No logical volumes": [
  null,
  "Mantıksal birimler yok"
 ],
 "No media inserted": [
  null,
  "Takılı ortam yok"
 ],
 "No partitioning": [
  null,
  "Bölümlendirme yok"
 ],
 "Not enough space to grow.": [
  null,
  "Büyütmek için yeterli alan yok."
 ],
 "Not found": [
  null,
  "Bulunamadı"
 ],
 "Not mounted": [
  null,
  "Bağlanmadı"
 ],
 "Not running": [
  null,
  "Çalışmıyor"
 ],
 "Ok": [
  null,
  "Tamam"
 ],
 "Old passphrase": [
  null,
  "Eski parola"
 ],
 "Only $0 of $1 are used.": [
  null,
  "Sadece $0 / $1 kullanılıyor."
 ],
 "Operation '$operation' on $target": [
  null,
  "$target üzerinde '$operation' işlemi"
 ],
 "Options": [
  null,
  "Seçenekler"
 ],
 "Other devices": [
  null,
  "Diğer aygıtlar"
 ],
 "Overwrite": [
  null,
  "Üzerine yaz"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Varolan verilerin üzerine sıfırlarla yaz (daha yavaş)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit çöktü"
 ],
 "Partition": [
  null,
  "Bölüm"
 ],
 "Partition of $0": [
  null,
  "$0'ın bölümü"
 ],
 "Partitioned block device": [
  null,
  "Bölünmüş blok aygıtı"
 ],
 "Partitioning": [
  null,
  "Bölümlendirme"
 ],
 "Partitions": [
  null,
  "Bölümler"
 ],
 "Passphrase": [
  null,
  "Parola"
 ],
 "Passphrase can not be empty": [
  null,
  "Parola boş olamaz"
 ],
 "Passphrase cannot be empty": [
  null,
  "Parola boş olamaz"
 ],
 "Passphrase from any other key slot": [
  null,
  "Başka bir anahtar yuvasından gelen parola"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Parolayı kaldırma, $0 kilidini açmayı engelleyebilir."
 ],
 "Passphrases do not match": [
  null,
  "Parolalar eşleşmiyor"
 ],
 "Password": [
  null,
  "Parola"
 ],
 "Path on server": [
  null,
  "Sunucu üzerindeki yol"
 ],
 "Path on server cannot be empty.": [
  null,
  "Sunucu üzerindeki yol boş olamaz."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Sunucu üzerindeki yol \"/\" ile başlamak zorundadır."
 ],
 "Permanently delete $0?": [
  null,
  "$0 aygıtı kalıcı olarak silinsin mi?"
 ],
 "Physical": [
  null,
  "Fiziksel"
 ],
 "Physical volumes": [
  null,
  "Fiziksel birimler"
 ],
 "Physical volumes can not be resized here.": [
  null,
  "Fiziksel birimler burada yeniden boyutlandırılamaz."
 ],
 "Pool": [
  null,
  "Havuz"
 ],
 "Pool for thin logical volumes": [
  null,
  "İnce mantıksal birimler için havuz"
 ],
 "Pool for thin volumes": [
  null,
  "İnce birimler için havuz"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Ölçülü kaynak sağlanan birimler için havuz"
 ],
 "Port": [
  null,
  "Bağlantı noktası"
 ],
 "Processes using the location": [
  null,
  "Konumu kullanan işlemler"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Şu blok aygıtlarda havuz için parolayı sağlayın:"
 ],
 "Purpose": [
  null,
  "Amaç"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (şeritleme)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (yansıtma)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (yansıtmaları şeritleme)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (ayrılmış eşlik)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (dağıtılmış eşlik)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (çift dağıtılmış eşlik)"
 ],
 "RAID device": [
  null,
  "RAID aygıtı"
 ],
 "RAID device $0": [
  null,
  "RAID aygıtı $0"
 ],
 "RAID level": [
  null,
  "RAID seviyesi"
 ],
 "RAID member": [
  null,
  "RAID üyesi"
 ],
 "Reading": [
  null,
  "Okunuyor"
 ],
 "Reboot": [
  null,
  "Yeniden başlat"
 ],
 "Recovering": [
  null,
  "Kurtarılıyor"
 ],
 "Recovering RAID device $target": [
  null,
  "RAID aygıtı $target kurtarılıyor"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "İlgili işlemler ve hizmetler zorla durdurulacaktır."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "İlgili işlemler zorla durdurulacaktır."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "İlgili hizmetler zorla durdurulacaktır."
 ],
 "Removals:": [
  null,
  "Kaldırılanlar:"
 ],
 "Remove": [
  null,
  "Kaldır"
 ],
 "Remove $0?": [
  null,
  "$0 kaldırılsın mı?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Tang anahtar sunucusu kaldırılsın mı?"
 ],
 "Remove device": [
  null,
  "Aygıtı kaldır"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "$0 anahtar yuvası içindeki parola kaldırılsın mı?"
 ],
 "Removing $0": [
  null,
  "$0 kaldırılıyor"
 ],
 "Removing $target from RAID device": [
  null,
  "RAID aygıtından $target kaldırılıyor"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Başka bir parolayı onaylamadan bir parolayı kaldırmak, diğer parolalar unutulur veya kaybolursa, kilit açma veya anahtar yönetimini önleyebilir."
 ],
 "Removing physical volume from $target": [
  null,
  "$target aygıtından fiziksel birim kaldırılıyor"
 ],
 "Rename": [
  null,
  "Yeniden adlandır"
 ],
 "Rename Stratis pool": [
  null,
  "Stratis havuzunu yeniden adlandır"
 ],
 "Rename filesystem": [
  null,
  "Dosya sistemini yeniden adlandır"
 ],
 "Rename logical volume": [
  null,
  "Mantıksal birimi yeniden adlandır"
 ],
 "Rename volume group": [
  null,
  "Birim grubunu yeniden adlandır"
 ],
 "Renaming $target": [
  null,
  "$target yeniden adlandırılıyor"
 ],
 "Repairing $target": [
  null,
  "$target onarılıyor"
 ],
 "Repeat passphrase": [
  null,
  "Parolayı tekrarla"
 ],
 "Resizing $target": [
  null,
  "$target yeniden boyutlandırılıyor"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Şifrelenmiş bir dosya sistemini yeniden boyutlandırmak, diskin kilidinin açılmasını gerektirir. Lütfen şu anki bir disk parolasını girin."
 ],
 "Reuse existing encryption": [
  null,
  "Varolan şifrelemeyi yeniden kullan"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Varolan şifrelemeyi yeniden kullan ($0)"
 ],
 "Running": [
  null,
  "Çalışıyor"
 ],
 "Runtime": [
  null,
  "Çalışma zamanı"
 ],
 "SHA1": [
  null,
  "SHA1"
 ],
 "SHA256": [
  null,
  "SHA256"
 ],
 "SMART self-test of $target": [
  null,
  "$target aygıtının SMART kendi kendini denemesi"
 ],
 "Save": [
  null,
  "Kaydet"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "LZ4 ile ayrı blokları sıkıştırarak alandan tasarruf edin"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Aynı veri bloklarını sadece bir kez depolayarak alandan tasarruf edin"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Yeni bir parola kaydetmek, diskin kilidinin açılmasını gerektirir. Lütfen şu anki bir disk parolasını girin."
 ],
 "Securely erasing $target": [
  null,
  "$target güvenli bir şekilde siliniyor"
 ],
 "Server": [
  null,
  "Sunucu"
 ],
 "Server address": [
  null,
  "Sunucu adresi"
 ],
 "Server address cannot be empty.": [
  null,
  "Sunucu adresi boş olamaz."
 ],
 "Server cannot be empty.": [
  null,
  "Sunucu boş olamaz."
 ],
 "Service": [
  null,
  "Hizmet"
 ],
 "Services using the location": [
  null,
  "Konumu kullanan hizmetler"
 ],
 "Setting up loop device $target": [
  null,
  "Döngü aygıtı $target ayarlanıyor"
 ],
 "Show $0 device": [
  null,
  "$0 aygıtı göster",
  "$0 aygıtın tümünü göster"
 ],
 "Show $0 drive": [
  null,
  "$0 sürücüyü göster",
  "$0 sürücünün tümünü göster"
 ],
 "Show all": [
  null,
  "Tümünü göster"
 ],
 "Shrink": [
  null,
  "Küçült"
 ],
 "Shrink logical volume": [
  null,
  "Mantıksal birimi küçült"
 ],
 "Shrink volume": [
  null,
  "Birimi küçült"
 ],
 "Size": [
  null,
  "Boyut"
 ],
 "Size cannot be negative": [
  null,
  "Boyut sıfırdan küçük olamaz"
 ],
 "Size cannot be zero": [
  null,
  "Boyut sıfır olamaz"
 ],
 "Size is too large": [
  null,
  "Boyut çok büyük"
 ],
 "Size must be a number": [
  null,
  "Boyut bir sayı olmak zorundadır"
 ],
 "Size must be at least $0": [
  null,
  "Boyut en az $0 olmak zorundadır"
 ],
 "Slot $0": [
  null,
  "Yuva $0"
 ],
 "Snapshot": [
  null,
  "Anlık görüntü"
 ],
 "Source": [
  null,
  "Kaynak"
 ],
 "Spare": [
  null,
  "Yedek"
 ],
 "Start": [
  null,
  "Başlat"
 ],
 "Start multipath": [
  null,
  "Multipath hizmetini başlat"
 ],
 "Starting RAID device $target": [
  null,
  "RAID aygıtı $target başlatılıyor"
 ],
 "Starting swapspace $target": [
  null,
  "Takas alanı $target başlatılıyor"
 ],
 "Stop": [
  null,
  "Durdur"
 ],
 "Stop and remove": [
  null,
  "Durdur ve kaldır"
 ],
 "Stop and unmount": [
  null,
  "Durdur ve bağlantısını kaldır"
 ],
 "Stop device": [
  null,
  "Aygıtı durdur"
 ],
 "Stopping RAID device $target": [
  null,
  "RAID aygıtı $target durduruluyor"
 ],
 "Stopping swapspace $target": [
  null,
  "Takas alanı $target durduruluyor"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Bu sistemde depolama yönetilemez."
 ],
 "Storage logs": [
  null,
  "Depolama günlükleri"
 ],
 "Store passphrase": [
  null,
  "Parolayı sakla"
 ],
 "Stored passphrase": [
  null,
  "Saklanmış parola"
 ],
 "Stratis member": [
  null,
  "Stratis üyesi"
 ],
 "Stratis pool": [
  null,
  "Stratis havuzu"
 ],
 "Stratis pool $0": [
  null,
  "$0 Stratis havuzu"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Başarılı olarak panoya kopyalandı!"
 ],
 "Support is installed.": [
  null,
  "Destek yüklendi."
 ],
 "Swap": [
  null,
  "Takas"
 ],
 "Synchronizing RAID device $target": [
  null,
  "RAID aygıtı $target eşitleniyor"
 ],
 "Tang keyserver": [
  null,
  "Tang anahtar sunucusu"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Stratis havuzları oluşturmak için $0 paketi yüklenmek zorundadır."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "VDO aygıtları oluşturmak için $0 paketi yüklenecektir."
 ],
 "The RAID array is in a degraded state": [
  null,
  "RAID dizilimi düşürülmüş bir durumda"
 ],
 "The RAID device must be running in order to add spare disks.": [
  null,
  "Yedek diskler eklemek için RAID aygıtı çalışıyor olmak zorundadır."
 ],
 "The RAID device must be running in order to remove disks.": [
  null,
  "Diskleri kaldırmak için RAID aygıtı çalışıyor olmak zorundadır."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Bu VDO aygıtının oluşturulması tamamlanmadı ve aygıt kullanılamaz."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Şu anda oturum açmış olan kullanıcının anahtarlar hakkındaki bilgileri görmesine izin verilmiyor."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "Biçimlendirmeden önce diskin kilidinin açılması gerekir. Lütfen varolan bir parola verin."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Dosya sisteminin kalıcı bağlama noktası yok."
 ],
 "The filesystem is already mounted at $0. Proceeding will unmount it.": [
  null,
  "Dosya sistemi zaten $0 konumuna bağlanmış. Devam etmek bağlantısını kaldıracak."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Dosya sistemi önyüklemede otomatik olarak bağlanacak şekilde yapılandırıldı ancak şifreleme kapsayıcısının kilidi o anda açılmayacaktır."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Dosya sistemi şu anda bağlanmış durumda ancak bir sonraki önyüklemeden sonra bağlanmayacak."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Dosya sistemi şu anda $0 noktasında bağlanmış durumda ancak bir sonraki önyüklemede $1 noktasında bağlanacak."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Dosya sistemi şu anda $0 noktasında bağlanmış durumda ancak bir sonraki önyüklemeden sonra bağlanmayacak."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Dosya sistemi şu anda bağlanmış değil ancak bir sonraki önyüklemede bağlanacak."
 ],
 "The filesystem is not mounted.": [
  null,
  "Dosya sistemi bağlanmadı."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Dosya sisteminin kilidi açılacak ve bir sonraki önyüklemeye bağlanacaktır. Bu bir parola girmeyi gerektirebilir."
 ],
 "The last disk of a RAID device cannot be removed.": [
  null,
  "Bir RAID aygıtının son diski kaldırılamaz."
 ],
 "The last key slot can not be removed": [
  null,
  "Son anahtar yuvası kaldırılamaz"
 ],
 "The last physical volume of a volume group cannot be removed.": [
  null,
  "Bir birim grubunun son fiziksel birimi kaldırılamaz."
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Listelenen işlemler ve hizmetler zorla durdurulacaktır."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Listelenen işlemler zorla durdurulacaktır."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Listelenen hizmetler zorla durdurulacaktır."
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "$0 bağlama noktası şu işlemler tarafından kullanılmakta:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "$0 bağlama noktası şu hizmetler tarafından kullanılmakta:"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Sistemde birden çok yola sahip aygıtlar var, ancak multipath hizmeti çalışmıyor."
 ],
 "There is not enough free space elsewhere to remove this physical volume. At least $0 more free space is needed.": [
  null,
  "Bu fiziksel birimi kaldırmak için başka bir yerde yeterli boş alan yok. En az $0 daha boş alana ihtiyaç var."
 ],
 "These changes will be made:": [
  null,
  "Şu değişiklikler yapılacaktır:"
 ],
 "Thin logical volume": [
  null,
  "İnce mantıksal birim"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Bu NFS bağlama noktası kullanımda ve sadece seçenekleri değiştirilebilir."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Bu VDO aygıtı, yedek aygıtlarının tümünü kullanmıyor."
 ],
 "This device is currently in use.": [
  null,
  "Bu aygıt şu anda kullanımda."
 ],
 "This disk cannot be removed while the device is recovering.": [
  null,
  "Aygıt kurtarılırken bu disk kaldırılamaz."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Bu mantıksal birim, içeriği tarafından tamamen kullanılmıyor."
 ],
 "This pool can not be unlocked here because its key description is not in the expected format.": [
  null,
  "Anahtar açıklaması beklenen biçimde olmadığından, bu havuzun kilidi burada açılamaz."
 ],
 "This volume needs to be activated before it can be resized.": [
  null,
  "Bu birimin yeniden boyutlandırılabilmesi için etkinleştirilmesi gerekir."
 ],
 "Tier": [
  null,
  "Katman"
 ],
 "Toggle": [
  null,
  "Değiştir"
 ],
 "Toggle bitmap": [
  null,
  "Bit eşlemi aç/kapat"
 ],
 "Total size: $0": [
  null,
  "Toplam boyut: $0"
 ],
 "Trust key": [
  null,
  "Güvenilen anahtar"
 ],
 "Type": [
  null,
  "Tür"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "Sunucuya ulaşılamıyor"
 ],
 "Unable to remove mount": [
  null,
  "Bağlama noktası kaldırılamıyor"
 ],
 "Unable to unmount filesystem": [
  null,
  "Dosya sisteminin bağlantısı kaldırılamıyor"
 ],
 "Unknown": [
  null,
  "Bilinmiyor"
 ],
 "Unknown ($0)": [
  null,
  "Bilinmeyen ($0)"
 ],
 "Unknown host name": [
  null,
  "Bilinmeyen anamakine adı"
 ],
 "Unknown type": [
  null,
  "Bilinmeyen tür"
 ],
 "Unlock": [
  null,
  "Kilidi aç"
 ],
 "Unlock automatically on boot": [
  null,
  "Önyüklemede kilidi otomatik olarak aç"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Şifrelenmiş Stratis havuzu kilidini aç"
 ],
 "Unlock pool to see filesystems.": [
  null,
  "Dosya sistemlerini görmek için havuz kilidini aç."
 ],
 "Unlocking $target": [
  null,
  "$target kilidi açılıyor"
 ],
 "Unlocking disk": [
  null,
  "Disk kilidi açılıyor"
 ],
 "Unmount": [
  null,
  "Bağlantıyı kaldır"
 ],
 "Unmount filesystem $0": [
  null,
  "$0 dosya sistemi bağlantısını kaldır"
 ],
 "Unmount now": [
  null,
  "Şimdi bağlantıyı kaldır"
 ],
 "Unmounting $target": [
  null,
  "$target bağlantısı kaldırılıyor"
 ],
 "Unrecognized data": [
  null,
  "Tanınmayan veri"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Tanınmayan veriler burada küçültülemez."
 ],
 "Unsupported volume": [
  null,
  "Desteklenmeyen birim"
 ],
 "Usage": [
  null,
  "Kullanım"
 ],
 "Usage of $0": [
  null,
  "$0 kullanımı"
 ],
 "Use": [
  null,
  "Kullan"
 ],
 "Use compression": [
  null,
  "Sıkıştırma kullan"
 ],
 "Use deduplication": [
  null,
  "Tekilleştirme kullan"
 ],
 "Used": [
  null,
  "Kullanılan"
 ],
 "Used for": [
  null,
  "Kullanılma"
 ],
 "User": [
  null,
  "Kullanıcı"
 ],
 "Username": [
  null,
  "Kullanıcı adı"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS şifrelemesi kullanma"
 ],
 "Using Tang server": [
  null,
  "Tang sunucusu kullanma"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO yedek aygıtları küçültülemez"
 ],
 "VDO device": [
  null,
  "VDO aygıtı"
 ],
 "VDO device $0": [
  null,
  "VDO aygıtı $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO dosya sistemi birimi (sıkıştırma/kopyaları kaldırma)"
 ],
 "VDO pool": [
  null,
  "VDO havuzu"
 ],
 "Verify key": [
  null,
  "Anahtarı doğrula"
 ],
 "Very securely erasing $target": [
  null,
  "$target çok güvenli bir şekilde siliniyor"
 ],
 "View all logs": [
  null,
  "Tüm günlükleri görüntüle"
 ],
 "Volume": [
  null,
  "Birim"
 ],
 "Volume group": [
  null,
  "Birim grubu"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Birim boyutu $0. İçerik boyutu $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Diğer yazılım yönetimi işlemlerinin bitmesi bekleniyor"
 ],
 "Write-mostly": [
  null,
  "Çoğunlukla yazma"
 ],
 "Writing": [
  null,
  "Yazma"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bayt ikili veri]"
 ],
 "[binary data]": [
  null,
  "[ikili veri]"
 ],
 "[no data]": [
  null,
  "[veri yok]"
 ],
 "backing device for VDO device": [
  null,
  "VDO aygıtı için aygıt yedekleniyor"
 ],
 "delete": [
  null,
  "sil"
 ],
 "disk": [
  null,
  "disk"
 ],
 "drive": [
  null,
  "sürücü"
 ],
 "edit": [
  null,
  "düzenle"
 ],
 "encryption": [
  null,
  "şifreleme"
 ],
 "filesystem": [
  null,
  "dosya sistemi"
 ],
 "format": [
  null,
  "biçim"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "grow": [
  null,
  "büyüt"
 ],
 "iSCSI targets": [
  null,
  "iSCSI hedefleri"
 ],
 "initialize": [
  null,
  "başlat"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "member of RAID device": [
  null,
  "RAID aygıtı üyesi"
 ],
 "member of Stratis pool": [
  null,
  "Stratis havuzu üyesi"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "bağla"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "never mounted at boot": [
  null,
  "önyüklemede asla bağlanmasın"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "none": [
  null,
  "yok"
 ],
 "partition": [
  null,
  "bölüm"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2 birim grubunun fiziksel birimi"
 ],
 "raid": [
  null,
  "raid"
 ],
 "read only": [
  null,
  "salt okunur"
 ],
 "remove from LVM2": [
  null,
  "LVM2'den kaldır"
 ],
 "remove from RAID": [
  null,
  "RAID'den kaldır"
 ],
 "shrink": [
  null,
  "küçült"
 ],
 "stop": [
  null,
  "durdur"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unknown target": [
  null,
  "bilinmeyen hedef"
 ],
 "unmount": [
  null,
  "bağlantıyı kaldır"
 ],
 "unpartitioned space on $0": [
  null,
  "$0 üzerinde bölümlendirilmemiş alan"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "birim"
 ],
 "yes": [
  null,
  "evet"
 ],
 "storage-id-desc\u0004$0 filesystem": [
  null,
  "$0 dosya sistemi"
 ],
 "storage-id-desc\u0004Filesystem (encrypted)": [
  null,
  "Dosya sistemi (şifrelenmiş)"
 ],
 "storage-id-desc\u0004Locked encrypted data": [
  null,
  "Kilitli şifrelenmiş veriler"
 ],
 "storage-id-desc\u0004Other data": [
  null,
  "Diğer veriler"
 ],
 "storage-id-desc\u0004Swap space": [
  null,
  "Takas alanı"
 ],
 "storage-id-desc\u0004Unrecognized data": [
  null,
  "Tanınmayan veri"
 ],
 "storage-id-desc\u0004VDO backing": [
  null,
  "VDO yedek"
 ],
 "storage\u0004Assessment": [
  null,
  "Değerlendirme"
 ],
 "storage\u0004Bitmap": [
  null,
  "Bitmap"
 ],
 "storage\u0004Capacity": [
  null,
  "Kapasite"
 ],
 "storage\u0004Device": [
  null,
  "Aygıt"
 ],
 "storage\u0004Device file": [
  null,
  "Aygıt dosyası"
 ],
 "storage\u0004Firmware version": [
  null,
  "Aygıt yazılımı sürümü"
 ],
 "storage\u0004Model": [
  null,
  "Model"
 ],
 "storage\u0004Multipathed devices": [
  null,
  "Çok yollu aygıtlar"
 ],
 "storage\u0004Optical drive": [
  null,
  "Optik sürücü"
 ],
 "storage\u0004RAID level": [
  null,
  "RAID seviyesi"
 ],
 "storage\u0004Removable drive": [
  null,
  "Çıkarılabilir sürücü"
 ],
 "storage\u0004Serial number": [
  null,
  "Seri numarası"
 ],
 "storage\u0004State": [
  null,
  "Durum"
 ],
 "storage\u0004UUID": [
  null,
  "UUID"
 ],
 "storage\u0004Usage": [
  null,
  "Kullanım"
 ],
 "storage\u0004World wide name": [
  null,
  "Dünya geneli ad (WWN)"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bayt"
 ]
});
