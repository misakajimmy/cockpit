cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 (encrypted)": [
  null,
  "$0 (დაშიფრული)"
 ],
 "$0 Stratis pool": [
  null,
  "Stratis-ის $0 პული"
 ],
 "$0 block device": [
  null,
  "$0 ბლოკური მოწყობილობა"
 ],
 "$0 cache": [
  null,
  "$0 ქეში"
 ],
 "$0 chunk size": [
  null,
  "ნაგლეჯის ზომა $0"
 ],
 "$0 data": [
  null,
  "$0 მონაცემები"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 მონაცემები + $1 დამატებით გამოყენებული $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 დღე",
  "დღეები: $0"
 ],
 "$0 disk is missing": [
  null,
  "$0 დისკი აკლია",
  "$0 ცალი დისკი აკლია"
 ],
 "$0 disks": [
  null,
  "$0 დისკი"
 ],
 "$0 filesystems can not be made larger.": [
  null,
  "$0 ფაილური სისტემა მეტად ვეღარ გაიზრდება."
 ],
 "$0 filesystems can not be made smaller.": [
  null,
  "$0 ფაილური სისტემა მეტად ვეღარ დაპატარავდება."
 ],
 "$0 filesystems can not be resized here.": [
  null,
  "$0 ფაილური სისტემაის ზომას აქ ვერ შეცვლით."
 ],
 "$0 hour": [
  null,
  "$0 საათი",
  "საათი: $0"
 ],
 "$0 is in use": [
  null,
  "$0 გამოიყენება"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 ხელმიუწვდომელია ყველა რეპოზიტორიიდან."
 ],
 "$0 minute": [
  null,
  "$0 წუთი",
  "წუთი: $0"
 ],
 "$0 month": [
  null,
  "$0 თვე",
  "თვე: $0"
 ],
 "$0 of unknown tier": [
  null,
  "$0 უცნობი კლასიდან"
 ],
 "$0 slot remains": [
  null,
  "დარჩენილია $0 სლოტი",
  "დარჩენილი სლოტების რაოდენობა $0"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "გამოყენებულია $0 $1-დან (შენახულია $2)"
 ],
 "$0 week": [
  null,
  "$0 კვირა",
  "კვირა: $0"
 ],
 "$0 will be installed.": [
  null,
  "დაყენდება $0."
 ],
 "$0 year": [
  null,
  "$0 წელი",
  "წელი: $0"
 ],
 "$0, $1 free": [
  null,
  "$0, $1 თავისუფალი"
 ],
 "$name (from $host)": [
  null,
  "$name ($host-დან)"
 ],
 "(recommended)": [
  null,
  "(რეკომენდებულია)"
 ],
 "1 MiB": [
  null,
  "1 მიბ"
 ],
 "1 day": [
  null,
  "1 დღე"
 ],
 "1 hour": [
  null,
  "1 საათი"
 ],
 "1 week": [
  null,
  "1 კვირა"
 ],
 "128 KiB": [
  null,
  "128 კიბ"
 ],
 "16 KiB": [
  null,
  "16 კიბ"
 ],
 "2 MiB": [
  null,
  "2 მიბ"
 ],
 "32 KiB": [
  null,
  "32 კიბ"
 ],
 "4 KiB": [
  null,
  "4 კიბ"
 ],
 "5 minutes": [
  null,
  "5 წთ"
 ],
 "512 KiB": [
  null,
  "512 კიბ"
 ],
 "6 hours": [
  null,
  "5 სთ"
 ],
 "64 KiB": [
  null,
  "64 კიბ"
 ],
 "8 KiB": [
  null,
  "8 კიბ"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "ფაილური სისტემა ამ სახელით მითითებულ პულში უკვე არსებობს."
 ],
 "A pool with this name exists already.": [
  null,
  "პული ამ სახელით უკვე არსებობს."
 ],
 "A spare disk needs to be added first before this disk can be removed.": [
  null,
  "დისკის მოცილებამდე საჭიროა სამარქაფო დისკის დამატება."
 ],
 "Action": [
  null,
  "ქმედება"
 ],
 "Activate": [
  null,
  "აქტივაცია"
 ],
 "Activating $target": [
  null,
  "$target-ის აქტივაცია"
 ],
 "Add": [
  null,
  "დამატება"
 ],
 "Add block devices": [
  null,
  "ბლოკური მოწყობილობების დამატება"
 ],
 "Add disks": [
  null,
  "დისკების დამატება"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI პორტალის დამატება"
 ],
 "Add key": [
  null,
  "გასაღების დამატება"
 ],
 "Adding physical volume to $target": [
  null,
  "$target-ზე ფიზიკური მოცულობების დამატება"
 ],
 "Additional packages:": [
  null,
  "დამატებითი პაკეტები:"
 ],
 "Address": [
  null,
  "მისამართი"
 ],
 "Address cannot be empty": [
  null,
  "მისამართი არ შეიძლება ცარიელი იყოს"
 ],
 "Address is not a valid URL": [
  null,
  "მისამართი არ წარმოადგენს სწორ URL-ს"
 ],
 "At least $0 disk is needed.": [
  null,
  "საჭიროა $0 დისკი მაინც.",
  "საჭიროა $0 ცალი დისკი მაინც."
 ],
 "At least one block device is needed.": [
  null,
  "საჭიროა ერთი ბლოკური ტიპის მოწყობილობა მაინც."
 ],
 "At least one disk is needed.": [
  null,
  "საჭიროა ერთი დისკი მაინც."
 ],
 "Authentication required": [
  null,
  "საჭიროა ავთენტიკაცია"
 ],
 "Available targets on $0": [
  null,
  "ხელმისაწვდომი სამიზნე $0-ზე"
 ],
 "Backing device": [
  null,
  "სამარქაფო მოწყობილობა"
 ],
 "Block": [
  null,
  "ბლოკი"
 ],
 "Block device for filesystems": [
  null,
  "ბლოკური მოწყობილობები ფაილური სისტემებისთვის"
 ],
 "Block devices": [
  null,
  "ბლოკური მოწყობილობები"
 ],
 "Blocked": [
  null,
  "დაბლოკილია"
 ],
 "Cache": [
  null,
  "ქეში"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Change": [
  null,
  "შეცვლა"
 ],
 "Change iSCSI initiator name": [
  null,
  "iSCSI ინიციატორის სახელის შეცვლა"
 ],
 "Change passphrase": [
  null,
  "საკვანძო ფრაზის შეცვლა"
 ],
 "Checking $target": [
  null,
  "$target-ის შემოწმება"
 ],
 "Checking RAID device $target": [
  null,
  "RAID მოწყობილობის, $target-ის შემოწმება"
 ],
 "Checking and repairing RAID device $target": [
  null,
  "RAID მოწყობილობა $target-ის შემოწმება და შეკეთება"
 ],
 "Checking installed software": [
  null,
  "დაყენებული პროგრამული უზრუნველყოფის შემოწმება"
 ],
 "Checking related processes": [
  null,
  "შესაბამისი პროცესების შემოწმება"
 ],
 "Chunk size": [
  null,
  "ბლოკის ზომა"
 ],
 "Cleaning up for $target": [
  null,
  "$target-ის გასუფთავება"
 ],
 "Cleartext device": [
  null,
  "მოწყობილობის შექმნა"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Command": [
  null,
  "ბრძანება"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "თავსებადია ყველა სისტემასა და მოწყობილობასთან (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "თავსებადია თანამედროვე სისტემებთან და >2TB დისკებთან (GPT)"
 ],
 "Compression": [
  null,
  "შეკუმშვა"
 ],
 "Confirm": [
  null,
  "დასტური"
 ],
 "Confirm deletion of $0": [
  null,
  "დაადასტურეთ $0-ის წაშლა"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "არასავალდებულო საკვნძო ფრაზის წაშლის დადასტურება"
 ],
 "Confirm stopping of $0": [
  null,
  "დაადასტურეთ $0-ის გაჩერება"
 ],
 "Content": [
  null,
  "შემცველობა"
 ],
 "Copy to clipboard": [
  null,
  "ბაფერში კოპირება"
 ],
 "Create": [
  null,
  "შექმნა"
 ],
 "Create LVM2 volume group": [
  null,
  "LVM2 საცავის ჯგუფის შექმნა"
 ],
 "Create RAID device": [
  null,
  "RAID მოწყობილობის შექმნა"
 ],
 "Create Stratis pool": [
  null,
  "Stratis-ის პულის შექმნა"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "ფაილური სისტემა $0-ის მყისიერი ასლის გადაღება"
 ],
 "Create devices": [
  null,
  "მოწყობილობების შექმნა"
 ],
 "Create filesystem": [
  null,
  "ფაილური სისტემის შექმნა"
 ],
 "Create logical volume": [
  null,
  "ლოგიკური ტომის შექმნა"
 ],
 "Create new filesystem": [
  null,
  "ახალი ფაილური სისტემის შექმნა"
 ],
 "Create new logical volume": [
  null,
  "ახალი ლოგიკური ტომის შექმნა"
 ],
 "Create partition": [
  null,
  "განაყოფის შექმნა"
 ],
 "Create partition on $0": [
  null,
  "$0-ზე სექციის შექმნა"
 ],
 "Create partition table": [
  null,
  "დაყოფის ცხრილის შექმნა"
 ],
 "Create snapshot": [
  null,
  "სწრაფი ასლის შექმნა"
 ],
 "Create thin volume": [
  null,
  "თხელი ტომის შექმნა"
 ],
 "Create volume group": [
  null,
  "ტომების ჯგუფის შექმნა"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "LVM2 საცავების ჯგუფი $target-ის შექმნა"
 ],
 "Creating RAID device $target": [
  null,
  "RAID მოწყობილობა $target-ის შექმნა"
 ],
 "Creating VDO device": [
  null,
  "VDO მოწყობილობის შექმნა"
 ],
 "Creating filesystem on $target": [
  null,
  "$target-ზე ფაილური სისტემის შექმნა"
 ],
 "Creating logical volume $target": [
  null,
  "ლოგიკური საცავს $target-ის შექმნა"
 ],
 "Creating partition $target": [
  null,
  "დანაყოფის შექმნა $target"
 ],
 "Creating snapshot of $target": [
  null,
  "$taget-ის სწრაფი ასლის შექმნა"
 ],
 "Currently in use": [
  null,
  "ამჟამად გამოიყენება"
 ],
 "Custom mount options": [
  null,
  "მიმაგრების მორგება"
 ],
 "Data": [
  null,
  "მონაცემები"
 ],
 "Data used": [
  null,
  "გამოყენებული მონაცემები"
 ],
 "Deactivate": [
  null,
  "დეაქტივაცია"
 ],
 "Deactivating $target": [
  null,
  "$target-ის დეაქტივაცია"
 ],
 "Deduplication": [
  null,
  "დედუპლიკაცია"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Deleting $target": [
  null,
  "$target-ის წაშლა"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "LVM2 საცავების ჯგუფი $taget-ის წაშლა"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Stratis-ის პულის წაშლა მასზე ჩაწერილი მონაცემების წაშლასაც გამოიწვევს."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "ფაილური სისტემის წაშლა მასზე არსებული მონაცემების წაშლასაც გამოიწვევს."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "ლოგიკური საცავის წაშლა მასზე მდებარე მონაცემების წაშლასაც გამოიწვევს."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "დანაყოფის წაშლა მასზე მდებარე მონაცემების წაშლასაც გამოიწვევს."
 ],
 "Deleting erases all data on a RAID device.": [
  null,
  "RAID მოწყობილობის წაშლის შემთხვევაში ასევე წაიშლება ზედ მდებარე მონაცემებიც."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "VDO მოწყობილობის წაშლის შემთხვევაში ასევე წაიშლება ზედ მდებარე ყველა მონაცემი."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "საცავების ჯგუფის წაშლისას ასევე წაიშლება ზედ მდებარე მონაცემებიც."
 ],
 "Description": [
  null,
  "აღწერა"
 ],
 "Device": [
  null,
  "მოწყობილობა"
 ],
 "Device file": [
  null,
  "მოწყობილობის ფაილი"
 ],
 "Device is read-only": [
  null,
  "მოწყობილობა მხოლოდ კითხვადია"
 ],
 "Devices": [
  null,
  "მოწყობილობები"
 ],
 "Disk is OK": [
  null,
  "დისკი კარგად გამოიყურება"
 ],
 "Disk is failing": [
  null,
  "დისკი კვდება"
 ],
 "Disk passphrase": [
  null,
  "დისკის საკვანძო სიტყვა"
 ],
 "Disks": [
  null,
  "დისკები"
 ],
 "Do not mount automatically on boot": [
  null,
  "ჩატვირთვისას არ მიმაგრება"
 ],
 "Downloading $0": [
  null,
  "$0-ის გადმოწერა"
 ],
 "Drive": [
  null,
  "დისკი"
 ],
 "Drives": [
  null,
  "დისკები"
 ],
 "Edit": [
  null,
  "ჩასწორება"
 ],
 "Edit Tang keyserver": [
  null,
  "Tang გასაღებების სერვერის ჩასწორება"
 ],
 "Editing a key requires a free slot": [
  null,
  "გასაღების ჩასასწორებლად საჭიროა თავისუფალი სლოტი"
 ],
 "Ejecting $target": [
  null,
  "$target-ის გამოგდება"
 ],
 "Emptying $target": [
  null,
  "$target-ის დაცარიელება"
 ],
 "Encrypt data": [
  null,
  "მონაცემების დაშიფვრა"
 ],
 "Encrypted $0": [
  null,
  "$0 დაშიფრულია"
 ],
 "Encrypted Stratis pool $0": [
  null,
  "სტრატისის დაშიფრული პული $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "ლოგიკური დაშიფრული საცავი $0"
 ],
 "Encrypted partition of $0": [
  null,
  "$0-ის დაშიფრული სექცია"
 ],
 "Encrypted volumes can not be resized here.": [
  null,
  "დაშიფრული საცავების ზომის შეცვლას აქედან ვერ შეძლებთ."
 ],
 "Encrypted volumes need to be unlocked before they can be resized.": [
  null,
  "ზომის შეცვლამდე საჭიროა დაშიფრული საცავების განბლოკვა."
 ],
 "Encryption": [
  null,
  "დაშიფვრა"
 ],
 "Encryption options": [
  null,
  "დაშიფვრის მორგება"
 ],
 "Encryption type": [
  null,
  "დაშიფვრის ტიპი"
 ],
 "Erasing $target": [
  null,
  "$target-ის წაშლა"
 ],
 "Error": [
  null,
  "შეცდომა"
 ],
 "Extended partition": [
  null,
  "გაფართოებული განაყოფი"
 ],
 "Failed": [
  null,
  "შეცდომით"
 ],
 "Filesystem": [
  null,
  "ფაილური სისტემა"
 ],
 "Filesystem is locked": [
  null,
  "ფაილური სისტემა ჩაკეტილია"
 ],
 "Filesystem name": [
  null,
  "ფაილური სისტემის სახელი"
 ],
 "Filesystems": [
  null,
  "ფაილური სისტემები"
 ],
 "Format": [
  null,
  "ფორმატი"
 ],
 "Format $0": [
  null,
  "$0-ის დაფორმატება"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "ფორმატირება ბლოკურ მოწყობილობაზე მდებარე ყველა მონაცემს წაშლის."
 ],
 "Free": [
  null,
  "თავისუფალი"
 ],
 "Free space": [
  null,
  "თავისუფალი სივრცე"
 ],
 "Free up space in this group: Shrink or delete other logical volumes or add another physical volume.": [
  null,
  "გაათავისუფლეთ ადგილი ამ ჯგუფში. შეამცირეთ ან წაშალეთ სხვა ლოგიკური საცავები ან დაამატეთ ახალი ფიზიკური საცავი."
 ],
 "Go to now": [
  null,
  "ახლავე გადასვლა"
 ],
 "Grow": [
  null,
  "გაზრდა"
 ],
 "Grow content": [
  null,
  "შემცველობის გაზრდა"
 ],
 "Grow logical size of $0": [
  null,
  "$0-ის ლოგიკური ზომის გადიდება"
 ],
 "Grow logical volume": [
  null,
  "ლოგიკური ტომის გაზრდა"
 ],
 "Grow to take all space": [
  null,
  "გადიდება მაქს. შესაძლო ზომამდე"
 ],
 "If this option is checked, the filesystem will not be mounted during the next boot even if it was mounted before it.  This is useful if mounting during boot is not possible, such as when a passphrase is required to unlock the filesystem but booting is unattended.": [
  null,
  "თუ ჩართულია, ფაილური სისტემა არ მიმაგრდება შემდეგი ჩატვირთვისას იმის მიუხედავად, იყო თუ არა ის მიმაგრებული მანამდე.  სასარგებლოა, თუ მიმაგრება ჩატვირთვისას შეუძლებელია. მაგალითად, თუ გადატვირთვისას საჭიროა პაროლი."
 ],
 "In sync": [
  null,
  "სინქრონიზებულია"
 ],
 "Inactive volume": [
  null,
  "არააქტიური საცავი"
 ],
 "Inconsistent filesystem mount": [
  null,
  "ფაილური სისტემის არასწორი მიმაგრება"
 ],
 "Index memory": [
  null,
  "ინდექსების მეხსიერება"
 ],
 "Initialize": [
  null,
  "ინიციალიზაცია"
 ],
 "Initialize disk $0": [
  null,
  "დისკის ინიციალიზაცია $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "ინიციალიზაცია დისკზე მდებარე მონაცემებს მთლიანად წაშლის."
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Install NFS support": [
  null,
  "NFS-ის მხარდაჭერის დაყენება"
 ],
 "Install Stratis support": [
  null,
  "Stratis-ის მხარდაჭერის დაყენება"
 ],
 "Install software": [
  null,
  "პროგრამების დაყენება"
 ],
 "Installing $0": [
  null,
  "$0-ის დაყენება"
 ],
 "Installing $0 would remove $1.": [
  null,
  "$0-ის დაყენება წაშლის $1-ს."
 ],
 "Installing packages": [
  null,
  "პაკეტების დაყენება"
 ],
 "Invalid username or password": [
  null,
  "არასწორი მომხმარებელი ან პაროლი"
 ],
 "Jobs": [
  null,
  "ამოცანები"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "უცნობი ტიპის გასაღებების ჩასწორება შეუძლებელია"
 ],
 "Key source": [
  null,
  "გასაღების წყარო"
 ],
 "Keys": [
  null,
  "გასაღებები"
 ],
 "Keyserver": [
  null,
  "გასაღებების სერვერი"
 ],
 "Keyserver address": [
  null,
  "გასაღების სერვერის მისამართი"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "გასაღებების სერვერის წაშლით თქვენ შეიძლება დაკარგოთ $0-ის განბლოკვის საშუალება."
 ],
 "LVM2 member": [
  null,
  "LVM2-ის წევრი"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 ტომების ჯგუფი"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 ტომის ჯგუფი $0"
 ],
 "Last modified: $0": [
  null,
  "ბოლოს შეიცვალა: $0"
 ],
 "Learn more": [
  null,
  "გაიგეთ მეტი"
 ],
 "Loading...": [
  null,
  "ჩატვირთვა..."
 ],
 "Local mount point": [
  null,
  "მიმაგრების ლოკალური წერტილი"
 ],
 "Location": [
  null,
  "მდებარეობა"
 ],
 "Lock": [
  null,
  "დაკეტვა"
 ],
 "Locked devices": [
  null,
  "ჩაკეტილი მოწყობილობები"
 ],
 "Locked encrypted Stratis pool": [
  null,
  "ჩაკეტილი დაშიფრული სტრატისის პული"
 ],
 "Locking $target": [
  null,
  "$target-ის ჩაკეტვა"
 ],
 "Logical": [
  null,
  "ლოგიკური"
 ],
 "Logical size": [
  null,
  "ლოგიკური ზომა"
 ],
 "Logical volume": [
  null,
  "ლოგიკური ტომი"
 ],
 "Logical volume (snapshot)": [
  null,
  "ლოგიკური ტომი (სწრაფი ასლი)"
 ],
 "Logical volume of $0": [
  null,
  "$0-ის ლოგიკური სივრცე"
 ],
 "Logical volumes": [
  null,
  "ლოგიკური ტომები"
 ],
 "Make sure the key hash from the Tang server matches one of the following:": [
  null,
  "სარწმუნდით, რომ Tang სერვერის გასაღების ჰეში ემთხვევა ერთერთს ამ სიიდან:"
 ],
 "Managing LVMs": [
  null,
  "LVM-ის მართვა"
 ],
 "Managing NFS mounts": [
  null,
  "NFS მიმაგრებების მართვა"
 ],
 "Managing RAIDs": [
  null,
  "RAID-ის მართვა"
 ],
 "Managing VDOs": [
  null,
  "VDO-ის მართვა"
 ],
 "Managing partitions": [
  null,
  "დამაყოფების მართვა"
 ],
 "Managing physical drives": [
  null,
  "ფიზიკური დისკების მართვა"
 ],
 "Manually check with SSH: ": [
  null,
  "SSH-სთან ხელით შემოწმება: "
 ],
 "Marking $target as faulty": [
  null,
  "$target-ის გაფუჭებულად მონიშვნა"
 ],
 "Metadata used": [
  null,
  "გამოყენებული მეტამონაცემები"
 ],
 "Modifying $target": [
  null,
  "$target-ის ჩასწორება"
 ],
 "Mount": [
  null,
  "მიმაგრება"
 ],
 "Mount also automatically on boot": [
  null,
  "ავტომატური მიმაგრება ჩატვირთვის დროს"
 ],
 "Mount at boot": [
  null,
  "ჩატვირთვისას მიმაგრება"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "$0-ზე ავტომატურად მიმაგრება ჩატვირთვის დროს"
 ],
 "Mount configuration": [
  null,
  "მიმაგრების კონფიგურაცია"
 ],
 "Mount filesystem": [
  null,
  "ფაილური სისტემის მიმაგრება"
 ],
 "Mount now": [
  null,
  "ახლა მიმაგრება"
 ],
 "Mount on $0 now": [
  null,
  "$0-ზე მიმაგრება"
 ],
 "Mount options": [
  null,
  "მიმაგრების მორგება"
 ],
 "Mount point": [
  null,
  "მიმაგრების წერტილი"
 ],
 "Mount point cannot be empty": [
  null,
  "მიმაგრების წერტილი არ შეიძლება ცარიელი იყოს"
 ],
 "Mount point cannot be empty.": [
  null,
  "მიმაგრების წერტილი არ შეიძლება ცარიელი იყოს."
 ],
 "Mount point is already used for $0": [
  null,
  "მიმაგრების წერტილი უკვე გამოიყენება $0-თვის"
 ],
 "Mount point must start with \"/\".": [
  null,
  "მიმაგრების წერტილი უნდა იწყებოდეს \"/\"-ით."
 ],
 "Mount read only": [
  null,
  "მიმაგრებულია, მხოლოდ წასაკითხად"
 ],
 "Mounting $target": [
  null,
  "$target-ის მიმაგრება"
 ],
 "NFS mount": [
  null,
  "NFS მიმაგრება"
 ],
 "NFS mounts": [
  null,
  "NFS მიმაგრებები"
 ],
 "NFS support not installed": [
  null,
  "NFS-ის მხარდაჭერა დაყენებული არაა"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Name can not be empty.": [
  null,
  "სახელი არ შეიძლება ცარიელი იყოს."
 ],
 "Name cannot be empty.": [
  null,
  "სახელი არ შეიძლება იყოს ცარიელი."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "სახელი არ შეიძლება $0 ბაიტზე გრძელი იყოს"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "სახელი არ შეიძლება $0 სიმბოლოზე მეტი იყოს"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "სახელი არ შეიძლება 127 სიმბოლოზე გრძელი იყოს."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "სახელი არ შეიძლება შეიცავდეს სიმბოლოს '$0'."
 ],
 "Name cannot contain whitespace.": [
  null,
  "სახელი არ შეიძლება შეიცავდეს ცარიელ სიმბოლოებს."
 ],
 "Never mount at boot": [
  null,
  "არ მიამაგრო სისტემის გაშვებისას"
 ],
 "New NFS mount": [
  null,
  "ახალი NFS მიმაგრება"
 ],
 "New passphrase": [
  null,
  "ახალი საკვანძო ფრაზა"
 ],
 "Next": [
  null,
  "შემდეგი"
 ],
 "No NFS mounts set up": [
  null,
  "NFS მიმაგრებები ნაპოვნი არაა"
 ],
 "No available slots": [
  null,
  "თავისუფალი სლოტი ხელმიუწვდომელია"
 ],
 "No block devices are available.": [
  null,
  "ბლოკური მოწყობილობები ხელმიუწვდომელია."
 ],
 "No devices": [
  null,
  "მოწყობილობების გარეშე"
 ],
 "No disks are available.": [
  null,
  "დისკები ხელმიუწვდომელია."
 ],
 "No drives attached": [
  null,
  "დისკები მიმაგრებული არაა"
 ],
 "No encryption": [
  null,
  "დაშიფვრის გარეშე"
 ],
 "No filesystem": [
  null,
  "ფაილური სისტემების გარეშე"
 ],
 "No filesystems": [
  null,
  "ფაილური სისტემების გარეშე"
 ],
 "No free key slots": [
  null,
  "გასაღების თავისუფალი სლოტების გარეშე"
 ],
 "No free space": [
  null,
  "თავისუფალი ადგილის გარეშე"
 ],
 "No iSCSI targets set up": [
  null,
  "iSCSI სამიზნეები მორგებული არაა"
 ],
 "No keys added": [
  null,
  "გასაღებები არ დამატებულა"
 ],
 "No logical volumes": [
  null,
  "ლოგიკური ტომების გარეშე"
 ],
 "No media inserted": [
  null,
  "დისკი არ დევს"
 ],
 "No partitioning": [
  null,
  "დანაყოფების გარეშე"
 ],
 "Not enough space to grow.": [
  null,
  "გასადიდებლად არასაკმარისი სივრცეა."
 ],
 "Not found": [
  null,
  "ნაპოვნი არაა"
 ],
 "Not mounted": [
  null,
  "მიმაგრებული არაა"
 ],
 "Not running": [
  null,
  "გაშვებული არაა"
 ],
 "Ok": [
  null,
  "დიახ"
 ],
 "Old passphrase": [
  null,
  "ძველი საკვანძო ფრაზა"
 ],
 "Only $0 of $1 are used.": [
  null,
  "$1-დან გამოყენებულია მხოლოდ $0."
 ],
 "Operation '$operation' on $target": [
  null,
  "ოპერაცია '$operation' $target-ზე"
 ],
 "Options": [
  null,
  "პარამეტრები"
 ],
 "Other devices": [
  null,
  "სხვა მოწყობილობები"
 ],
 "Overwrite": [
  null,
  "გადაწერა"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "არსებულ მონაცემებზე ნულების გადაწერა (ნელი)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit-ის ავარია"
 ],
 "Partition": [
  null,
  "განაყოფი"
 ],
 "Partition of $0": [
  null,
  "$0-ის დანაყოფი"
 ],
 "Partitioned block device": [
  null,
  "დაყოფილი ბლოკური მოწყობილობა"
 ],
 "Partitioning": [
  null,
  "დაყოფა"
 ],
 "Partitions": [
  null,
  "დანაყოფები"
 ],
 "Passphrase": [
  null,
  "საკვანძო სიტყვა"
 ],
 "Passphrase can not be empty": [
  null,
  "საკვანძო ფრაზა ცარიელი არ შეიძლება იყოს"
 ],
 "Passphrase cannot be empty": [
  null,
  "საკვანძო ფრაზა არ შეიძლება ცარიელი იყოს"
 ],
 "Passphrase from any other key slot": [
  null,
  "საკვანძო ფრაზა ნებისმიერი სხვა გასაღების სლოტიდან"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "საკვანძო ფრაზის მოცილებამ შეიძლება შეუძლებელი გახადოს $0-ის განბლოკვა."
 ],
 "Passphrases do not match": [
  null,
  "საკვანძო ფრაზები ერთმანეთს არ ემთხვევა"
 ],
 "Password": [
  null,
  "პაროლი"
 ],
 "Path on server": [
  null,
  "ბილიკი სერვერზე"
 ],
 "Path on server cannot be empty.": [
  null,
  "სერვერზე ბილიკის ველი არ შეიძლება ცარიელი იყოს."
 ],
 "Path on server must start with \"/\".": [
  null,
  "ბილიკი სერვერზე უნდა იწყებოდეს სიმბოლოთი \"/\"."
 ],
 "Permanently delete $0?": [
  null,
  "წავშალო სამუდამოდ $0?"
 ],
 "Physical": [
  null,
  "ფიზიკური"
 ],
 "Physical volumes": [
  null,
  "ფიზიკური ტომები"
 ],
 "Physical volumes can not be resized here.": [
  null,
  "აქ შეგიძლიათ ფიზიკურ საცავებს ზომა შეუცვალოთ."
 ],
 "Pool": [
  null,
  "პული"
 ],
 "Pool for thin logical volumes": [
  null,
  "თხელი ლოგიკური საცავების პული"
 ],
 "Pool for thin volumes": [
  null,
  "თხელი საცავების პული"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "თხლად გაწერილი საცავების პული"
 ],
 "Port": [
  null,
  "პორტი"
 ],
 "Processes using the location": [
  null,
  "მდებარეობის გამოყენებელი პროცესები"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "შეიყვანეთ საკვანძო ფრაზა ამ ბლოკური მოწყობილობების პულისტვის:"
 ],
 "Purpose": [
  null,
  "დანიშნულება"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (stripe)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (სარკე)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (სარკეების ზოლები)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (გამოყოფილი ლუწობა)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (განაწილებული ლუწობა)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (ორმაგად განაწილებული ლუწობა)"
 ],
 "RAID device": [
  null,
  "RAID მოწყობილობა"
 ],
 "RAID device $0": [
  null,
  "RAID მოწყობილობა $0"
 ],
 "RAID level": [
  null,
  "RAID-ის დონე"
 ],
 "RAID member": [
  null,
  "RAID-ის წევრი"
 ],
 "Reading": [
  null,
  "ვკითხულობ"
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Recovering": [
  null,
  "აღდგენა"
 ],
 "Recovering RAID device $target": [
  null,
  "RAID მოწყობილობა $target-ის აღდგენა"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "დაკავშირებული პროცესები და სერვისები ძალით იქნებიან გაჩერებული."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "დაკავშირებული პროცესები ძალით იქნება გაჩერებული."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "დაკავშირებული სერვისები ძალით იქნება გაჩერებული."
 ],
 "Removals:": [
  null,
  "წაიშლება:"
 ],
 "Remove": [
  null,
  "წაშლა"
 ],
 "Remove $0?": [
  null,
  "წავშალო $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "წავშალო Tang გასაღებების სერვერი?"
 ],
 "Remove device": [
  null,
  "მოწყობილობის წაშლა"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "წავშალო საკვანძო ფრაზა გასაღების სლოტი $0-დან?"
 ],
 "Removing $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Removing $target from RAID device": [
  null,
  "$target-ის RAID მოწყობილობიდან მოცილება"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "კვანძური ფრაზის წაშლას სხვა კვანძური ფრაზის ჩამატების გარეშე შეუძლია გამოიწვიოს გასაღებების მართვის დაბლოკვა, თუ სხვა საკვანძო ფრაზები დაგავწყდებათ."
 ],
 "Removing physical volume from $target": [
  null,
  "$target-დან ფიზიკური საცავის მოცილება"
 ],
 "Rename": [
  null,
  "სახელის გადარქმევა"
 ],
 "Rename Stratis pool": [
  null,
  "Stratis-ის პულისთვის სახელის გადარქმევა"
 ],
 "Rename filesystem": [
  null,
  "ფაილური სისტემის სახელის გადარქმევა"
 ],
 "Rename logical volume": [
  null,
  "ლოგიკური ტომისთვის სახელის გადარქმევა"
 ],
 "Rename volume group": [
  null,
  "ტომების ჯგუფისათვის სახელის გადარქმევა"
 ],
 "Renaming $target": [
  null,
  "$target-ის სახელის გადარქმევა"
 ],
 "Repairing $target": [
  null,
  "$target-ის შეკეთება"
 ],
 "Repeat passphrase": [
  null,
  "გაიმეორეთ საკვანძო სიტყვა"
 ],
 "Resizing $target": [
  null,
  "$target-ის ზომის შესვლა"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "დაშიფრული ფაილური სისტემის ზომის შეცვლას ჯერ დისკის განბლოკვა სჭირდება. შეიყვანეთ დისკის საკვანძო ფრაზა."
 ],
 "Reuse existing encryption": [
  null,
  "არსებული დაშიფვრის გამოყენება"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "არსებული დაშიფვრის ($0) გამოყენება"
 ],
 "Running": [
  null,
  "გაშვებული"
 ],
 "Runtime": [
  null,
  "გაშვების დრო"
 ],
 "SHA1": [
  null,
  "SHA1"
 ],
 "SHA256": [
  null,
  "SHA256"
 ],
 "SMART self-test of $target": [
  null,
  "$target-ის SMART თვითშემოწმების გაშვება"
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "ადგილის შენახვა ინდივიდუალური ბლოკების LZ4-ის საშუალებით შეკუმშვით"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "ადგილის შენახვა მონაცემების ერთნაირი ბლოკების მხოლოდ ერთხელ შენახვის საშუალებით"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "ახალი საკვანძო სიტყვის შესანახად საჭიროა დისკის განბლოკვა. შეიყვანეთ დისკის საკვანძო ფრაზა."
 ],
 "Securely erasing $target": [
  null,
  "$target-ის გარანტირებული წაშლა"
 ],
 "Server": [
  null,
  "სერვერი"
 ],
 "Server address": [
  null,
  "სერვერის მისამართი"
 ],
 "Server address cannot be empty.": [
  null,
  "სერვერის მისამართი ცარიელი არ შეიძლება იყოს."
 ],
 "Server cannot be empty.": [
  null,
  "სერვერი არ შეიძლება ცარიელი იყოს."
 ],
 "Service": [
  null,
  "სერვისი"
 ],
 "Services using the location": [
  null,
  "მდებარეობის გამომყენებელი სერვისები"
 ],
 "Setting up loop device $target": [
  null,
  "$target-ზე მარყუჟული მოწყობილობის შექმნა"
 ],
 "Show $0 device": [
  null,
  "$0 მოწყობილობის ჩვენება",
  "$0 მოწყობილობის(სულ) ჩვენება"
 ],
 "Show $0 drive": [
  null,
  "$0 დისკის ჩვენება",
  "$0 დისკის (სულ) ჩვენება"
 ],
 "Show all": [
  null,
  "ყველას ჩვენება"
 ],
 "Shrink": [
  null,
  "შეწნეხვა"
 ],
 "Shrink logical volume": [
  null,
  "ლოგიკური ტომის შემცირება"
 ],
 "Shrink volume": [
  null,
  "ტომის შემცირება"
 ],
 "Size": [
  null,
  "ზომა"
 ],
 "Size cannot be negative": [
  null,
  "ზომა არ შეიძლება უარყოფითი იყოს"
 ],
 "Size cannot be zero": [
  null,
  "ზომა არ შეიძლება ნულის ტოლი იყოს"
 ],
 "Size is too large": [
  null,
  "ზომა ძალიან დიდია"
 ],
 "Size must be a number": [
  null,
  "ზომა რიცხვი უნდა იყოს"
 ],
 "Size must be at least $0": [
  null,
  "ზომის მინიმალური მნიშვნელობაა $0"
 ],
 "Slot $0": [
  null,
  "სლოტი $0"
 ],
 "Snapshot": [
  null,
  "სწრაფი ასლი"
 ],
 "Source": [
  null,
  "წყარო"
 ],
 "Spare": [
  null,
  "მარქაფი"
 ],
 "Start": [
  null,
  "დაწყება"
 ],
 "Start multipath": [
  null,
  "multipath-ის გაშვება"
 ],
 "Starting RAID device $target": [
  null,
  "RAID მოწყობილობა $target-ის გაშვება"
 ],
 "Starting swapspace $target": [
  null,
  "სვაპის ($target) გაშვება"
 ],
 "Stop": [
  null,
  "გაჩერება"
 ],
 "Stop and remove": [
  null,
  "გაჩერება და წაშლა"
 ],
 "Stop and unmount": [
  null,
  "გაჩერება და მოძრობა"
 ],
 "Stop device": [
  null,
  "მოწყობილობის გაჩერება"
 ],
 "Stopping RAID device $target": [
  null,
  "RAID მოწყობილობა $target-ის გაჩერება"
 ],
 "Stopping swapspace $target": [
  null,
  "სვაპის ($target) გაჩერება"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Storage can not be managed on this system.": [
  null,
  "ამ სისტემაზე საცავის მართვა შეუძლებელია."
 ],
 "Storage logs": [
  null,
  "საცავის ჟურნალი"
 ],
 "Store passphrase": [
  null,
  "საკვანძო სიტყვის დამახსოვრება"
 ],
 "Stored passphrase": [
  null,
  "დამახსოვრებული საკვანძო სიტყვა"
 ],
 "Stratis member": [
  null,
  "Stratis-ის წევრი"
 ],
 "Stratis pool": [
  null,
  "Startis-ის პული"
 ],
 "Stratis pool $0": [
  null,
  "Stratis-ის პული $0"
 ],
 "Successfully copied to clipboard!": [
  null,
  "წარმატებით დაკოპირდა ბუფერში!"
 ],
 "Support is installed.": [
  null,
  "მხარდაჭერა დაყენებულია."
 ],
 "Swap": [
  null,
  "სვაპი"
 ],
 "Synchronizing RAID device $target": [
  null,
  "RAID მოწყობილობა $target-ის სინქრონიზაცია"
 ],
 "Tang keyserver": [
  null,
  "გასაღებების სერვერი Tang"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Stratis-ის პულის შესაქმნელად საჭიროა დაყენებული იყოს პაკეტი $0."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "VDO მოწყობილობების შესაქმნელად დაყენდება პაკეტი $0."
 ],
 "The RAID array is in a degraded state": [
  null,
  "RAID მოწყობილობა ავარიულ მდგომარეობაშია"
 ],
 "The RAID device must be running in order to add spare disks.": [
  null,
  "დამატებითი დისკების დასამატებლად RAID მოწყობილობა გაშვებული უნდა იყოს."
 ],
 "The RAID device must be running in order to remove disks.": [
  null,
  "დისკების წასაშლელად RAID მოწყობილობა გაშვებული უნდა იყოს."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "VDO მოწყობილობის შექმნა გაუქმებულია. მოწყობილობის გამოყენება შეუძლებელია."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "ამჟამად შესულ მომხმარებელს არ აქვს უფლება გასაღებების შესახებ ინფორმაცია მოითხოვოს."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "დაფორმატებამდე საჭიროა დისკის განბლოკვა.  შეიყვანეთ საკვანძო ფრაზა."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "ფაილურ სისტემას მუდმივი მისამაგრებელი წერტილი არ გააჩნია."
 ],
 "The filesystem is already mounted at $0. Proceeding will unmount it.": [
  null,
  "ფაილური სისტემა უკვე მიმაგრებულია $0-ზე. თუ გააგრძელებთ, მიმაგრება გაუქმდება."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "ფაილური სისტემა მორგებულია ჩატვირთვისას ავტომატურად მისამაგრებლად. მაგრამ დაშიფვრის მისი კონტეინერი ამ დროს განბლოკილი არ იქნება."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "ამჟამად ფაილური სისტემა მიმაგრებულია, მაგრამ შემდეგი ჩატვირთვისას აღარ იქნება."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "ფაილური სისტემა ამჟამად მიმაგრებულია $0-ზე, მაგრამ შემდეგი ჩატვირთვისას მიმაგრებული იქნება $1-ზე."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "ფაილური სისტემა უკვე მიმაგრებულია $0ზე, მაგრამ შემდეგი ჩატვირთვისას არ იქნება მიმაგრებული."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "ფაილური სისტემა ახლა მიმაგრებული არაა, მაგრამ იქნება შემდეგი ჩატვირთვისას."
 ],
 "The filesystem is not mounted.": [
  null,
  "ფაილური სისტემა მიმაგრებული არაა."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "ფაილური სისტემა განიბლოკება და მიმაგრდება შემდეგი ჩატვირთვისას. ამას საკვანძო სიტყვის შეყვანა შეიძლება დასჭირდეს."
 ],
 "The last disk of a RAID device cannot be removed.": [
  null,
  "RAID მოწყობილობის ბოლო დისკს ვერ წაშლით."
 ],
 "The last key slot can not be removed": [
  null,
  "ბოლო სლოტს ვერ წაშლით"
 ],
 "The last physical volume of a volume group cannot be removed.": [
  null,
  "საცავის ჯგუფში ბოლო ფიზიკურ საცავს ვერ წაშლით."
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "ჩამოთვლილი პროცესები და სერვისები ძალით იქნება გაჩერებული."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "ჩამოთვლილი პროცესები ძალით გაჩერდება."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "ჩამოთვლილი სერვისები ძალით გაჩერდება."
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "მიმაგრების წერტილი $0 დაკავებულია ჩამოთვლილი პროცესების მიერ:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "მიმაგრების წერტილი $0 გამოიყენება ჩამოთვლილი სერვისების მიერ:"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "სისმტეაში არის მოწყობილობები მრავალი ბილიკით, მაგრამ multipath სერვისი გაშვებული არაა."
 ],
 "There is not enough free space elsewhere to remove this physical volume. At least $0 more free space is needed.": [
  null,
  "ამ ფიზიკური სივრცის წასაშლელად თავისუფალი სივრცე არსად არაა. საჭიროა სულ ცოტა $0 ."
 ],
 "These changes will be made:": [
  null,
  "მოხდება ეს ცვლილებები:"
 ],
 "Thin logical volume": [
  null,
  "თხელი ლოგიკური ტომი"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "NFS მიმაგრება უკვე გამოიყენება და მხოლოდ მისი პარამეტრების შეცვლა შეგიძლიათ."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "VDO მოწყობილობა თავის ყველა ზურგის მოწყობილობას არ იყენებს."
 ],
 "This device is currently in use.": [
  null,
  "მოწყობილობა უკვე გამოიყენება."
 ],
 "This disk cannot be removed while the device is recovering.": [
  null,
  "დისკის წაშლა, სანამ მოწყობილობა აღდგენის რეჟიმშია, შეუძლებელია."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "ლოგიკური საცავი მთლიანად არ გამოიყენება."
 ],
 "This pool can not be unlocked here because its key description is not in the expected format.": [
  null,
  "პულის განბლოკვა შეუძლებელია მისი საკვანძო განმარტების არასწორი ფორმატის გამო."
 ],
 "This volume needs to be activated before it can be resized.": [
  null,
  "ზომის შეცვლამდე საჭიროა საცავის აქტივაცია."
 ],
 "Tier": [
  null,
  "კლასი"
 ],
 "Toggle": [
  null,
  "გადართვა"
 ],
 "Toggle bitmap": [
  null,
  "ბიტური რუკის ჩართ/გამორთ"
 ],
 "Total size: $0": [
  null,
  "ჯამური ზომა: $0"
 ],
 "Trust key": [
  null,
  "ნდობის გასაღები"
 ],
 "Type": [
  null,
  "ტიპი"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "სერვერამდე მიღწევის შეცდომა"
 ],
 "Unable to remove mount": [
  null,
  "მიმაგრების მოხსნის შეცდომა"
 ],
 "Unable to unmount filesystem": [
  null,
  "ფაილური სისტემის მოძრობის შეცდომა"
 ],
 "Unknown": [
  null,
  "უცნობი"
 ],
 "Unknown ($0)": [
  null,
  "უცნობი ($0)"
 ],
 "Unknown host name": [
  null,
  "ჰოსტის უცნობი სახელი"
 ],
 "Unknown type": [
  null,
  "უცნობი ტიპი"
 ],
 "Unlock": [
  null,
  "განბლოკვა"
 ],
 "Unlock automatically on boot": [
  null,
  "ავტომატური განბლოკვა ჩატვირთვისას"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Stratis-ის დაშიფრული პულის განბლოკვა"
 ],
 "Unlock pool to see filesystems.": [
  null,
  "ფაილური სისტემების დასანახავად საჭიროა პულის განბლოკვა."
 ],
 "Unlocking $target": [
  null,
  "$target-ის განბლოკვა"
 ],
 "Unlocking disk": [
  null,
  "დისკის განბლოკვა"
 ],
 "Unmount": [
  null,
  "მოძრობა"
 ],
 "Unmount filesystem $0": [
  null,
  "ფაილური სისტემის მოძრობა: $0"
 ],
 "Unmount now": [
  null,
  "მიმაგრების მოხსნა"
 ],
 "Unmounting $target": [
  null,
  "$target-ის მიმაგრების მოხსნა"
 ],
 "Unrecognized data": [
  null,
  "შეუცნობელი მონაცემები"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "აქ უცნობი მონაცემების დაპატარავება შეუძლებელია."
 ],
 "Unsupported volume": [
  null,
  "მხარდაუჭერელი ტომი"
 ],
 "Usage": [
  null,
  "გამოყენება"
 ],
 "Usage of $0": [
  null,
  "$0-ის გამოყენების წესები"
 ],
 "Use": [
  null,
  "გამოყენება"
 ],
 "Use compression": [
  null,
  "შეკუმშვის გამოყენება"
 ],
 "Use deduplication": [
  null,
  "დედუპლიკაციის გამოყენება"
 ],
 "Used": [
  null,
  "გამოყენებულია"
 ],
 "Used for": [
  null,
  "გამოიყენება"
 ],
 "User": [
  null,
  "მომხმარებელი"
 ],
 "Username": [
  null,
  "მომხმარებლის სახელი"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS დაშიფვრის გამოყენებით"
 ],
 "Using Tang server": [
  null,
  "Tang სერვერის გამოყენებით"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO-ის მხარდამჭერი მოწყობილობები მეტად ვეღარ დაპატარავდება"
 ],
 "VDO device": [
  null,
  "VDO მოწყობილობა"
 ],
 "VDO device $0": [
  null,
  "VDO მოწყობილობა: $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO ფაილური სისტემის საცავი (შეკუმშვა/დედუპლიკაცია)"
 ],
 "VDO pool": [
  null,
  "VDO პული"
 ],
 "Verify key": [
  null,
  "გასაღების შემოწმება"
 ],
 "Very securely erasing $target": [
  null,
  "$target-ის ძალიან უსაფრთხოდ წაშლა"
 ],
 "View all logs": [
  null,
  "ყველა ჟურნალის ნახვა"
 ],
 "Volume": [
  null,
  "საცავი"
 ],
 "Volume group": [
  null,
  "ტომების ჯგუფი"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "საცავის ზომაა $0. შემცველობის კი $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "პროგრამების მართვის სხვა ოპერაციების დასრულების მოლოდინი"
 ],
 "Write-mostly": [
  null,
  "ძირითადად-ჩაწერა"
 ],
 "Writing": [
  null,
  "ჩაწერა"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[ბინარული მონაცემების $0 ბაიტი]"
 ],
 "[binary data]": [
  null,
  "[ბინარული მონაცემები]"
 ],
 "[no data]": [
  null,
  "[მონაცემების გარეშე]"
 ],
 "backing device for VDO device": [
  null,
  "VDO მოწყობილობის მხარდამჭერი მოწყობილობა"
 ],
 "delete": [
  null,
  "წაშლა"
 ],
 "disk": [
  null,
  "დისკი"
 ],
 "drive": [
  null,
  "დისკი"
 ],
 "edit": [
  null,
  "ჩასწორება"
 ],
 "encryption": [
  null,
  "დაშიფვრა"
 ],
 "filesystem": [
  null,
  "ფაილური სისტემა"
 ],
 "format": [
  null,
  "ფორმატი"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "grow": [
  null,
  "გაზრდა"
 ],
 "iSCSI targets": [
  null,
  "iSCSI სამიზნეები"
 ],
 "initialize": [
  null,
  "ინიციალიზაცია"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "member of RAID device": [
  null,
  "RAID მოწყობილობის წევრი"
 ],
 "member of Stratis pool": [
  null,
  "Stratis-ის პულის წევრი"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "მიმაგრება"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "never mounted at boot": [
  null,
  "არასოდეს მიმაგრებულა ჩატვირთვის დროს"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "none": [
  null,
  "არცერთი"
 ],
 "partition": [
  null,
  "განყოფილება"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2 საცავების ჯგუფის წევრი ფიზიკური საცავი"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "read only": [
  null,
  "მხოლოდ კითხვისთვის"
 ],
 "remove from LVM2": [
  null,
  "LVM2-დან წაშლა"
 ],
 "remove from RAID": [
  null,
  "RAID-დან წაშლა"
 ],
 "shrink": [
  null,
  "შემცირება"
 ],
 "stop": [
  null,
  "გაჩერება"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unknown target": [
  null,
  "უცნობი სამიზნე ობიექტი"
 ],
 "unmount": [
  null,
  "მოძრობა"
 ],
 "unpartitioned space on $0": [
  null,
  "$0-ზე დარჩენილი დაუხლეჩავი სივრცე"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "საცავი"
 ],
 "yes": [
  null,
  "დიახ"
 ],
 "storage-id-desc\u0004$0 filesystem": [
  null,
  "$0 ფაილური სისტემა"
 ],
 "storage-id-desc\u0004Filesystem (encrypted)": [
  null,
  "ფაილური სისტემა (დაშიფრული)"
 ],
 "storage-id-desc\u0004Locked encrypted data": [
  null,
  "ჩაკეტილი დაშიფრული მონაცემები"
 ],
 "storage-id-desc\u0004Other data": [
  null,
  "სხვა მონაცემები"
 ],
 "storage-id-desc\u0004Swap space": [
  null,
  "სვაპის ზომა"
 ],
 "storage-id-desc\u0004Unrecognized data": [
  null,
  "შეუცნობელი მონაცემები"
 ],
 "storage-id-desc\u0004VDO backing": [
  null,
  "VDO მარქაფი"
 ],
 "storage\u0004Assessment": [
  null,
  "შეფასება"
 ],
 "storage\u0004Bitmap": [
  null,
  "ბიტური რუკა"
 ],
 "storage\u0004Capacity": [
  null,
  "მოცულობა"
 ],
 "storage\u0004Device": [
  null,
  "მოწყობილობა"
 ],
 "storage\u0004Device file": [
  null,
  "მოწყობილობის ფაილი"
 ],
 "storage\u0004Firmware version": [
  null,
  "მიკროპროგრამის ვერსია"
 ],
 "storage\u0004Model": [
  null,
  "მოდელი"
 ],
 "storage\u0004Multipathed devices": [
  null,
  "მრავალბილიკა მოწყობილობები"
 ],
 "storage\u0004Optical drive": [
  null,
  "ოპტიკური დისკი"
 ],
 "storage\u0004RAID level": [
  null,
  "RAID-ის დონე"
 ],
 "storage\u0004Removable drive": [
  null,
  "მოხსნადი დისკი"
 ],
 "storage\u0004Serial number": [
  null,
  "სერიული ნომერი"
 ],
 "storage\u0004State": [
  null,
  "მდგომარეობა"
 ],
 "storage\u0004UUID": [
  null,
  "UUID"
 ],
 "storage\u0004Usage": [
  null,
  "გამოყენება"
 ],
 "storage\u0004World wide name": [
  null,
  "WWN სახელი"
 ],
 "format-bytes\u0004bytes": [
  null,
  "ბაიტი"
 ]
});
