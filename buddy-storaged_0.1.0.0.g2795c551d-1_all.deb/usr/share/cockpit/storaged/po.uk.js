cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 (encrypted)": [
  null,
  "$0 (зашифровано)"
 ],
 "$0 Stratis pool": [
  null,
  "$0 буфер Stratis"
 ],
 "$0 block device": [
  null,
  "$0, блоковий пристрій"
 ],
 "$0 cache": [
  null,
  "Кеш $0"
 ],
 "$0 chunk size": [
  null,
  "Розмір фрагмента $0"
 ],
 "$0 data": [
  null,
  "Дані $0"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 даних + $1 додатково використано з $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дні",
  "$0 днів"
 ],
 "$0 disk is missing": [
  null,
  "Не вистачає $0 диска",
  "Не вистачає $0 дисків",
  "Не вистачає $0 дисків"
 ],
 "$0 disks": [
  null,
  "Диски $0"
 ],
 "$0 filesystems can not be made larger.": [
  null,
  "Файлові системи $0 не можна розширювати."
 ],
 "$0 filesystems can not be made smaller.": [
  null,
  "Файлові системи $0 не можна звужувати."
 ],
 "$0 filesystems can not be resized here.": [
  null,
  "Тут не можна змінювати розмір файлових систем $0."
 ],
 "$0 hour": [
  null,
  "$0 година",
  "$0 години",
  "$0 годин"
 ],
 "$0 is in use": [
  null,
  "$0 використовується"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 немає у жодному зі сховищ."
 ],
 "$0 minute": [
  null,
  "$0 хвилина",
  "$0 хвилини",
  "$0 хвилин"
 ],
 "$0 month": [
  null,
  "$0 місяць",
  "$0 місяці",
  "$0 місяців"
 ],
 "$0 of unknown tier": [
  null,
  "$0 невідомого класу"
 ],
 "$0 slot remains": [
  null,
  "Лишився $0 слот",
  "Лишилося $0 слоти",
  "Лишилося $0 слотів"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 використано з $1 ($2 заощаджено)"
 ],
 "$0 week": [
  null,
  "$0 тиждень",
  "$0 тижні",
  "$0 тижнів"
 ],
 "$0 will be installed.": [
  null,
  "Буде встановлено $0."
 ],
 "$0 year": [
  null,
  "$0 рік",
  "$0 роки",
  "$0 років"
 ],
 "$0, $1 free": [
  null,
  "$0, вільно $1"
 ],
 "$name (from $host)": [
  null,
  "$name (з $host)"
 ],
 "(recommended)": [
  null,
  "(рекомендовано)"
 ],
 "1 MiB": [
  null,
  "1 МіБ"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 година"
 ],
 "1 week": [
  null,
  "1 тиждень"
 ],
 "128 KiB": [
  null,
  "128 КіБ"
 ],
 "16 KiB": [
  null,
  "16 КіБ"
 ],
 "2 MiB": [
  null,
  "2 МіБ"
 ],
 "32 KiB": [
  null,
  "32 КіБ"
 ],
 "4 KiB": [
  null,
  "4 КіБ"
 ],
 "5 minutes": [
  null,
  "5 хвилин"
 ],
 "512 KiB": [
  null,
  "512 КіБ"
 ],
 "6 hours": [
  null,
  "6 годин"
 ],
 "64 KiB": [
  null,
  "64 КіБ"
 ],
 "8 KiB": [
  null,
  "8 КіБ"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "У цьому буфері вже існує файлова система із цією назвою."
 ],
 "A pool with this name exists already.": [
  null,
  "Буфер із цією назвою вже існує."
 ],
 "A spare disk needs to be added first before this disk can be removed.": [
  null,
  "Перш ніж вилучати цей диск, слід додати резервний диск."
 ],
 "Action": [
  null,
  "Дія"
 ],
 "Activate": [
  null,
  "Задіяти"
 ],
 "Activating $target": [
  null,
  "Активуємо $target"
 ],
 "Add": [
  null,
  "Додати"
 ],
 "Add block devices": [
  null,
  "Додати блокові пристрої"
 ],
 "Add disks": [
  null,
  "Додати диски"
 ],
 "Add iSCSI portal": [
  null,
  "Додати портал iSCSI"
 ],
 "Add key": [
  null,
  "Додати ключ"
 ],
 "Adding physical volume to $target": [
  null,
  "Додаємо фізичний том до $target"
 ],
 "Additional packages:": [
  null,
  "Додаткові пакунки:"
 ],
 "Address": [
  null,
  "Адреса"
 ],
 "Address cannot be empty": [
  null,
  "Адреса не може бути порожньою"
 ],
 "Address is not a valid URL": [
  null,
  "Адреса є некоректною"
 ],
 "At least $0 disk is needed.": [
  null,
  "Потрібен принаймні $0 диск.",
  "Потрібно принаймні $0 диски.",
  "Потрібно принаймні $0 дисків."
 ],
 "At least one block device is needed.": [
  null,
  "Потрібен принаймні один блоковий пристрій."
 ],
 "At least one disk is needed.": [
  null,
  "Потрібен принаймні один диск."
 ],
 "Authentication required": [
  null,
  "Слід пройти розпізнавання"
 ],
 "Available targets on $0": [
  null,
  "Доступні призначення на $0"
 ],
 "Backing device": [
  null,
  "Резервний пристрій"
 ],
 "Block": [
  null,
  "Блок"
 ],
 "Block device for filesystems": [
  null,
  "Блоковий пристрій для файлових систем"
 ],
 "Block devices": [
  null,
  "Блокові пристрої"
 ],
 "Blocked": [
  null,
  "Заблоковано"
 ],
 "Cache": [
  null,
  "Кеш"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Change": [
  null,
  "Змінити"
 ],
 "Change iSCSI initiator name": [
  null,
  "Змінити назву ініціатора iSCSI"
 ],
 "Change passphrase": [
  null,
  "Змінити пароль"
 ],
 "Checking $target": [
  null,
  "Перевіряємо $target"
 ],
 "Checking RAID device $target": [
  null,
  "Перевіряємо пристрій RAID $target"
 ],
 "Checking and repairing RAID device $target": [
  null,
  "Перевіряємо і відновлюємо пристрій RAID $target"
 ],
 "Checking installed software": [
  null,
  "Перевіряємо встановлене програмне забезпечення"
 ],
 "Checking related processes": [
  null,
  "Перевіряємо пов'язані процеси"
 ],
 "Chunk size": [
  null,
  "Розмір фрагмента"
 ],
 "Cleaning up for $target": [
  null,
  "Спорожнюємо для $target"
 ],
 "Cleartext device": [
  null,
  "Пристрій Cleartext"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Command": [
  null,
  "Команда"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Сумісний із усіма системами та пристроями (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Сумісний зі сучасними системами та жорсткими дисками > 2 ТБ (GPT)"
 ],
 "Compression": [
  null,
  "Стискання"
 ],
 "Confirm": [
  null,
  "Підтвердити"
 ],
 "Confirm deletion of $0": [
  null,
  "Підтвердьте вилучення $0"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Підтвердьте вилучення введенням альтернативного пароля"
 ],
 "Confirm stopping of $0": [
  null,
  "Підтвердьте зупинку $0"
 ],
 "Content": [
  null,
  "Вміст"
 ],
 "Copy to clipboard": [
  null,
  "Копіювати до буфера"
 ],
 "Create": [
  null,
  "Створити"
 ],
 "Create LVM2 volume group": [
  null,
  "Створити групу томів LVM2"
 ],
 "Create RAID device": [
  null,
  "Створити пристрій RAID"
 ],
 "Create Stratis pool": [
  null,
  "Створити буфер Stratis"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Створити знімок файлової системи $0"
 ],
 "Create devices": [
  null,
  "Створити пристрої"
 ],
 "Create filesystem": [
  null,
  "Створити файлову систему"
 ],
 "Create logical volume": [
  null,
  "Створити логічний том"
 ],
 "Create new filesystem": [
  null,
  "Створити файлову систему"
 ],
 "Create new logical volume": [
  null,
  "Створити логічний том"
 ],
 "Create partition": [
  null,
  "Створити розділ"
 ],
 "Create partition on $0": [
  null,
  "Створити розділ на $0"
 ],
 "Create partition table": [
  null,
  "Створити таблицю розділів"
 ],
 "Create snapshot": [
  null,
  "Створення знімка"
 ],
 "Create thin volume": [
  null,
  "Створити тонкий том"
 ],
 "Create volume group": [
  null,
  "Створити групу томів"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Створюємо групу томів LVM2 $target"
 ],
 "Creating RAID device $target": [
  null,
  "Створюємо пристрій RAID $target"
 ],
 "Creating VDO device": [
  null,
  "Створення пристрою VDO"
 ],
 "Creating filesystem on $target": [
  null,
  "Створюємо файлову систему на $target"
 ],
 "Creating logical volume $target": [
  null,
  "Створюємо логічний том $target"
 ],
 "Creating partition $target": [
  null,
  "Створюємо розділ $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Створюємо знімок $target"
 ],
 "Currently in use": [
  null,
  "Зараз використовується"
 ],
 "Custom mount options": [
  null,
  "Нетипові параметри монтування"
 ],
 "Data": [
  null,
  "Дані"
 ],
 "Data used": [
  null,
  "Використано даних"
 ],
 "Deactivate": [
  null,
  "Вимкнути"
 ],
 "Deactivating $target": [
  null,
  "Деактивуємо $target"
 ],
 "Deduplication": [
  null,
  "Скасування дублювання"
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Deleting $target": [
  null,
  "Вилучаємо $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Вилучаємо групу томів LVM2 $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Вилучення буфера Stratis призведе до витирання усіх даних, що на ньому зберігаються."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Вилучення файлової системи призведе до вилучення усіх даних, що на ньому зберігаються."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Вилучення логічного тому призведе до витирання усіх даних, що на ньому зберігаються."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Вилучення розділу призведе до вилучення усіх даних, що на ньому зберігаються."
 ],
 "Deleting erases all data on a RAID device.": [
  null,
  "Вилучення призведе до витирання усіх даних на пристрої RAID."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Вилучення призведе до витирання усіх даних на пристрої VDO."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Вилучення призведе до витирання усіх даних на групі томів."
 ],
 "Description": [
  null,
  "Опис"
 ],
 "Device": [
  null,
  "Пристрій"
 ],
 "Device file": [
  null,
  "Файл пристрою"
 ],
 "Device is read-only": [
  null,
  "Пристрій придатний лише для читання"
 ],
 "Devices": [
  null,
  "Пристрої"
 ],
 "Disk is OK": [
  null,
  "З диском усе гаразд"
 ],
 "Disk is failing": [
  null,
  "Диск виходить з ладу"
 ],
 "Disk passphrase": [
  null,
  "Пароль до диска"
 ],
 "Disks": [
  null,
  "Диски"
 ],
 "Do not mount automatically on boot": [
  null,
  "Не монтувати автоматично під час завантаження"
 ],
 "Downloading $0": [
  null,
  "Отримуємо $0"
 ],
 "Drive": [
  null,
  "Диск"
 ],
 "Drives": [
  null,
  "Диски"
 ],
 "Edit": [
  null,
  "Змінити"
 ],
 "Edit Tang keyserver": [
  null,
  "Редагувати сервер ключів Tang"
 ],
 "Editing a key requires a free slot": [
  null,
  "Редагування ключа потребує вільного слоту"
 ],
 "Ejecting $target": [
  null,
  "Видобуваємо $target"
 ],
 "Emptying $target": [
  null,
  "Спорожняємо $target"
 ],
 "Encrypt data": [
  null,
  "Зашифрувати дані"
 ],
 "Encrypted $0": [
  null,
  "Зашифрований $0"
 ],
 "Encrypted Stratis pool $0": [
  null,
  "Шифрований буфер Stratis $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Зашифрований логічний том $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Шифрований розділ $0"
 ],
 "Encrypted volumes can not be resized here.": [
  null,
  "Тут не можна змінювати розмір шифрованих томів."
 ],
 "Encrypted volumes need to be unlocked before they can be resized.": [
  null,
  "Перш ніж можна буде змінювати розмір зашифрованих томів, такі томи слід розблокувати."
 ],
 "Encryption": [
  null,
  "Шифрування"
 ],
 "Encryption options": [
  null,
  "Параметри шифрування"
 ],
 "Encryption type": [
  null,
  "Тип шифрування"
 ],
 "Erasing $target": [
  null,
  "Витираємо $target"
 ],
 "Error": [
  null,
  "Помилка"
 ],
 "Extended partition": [
  null,
  "Розширений розділ"
 ],
 "Failed": [
  null,
  "Помилка"
 ],
 "Filesystem": [
  null,
  "Файлова система"
 ],
 "Filesystem is locked": [
  null,
  "Файлову систему заблоковано"
 ],
 "Filesystem name": [
  null,
  "Назва файлової системи"
 ],
 "Filesystems": [
  null,
  "Файлові системи"
 ],
 "Format": [
  null,
  "Формат"
 ],
 "Format $0": [
  null,
  "Форматувати $0"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Форматування призведе до знищення усіх даних на пристрої для зберігання даних."
 ],
 "Free": [
  null,
  "Вільно"
 ],
 "Free space": [
  null,
  "Вільне місце"
 ],
 "Free up space in this group: Shrink or delete other logical volumes or add another physical volume.": [
  null,
  "Звільніть місце у цій групі: зменшіть розмір інших логічних томів або вилучіть їх чи додайте ще один фізичний том."
 ],
 "Go to now": [
  null,
  "Перейти зараз"
 ],
 "Grow": [
  null,
  "Збільшити"
 ],
 "Grow content": [
  null,
  "Збільшити вміст"
 ],
 "Grow logical size of $0": [
  null,
  "Збільшити логічний розмір $0"
 ],
 "Grow logical volume": [
  null,
  "Збільшити логічний том"
 ],
 "Grow to take all space": [
  null,
  "Збільшити так, щоб використати усе місце"
 ],
 "If this option is checked, the filesystem will not be mounted during the next boot even if it was mounted before it.  This is useful if mounting during boot is not possible, such as when a passphrase is required to unlock the filesystem but booting is unattended.": [
  null,
  "Якщо позначено цей пункт, файлову систему не буде змонтовано під час наступного завантаження, навіть якщо раніше система її монтувала. Це корисно, якщо монтування під час завантаження неможливе, зокрема, коли для розблоковування файлової системи потрібен пароль, а завантаження виконується в автоматичному режимі."
 ],
 "In sync": [
  null,
  "Синхронізовано"
 ],
 "Inactive volume": [
  null,
  "Неактивний том"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Несумісне монтування файлових систем"
 ],
 "Index memory": [
  null,
  "Пам'ять покажчика"
 ],
 "Initialize": [
  null,
  "Ініціалізувати"
 ],
 "Initialize disk $0": [
  null,
  "Ініціалізувати диск $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Ініціалізація призведе до знищення усіх даних, які зберігаються на диску."
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Install NFS support": [
  null,
  "Встановити підтримку NFS"
 ],
 "Install Stratis support": [
  null,
  "Встановити підтримку Stratis"
 ],
 "Install software": [
  null,
  "Встановити програмне забезпечення"
 ],
 "Installing $0": [
  null,
  "Встановлюємо $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "Встановлення $0 призведе до вилучення $1."
 ],
 "Installing packages": [
  null,
  "Встановлення пакунків"
 ],
 "Invalid username or password": [
  null,
  "Некоректне ім’я користувача чи пароль"
 ],
 "Jobs": [
  null,
  "Завдання"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Тут не можна редагувати слоти ключів із невідомими типами"
 ],
 "Key source": [
  null,
  "Джерело ключа"
 ],
 "Keys": [
  null,
  "Ключі"
 ],
 "Keyserver": [
  null,
  "Сервер ключів"
 ],
 "Keyserver address": [
  null,
  "Адреса сервера ключів"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Вилучення сервера ключів може завадити розблокуванню $0."
 ],
 "LVM2 member": [
  null,
  "Учасник LVM2"
 ],
 "LVM2 volume group": [
  null,
  "Група томів LVM2"
 ],
 "LVM2 volume group $0": [
  null,
  "Група томів LVM2 $0"
 ],
 "Last modified: $0": [
  null,
  "Востаннє змінено: $0"
 ],
 "Learn more": [
  null,
  "Докладніше"
 ],
 "Loading...": [
  null,
  "Завантаження…"
 ],
 "Local mount point": [
  null,
  "Локальна точка монтування"
 ],
 "Location": [
  null,
  "Розташування"
 ],
 "Lock": [
  null,
  "Заблокувати"
 ],
 "Locked devices": [
  null,
  "Заблоковані пристрої"
 ],
 "Locked encrypted Stratis pool": [
  null,
  "Заблоковано зашифрований буфер Stratis"
 ],
 "Locking $target": [
  null,
  "Блокуємо $target"
 ],
 "Logical": [
  null,
  "Логічний"
 ],
 "Logical size": [
  null,
  "Логічний розмір"
 ],
 "Logical volume": [
  null,
  "Логічний том"
 ],
 "Logical volume (snapshot)": [
  null,
  "Логічний том (знімок)"
 ],
 "Logical volume of $0": [
  null,
  "Логічний том $0"
 ],
 "Logical volumes": [
  null,
  "Логічні томи"
 ],
 "Make sure the key hash from the Tang server matches one of the following:": [
  null,
  "Переконайтеся, що хеш ключа з сервера Tang відповідає одному з таких критеріїв:"
 ],
 "Managing LVMs": [
  null,
  "Керування LVM"
 ],
 "Managing NFS mounts": [
  null,
  "Керування монтуванням NFS"
 ],
 "Managing RAIDs": [
  null,
  "Керування RAID"
 ],
 "Managing VDOs": [
  null,
  "Керування VDO"
 ],
 "Managing partitions": [
  null,
  "Керування розділами диска"
 ],
 "Managing physical drives": [
  null,
  "Керування фізичними дисками"
 ],
 "Manually check with SSH: ": [
  null,
  "Перевірка вручну за допомогою SSH: "
 ],
 "Marking $target as faulty": [
  null,
  "Позначаємо $target як помилковий"
 ],
 "Metadata used": [
  null,
  "Використано метаданих"
 ],
 "Modifying $target": [
  null,
  "Змінюємо $target"
 ],
 "Mount": [
  null,
  "Змонтувати"
 ],
 "Mount also automatically on boot": [
  null,
  "Також монтувати автоматично під час завантаження"
 ],
 "Mount at boot": [
  null,
  "Змонтувати при завантаженні"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Монтувати автоматично до $0 під час завантаження"
 ],
 "Mount configuration": [
  null,
  "Налаштування монтування"
 ],
 "Mount filesystem": [
  null,
  "Змонтувати файлову систему"
 ],
 "Mount now": [
  null,
  "Змонтувати зараз"
 ],
 "Mount on $0 now": [
  null,
  "Змонтувати до $0 зараз"
 ],
 "Mount options": [
  null,
  "Параметри монтування"
 ],
 "Mount point": [
  null,
  "Точка монтування"
 ],
 "Mount point cannot be empty": [
  null,
  "Точка монтування не може бути порожньою"
 ],
 "Mount point cannot be empty.": [
  null,
  "Точка монтування не може бути порожньою."
 ],
 "Mount point is already used for $0": [
  null,
  "Точку монтування вже використано для $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Запис точки монтування має починатися з «/»."
 ],
 "Mount read only": [
  null,
  "Змонтувати лише для читання"
 ],
 "Mounting $target": [
  null,
  "Монтуємо $target"
 ],
 "NFS mount": [
  null,
  "Змонтована NFS"
 ],
 "NFS mounts": [
  null,
  "Монтування NFS"
 ],
 "NFS support not installed": [
  null,
  "Не встановлено підтримки NFS"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Name can not be empty.": [
  null,
  "Назва не повинна бути порожньою."
 ],
 "Name cannot be empty.": [
  null,
  "Назва не може бути порожньою."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Назва не повинна бути довшою за $0 байтів"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Назва не повинна бути довшою за $0 символів"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Назва не повинна бути довшою за 127 символів."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Назва не повинна містити символу «$0»."
 ],
 "Name cannot contain whitespace.": [
  null,
  "У назві не повинно бути пробілів."
 ],
 "Never mount at boot": [
  null,
  "Ніколи не монтувати при завантаженні"
 ],
 "New NFS mount": [
  null,
  "Нове монтування NFS"
 ],
 "New passphrase": [
  null,
  "Новий пароль"
 ],
 "Next": [
  null,
  "Далі"
 ],
 "No NFS mounts set up": [
  null,
  "Монтувань NFS не налаштовано"
 ],
 "No available slots": [
  null,
  "Немає доступних слотів"
 ],
 "No block devices are available.": [
  null,
  "Немає доступних блокових пристроїв."
 ],
 "No devices": [
  null,
  "Немає пристроїв"
 ],
 "No disks are available.": [
  null,
  "Немає доступних дисків."
 ],
 "No drives attached": [
  null,
  "Не долучено жодного диска"
 ],
 "No encryption": [
  null,
  "Без шифрування"
 ],
 "No filesystem": [
  null,
  "Немає файлової системи"
 ],
 "No filesystems": [
  null,
  "Немає файлових систем"
 ],
 "No free key slots": [
  null,
  "Немає вільних слотів ключів"
 ],
 "No free space": [
  null,
  "Недостатньо вільного простору"
 ],
 "No iSCSI targets set up": [
  null,
  "Призначень iSCSI не налаштовано"
 ],
 "No keys added": [
  null,
  "Не додано жодного ключа"
 ],
 "No logical volumes": [
  null,
  "Немає логічних томів"
 ],
 "No media inserted": [
  null,
  "Не виявлено носія даних"
 ],
 "No partitioning": [
  null,
  "Немає розподілу на розділи"
 ],
 "Not enough space to grow.": [
  null,
  "Недостатньо місця для росту."
 ],
 "Not found": [
  null,
  "Не знайдено"
 ],
 "Not mounted": [
  null,
  "Не змонтовано"
 ],
 "Not running": [
  null,
  "Зупинено"
 ],
 "Ok": [
  null,
  "Гаразд"
 ],
 "Old passphrase": [
  null,
  "Старий пароль"
 ],
 "Only $0 of $1 are used.": [
  null,
  "Використано лише $0 з $1."
 ],
 "Operation '$operation' on $target": [
  null,
  "Дія «$operation» над $target"
 ],
 "Options": [
  null,
  "Параметри"
 ],
 "Other devices": [
  null,
  "Інші пристрої"
 ],
 "Overwrite": [
  null,
  "Перезаписати"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Перезаписати наявні дані нулями (повільно)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "Аварійне завершення роботи PackageKit"
 ],
 "Partition": [
  null,
  "Розділ"
 ],
 "Partition of $0": [
  null,
  "Розділ $0"
 ],
 "Partitioned block device": [
  null,
  "Поділений на розділи блоковий пристрій"
 ],
 "Partitioning": [
  null,
  "Розподіл"
 ],
 "Partitions": [
  null,
  "Розділи"
 ],
 "Passphrase": [
  null,
  "Пароль"
 ],
 "Passphrase can not be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "Passphrase cannot be empty": [
  null,
  "Пароль не може бути порожнім"
 ],
 "Passphrase from any other key slot": [
  null,
  "Пароль з будь-якого іншого слоту ключів"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Вилучення пароля може завадити розблокуванню $0."
 ],
 "Passphrases do not match": [
  null,
  "Паролі не збігаються"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Path on server": [
  null,
  "Шлях на сервері"
 ],
 "Path on server cannot be empty.": [
  null,
  "Шлях на сервері не може бути порожнім."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Шлях на сервері має починатися з «/»."
 ],
 "Permanently delete $0?": [
  null,
  "Остаточно вилучити $0?"
 ],
 "Physical": [
  null,
  "Фізичний"
 ],
 "Physical volumes": [
  null,
  "Фізичні томи"
 ],
 "Physical volumes can not be resized here.": [
  null,
  "Тут не можна змінювати розміри фізичних томів."
 ],
 "Pool": [
  null,
  "Буфер"
 ],
 "Pool for thin logical volumes": [
  null,
  "Буфер для тонких логічних томів"
 ],
 "Pool for thin volumes": [
  null,
  "Буфер для тонких томів"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Буфер для тонких резервованих томів"
 ],
 "Port": [
  null,
  "Порт"
 ],
 "Processes using the location": [
  null,
  "Процеси, що використовують це місце"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Вкажіть пароль до буфера даних на цих блокових пристроях:"
 ],
 "Purpose": [
  null,
  "Призначення"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Стрічка)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Дзеркало)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (Стрічка дзеркал)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (Пов’язана парність)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (Розподілена парність)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (Подвійна розподілена парність)"
 ],
 "RAID device": [
  null,
  "пристрій RAID"
 ],
 "RAID device $0": [
  null,
  "Пристій RAID $0"
 ],
 "RAID level": [
  null,
  "Рівень RAID"
 ],
 "RAID member": [
  null,
  "Елемент RAID"
 ],
 "Reading": [
  null,
  "Читання"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Recovering": [
  null,
  "Відновлюємо"
 ],
 "Recovering RAID device $target": [
  null,
  "Відновлюємо пристрій RAID $target"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Пов'язані процеси і служби буде примусово зупинено."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Пов'язані процеси буде примусово зупинено."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Пов'язані служби буде примусово зупинено."
 ],
 "Removals:": [
  null,
  "Вилучення:"
 ],
 "Remove": [
  null,
  "Вилучити"
 ],
 "Remove $0?": [
  null,
  "Вилучити $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Вилучити сервер ключів Tang?"
 ],
 "Remove device": [
  null,
  "Вилучити пристрій"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Вилучити пароль у слоті ключів $0?"
 ],
 "Removing $0": [
  null,
  "Вилучаємо $0"
 ],
 "Removing $target from RAID device": [
  null,
  "Вилучаємо $target з пристрою RAID"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Вилучення пароля без підтвердження іншим паролем може закрити доступ до розблоковування або керування ключами, якщо інші паролі буде забуто або втрачено."
 ],
 "Removing physical volume from $target": [
  null,
  "Вилучаємо фізичний том з $target"
 ],
 "Rename": [
  null,
  "Перейменувати"
 ],
 "Rename Stratis pool": [
  null,
  "Перейменувати буфер Stratis"
 ],
 "Rename filesystem": [
  null,
  "Перейменувати файлову систему"
 ],
 "Rename logical volume": [
  null,
  "Перейменувати логічний том"
 ],
 "Rename volume group": [
  null,
  "Перейменувати групу томів"
 ],
 "Renaming $target": [
  null,
  "Перейменовуємо $target"
 ],
 "Repairing $target": [
  null,
  "Відновлюємо $target"
 ],
 "Repeat passphrase": [
  null,
  "Повторіть пароль"
 ],
 "Resizing $target": [
  null,
  "Зміна розміру $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Зміна розмірів зашифрованої системи потребує розблокування диска. Будь ласка, вкажіть поточний пароль до диска."
 ],
 "Reuse existing encryption": [
  null,
  "Повторно використати наявне шифрування"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Повторно використати наявне шифрування ($0)"
 ],
 "Running": [
  null,
  "Працює"
 ],
 "Runtime": [
  null,
  "Простір виконання"
 ],
 "SHA1": [
  null,
  "SHA1"
 ],
 "SHA256": [
  null,
  "SHA256"
 ],
 "SMART self-test of $target": [
  null,
  "Самоперевірка SMART $target"
 ],
 "Save": [
  null,
  "Зберегти"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Заощаджувати місце стисканням окремих блоків за допомогою LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Заощаджувати місце, зберігаючи ідентичні блоки даних лише раз"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Збереження нового пароля потребує розблокування диска. Будь ласка, вкажіть поточний пароль до диска."
 ],
 "Securely erasing $target": [
  null,
  "Безпечно витираємо $target"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Server address": [
  null,
  "Адреса сервера"
 ],
 "Server address cannot be empty.": [
  null,
  "Адреса сервера не може бути порожньою."
 ],
 "Server cannot be empty.": [
  null,
  "Запис сервера не може бути порожнім."
 ],
 "Service": [
  null,
  "Служба"
 ],
 "Services using the location": [
  null,
  "Служби, що використовують це місце"
 ],
 "Setting up loop device $target": [
  null,
  "Налаштовуємо петльовий пристрій $target"
 ],
 "Show $0 device": [
  null,
  "Показати усі $0 пристрій",
  "Показати усі $0 пристрої",
  "Показати усі $0 пристроїв"
 ],
 "Show $0 drive": [
  null,
  "Показати увесь $0 диск",
  "Показати усі $0 диски",
  "Показати усі $0 дисків"
 ],
 "Show all": [
  null,
  "Показати усі"
 ],
 "Shrink": [
  null,
  "Стиснути"
 ],
 "Shrink logical volume": [
  null,
  "Стиснути логічний том"
 ],
 "Shrink volume": [
  null,
  "Стиснути том"
 ],
 "Size": [
  null,
  "Розмір"
 ],
 "Size cannot be negative": [
  null,
  "Розмір не може бути від’ємним"
 ],
 "Size cannot be zero": [
  null,
  "Розмір не може бути нульовим"
 ],
 "Size is too large": [
  null,
  "Розмір є надто великим"
 ],
 "Size must be a number": [
  null,
  "Розмір має бути числом"
 ],
 "Size must be at least $0": [
  null,
  "Розмір має бути не меншим за $0"
 ],
 "Slot $0": [
  null,
  "Слот $0"
 ],
 "Snapshot": [
  null,
  "Знімок"
 ],
 "Source": [
  null,
  "Джерело"
 ],
 "Spare": [
  null,
  "Запас"
 ],
 "Start": [
  null,
  "Почати"
 ],
 "Start multipath": [
  null,
  "Запустити Multipath"
 ],
 "Starting RAID device $target": [
  null,
  "Зупиняємо пристрій RAID $target"
 ],
 "Starting swapspace $target": [
  null,
  "Запускаємо резервну область пам’яті $target"
 ],
 "Stop": [
  null,
  "Зупинити"
 ],
 "Stop and remove": [
  null,
  "Зупинити і вилучити"
 ],
 "Stop and unmount": [
  null,
  "Зупинити і демонтувати"
 ],
 "Stop device": [
  null,
  "Зупинити пристрій"
 ],
 "Stopping RAID device $target": [
  null,
  "Зупиняємо пристрій RAID $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Зупиняємо резервну область пам’яті $target"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Storage can not be managed on this system.": [
  null,
  "У цій системі не можна керувати сховищем даних."
 ],
 "Storage logs": [
  null,
  "Журнали зберігання"
 ],
 "Store passphrase": [
  null,
  "Зберігати пароль"
 ],
 "Stored passphrase": [
  null,
  "Збережений пароль"
 ],
 "Stratis member": [
  null,
  "Учасник Stratis"
 ],
 "Stratis pool": [
  null,
  "Буфер Stratis"
 ],
 "Stratis pool $0": [
  null,
  "Буфер Stratis $0"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Успішно скопійовано до буфера обміну!"
 ],
 "Support is installed.": [
  null,
  "Підтримку встановлено."
 ],
 "Swap": [
  null,
  "Свопінґ"
 ],
 "Synchronizing RAID device $target": [
  null,
  "Синхронізуємо пристрій RAID $target"
 ],
 "Tang keyserver": [
  null,
  "Сервер ключів Tang"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Для створення буферів Stratis має бути встановлено пакунок $0."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Для створення пристроїв VDO буде встановлено пакунок $0."
 ],
 "The RAID array is in a degraded state": [
  null,
  "Масив RAID перебуває у стані із погіршеними властивостями"
 ],
 "The RAID device must be running in order to add spare disks.": [
  null,
  "Для додавання резервних дисків має працювати пристрій RAID."
 ],
 "The RAID device must be running in order to remove disks.": [
  null,
  "Для вилучення дисків має працювати пристрій RAID."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Створення цього пристрою VDO не завершено, ним не можна користуватися."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Поточний користувач, від імені якого було здійснено вхід до системи, не має права перегляду даних щодо ключів."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "Перед форматуванням диск має бути розблоковано. Будь ласка, надайте наявний пароль."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "У файлової системи немає сталої точки монтування."
 ],
 "The filesystem is already mounted at $0. Proceeding will unmount it.": [
  null,
  "Файлову систему вже змонтовано до $0. У результаті виконання цієї дії її буде демонтовано."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Файлову систему налаштовано на автоматичне монтування при вході до системи, але її контейнер шифрування не буде розблоковано вчасно."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Файлову систему зараз змонтовано, але її не буде змонтовано після наступного завантаження."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Файлову систему зараз змонтовано до $0, але її буде змонтовано до $1 під час наступного завантаження."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Файлову систему зараз змонтовано до $0, але її не буде змонтовано після наступного завантаження."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Файлову систему зараз не змонтовано, але її буде змонтовано під час наступного завантаження."
 ],
 "The filesystem is not mounted.": [
  null,
  "Файлову систему не змонтовано."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Файлову систему буде розблоковано і змонтовано під час наступного завантаження. Це може потребувати введення пароля."
 ],
 "The last disk of a RAID device cannot be removed.": [
  null,
  "Останній диск пристрою RAID вилучати не можна."
 ],
 "The last key slot can not be removed": [
  null,
  "Не можна вилучати останній слот ключів"
 ],
 "The last physical volume of a volume group cannot be removed.": [
  null,
  "Не можна вилучати останній фізичний том із групи томів."
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Процеси і служби зі списку буде примусово зупинено."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Процеси зі списку буде примусово зупинено."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Служби зі списку буде примусово зупинено."
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Точка монтування $0 перебуває у користуванні такими процесами:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Точка монтування $0 перебуває у користуванні такими службами:"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "У системі є пристрої із декількома шляхами доступу, але службу multipath не запущено."
 ],
 "There is not enough free space elsewhere to remove this physical volume. At least $0 more free space is needed.": [
  null,
  "Для вилучення цього фізичного тому недостатньо вільного місця. Потрібно принаймні $0 вільного місця."
 ],
 "These changes will be made:": [
  null,
  "Буде внесено такі зміни:"
 ],
 "Thin logical volume": [
  null,
  "Тонкий логічний том"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Це монтування NFS використовується; можна лише змінювати його параметри."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Цей пристрій VDO не використовує увесь об'єм резервного пристрою."
 ],
 "This device is currently in use.": [
  null,
  "Цей пристрій зараз перебуває у користуванні."
 ],
 "This disk cannot be removed while the device is recovering.": [
  null,
  "Цей диск не можна вилучати, доки пристрій перебуває у стані відновлення."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Місце на цьому логічному томі не повністю використано даними, які на ньому зберігаються."
 ],
 "This pool can not be unlocked here because its key description is not in the expected format.": [
  null,
  "Цей буфер не можна розблокувати тут, оскільки його опис ключа записано не в очікуваному форматі."
 ],
 "This volume needs to be activated before it can be resized.": [
  null,
  "Перш ніж розмір цього тому можна буде змінювати, його слід активувати."
 ],
 "Tier": [
  null,
  "Клас"
 ],
 "Toggle": [
  null,
  "Перемкнути"
 ],
 "Toggle bitmap": [
  null,
  "Перемкнути бітову карту"
 ],
 "Total size: $0": [
  null,
  "Загальний розмір: $0"
 ],
 "Trust key": [
  null,
  "Довіряти ключу"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "Не вдалося досягти сервера"
 ],
 "Unable to remove mount": [
  null,
  "Не вдалося вилучити монтування"
 ],
 "Unable to unmount filesystem": [
  null,
  "Не вдалося демонтувати файлову систему"
 ],
 "Unknown": [
  null,
  "Невідомий"
 ],
 "Unknown ($0)": [
  null,
  "Невідомий ($0)"
 ],
 "Unknown host name": [
  null,
  "Невідома назва вузла"
 ],
 "Unknown type": [
  null,
  "Невідомий тип"
 ],
 "Unlock": [
  null,
  "Розблокувати"
 ],
 "Unlock automatically on boot": [
  null,
  "Автоматично розблокувати при завантаженні"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Розблокувати зашифрований буфер Stratis"
 ],
 "Unlock pool to see filesystems.": [
  null,
  "Розблокуйте буфер для перегляду файлових систем."
 ],
 "Unlocking $target": [
  null,
  "Розблокуємо $target"
 ],
 "Unlocking disk": [
  null,
  "Розблоковуємо диск"
 ],
 "Unmount": [
  null,
  "Демонтувати"
 ],
 "Unmount filesystem $0": [
  null,
  "Демонтувати файлову систему $0"
 ],
 "Unmount now": [
  null,
  "Демонтувати зараз"
 ],
 "Unmounting $target": [
  null,
  "Демонтуємо $target"
 ],
 "Unrecognized data": [
  null,
  "Нерозпізнані дані"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Тут не можна зменшити об'єм нерозпізнаних даних."
 ],
 "Unsupported volume": [
  null,
  "Непідтримуваний том"
 ],
 "Usage": [
  null,
  "Використання"
 ],
 "Usage of $0": [
  null,
  "Вживання $0"
 ],
 "Use": [
  null,
  "Використати"
 ],
 "Use compression": [
  null,
  "Скористатися стисканням"
 ],
 "Use deduplication": [
  null,
  "Скористатися скасуванням дублювання"
 ],
 "Used": [
  null,
  "Використано"
 ],
 "Used for": [
  null,
  "Використано для"
 ],
 "User": [
  null,
  "Користувач"
 ],
 "Username": [
  null,
  "Користувач"
 ],
 "Using LUKS encryption": [
  null,
  "З використанням шифрування LUKS"
 ],
 "Using Tang server": [
  null,
  "З використанням сервера Tang"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Пристрої резервного копіювання VDO не можна звужувати"
 ],
 "VDO device": [
  null,
  "Пристрій VDO"
 ],
 "VDO device $0": [
  null,
  "Пристрій VDO $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Том файлової системи VDO (стискання/дедублікація)"
 ],
 "VDO pool": [
  null,
  "Буфер VDO"
 ],
 "Verify key": [
  null,
  "Перевірити ключ"
 ],
 "Very securely erasing $target": [
  null,
  "Дуже безпечно витираємо $target"
 ],
 "View all logs": [
  null,
  "Переглянути усі журнали"
 ],
 "Volume": [
  null,
  "Том"
 ],
 "Volume group": [
  null,
  "Група томів"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Розмір тому — $0. Розмір даних — $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Очікуємо на завершення інших дій із програмним забезпеченням"
 ],
 "Write-mostly": [
  null,
  "Здебільшого запис"
 ],
 "Writing": [
  null,
  "Запис"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 байтів двійкових даних]"
 ],
 "[binary data]": [
  null,
  "[двійкові дані]"
 ],
 "[no data]": [
  null,
  "[немає даних]"
 ],
 "backing device for VDO device": [
  null,
  "резервний пристрій для пристрою VDO"
 ],
 "delete": [
  null,
  "вилучити"
 ],
 "disk": [
  null,
  "диск"
 ],
 "drive": [
  null,
  "диск"
 ],
 "edit": [
  null,
  "редагувати"
 ],
 "encryption": [
  null,
  "шифрування"
 ],
 "filesystem": [
  null,
  "файлова система"
 ],
 "format": [
  null,
  "формат"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "grow": [
  null,
  "збільшити"
 ],
 "iSCSI targets": [
  null,
  "Призначення iSCSI"
 ],
 "initialize": [
  null,
  "ініціалізувати"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "member of RAID device": [
  null,
  "елемент пристрою RAID"
 ],
 "member of Stratis pool": [
  null,
  "частина буфера Stratis"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "монтування"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "never mounted at boot": [
  null,
  "ніколи не монтується при завантаженні"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "none": [
  null,
  "немає"
 ],
 "partition": [
  null,
  "розділ"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "фізичний том групи томів LVM2"
 ],
 "raid": [
  null,
  "raid"
 ],
 "read only": [
  null,
  "лише читання"
 ],
 "remove from LVM2": [
  null,
  "вилучити з LVM2"
 ],
 "remove from RAID": [
  null,
  "вилучити з RAID"
 ],
 "shrink": [
  null,
  "стиснути"
 ],
 "stop": [
  null,
  "зупинити"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unknown target": [
  null,
  "невідоме призначення"
 ],
 "unmount": [
  null,
  "демонтувати"
 ],
 "unpartitioned space on $0": [
  null,
  "нерозподілене місце на $0"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "том"
 ],
 "yes": [
  null,
  "так"
 ],
 "storage-id-desc\u0004$0 filesystem": [
  null,
  "Файлова система $0"
 ],
 "storage-id-desc\u0004Filesystem (encrypted)": [
  null,
  "Файлова система (зашифровано)"
 ],
 "storage-id-desc\u0004Locked encrypted data": [
  null,
  "Заблоковано зашифровані дані"
 ],
 "storage-id-desc\u0004Other data": [
  null,
  "Інші дані"
 ],
 "storage-id-desc\u0004Swap space": [
  null,
  "Резервна пам’ять"
 ],
 "storage-id-desc\u0004Unrecognized data": [
  null,
  "Нерозпізнані дані"
 ],
 "storage-id-desc\u0004VDO backing": [
  null,
  "Резерв VDO"
 ],
 "storage\u0004Assessment": [
  null,
  "Оцінювання"
 ],
 "storage\u0004Bitmap": [
  null,
  "Бітова карта"
 ],
 "storage\u0004Capacity": [
  null,
  "Місткість"
 ],
 "storage\u0004Device": [
  null,
  "Пристрій"
 ],
 "storage\u0004Device file": [
  null,
  "Файл пристрою"
 ],
 "storage\u0004Firmware version": [
  null,
  "Версія мікропрограми"
 ],
 "storage\u0004Model": [
  null,
  "Модель"
 ],
 "storage\u0004Multipathed devices": [
  null,
  "Пристрої із багатьма шляхами"
 ],
 "storage\u0004Optical drive": [
  null,
  "Пристрій читання оптичних дисків"
 ],
 "storage\u0004RAID level": [
  null,
  "Рівень RAID"
 ],
 "storage\u0004Removable drive": [
  null,
  "Портативний диск"
 ],
 "storage\u0004Serial number": [
  null,
  "Серійний номер"
 ],
 "storage\u0004State": [
  null,
  "Стан"
 ],
 "storage\u0004UUID": [
  null,
  "UUID"
 ],
 "storage\u0004Usage": [
  null,
  "Використання"
 ],
 "storage\u0004World wide name": [
  null,
  "World wide name"
 ],
 "format-bytes\u0004bytes": [
  null,
  "байтів"
 ]
});
