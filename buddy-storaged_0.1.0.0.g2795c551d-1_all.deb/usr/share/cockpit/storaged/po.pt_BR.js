cockpit.locale({
 "": {
  "plural-forms": (n) => (n != 1),
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "$0 (encrypted)": [
  null,
  "$0 (encriptado)"
 ],
 "$0 block device": [
  null,
  "$0 Dispositivos de Bloco"
 ],
 "$0 cache": [
  null,
  "$0 cache"
 ],
 "$0 chunk size": [
  null,
  "$0 Tamanho do Bloco"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 dados + $1 sobrecarga usada de $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 dia",
  "$0 dias"
 ],
 "$0 disk is missing": [
  null,
  "$0 disco não encontrado",
  "$0 discos não encontrados"
 ],
 "$0 disks": [
  null,
  "$0 Discos"
 ],
 "$0 filesystems can not be made larger.": [
  null,
  "$0 sistemas de arquivos não podem ser maiores."
 ],
 "$0 filesystems can not be made smaller.": [
  null,
  "$0 sistemas de arquivos não podem ser menores."
 ],
 "$0 filesystems can not be resized here.": [
  null,
  "$0 sistemas de arquivos não podem ser redimensionados aqui."
 ],
 "$0 hour": [
  null,
  "$0 hora",
  "$0 horas"
 ],
 "$0 is in use": [
  null,
  "$0 está em uso"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 não está disponível em nenhum repositório."
 ],
 "$0 minute": [
  null,
  "$0 minuto",
  "$0 minutos"
 ],
 "$0 month": [
  null,
  "$0 mês",
  "$0 meses"
 ],
 "$0 slot remains": [
  null,
  "$0 slot restante",
  "$0 slots restantes"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 usados of $1 ($2 salvos)"
 ],
 "$0 week": [
  null,
  "$0 semana",
  "$0 semanas"
 ],
 "$0 will be installed.": [
  null,
  "$0 será instalado."
 ],
 "$0 year": [
  null,
  "$0 ano",
  "$0 anos"
 ],
 "$0, $1 free": [
  null,
  "$0, $1 livre"
 ],
 "$name (from $host)": [
  null,
  "$nome(vindo de $host)"
 ],
 "(recommended)": [
  null,
  "(recomendado)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 dia"
 ],
 "1 hour": [
  null,
  "1 hora"
 ],
 "1 week": [
  null,
  "1 semana"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "5 minutes": [
  null,
  "5 minutos"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 horas"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  ""
 ],
 "A pool with this name exists already.": [
  null,
  ""
 ],
 "A spare disk needs to be added first before this disk can be removed.": [
  null,
  "Um disco de reposição precisa ser adicionado primeiro antes que este disco possa ser removido."
 ],
 "Activate": [
  null,
  "Ativar"
 ],
 "Activating $target": [
  null,
  "Ativando $target"
 ],
 "Add": [
  null,
  "Adicionar"
 ],
 "Add disks": [
  null,
  "Adicionar Discos"
 ],
 "Add iSCSI portal": [
  null,
  "Adicionar Portal iSCSI"
 ],
 "Add key": [
  null,
  "Adicionar chave"
 ],
 "Adding physical volume to $target": [
  null,
  "Adicionando volume físico a $target"
 ],
 "Additional packages:": [
  null,
  "Pacotes adicionais:"
 ],
 "Address": [
  null,
  "Endereço"
 ],
 "Address cannot be empty": [
  null,
  "O endereço não pode estar vazio"
 ],
 "Address is not a valid URL": [
  null,
  "O endereço não é um URL válido"
 ],
 "At least $0 disk is needed.": [
  null,
  "Pelo menos $0 disco é necessário.",
  "Pelo menos $0 discos são necessários."
 ],
 "At least one disk is needed.": [
  null,
  "Pelo menos um disco é necessário."
 ],
 "Authentication required": [
  null,
  "Autenticação requerida"
 ],
 "Available targets on $0": [
  null,
  "Alvos disponíveis em $0"
 ],
 "Backing device": [
  null,
  "Dispositivo de apoio"
 ],
 "Block": [
  null,
  "Bloco"
 ],
 "Block device for filesystems": [
  null,
  "Dispositivo de bloqueio para sistemas de arquivos"
 ],
 "Blocked": [
  null,
  "Bloqueado"
 ],
 "Cancel": [
  null,
  "Cancelar"
 ],
 "Change": [
  null,
  "Alterar"
 ],
 "Change iSCSI initiator name": [
  null,
  "Alterar Nome do Iniciador iSCSI"
 ],
 "Change passphrase": [
  null,
  "Alterar senha"
 ],
 "Checking $target": [
  null,
  "Vericando $target"
 ],
 "Checking RAID device $target": [
  null,
  "Checando Dispositivo RAID $target"
 ],
 "Checking and repairing RAID device $target": [
  null,
  "Checando e Reparando o Dispositivo RAID $target"
 ],
 "Checking installed software": [
  null,
  "Verificando o software instalado"
 ],
 "Chunk size": [
  null,
  "Tamanho do Bloco"
 ],
 "Cleaning up for $target": [
  null,
  "Limpando $target"
 ],
 "Close": [
  null,
  "Fechar"
 ],
 "Command": [
  null,
  "Comando"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Compatível com todos os sistemas e dispositivos (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Compatível com sistema moderno e discos rígidos > 2TB (GPT)"
 ],
 "Compression": [
  null,
  "Compressão"
 ],
 "Confirm": [
  null,
  "Confirmar"
 ],
 "Content": [
  null,
  "Conteúdo"
 ],
 "Copy to clipboard": [
  null,
  "Copiar para área de transferência"
 ],
 "Create": [
  null,
  "Criar"
 ],
 "Create RAID device": [
  null,
  "Criar dispositivo RAID"
 ],
 "Create devices": [
  null,
  "Criar dispositivos"
 ],
 "Create logical volume": [
  null,
  "Criar Volume Lógico"
 ],
 "Create new logical volume": [
  null,
  "Criar novo Volume Lógico"
 ],
 "Create partition": [
  null,
  "Criar Partição"
 ],
 "Create partition on $0": [
  null,
  "Criar Partição em $0"
 ],
 "Create partition table": [
  null,
  "Criar tabela de partição"
 ],
 "Create snapshot": [
  null,
  "Criar Snapshot"
 ],
 "Create thin volume": [
  null,
  "Criar Thin Volume"
 ],
 "Create volume group": [
  null,
  "Criar Grupo de Volumes"
 ],
 "Creating RAID device $target": [
  null,
  "Criando Dispositivo RAID $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Criando sistema de arquivos em $target"
 ],
 "Creating logical volume $target": [
  null,
  "Criando volume lógico $target"
 ],
 "Creating partition $target": [
  null,
  "Criando partição $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Criando snapshot de $target"
 ],
 "Custom mount options": [
  null,
  "Opções de montagem personalizadas"
 ],
 "Data used": [
  null,
  "Dados Usados"
 ],
 "Deactivate": [
  null,
  "Desativar"
 ],
 "Deactivating $target": [
  null,
  "Desativando $target"
 ],
 "Deduplication": [
  null,
  "Desduplicação"
 ],
 "Delete": [
  null,
  "Excluir"
 ],
 "Deleting $target": [
  null,
  "Deletando $0"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Excluindo um volume lógico irá excluir todos os dados nele."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "A exclusão de uma partição apaga todos os dados da mesma."
 ],
 "Description": [
  null,
  "Descrição"
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Device file": [
  null,
  "Arquivo do dispositivo"
 ],
 "Device is read-only": [
  null,
  "Dispositivo é somente leitura"
 ],
 "Devices": [
  null,
  "Dispositivos"
 ],
 "Disk is OK": [
  null,
  "O Disco está OK"
 ],
 "Disk passphrase": [
  null,
  "Senha de disco"
 ],
 "Disks": [
  null,
  "Discos"
 ],
 "Do not mount automatically on boot": [
  null,
  ""
 ],
 "Downloading $0": [
  null,
  "Baixando $0"
 ],
 "Drive": [
  null,
  "Unidade"
 ],
 "Drives": [
  null,
  "Unidades"
 ],
 "Edit": [
  null,
  "Editar"
 ],
 "Edit Tang keyserver": [
  null,
  "Editar o servidor de chaves Tang"
 ],
 "Editing a key requires a free slot": [
  null,
  "Editar uma chave requer um espaço livre"
 ],
 "Ejecting $target": [
  null,
  "Ejetando $target"
 ],
 "Emptying $target": [
  null,
  "Esvaziando $target"
 ],
 "Encrypt data": [
  null,
  "Criptografar dados"
 ],
 "Encrypted $0": [
  null,
  "Encriptado"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Volume Lógico Criptografado de $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Partição Criptografada de $0"
 ],
 "Encrypted volumes can not be resized here.": [
  null,
  "Volumes criptografados não podem ser redimensionados aqui."
 ],
 "Encrypted volumes need to be unlocked before they can be resized.": [
  null,
  "Volumes criptografados precisam ser desbloqueados antes de serem redimensionados."
 ],
 "Encryption": [
  null,
  "Encriptação"
 ],
 "Encryption options": [
  null,
  "Opções de Criptografia"
 ],
 "Encryption type": [
  null,
  "Tipo de encriptação"
 ],
 "Erasing $target": [
  null,
  "Apagando $target"
 ],
 "Error": [
  null,
  "Erro"
 ],
 "Extended partition": [
  null,
  "Partição Extendida"
 ],
 "Failed": [
  null,
  "Falhou"
 ],
 "Filesystem": [
  null,
  "Sistema de arquivos"
 ],
 "Filesystem name": [
  null,
  "Nome do Sistema de Arquivos"
 ],
 "Filesystems": [
  null,
  "Sistema de Arquivos"
 ],
 "Format": [
  null,
  "Formate"
 ],
 "Format $0": [
  null,
  "Formate $0"
 ],
 "Free": [
  null,
  "Livre"
 ],
 "Free space": [
  null,
  "Espaço Livre"
 ],
 "Free up space in this group: Shrink or delete other logical volumes or add another physical volume.": [
  null,
  ""
 ],
 "Go to now": [
  null,
  "Ir para agora"
 ],
 "Grow": [
  null,
  "Crescer"
 ],
 "Grow logical size of $0": [
  null,
  "Crescer tamanho lógico de $0"
 ],
 "Grow logical volume": [
  null,
  "Aumentar o Volume Lógico"
 ],
 "Grow to take all space": [
  null,
  "Crescer para tomar todo o espaço"
 ],
 "If this option is checked, the filesystem will not be mounted during the next boot even if it was mounted before it.  This is useful if mounting during boot is not possible, such as when a passphrase is required to unlock the filesystem but booting is unattended.": [
  null,
  ""
 ],
 "In sync": [
  null,
  "Em Sincronização"
 ],
 "Inactive volume": [
  null,
  "Volume inativo"
 ],
 "Inconsistent filesystem mount": [
  null,
  ""
 ],
 "Index memory": [
  null,
  "Memória de índice"
 ],
 "Install": [
  null,
  "Instale"
 ],
 "Install NFS support": [
  null,
  "Instale o suporte ao NFS"
 ],
 "Install software": [
  null,
  "Instale Software"
 ],
 "Installing $0": [
  null,
  "Instalando $0"
 ],
 "Invalid username or password": [
  null,
  "Nome de usuário ou senha inválidos"
 ],
 "Jobs": [
  null,
  "Trabalhos"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Slots chave com tipos desconhecidos não podem ser editados aqui"
 ],
 "Key source": [
  null,
  "Fonte chave"
 ],
 "Keys": [
  null,
  "Chaves"
 ],
 "Keyserver": [
  null,
  "Servidor de chaves"
 ],
 "Keyserver address": [
  null,
  "Endereço do servidor de chaves"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "A remoção do Keyserver pode impedir o desbloqueio de $0."
 ],
 "Last modified: $0": [
  null,
  "Última modificação: $0"
 ],
 "Learn more": [
  null,
  "Saiba mais"
 ],
 "Loading...": [
  null,
  "Carregando..."
 ],
 "Local mount point": [
  null,
  "Ponto de montagem local"
 ],
 "Location": [
  null,
  "Localização"
 ],
 "Lock": [
  null,
  "Travar"
 ],
 "Locked devices": [
  null,
  "Dispositivos bloqueados"
 ],
 "Locking $target": [
  null,
  "Bloqueando $target"
 ],
 "Logical": [
  null,
  "Lógico"
 ],
 "Logical size": [
  null,
  "Tamanho Lógico"
 ],
 "Logical volume": [
  null,
  "Volume Lógico"
 ],
 "Logical volume (snapshot)": [
  null,
  "Volume Lógico (Snapshot)"
 ],
 "Logical volume of $0": [
  null,
  "Volume Lógico de $0"
 ],
 "Logical volumes": [
  null,
  "Volumes lógico"
 ],
 "Manually check with SSH: ": [
  null,
  "Verificar manualmente com o SSH: "
 ],
 "Marking $target as faulty": [
  null,
  "Marcando $target como defeituoso"
 ],
 "Metadata used": [
  null,
  "Metadados Usados"
 ],
 "Modifying $target": [
  null,
  "Modificando $target"
 ],
 "Mount": [
  null,
  "Montar"
 ],
 "Mount also automatically on boot": [
  null,
  ""
 ],
 "Mount at boot": [
  null,
  "Monte na Inicialização"
 ],
 "Mount automatically on $0 on boot": [
  null,
  ""
 ],
 "Mount configuration": [
  null,
  "Configuração de montagem"
 ],
 "Mount filesystem": [
  null,
  "Montar sistema de arquivos"
 ],
 "Mount now": [
  null,
  ""
 ],
 "Mount on $0 now": [
  null,
  ""
 ],
 "Mount options": [
  null,
  "Opções de Montagem"
 ],
 "Mount point": [
  null,
  "Ponto de Montagem"
 ],
 "Mount point cannot be empty": [
  null,
  "O ponto de montagem não pode estar vazio"
 ],
 "Mount point cannot be empty.": [
  null,
  "O ponto de montagem não pode estar vazio."
 ],
 "Mount point is already used for $0": [
  null,
  ""
 ],
 "Mount point must start with \"/\".": [
  null,
  "O ponto de montagem deve começar com \"/\"."
 ],
 "Mount read only": [
  null,
  "Monte só de leitura"
 ],
 "Mounting $target": [
  null,
  "Montando $target"
 ],
 "NFS mount": [
  null,
  "Montagem NFS"
 ],
 "NFS mounts": [
  null,
  "Montagens NFS"
 ],
 "NFS support not installed": [
  null,
  "Suporte ao NFS não instalado"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Name can not be empty.": [
  null,
  "O nome não pode estar vazio."
 ],
 "Name cannot be empty.": [
  null,
  "O nome não pode estar vazio."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "O nome não pode ser maior que $0 bytes"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "O nome não pode ser maior do que $0 caracteres"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "O nome não pode ser maior do que 127 caracteres."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "O nome não pode conter o caractere '$0'."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Nome não pode conter espaço em branco."
 ],
 "New NFS mount": [
  null,
  "Nova montagem de volume NFS"
 ],
 "New passphrase": [
  null,
  "Nova senha"
 ],
 "Next": [
  null,
  "Próximo"
 ],
 "No NFS mounts set up": [
  null,
  "Nenhum volume NFS montado"
 ],
 "No available slots": [
  null,
  "Sem slots disponíveis"
 ],
 "No devices": [
  null,
  "Nenhum dispositivo"
 ],
 "No disks are available.": [
  null,
  "Sem discos disponíveis."
 ],
 "No drives attached": [
  null,
  "Não há unidades anexadas"
 ],
 "No filesystem": [
  null,
  "Nenhum Sistema de Arquivos"
 ],
 "No free key slots": [
  null,
  "Nenhum slot de chave livre"
 ],
 "No free space": [
  null,
  "Não há espaço livre"
 ],
 "No iSCSI targets set up": [
  null,
  "Nenhum destino iSCSI configurado"
 ],
 "No keys added": [
  null,
  "Nenhuma chave adicionada"
 ],
 "No logical volumes": [
  null,
  "Nenhum Volume Lógico"
 ],
 "No media inserted": [
  null,
  "Nenhuma mídia inserida"
 ],
 "No partitioning": [
  null,
  "Sem particionamento"
 ],
 "Not enough space to grow.": [
  null,
  ""
 ],
 "Not found": [
  null,
  "Não encontrado"
 ],
 "Not mounted": [
  null,
  "Não montado"
 ],
 "Not running": [
  null,
  "Não está rodando"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old passphrase": [
  null,
  "Senha antiga"
 ],
 "Only $0 of $1 are used.": [
  null,
  "Somente $0 de $1 está em uso."
 ],
 "Operation '$operation' on $target": [
  null,
  "Operação '$operation' em $target"
 ],
 "Options": [
  null,
  "Opções"
 ],
 "Other devices": [
  null,
  "Outros dispositivos"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit caiu"
 ],
 "Partition": [
  null,
  "Partição"
 ],
 "Partition of $0": [
  null,
  "Partição de $0"
 ],
 "Partitioning": [
  null,
  "Particionamento"
 ],
 "Partitions": [
  null,
  "Partições"
 ],
 "Passphrase": [
  null,
  "Frase-senha"
 ],
 "Passphrase can not be empty": [
  null,
  "A senha não pode estar vazia"
 ],
 "Passphrase cannot be empty": [
  null,
  "A senha não pode estar vazia"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "A remoção da senha pode impedir o desbloqueio de $0."
 ],
 "Passphrases do not match": [
  null,
  "As senhas não correspondem"
 ],
 "Password": [
  null,
  "Senha"
 ],
 "Path on server": [
  null,
  "Caminho no servidor"
 ],
 "Path on server cannot be empty.": [
  null,
  "Caminho no servidor não pode estar vazio."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Caminho no servidor deve começar com \"/\"."
 ],
 "Permanently delete $0?": [
  null,
  ""
 ],
 "Physical": [
  null,
  "Fisica"
 ],
 "Physical volumes": [
  null,
  "Volumes Físicos"
 ],
 "Physical volumes can not be resized here.": [
  null,
  "Volumes físicos não podem ser redimensionados aqui."
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Pool for thin logical volumes": [
  null,
  "Buscando por Thin Logical Volumes"
 ],
 "Pool for thin volumes": [
  null,
  "Pool para Volumes Finos"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool para volumes finamente provisionados"
 ],
 "Port": [
  null,
  "Porta"
 ],
 "Processes using the location": [
  null,
  ""
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  ""
 ],
 "Purpose": [
  null,
  "Propósito"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Distribuição)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Espelhamento)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (Distribuição de Espelhos)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (Paridade Dedicada)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (Paridade Distribuída)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (Paridade Duplamente Distribuída)"
 ],
 "RAID device": [
  null,
  "Dispositivo RAID"
 ],
 "RAID device $0": [
  null,
  "Dispositivo RAID $0"
 ],
 "RAID level": [
  null,
  "Nível de RAID"
 ],
 "RAID member": [
  null,
  "Membro RAID"
 ],
 "Reboot": [
  null,
  "Reiniciar"
 ],
 "Recovering": [
  null,
  "Recuperação"
 ],
 "Recovering RAID device $target": [
  null,
  "Recuperando Dispositivo RAID $target"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  ""
 ],
 "Related processes will be forcefully stopped.": [
  null,
  ""
 ],
 "Related services will be forcefully stopped.": [
  null,
  ""
 ],
 "Removals:": [
  null,
  "Remoções:"
 ],
 "Remove": [
  null,
  "Remover"
 ],
 "Remove $0?": [
  null,
  "Remover $0?"
 ],
 "Remove device": [
  null,
  "Remover dispositivo"
 ],
 "Removing $0": [
  null,
  "Removendo $0"
 ],
 "Removing $target from RAID device": [
  null,
  "Removendo $target de Dispositivo RAID"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  ""
 ],
 "Removing physical volume from $target": [
  null,
  "Removendo volume físico de $target"
 ],
 "Rename": [
  null,
  "Renomear"
 ],
 "Rename logical volume": [
  null,
  "Renomear Volume Lógico"
 ],
 "Rename volume group": [
  null,
  "Renomear Grupo de Volume"
 ],
 "Renaming $target": [
  null,
  "Renomeando $target"
 ],
 "Repairing $target": [
  null,
  "Reparando $target"
 ],
 "Repeat passphrase": [
  null,
  "Repita a frase secreta"
 ],
 "Resizing $target": [
  null,
  "Redimensionando $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  ""
 ],
 "Reuse existing encryption ($0)": [
  null,
  ""
 ],
 "Running": [
  null,
  "Executando"
 ],
 "Runtime": [
  null,
  ""
 ],
 "SHA1": [
  null,
  ""
 ],
 "SHA256": [
  null,
  ""
 ],
 "SMART self-test of $target": [
  null,
  "SMART auto-teste de $target"
 ],
 "Save": [
  null,
  "Salvar"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  ""
 ],
 "Save space by storing identical data blocks just once": [
  null,
  ""
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Salvar uma nova senha requer o desbloqueio do disco. Por favor, forneça uma senha de disco atual."
 ],
 "Securely erasing $target": [
  null,
  "Apagando com segurança $target"
 ],
 "Server": [
  null,
  "Servidor"
 ],
 "Server address": [
  null,
  "Endereço do Servidor"
 ],
 "Server address cannot be empty.": [
  null,
  "O endereço do servidor não pode estar vazio."
 ],
 "Server cannot be empty.": [
  null,
  "O servidor não pode estar vazio."
 ],
 "Service": [
  null,
  "Serviço"
 ],
 "Setting up loop device $target": [
  null,
  "Configurando o dispositivo de loop $target"
 ],
 "Show $0 device": [
  null,
  "Mostrar $0 dispositivo",
  "Mostrar todos os $0 dispositivos"
 ],
 "Show $0 drive": [
  null,
  "Mostrar $0 drive",
  "Mostrar todos os $0 drives"
 ],
 "Show all": [
  null,
  "Exibir todos"
 ],
 "Shrink": [
  null,
  "Compactar"
 ],
 "Shrink logical volume": [
  null,
  "Compactar Logical Volume"
 ],
 "Size": [
  null,
  "Tamanho"
 ],
 "Size cannot be negative": [
  null,
  "O tamanho não pode ser negativo"
 ],
 "Size cannot be zero": [
  null,
  "O tamanho não pode ser zero"
 ],
 "Size is too large": [
  null,
  "O tamanho é muito extenso"
 ],
 "Size must be a number": [
  null,
  "O tamanho deve ser um número"
 ],
 "Size must be at least $0": [
  null,
  "O tamanho deve ser pelo menos $0"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Source": [
  null,
  "Fonte"
 ],
 "Spare": [
  null,
  "Reposição"
 ],
 "Start": [
  null,
  "Iniciar"
 ],
 "Start multipath": [
  null,
  "Iniciar Multipath"
 ],
 "Starting RAID device $target": [
  null,
  "Iniciando o Dispositivo RAID $target"
 ],
 "Starting swapspace $target": [
  null,
  "Iniciando swapspace $target"
 ],
 "Stop": [
  null,
  "Pare"
 ],
 "Stop and remove": [
  null,
  "Pare e remova"
 ],
 "Stop and unmount": [
  null,
  "Parar e desmontar"
 ],
 "Stop device": [
  null,
  "Parar dispositivo"
 ],
 "Stopping RAID device $target": [
  null,
  "Parando o Dispositivo RAID $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Parando swapspace $target"
 ],
 "Storage": [
  null,
  "Armazenamento"
 ],
 "Storage can not be managed on this system.": [
  null,
  "O armazenamento não pode ser gerenciado neste sistema."
 ],
 "Storage logs": [
  null,
  "Logs de Armazenamento"
 ],
 "Store passphrase": [
  null,
  "Armazene a senha"
 ],
 "Stored passphrase": [
  null,
  "Senha armazenada"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Copiado com sucesso para a área de transferência!"
 ],
 "Support is installed.": [
  null,
  "O suporte está instalado."
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Synchronizing RAID device $target": [
  null,
  "Sincronizando Dispositivo RAID $target"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  ""
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  ""
 ],
 "The RAID array is in a degraded state": [
  null,
  "A matriz RAID está em um estado degradado"
 ],
 "The RAID device must be running in order to add spare disks.": [
  null,
  "O dispositivo RAID deve estar em execução para adicionar discos sobressalentes."
 ],
 "The RAID device must be running in order to remove disks.": [
  null,
  "O dispositivo RAID deve estar em execução para remover discos."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "A criação deste dispositivo VDO não foi concluída e o dispositivo não pode ser usado."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "O usuário atualmente conectado não tem permissão para ver informações sobre chaves."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  ""
 ],
 "The filesystem has no permanent mount point.": [
  null,
  ""
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  ""
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  ""
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  ""
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  ""
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  ""
 ],
 "The filesystem is not mounted.": [
  null,
  ""
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  ""
 ],
 "The last disk of a RAID device cannot be removed.": [
  null,
  "O último disco de um dispositivo RAID não pode ser removido."
 ],
 "The last key slot can not be removed": [
  null,
  "O último slot chave não pode ser removido"
 ],
 "The last physical volume of a volume group cannot be removed.": [
  null,
  "O último volume físico de um grupo de volumes não pode ser removido."
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  ""
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  ""
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  ""
 ],
 "The mount point $0 is in use by these services:": [
  null,
  ""
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Há dispositivos com vários caminhos no sistema, mas o serviço de multicaminho não está sendo executado."
 ],
 "There is not enough free space elsewhere to remove this physical volume. At least $0 more free space is needed.": [
  null,
  "Não há espaço livre suficiente em outro lugar para remover este volume físico. Pelo menos mais $0 de espaço livre é necessário."
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Esta montagem NFS está em uso e somente suas opções podem ser alteradas."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Este dispositivo VDO não usa todo o seu dispositivo de apoio."
 ],
 "This disk cannot be removed while the device is recovering.": [
  null,
  "Este disco não pode ser removido enquanto o dispositivo está se recuperando."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  ""
 ],
 "This pool can not be unlocked here because its key description is not in the expected format.": [
  null,
  ""
 ],
 "This volume needs to be activated before it can be resized.": [
  null,
  "Este volume precisa ser ativado antes de poder ser redimensionado."
 ],
 "Tier": [
  null,
  ""
 ],
 "Toggle": [
  null,
  ""
 ],
 "Toggle bitmap": [
  null,
  ""
 ],
 "Total size: $0": [
  null,
  "Tamanho total: $0"
 ],
 "Trust key": [
  null,
  "Chave de confiança"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "Não é possível acessar o servidor"
 ],
 "Unable to remove mount": [
  null,
  "Não é possível remover a unidade montade"
 ],
 "Unable to unmount filesystem": [
  null,
  "Não é possível desmontar o sistema de arquivos"
 ],
 "Unknown": [
  null,
  "Desconhecido"
 ],
 "Unknown ($0)": [
  null,
  "Desconhecido ($0)"
 ],
 "Unknown host name": [
  null,
  "Nome de host desconhecido"
 ],
 "Unknown type": [
  null,
  "Tipo desconhecido"
 ],
 "Unlock": [
  null,
  "Destravar"
 ],
 "Unlocking $target": [
  null,
  "Desbloqueando $target"
 ],
 "Unmount": [
  null,
  "Desmontar"
 ],
 "Unmount now": [
  null,
  ""
 ],
 "Unmounting $target": [
  null,
  "Desmontando $target"
 ],
 "Unrecognized data": [
  null,
  "Dados não reconhecidos"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Dados não reconhecidos não podem ser reduzidos aqui."
 ],
 "Unsupported volume": [
  null,
  "Volume não suportado"
 ],
 "Usage": [
  null,
  "Uso"
 ],
 "Used": [
  null,
  "Usado"
 ],
 "User": [
  null,
  "Usuário"
 ],
 "Username": [
  null,
  "Nome de Usuário"
 ],
 "Using LUKS encryption": [
  null,
  ""
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Dispositivos de suporte VDO não podem ser menores"
 ],
 "VDO device": [
  null,
  "Dispositivo VDO"
 ],
 "VDO device $0": [
  null,
  "Dispositivo VDO $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  ""
 ],
 "Verify key": [
  null,
  "Verificar chave"
 ],
 "Very securely erasing $target": [
  null,
  "Apagando com muita segurança $target"
 ],
 "View all logs": [
  null,
  "Ver todos os logs"
 ],
 "Volume": [
  null,
  "Volume"
 ],
 "Volume group": [
  null,
  "Grupo de volumes"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  ""
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Aguardando que outras operações de gerenciamento de software terminem"
 ],
 "Write-mostly": [
  null,
  "Maioria-Escrita"
 ],
 "Writing": [
  null,
  "Escrevendo"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bytes de data bynária]"
 ],
 "[binary data]": [
  null,
  "[dados binários]"
 ],
 "[no data]": [
  null,
  "[sem dados]"
 ],
 "disk": [
  null,
  "disco"
 ],
 "drive": [
  null,
  ""
 ],
 "edit": [
  null,
  ""
 ],
 "encryption": [
  null,
  ""
 ],
 "filesystem": [
  null,
  "sistema de arquivos"
 ],
 "format": [
  null,
  ""
 ],
 "fstab": [
  null,
  ""
 ],
 "grow": [
  null,
  ""
 ],
 "iSCSI targets": [
  null,
  "Alvos iSCSI"
 ],
 "iscsi": [
  null,
  ""
 ],
 "luks": [
  null,
  ""
 ],
 "lvm2": [
  null,
  ""
 ],
 "mkfs": [
  null,
  ""
 ],
 "mount": [
  null,
  ""
 ],
 "nbde": [
  null,
  ""
 ],
 "nfs": [
  null,
  ""
 ],
 "none": [
  null,
  "Nenhum"
 ],
 "partition": [
  null,
  "partição"
 ],
 "raid": [
  null,
  ""
 ],
 "read only": [
  null,
  ""
 ],
 "remove from LVM2": [
  null,
  ""
 ],
 "stop": [
  null,
  ""
 ],
 "tang": [
  null,
  ""
 ],
 "udisks": [
  null,
  ""
 ],
 "unknown target": [
  null,
  "alvo desconhecido"
 ],
 "unmount": [
  null,
  ""
 ],
 "unpartitioned space on $0": [
  null,
  "espaço não particionado em $0"
 ],
 "vdo": [
  null,
  ""
 ],
 "yes": [
  null,
  "sim"
 ],
 "storage-id-desc\u0004$0 filesystem": [
  null,
  "$0 sistema de arquivos"
 ],
 "storage-id-desc\u0004Other data": [
  null,
  "Outros Dados"
 ],
 "storage-id-desc\u0004Swap space": [
  null,
  "Swap Espaço"
 ],
 "storage-id-desc\u0004Unrecognized data": [
  null,
  "Dados não reconhecidos"
 ],
 "storage\u0004Assessment": [
  null,
  ""
 ],
 "storage\u0004Bitmap": [
  null,
  ""
 ],
 "storage\u0004Capacity": [
  null,
  "Capacidade"
 ],
 "storage\u0004Device": [
  null,
  "Dispositivo"
 ],
 "storage\u0004Device file": [
  null,
  "Arquivo de dispositivo"
 ],
 "storage\u0004Firmware version": [
  null,
  "Versão do firmware"
 ],
 "storage\u0004Model": [
  null,
  "Modelo"
 ],
 "storage\u0004Optical drive": [
  null,
  "Drive óptico"
 ],
 "storage\u0004Removable drive": [
  null,
  "Drive removível"
 ],
 "storage\u0004Serial number": [
  null,
  "Número de série"
 ],
 "storage\u0004State": [
  null,
  "Estado"
 ],
 "storage\u0004UUID": [
  null,
  "UUID"
 ],
 "storage\u0004World wide name": [
  null,
  ""
 ],
 "format-bytes\u0004bytes": [
  null,
  "bytes"
 ]
});
