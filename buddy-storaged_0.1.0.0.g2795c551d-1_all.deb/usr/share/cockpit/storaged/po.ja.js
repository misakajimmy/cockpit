cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "$0 (encrypted)": [
  null,
  "$0 (暗号化)"
 ],
 "$0 Stratis pool": [
  null,
  "$0 Stratis プール"
 ],
 "$0 block device": [
  null,
  "$0 ブロックデバイス"
 ],
 "$0 cache": [
  null,
  "$0 キャッシュ"
 ],
 "$0 chunk size": [
  null,
  "$0 チャンクサイズ"
 ],
 "$0 data": [
  null,
  "$0 データ"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 データ + $1 オーバーヘッドが $2 ($3) を使用しています"
 ],
 "$0 day": [
  null,
  "$0 日"
 ],
 "$0 disk is missing": [
  null,
  "$0 本のディスクがありません"
 ],
 "$0 disks": [
  null,
  "$0 ディスク"
 ],
 "$0 filesystems can not be made larger.": [
  null,
  "$0 ファイルシステムは大きくすることができません。"
 ],
 "$0 filesystems can not be made smaller.": [
  null,
  "$0 ファイルシステムは小さくすることができません。"
 ],
 "$0 filesystems can not be resized here.": [
  null,
  "ここでは、$0 ファイルシステムのサイズを変更できません。"
 ],
 "$0 hour": [
  null,
  "$0 時間"
 ],
 "$0 is in use": [
  null,
  "$0 は使用されています"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 は、あらゆるリポジトリーから利用できません。"
 ],
 "$0 minute": [
  null,
  "$0 分"
 ],
 "$0 month": [
  null,
  "$0 カ月"
 ],
 "$0 of unknown tier": [
  null,
  "不明な層の $0"
 ],
 "$0 slot remains": [
  null,
  "$0 スロットが残ります"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 が $1 ($2 が保存) を使用しています"
 ],
 "$0 week": [
  null,
  "$0 週"
 ],
 "$0 will be installed.": [
  null,
  "$0 がインストールされます。"
 ],
 "$0 year": [
  null,
  "$0 年"
 ],
 "$0, $1 free": [
  null,
  "$0, $1 空き"
 ],
 "$name (from $host)": [
  null,
  "$name ($host)"
 ],
 "(recommended)": [
  null,
  "(推奨)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 日"
 ],
 "1 hour": [
  null,
  "1 時間"
 ],
 "1 week": [
  null,
  "1 週間"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "5 minutes": [
  null,
  "5 分"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 時間"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "この名前のファイルシステムは、すでにこのプールに存在します。"
 ],
 "A pool with this name exists already.": [
  null,
  "この名前を持つプールはすでに存在します。"
 ],
 "A spare disk needs to be added first before this disk can be removed.": [
  null,
  "このディスクを削除する前に、スペアディスクを追加する必要があります。"
 ],
 "Action": [
  null,
  "アクション"
 ],
 "Activate": [
  null,
  "有効化"
 ],
 "Activating $target": [
  null,
  "$target のアクティベート"
 ],
 "Add": [
  null,
  "追加する"
 ],
 "Add block devices": [
  null,
  "ブロックデバイスを追加する"
 ],
 "Add disks": [
  null,
  "ディスクを追加する"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI ポータルを追加する"
 ],
 "Add key": [
  null,
  "キーを追加する"
 ],
 "Adding physical volume to $target": [
  null,
  "$target への物理ボリュームの追加"
 ],
 "Additional packages:": [
  null,
  "追加のパッケージ:"
 ],
 "Address": [
  null,
  "アドレス"
 ],
 "Address cannot be empty": [
  null,
  "アドレスは空欄にできません"
 ],
 "Address is not a valid URL": [
  null,
  "アドレスの URL は有効ではありません"
 ],
 "At least $0 disk is needed.": [
  null,
  "少なくとも $0 ディスクが必要です。"
 ],
 "At least one block device is needed.": [
  null,
  "1 つ以上のブロックデバイスが必要です。"
 ],
 "At least one disk is needed.": [
  null,
  "1 つ以上のディスクが必要です。"
 ],
 "Authentication required": [
  null,
  "認証が必要です"
 ],
 "Available targets on $0": [
  null,
  "$0 で利用可能なターゲット"
 ],
 "Backing device": [
  null,
  "バッキングデバイス"
 ],
 "Block": [
  null,
  "ブロック"
 ],
 "Block device for filesystems": [
  null,
  "ファイルシステム用ブロックデバイス"
 ],
 "Block devices": [
  null,
  "ブロックデバイス"
 ],
 "Blocked": [
  null,
  "ブロック済み"
 ],
 "Cache": [
  null,
  "キャッシュ"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Change": [
  null,
  "変更"
 ],
 "Change iSCSI initiator name": [
  null,
  "iSCSI イニシエーター名の変更"
 ],
 "Change passphrase": [
  null,
  "パスフレーズの変更"
 ],
 "Checking $target": [
  null,
  "$target の確認中"
 ],
 "Checking RAID device $target": [
  null,
  "RAID デバイス $target の確認中"
 ],
 "Checking and repairing RAID device $target": [
  null,
  "RAID デバイス $target の確認および修復中"
 ],
 "Checking installed software": [
  null,
  "インストールされたソフトウェアの確認中"
 ],
 "Checking related processes": [
  null,
  "関連プロセスの確認中"
 ],
 "Chunk size": [
  null,
  "チャンクサイズ"
 ],
 "Cleaning up for $target": [
  null,
  "$target のクリーンアップ中"
 ],
 "Cleartext device": [
  null,
  "cleartext デバイス"
 ],
 "Close": [
  null,
  "閉じる"
 ],
 "Command": [
  null,
  "コマンド"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "すべてのシステムおよびデバイスとの互換性あり (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "最新のシステムとの互換性があり、ハードディスクが 2TB よりも大きい (GPT)"
 ],
 "Compression": [
  null,
  "圧縮"
 ],
 "Confirm": [
  null,
  "確定します"
 ],
 "Confirm deletion of $0": [
  null,
  "$0 の削除を確定する"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "代替のパスフレーズで削除を確認"
 ],
 "Confirm stopping of $0": [
  null,
  "$0 の停止を確定する"
 ],
 "Content": [
  null,
  "コンテンツ"
 ],
 "Copy to clipboard": [
  null,
  "クリップボードにコピー"
 ],
 "Create": [
  null,
  "作成"
 ],
 "Create LVM2 volume group": [
  null,
  "LVM2 ボリュームグループの作成"
 ],
 "Create RAID device": [
  null,
  "RAID デバイスの作成"
 ],
 "Create Stratis pool": [
  null,
  "Stratis プールの作成"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "ファイルシステム $0 のスナップショットの作成"
 ],
 "Create devices": [
  null,
  "デバイスの作成"
 ],
 "Create filesystem": [
  null,
  "ファイルシステムの作成"
 ],
 "Create logical volume": [
  null,
  "論理ボリュームの作成"
 ],
 "Create new filesystem": [
  null,
  "新規ファイルシステムの作成"
 ],
 "Create new logical volume": [
  null,
  "新規論理ボリュームの作成"
 ],
 "Create partition": [
  null,
  "パーティションの作成"
 ],
 "Create partition on $0": [
  null,
  "$0 上でのパーティションの作成"
 ],
 "Create partition table": [
  null,
  "パーティションテーブルの作成"
 ],
 "Create snapshot": [
  null,
  "スナップショットの作成"
 ],
 "Create thin volume": [
  null,
  "シンボリュームの作成"
 ],
 "Create volume group": [
  null,
  "ボリュームグループの作成"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "LVM2 ボリュームグループ $target の作成"
 ],
 "Creating RAID device $target": [
  null,
  "RAID デバイス $target の作成"
 ],
 "Creating VDO device": [
  null,
  "VDO デバイスの作成"
 ],
 "Creating filesystem on $target": [
  null,
  "$target 上でのファイルシステムの作成"
 ],
 "Creating logical volume $target": [
  null,
  "論理ボリューム $target の作成"
 ],
 "Creating partition $target": [
  null,
  "パーティション $target の作成"
 ],
 "Creating snapshot of $target": [
  null,
  "$target のスナップショットの作成"
 ],
 "Currently in use": [
  null,
  "現在使用されています"
 ],
 "Custom mount options": [
  null,
  "カスタムのマウントオプション"
 ],
 "Data": [
  null,
  "データ"
 ],
 "Data used": [
  null,
  "使用済みデータ"
 ],
 "Deactivate": [
  null,
  "解除"
 ],
 "Deactivating $target": [
  null,
  "$target の非アクティブ化"
 ],
 "Deduplication": [
  null,
  "重複"
 ],
 "Delete": [
  null,
  "削除"
 ],
 "Deleting $target": [
  null,
  "$target の削除中"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "LVM2 ボリュームグループ $target の削除"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Stratis プールを削除すると、Stratis プールに含まれるデータがすべて消去されます。"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "ファイルシステムを削除すると、そのファイルシステム内のすべてのデータが削除されます。"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "論理ボリュームを削除すると、論理ボリューム内のすべてのデータが削除されます。"
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "パーティションを削除すると、パーティション内のすべてのデータが削除されます。"
 ],
 "Deleting erases all data on a RAID device.": [
  null,
  "削除すると、RAID デバイスのデータはすべて消去されます。"
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "削除すると、VDO デバイスのデータがすべて消去されます。"
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "削除すると、ボリュームグループのデータがすべて消去されます。"
 ],
 "Description": [
  null,
  "説明"
 ],
 "Device": [
  null,
  "デバイス"
 ],
 "Device file": [
  null,
  "デバイスファイル"
 ],
 "Device is read-only": [
  null,
  "デバイスは読み取り専用です"
 ],
 "Devices": [
  null,
  "デバイス"
 ],
 "Disk is OK": [
  null,
  "ディスクは OK です"
 ],
 "Disk is failing": [
  null,
  "ディスクで障害が発生中"
 ],
 "Disk passphrase": [
  null,
  "ディスクのパスフレーズ"
 ],
 "Disks": [
  null,
  "ディスク"
 ],
 "Do not mount automatically on boot": [
  null,
  "起動時に自動的にマウントしない"
 ],
 "Downloading $0": [
  null,
  "$0 をダウンロード中"
 ],
 "Drive": [
  null,
  "ドライブ"
 ],
 "Drives": [
  null,
  "ドライブ"
 ],
 "Edit": [
  null,
  "編集"
 ],
 "Edit Tang keyserver": [
  null,
  "Tang キーサーバーを編集する"
 ],
 "Editing a key requires a free slot": [
  null,
  "キーの編集にはフリースロットが必要です"
 ],
 "Ejecting $target": [
  null,
  "$target の取り出し中"
 ],
 "Emptying $target": [
  null,
  "$target を空にしています"
 ],
 "Encrypt data": [
  null,
  "暗号化データ"
 ],
 "Encrypted $0": [
  null,
  "暗号化された $0"
 ],
 "Encrypted Stratis pool $0": [
  null,
  "暗号化された Stratis プール $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "暗号化された $0 の論理ボリューム"
 ],
 "Encrypted partition of $0": [
  null,
  "暗号化された $0 のパーティション"
 ],
 "Encrypted volumes can not be resized here.": [
  null,
  "ここでは、暗号化したボリュームのサイズを変更することができません。"
 ],
 "Encrypted volumes need to be unlocked before they can be resized.": [
  null,
  "暗号化したボリュームは、サイズを変更する前にロックを解除する必要があります。"
 ],
 "Encryption": [
  null,
  "暗号化"
 ],
 "Encryption options": [
  null,
  "暗号化オプション"
 ],
 "Encryption type": [
  null,
  "暗号化タイプ"
 ],
 "Erasing $target": [
  null,
  "$target の削除中"
 ],
 "Error": [
  null,
  "エラー"
 ],
 "Extended partition": [
  null,
  "拡張パーティション"
 ],
 "Failed": [
  null,
  "失敗"
 ],
 "Filesystem": [
  null,
  "ファイルシステム"
 ],
 "Filesystem is locked": [
  null,
  "ファイルシステムがロックされています"
 ],
 "Filesystem name": [
  null,
  "ファイルシステム名"
 ],
 "Filesystems": [
  null,
  "ファイルシステム"
 ],
 "Format": [
  null,
  "フォーマット"
 ],
 "Format $0": [
  null,
  "$0 のフォーマット"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "フォーマットすると、ストレージデバイスのすべてのデータが削除されます。"
 ],
 "Free": [
  null,
  "空き"
 ],
 "Free space": [
  null,
  "空き領域"
 ],
 "Free up space in this group: Shrink or delete other logical volumes or add another physical volume.": [
  null,
  "このグループ内で領域を解放します: 他の論理ボリュームを縮小または削除するか、新たな物理ボリュームを追加してください。"
 ],
 "Go to now": [
  null,
  "今すぐ移動"
 ],
 "Grow": [
  null,
  "増加"
 ],
 "Grow content": [
  null,
  "コンテンツを増やす"
 ],
 "Grow logical size of $0": [
  null,
  "$0 の論理サイズを増加"
 ],
 "Grow logical volume": [
  null,
  "論理ボリュームの増加"
 ],
 "Grow to take all space": [
  null,
  "すべての領域を使用して増加"
 ],
 "If this option is checked, the filesystem will not be mounted during the next boot even if it was mounted before it.  This is useful if mounting during boot is not possible, such as when a passphrase is required to unlock the filesystem but booting is unattended.": [
  null,
  "このオプションにチェックが付けられると、次回の起動時にファイルシステムがマウントされていても、次回の起動時にマウントされません。これは、ファイルシステムのロックを解除する必要があるが、起動が無人の場合などに、起動時にマウントできない場合に役立ちます。"
 ],
 "In sync": [
  null,
  "同期"
 ],
 "Inactive volume": [
  null,
  "非アクティブなボリューム"
 ],
 "Inconsistent filesystem mount": [
  null,
  "一貫性のないシステムマウント"
 ],
 "Index memory": [
  null,
  "インデックスメモリー"
 ],
 "Initialize": [
  null,
  "初期化"
 ],
 "Initialize disk $0": [
  null,
  "ディスク $0 を初期化します"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "初期化すると、ディスク上の全データが削除されます。"
 ],
 "Install": [
  null,
  "インストール"
 ],
 "Install NFS support": [
  null,
  "NFS サポートをインストールする"
 ],
 "Install Stratis support": [
  null,
  "Stratis サポートをインストールする"
 ],
 "Install software": [
  null,
  "ソフトウェアをインストール"
 ],
 "Installing $0": [
  null,
  "$0 をインストール中"
 ],
 "Installing $0 would remove $1.": [
  null,
  "$0 をインストールすると、$1 が削除されます。"
 ],
 "Installing packages": [
  null,
  "パッケージのインストール"
 ],
 "Invalid username or password": [
  null,
  "無効なユーザー名またはパスワード"
 ],
 "Jobs": [
  null,
  "ジョブ"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "タイプ不明のキースロットは、ここでは編集できません"
 ],
 "Key source": [
  null,
  "キーソース"
 ],
 "Keys": [
  null,
  "キー"
 ],
 "Keyserver": [
  null,
  "キーサーバー"
 ],
 "Keyserver address": [
  null,
  "キーサーバーのアドレス"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "キーサーバーの削除により、$0 のロック解除ができない可能性があります。"
 ],
 "LVM2 member": [
  null,
  "LVM2 メンバー"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 ボリュームグループ"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 ボリュームグループ $0"
 ],
 "Last modified: $0": [
  null,
  "最終更新日: $0"
 ],
 "Learn more": [
  null,
  "もっと詳しく"
 ],
 "Loading...": [
  null,
  "ロード中..."
 ],
 "Local mount point": [
  null,
  "ローカルマウントポイント"
 ],
 "Location": [
  null,
  "場所"
 ],
 "Lock": [
  null,
  "ロック"
 ],
 "Locked devices": [
  null,
  "ロックされたデバイス"
 ],
 "Locked encrypted Stratis pool": [
  null,
  "ロックされている暗号化 Stratis プール"
 ],
 "Locking $target": [
  null,
  "$target のロック中"
 ],
 "Logical": [
  null,
  "論理"
 ],
 "Logical size": [
  null,
  "論理サイズ"
 ],
 "Logical volume": [
  null,
  "論理ボリューム"
 ],
 "Logical volume (snapshot)": [
  null,
  "論理ボリューム (スナップショット)"
 ],
 "Logical volume of $0": [
  null,
  "$0 の論理ボリューム"
 ],
 "Logical volumes": [
  null,
  "論理ボリューム"
 ],
 "Make sure the key hash from the Tang server matches one of the following:": [
  null,
  "Tang サーバーのキーハッシュが、以下のいずれかと一致することを確認します:"
 ],
 "Managing LVMs": [
  null,
  "LVM の管理"
 ],
 "Managing NFS mounts": [
  null,
  "NFS マウントの管理"
 ],
 "Managing RAIDs": [
  null,
  "RAID の管理"
 ],
 "Managing VDOs": [
  null,
  "VDO の管理"
 ],
 "Managing partitions": [
  null,
  "パーティション管理"
 ],
 "Managing physical drives": [
  null,
  "物理ドライブの管理"
 ],
 "Manually check with SSH: ": [
  null,
  "手動で SSH を確認します: "
 ],
 "Marking $target as faulty": [
  null,
  "$target を問題があるものとしてマークする"
 ],
 "Metadata used": [
  null,
  "使用済みメタデータ"
 ],
 "Modifying $target": [
  null,
  "$target の変更"
 ],
 "Mount": [
  null,
  "マウント"
 ],
 "Mount also automatically on boot": [
  null,
  "起動時に自動的にもマウントします"
 ],
 "Mount at boot": [
  null,
  "起動時にマウント"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "起動時に自動的に $0 にマウントします"
 ],
 "Mount configuration": [
  null,
  "マウント設定"
 ],
 "Mount filesystem": [
  null,
  "ファイルシステムをマウントします"
 ],
 "Mount now": [
  null,
  "今すぐマウントします"
 ],
 "Mount on $0 now": [
  null,
  "$0 に今すぐマウントします"
 ],
 "Mount options": [
  null,
  "マウントオプション"
 ],
 "Mount point": [
  null,
  "マウントポイント"
 ],
 "Mount point cannot be empty": [
  null,
  "マウントポイントは空欄にできません"
 ],
 "Mount point cannot be empty.": [
  null,
  "マウントポイントは空欄にできません。"
 ],
 "Mount point is already used for $0": [
  null,
  "マウントポイントはすでに $0 で使用しています"
 ],
 "Mount point must start with \"/\".": [
  null,
  "マウントポイントは \"/\" で開始してください。"
 ],
 "Mount read only": [
  null,
  "読み取り専用でマウント"
 ],
 "Mounting $target": [
  null,
  "$target のマウント"
 ],
 "NFS mount": [
  null,
  "NFS マウント"
 ],
 "NFS mounts": [
  null,
  "NFS マウント"
 ],
 "NFS support not installed": [
  null,
  "NFS サポートはインストールされていません"
 ],
 "Name": [
  null,
  "名前"
 ],
 "Name can not be empty.": [
  null,
  "名前は空欄にできません。"
 ],
 "Name cannot be empty.": [
  null,
  "名前は空欄にすることができません。"
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "名前は、$0 バイトを超えることができません"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "名前は、$0 文字を超えることができません"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "名前は 127 文字を超えることができません。"
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "名前には文字 '$0' を含めることができません。"
 ],
 "Name cannot contain whitespace.": [
  null,
  "名前にはスペースを含めることができません。"
 ],
 "Never mount at boot": [
  null,
  "起動時のマウントなし"
 ],
 "New NFS mount": [
  null,
  "NFS の新規マウント"
 ],
 "New passphrase": [
  null,
  "新しいパスフレーズ"
 ],
 "Next": [
  null,
  "次へ"
 ],
 "No NFS mounts set up": [
  null,
  "NFS マウントが設定されていません"
 ],
 "No available slots": [
  null,
  "利用可能なスロットはありません"
 ],
 "No block devices are available.": [
  null,
  "ブロックデバイスは利用できません。"
 ],
 "No devices": [
  null,
  "デバイスがありません"
 ],
 "No disks are available.": [
  null,
  "ディスクが利用できません。"
 ],
 "No drives attached": [
  null,
  "ドライブが割り当てられていません"
 ],
 "No encryption": [
  null,
  "暗号化なし"
 ],
 "No filesystem": [
  null,
  "ファイルシステムなし"
 ],
 "No filesystems": [
  null,
  "ファイルシステムがありません"
 ],
 "No free key slots": [
  null,
  "フリーのキースロットはありません"
 ],
 "No free space": [
  null,
  "空き領域なし"
 ],
 "No iSCSI targets set up": [
  null,
  "iSCSI ターゲットが設定されていません"
 ],
 "No keys added": [
  null,
  "追加されたキーはありません"
 ],
 "No logical volumes": [
  null,
  "論理ボリュームなし"
 ],
 "No media inserted": [
  null,
  "メディアが挿入されていません"
 ],
 "No partitioning": [
  null,
  "パーティションなし"
 ],
 "Not enough space to grow.": [
  null,
  "スペースが不足しています。"
 ],
 "Not found": [
  null,
  "見つかりません"
 ],
 "Not mounted": [
  null,
  "マウントされていません"
 ],
 "Not running": [
  null,
  "実行中ではありません"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old passphrase": [
  null,
  "古いパスフレーズ"
 ],
 "Only $0 of $1 are used.": [
  null,
  "$1 のうち $0 だけが使用されています。"
 ],
 "Operation '$operation' on $target": [
  null,
  "$target 上の操作 '$operation'"
 ],
 "Options": [
  null,
  "オプション"
 ],
 "Other devices": [
  null,
  "他のデバイス"
 ],
 "Overwrite": [
  null,
  "上書き"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "既存のデータをゼロで上書き (低速)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit がクラッシュしました"
 ],
 "Partition": [
  null,
  "パーティション"
 ],
 "Partition of $0": [
  null,
  "$0 のパーティション"
 ],
 "Partitioned block device": [
  null,
  "パーティション設定されたブロックデバイス"
 ],
 "Partitioning": [
  null,
  "パーティション構成"
 ],
 "Partitions": [
  null,
  "パーティション"
 ],
 "Passphrase": [
  null,
  "パスフレーズ"
 ],
 "Passphrase can not be empty": [
  null,
  "パスフレーズは空欄にすることはできません"
 ],
 "Passphrase cannot be empty": [
  null,
  "パスフレーズは空欄にすることができません"
 ],
 "Passphrase from any other key slot": [
  null,
  "その他のキースロットのパスフレーズ"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "パスフレーズの削除で、$0 のロック解除ができない可能性があります。"
 ],
 "Passphrases do not match": [
  null,
  "パスフレーズが一致しません"
 ],
 "Password": [
  null,
  "パスワード"
 ],
 "Path on server": [
  null,
  "サーバーのパス"
 ],
 "Path on server cannot be empty.": [
  null,
  "サーバーのパスは空欄にはできません。"
 ],
 "Path on server must start with \"/\".": [
  null,
  "サーバーのパスは \"/\" で開始してください。"
 ],
 "Permanently delete $0?": [
  null,
  "$0 を永続的に削除しますか？"
 ],
 "Physical": [
  null,
  "物理"
 ],
 "Physical volumes": [
  null,
  "物理ボリューム"
 ],
 "Physical volumes can not be resized here.": [
  null,
  "ここでは、物理ボリュームのサイズを変更することができません。"
 ],
 "Pool": [
  null,
  "プール"
 ],
 "Pool for thin logical volumes": [
  null,
  "シン論理ボリューム用プール"
 ],
 "Pool for thin volumes": [
  null,
  "シンボリューム用プール"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "シンプロビジョニングされたボリューム用プール"
 ],
 "Port": [
  null,
  "ポート"
 ],
 "Processes using the location": [
  null,
  "ロケーションを使用するプロセス"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "このブロックデバイス上のプールのパスフレーズを指定します:"
 ],
 "Purpose": [
  null,
  "目的"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (ストライプ)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (ミラー)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (ミラーのストライプ)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (専用パリティー)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (分散パリティー)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (ダブル分散パリティー)"
 ],
 "RAID device": [
  null,
  "RAID デバイス"
 ],
 "RAID device $0": [
  null,
  "RAID デバイス $0"
 ],
 "RAID level": [
  null,
  "RAID レベル"
 ],
 "RAID member": [
  null,
  "RAID メンバー"
 ],
 "Reboot": [
  null,
  "再起動"
 ],
 "Recovering": [
  null,
  "復旧"
 ],
 "Recovering RAID device $target": [
  null,
  "RAID デバイス $target の復旧"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "関連するプロセスとサービスは強制的に停止されます。"
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "関連するプロセスは強制的に停止されます。"
 ],
 "Related services will be forcefully stopped.": [
  null,
  "関連するサービスは強制的に停止されます。"
 ],
 "Removals:": [
  null,
  "削除:"
 ],
 "Remove": [
  null,
  "削除"
 ],
 "Remove $0?": [
  null,
  "$0 を削除しますか?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Tang キーサーバーを削除しますか？"
 ],
 "Remove device": [
  null,
  "デバイスの削除"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "キースロットのパスフレーズ $0 を削除しますか？"
 ],
 "Removing $0": [
  null,
  "$0 を削除中"
 ],
 "Removing $target from RAID device": [
  null,
  "$target を RAID デバイスから削除"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "別のパスフレーズの確認なしでパスフレーズを削除すると、その他のパスフレーズを忘れたり、紛失した場合に、アンロックやキー管理ができなくなることがあります。"
 ],
 "Removing physical volume from $target": [
  null,
  "$target から物理ボリュームを削除"
 ],
 "Rename": [
  null,
  "名前変更"
 ],
 "Rename Stratis pool": [
  null,
  "Stratis プールの名前変更"
 ],
 "Rename filesystem": [
  null,
  "ファイルシステムの名前変更"
 ],
 "Rename logical volume": [
  null,
  "論理ボリュームの名前変更"
 ],
 "Rename volume group": [
  null,
  "ボリュームグループの名前変更"
 ],
 "Renaming $target": [
  null,
  "$target の名前変更"
 ],
 "Repairing $target": [
  null,
  "$target の修復"
 ],
 "Repeat passphrase": [
  null,
  "パスフレーズの繰り返し"
 ],
 "Resizing $target": [
  null,
  "$target のサイズ変更"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "暗号化されたファイルシステムのサイズ変更には、ディスクのロック解除が必要です。現在のディスクのパスフレーズを提供してください。"
 ],
 "Reuse existing encryption": [
  null,
  "既存の暗号化を再利用"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "既存の暗号化を再利用 ($0)"
 ],
 "Running": [
  null,
  "実行中"
 ],
 "Runtime": [
  null,
  "ランタイム"
 ],
 "SHA1": [
  null,
  "SHA1"
 ],
 "SHA256": [
  null,
  "SHA256"
 ],
 "SMART self-test of $target": [
  null,
  "$target の SMART 自己テスト"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "LZ4 で個別のブロックを圧縮して空き領域を節約します"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "同一のデータブロックを 1 回だけ保存することで、空き領域を節約します"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "新しいパスフレーズの保存には、ディスクのロック解除が必要です。現在のディスクのパスフレーズを提供してください。"
 ],
 "Securely erasing $target": [
  null,
  "$target を安全に削除"
 ],
 "Server": [
  null,
  "サーバー"
 ],
 "Server address": [
  null,
  "サーバーアドレス"
 ],
 "Server address cannot be empty.": [
  null,
  "サーバーアドレスは空欄にできません。"
 ],
 "Server cannot be empty.": [
  null,
  "サーバーは空欄にできません。"
 ],
 "Service": [
  null,
  "サービス"
 ],
 "Services using the location": [
  null,
  "ロケーションを使用するサービス"
 ],
 "Setting up loop device $target": [
  null,
  "ループデバイス $target の設定"
 ],
 "Show $0 device": [
  null,
  "$0 デバイスを表示します"
 ],
 "Show $0 drive": [
  null,
  "$0 ドライブを表示します"
 ],
 "Show all": [
  null,
  "すべて表示"
 ],
 "Shrink": [
  null,
  "縮小"
 ],
 "Shrink logical volume": [
  null,
  "論理ボリュームの縮小"
 ],
 "Shrink volume": [
  null,
  "ボリュームの縮小"
 ],
 "Size": [
  null,
  "サイズ"
 ],
 "Size cannot be negative": [
  null,
  "サイズはマイナスにすることができません"
 ],
 "Size cannot be zero": [
  null,
  "サイズはゼロにすることができません"
 ],
 "Size is too large": [
  null,
  "サイズが大きすぎます"
 ],
 "Size must be a number": [
  null,
  "サイズは数値である必要があります"
 ],
 "Size must be at least $0": [
  null,
  "サイズは $0 以上にする必要があります"
 ],
 "Slot $0": [
  null,
  "スロット $0"
 ],
 "Snapshot": [
  null,
  "スナップショット"
 ],
 "Source": [
  null,
  "ソース"
 ],
 "Spare": [
  null,
  "スペア"
 ],
 "Start": [
  null,
  "起動"
 ],
 "Start multipath": [
  null,
  "マルチパスの開始"
 ],
 "Starting RAID device $target": [
  null,
  "RAID デバイス $target の起動"
 ],
 "Starting swapspace $target": [
  null,
  "スワップ領域 $target の起動"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Stop and remove": [
  null,
  "停止して削除"
 ],
 "Stop and unmount": [
  null,
  "停止してアンマウント"
 ],
 "Stop device": [
  null,
  "デバイスの停止"
 ],
 "Stopping RAID device $target": [
  null,
  "RAID デバイス $target の停止"
 ],
 "Stopping swapspace $target": [
  null,
  "スワップ領域 $target の停止"
 ],
 "Storage": [
  null,
  "ストレージ"
 ],
 "Storage can not be managed on this system.": [
  null,
  "ストレージは、このシステムで管理できません。"
 ],
 "Storage logs": [
  null,
  "ストレージログ"
 ],
 "Store passphrase": [
  null,
  "パスフレーズの保存"
 ],
 "Stored passphrase": [
  null,
  "保存されたパスフレーズ"
 ],
 "Stratis member": [
  null,
  "Stratis メンバー"
 ],
 "Stratis pool": [
  null,
  "Stratis プール"
 ],
 "Stratis pool $0": [
  null,
  "Stratis プール $0"
 ],
 "Successfully copied to clipboard!": [
  null,
  "クリップボードへのコピーに成功しました！"
 ],
 "Support is installed.": [
  null,
  "サポートはインストールされました。"
 ],
 "Swap": [
  null,
  "スワップ"
 ],
 "Synchronizing RAID device $target": [
  null,
  "RAID デバイス $target の同期"
 ],
 "Tang keyserver": [
  null,
  "Tang キーサーバー"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Stratis デバイスを作成するために $0 パッケージをインストールする必要があります。"
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "$0 パッケージがインストールされ、VDO デバイスを作成します。"
 ],
 "The RAID array is in a degraded state": [
  null,
  "RAID アレイは劣化状態にあります"
 ],
 "The RAID device must be running in order to add spare disks.": [
  null,
  "スペアディスクを追加する場合は、RAID デバイスが実行中である必要があります。"
 ],
 "The RAID device must be running in order to remove disks.": [
  null,
  "ディスクを取り外す場合は、RAID デバイスが実行中である必要があります。"
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "この VDO デバイスの作成は終了していないため、使用できません。"
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "現在ログイン中のユーザーは、キーに関する情報を見ることを許可されていません。"
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "ディスクをフォーマットする前にロックを解除する必要があります。既存のパスフレーズを指定してください。"
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "ファイルシステムには永続的なマウントポイントがありません。"
 ],
 "The filesystem is already mounted at $0. Proceeding will unmount it.": [
  null,
  "ファイルシステムはすでに $0 にマウントされています。続行するとアンマウントされます。"
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "ファイルシステムは起動時に自動的にマウントされるように設定されていますが、その暗号化コンテナーはその時点ではアンロックされません。"
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "ファイルシステムは現在マウントされていますが、次回のブート後はマウントされません。"
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "ファイルシステムは現在 $0 にマウントされていますが、次回のブート時に $1 にマウントされます。"
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "ファイルシステムは現在 $0 にマウントされていますが、次回のブート後はマウントされません。"
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "ファイルシステムは現在マウントされていませんが、次回のブート時にマウントされます。"
 ],
 "The filesystem is not mounted.": [
  null,
  "ファイルシステムはマウントされていません。"
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "ファイルシステムはロック解除され、次回の起動時にマウントされます。パスフレーズの入力が必要になる場合があります。"
 ],
 "The last disk of a RAID device cannot be removed.": [
  null,
  "RAID デバイスの最後のディスクは取り外すことができません。"
 ],
 "The last key slot can not be removed": [
  null,
  "最後のキースロットは削除できません"
 ],
 "The last physical volume of a volume group cannot be removed.": [
  null,
  "ボリュームグループの最後の物理ボリュームは削除できません。"
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "一覧表示されたプロセスとサービスは強制的に停止されます。"
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "一覧表示されたプロセスは強制的に停止されます。"
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "一覧表示されたサービスは強制的に停止されます。"
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "マウントポイント $0 は、以下のプロセスにより使用されています:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "マウントポイント $0 は、以下のサービスにより使用されています:"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "システムに複数のパスを持つデバイスがありますが、マルチパスサービスが実行されていません。"
 ],
 "There is not enough free space elsewhere to remove this physical volume. At least $0 more free space is needed.": [
  null,
  "この物理ボリュームを削除するのに十分な空き領域がありません。少なくとも $0 の空き領域が必要です。"
 ],
 "These changes will be made:": [
  null,
  "以下の変更が行われます:"
 ],
 "Thin logical volume": [
  null,
  "シン論理ボリューム"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "この NFS マウントは使用中で、そのオプションだけを変更できます。"
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "この VDO デバイスは、そのバッキングデバイスをすべて使用していません。"
 ],
 "This device is currently in use.": [
  null,
  "このデバイスは現在使用されています。"
 ],
 "This disk cannot be removed while the device is recovering.": [
  null,
  "このディスクは、デバイスが復旧中に取り外すことができません。"
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "この論理ボリュームは、コンテンツによって完全には使用されていません。"
 ],
 "This pool can not be unlocked here because its key description is not in the expected format.": [
  null,
  "キーの説明が想定される形式ではないため、このプールはここでアンロックできません。"
 ],
 "This volume needs to be activated before it can be resized.": [
  null,
  "このボリュームは、サイズを変更する前にアクティベートする必要があります。"
 ],
 "Tier": [
  null,
  "階層"
 ],
 "Toggle": [
  null,
  "切り替え"
 ],
 "Toggle bitmap": [
  null,
  "ビットマップを切り替える"
 ],
 "Total size: $0": [
  null,
  "合計サイズ: $0"
 ],
 "Trust key": [
  null,
  "キーを信頼します"
 ],
 "Type": [
  null,
  "タイプ"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "サーバーに到達できません"
 ],
 "Unable to remove mount": [
  null,
  "マウントを削除できません"
 ],
 "Unable to unmount filesystem": [
  null,
  "ファイルシステムをアンマウントできません"
 ],
 "Unknown": [
  null,
  "不明"
 ],
 "Unknown ($0)": [
  null,
  "不明な ($0)"
 ],
 "Unknown host name": [
  null,
  "不明なホスト名"
 ],
 "Unknown type": [
  null,
  "不明なタイプ"
 ],
 "Unlock": [
  null,
  "ロック解除"
 ],
 "Unlock automatically on boot": [
  null,
  "システムの起動時に自動ロック解除"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "暗号化 Stratis プールのロック解除"
 ],
 "Unlock pool to see filesystems.": [
  null,
  "プールをアンロックしてファイルシステムを表示します。"
 ],
 "Unlocking $target": [
  null,
  "$target をロック解除中"
 ],
 "Unlocking disk": [
  null,
  "ディスクのロック解除"
 ],
 "Unmount": [
  null,
  "アンマウント"
 ],
 "Unmount filesystem $0": [
  null,
  "ファイルシステム $0 のアンマウント"
 ],
 "Unmount now": [
  null,
  "今すぐアンマウントします"
 ],
 "Unmounting $target": [
  null,
  "$target のアンマウント中"
 ],
 "Unrecognized data": [
  null,
  "認識されないデータ"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "ここでは、認識されないデータを小さくすることはできません。"
 ],
 "Unsupported volume": [
  null,
  "サポートされないボリューム"
 ],
 "Usage": [
  null,
  "使用率"
 ],
 "Usage of $0": [
  null,
  "$0 の使用率"
 ],
 "Use": [
  null,
  "使用"
 ],
 "Use compression": [
  null,
  "圧縮の使用"
 ],
 "Use deduplication": [
  null,
  "重複排除の使用"
 ],
 "Used": [
  null,
  "使用済み"
 ],
 "Used for": [
  null,
  "用途"
 ],
 "User": [
  null,
  "ユーザー"
 ],
 "Username": [
  null,
  "ユーザー名"
 ],
 "Using LUKS encryption": [
  null,
  "LUKS 暗号化の使用"
 ],
 "Using Tang server": [
  null,
  "Tang サーバーの使用"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO バッキングデバイスを小さくすることはできません"
 ],
 "VDO device": [
  null,
  "VDO デバイス"
 ],
 "VDO device $0": [
  null,
  "VDO デバイス $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO ファイルシステムボリューム (圧縮/重複排除)"
 ],
 "VDO pool": [
  null,
  "VDO プール"
 ],
 "Verify key": [
  null,
  "キーを検証します"
 ],
 "Very securely erasing $target": [
  null,
  "$target を非常に安全に削除"
 ],
 "View all logs": [
  null,
  "すべてのログの表示"
 ],
 "Volume": [
  null,
  "音量"
 ],
 "Volume group": [
  null,
  "ボリュームグループ"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "ボリュームサイズは $0 です。コンテンツサイズは $1 です。"
 ],
 "Waiting for other software management operations to finish": [
  null,
  "他のソフトウェア管理オペレーションが終了するまで待機中"
 ],
 "Write-mostly": [
  null,
  "Write-mostly"
 ],
 "Writing": [
  null,
  "書き込み"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[バイナリーデータの $0 バイト]"
 ],
 "[binary data]": [
  null,
  "[バイナリーデータ]"
 ],
 "[no data]": [
  null,
  "[データなし]"
 ],
 "backing device for VDO device": [
  null,
  "VDO デバイスのバッキングデバイス"
 ],
 "delete": [
  null,
  "削除"
 ],
 "disk": [
  null,
  "ディスク"
 ],
 "drive": [
  null,
  "ドライブ"
 ],
 "edit": [
  null,
  "編集"
 ],
 "encryption": [
  null,
  "暗号化"
 ],
 "filesystem": [
  null,
  "ファイルシステム"
 ],
 "format": [
  null,
  "フォーマット"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "grow": [
  null,
  "増加"
 ],
 "iSCSI targets": [
  null,
  "iSCSI ターゲット"
 ],
 "initialize": [
  null,
  "初期化"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "LUKS"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "member of RAID device": [
  null,
  "RAID デバイスのメンバー"
 ],
 "member of Stratis pool": [
  null,
  "Stratis プールのメンバー"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "マウント"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "never mounted at boot": [
  null,
  "起動時のマウントなし"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "none": [
  null,
  "なし"
 ],
 "partition": [
  null,
  "パーティション"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "LVM2 ボリュームグループの物理ボリューム"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "read only": [
  null,
  "読み取り専用"
 ],
 "remove from LVM2": [
  null,
  "LVM2 からの削除"
 ],
 "remove from RAID": [
  null,
  "RAID からの削除"
 ],
 "shrink": [
  null,
  "縮小"
 ],
 "stop": [
  null,
  "停止"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unknown target": [
  null,
  "不明なターゲット"
 ],
 "unmount": [
  null,
  "アンマウント"
 ],
 "unpartitioned space on $0": [
  null,
  "$0 の未パーティション領域"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "ボリューム"
 ],
 "yes": [
  null,
  "はい"
 ],
 "storage-id-desc\u0004$0 filesystem": [
  null,
  "$0 ファイルシステム"
 ],
 "storage-id-desc\u0004Filesystem (encrypted)": [
  null,
  "ファイルシステム (暗号化)"
 ],
 "storage-id-desc\u0004Locked encrypted data": [
  null,
  "ロックされた暗号化データ"
 ],
 "storage-id-desc\u0004Other data": [
  null,
  "他のデータ"
 ],
 "storage-id-desc\u0004Swap space": [
  null,
  "スワップ領域"
 ],
 "storage-id-desc\u0004Unrecognized data": [
  null,
  "認識されないデータ"
 ],
 "storage-id-desc\u0004VDO backing": [
  null,
  "VDO バッキング"
 ],
 "storage\u0004Assessment": [
  null,
  "評価"
 ],
 "storage\u0004Bitmap": [
  null,
  "ビットマップ"
 ],
 "storage\u0004Capacity": [
  null,
  "容量"
 ],
 "storage\u0004Device": [
  null,
  "デバイス"
 ],
 "storage\u0004Device file": [
  null,
  "デバイスファイル"
 ],
 "storage\u0004Firmware version": [
  null,
  "ファームウェアバージョン"
 ],
 "storage\u0004Model": [
  null,
  "モデル"
 ],
 "storage\u0004Multipathed devices": [
  null,
  "マルチパスデバイス"
 ],
 "storage\u0004Optical drive": [
  null,
  "光学ドライブ"
 ],
 "storage\u0004RAID level": [
  null,
  "RAID レベル"
 ],
 "storage\u0004Removable drive": [
  null,
  "リムーバブルドライブ"
 ],
 "storage\u0004Serial number": [
  null,
  "シリアルナンバー"
 ],
 "storage\u0004State": [
  null,
  "状態"
 ],
 "storage\u0004UUID": [
  null,
  "UUID"
 ],
 "storage\u0004Usage": [
  null,
  "使用率"
 ],
 "storage\u0004World wide name": [
  null,
  "World wide name"
 ],
 "format-bytes\u0004bytes": [
  null,
  "バイト"
 ]
});
