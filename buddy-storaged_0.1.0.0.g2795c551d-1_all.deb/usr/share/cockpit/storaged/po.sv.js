cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "sv",
  "language-direction": "ltr"
 },
 "$0 (encrypted)": [
  null,
  "$0 (krypterad)"
 ],
 "$0 Stratis pool": [
  null,
  "$0 Stratis-pool"
 ],
 "$0 block device": [
  null,
  "$0 blockenhet"
 ],
 "$0 cache": [
  null,
  "$0 cache"
 ],
 "$0 chunk size": [
  null,
  "$0 styckesstorlek"
 ],
 "$0 data": [
  null,
  "$0 data"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 data + $1 extra använt av $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagar"
 ],
 "$0 disk is missing": [
  null,
  "$0 disk saknas",
  "$0 diskar saknas"
 ],
 "$0 disks": [
  null,
  "$0 diskar"
 ],
 "$0 filesystems can not be made larger.": [
  null,
  "$0 filsystem kan inte göras större."
 ],
 "$0 filesystems can not be made smaller.": [
  null,
  "$0 filsystem kan inte göras mindre."
 ],
 "$0 filesystems can not be resized here.": [
  null,
  "$0 filsystem kan inte storleksändras här."
 ],
 "$0 hour": [
  null,
  "$0 timme",
  "$0 timmar"
 ],
 "$0 is in use": [
  null,
  "$0 används"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 är inte tillgängligt från något förråd."
 ],
 "$0 minute": [
  null,
  "$0 minut",
  "$0 minuter"
 ],
 "$0 month": [
  null,
  "$0 månad",
  "$0 månader"
 ],
 "$0 of unknown tier": [
  null,
  "$0 av okänd nivå"
 ],
 "$0 slot remains": [
  null,
  "$0 fack återstår",
  "$0 fack återstår"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 använt av $1 ($2 sparat)"
 ],
 "$0 week": [
  null,
  "$0 vecka",
  "$0 veckor"
 ],
 "$0 will be installed.": [
  null,
  "$0 kommer att installeras."
 ],
 "$0 year": [
  null,
  "$0 år",
  "$0 år"
 ],
 "$0, $1 free": [
  null,
  "$0, $1 fritt"
 ],
 "$name (from $host)": [
  null,
  "$name (från $host)"
 ],
 "(recommended)": [
  null,
  "(rekommenderad)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 timme"
 ],
 "1 week": [
  null,
  "1 vecka"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "5 minutes": [
  null,
  "5 minuter"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 timmar"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Ett filsystem med detta namn existerar redan i denna pool."
 ],
 "A pool with this name exists already.": [
  null,
  "En pool med detta namn finns redan."
 ],
 "A spare disk needs to be added first before this disk can be removed.": [
  null,
  "En reservdisk behöver läggas till först före denna disk kan tas bort."
 ],
 "Action": [
  null,
  "Åtgärd"
 ],
 "Activate": [
  null,
  "Aktivera"
 ],
 "Activating $target": [
  null,
  "Aktivera $target"
 ],
 "Add": [
  null,
  "Lägg till"
 ],
 "Add block devices": [
  null,
  "Lägg till blockenheter"
 ],
 "Add disks": [
  null,
  "Lägg till diskar"
 ],
 "Add iSCSI portal": [
  null,
  "Lägg till iSCSI-portal"
 ],
 "Add key": [
  null,
  "Lägg till nyckel"
 ],
 "Adding physical volume to $target": [
  null,
  "Lägger till fysisk volym till $target"
 ],
 "Additional packages:": [
  null,
  "Ytterligare paket:"
 ],
 "Address": [
  null,
  "Adress"
 ],
 "Address cannot be empty": [
  null,
  "Adressen kan inte vara tom"
 ],
 "Address is not a valid URL": [
  null,
  "Adressen är inte en giltig URL"
 ],
 "At least $0 disk is needed.": [
  null,
  "Åtminstone $0 disk behövs.",
  "Åtminstone $0 diskar behövs."
 ],
 "At least one block device is needed.": [
  null,
  "Åtminstone en blockenhet behövs."
 ],
 "At least one disk is needed.": [
  null,
  "Åtminstone en disk behövs."
 ],
 "Authentication required": [
  null,
  "Autentisering krävs"
 ],
 "Available targets on $0": [
  null,
  "Tillgängliga mål på $0"
 ],
 "Backing device": [
  null,
  "Bakomliggande enhet"
 ],
 "Block": [
  null,
  "Block"
 ],
 "Block device for filesystems": [
  null,
  "Blockenhet för filsystem"
 ],
 "Block devices": [
  null,
  "Blockenheter"
 ],
 "Blocked": [
  null,
  "Blockerat"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Avbryt"
 ],
 "Change": [
  null,
  "Ändra"
 ],
 "Change iSCSI initiator name": [
  null,
  "Ändra iSCSI-initierarnamn"
 ],
 "Change passphrase": [
  null,
  "Ändra lösenfras"
 ],
 "Checking $target": [
  null,
  "Kontrollerar $target"
 ],
 "Checking RAID device $target": [
  null,
  "Kontrollerar RAID-enhet $target"
 ],
 "Checking and repairing RAID device $target": [
  null,
  "Kontrollerar och reparerar RAID-enhet $target"
 ],
 "Checking installed software": [
  null,
  "Kontrollerar installerad programvara"
 ],
 "Checking related processes": [
  null,
  "Kontrollerar relaterade processer"
 ],
 "Chunk size": [
  null,
  "Styckesstorlek"
 ],
 "Cleaning up for $target": [
  null,
  "Rensar upp för $target"
 ],
 "Cleartext device": [
  null,
  "Klar text enhet"
 ],
 "Close": [
  null,
  "Stäng"
 ],
 "Command": [
  null,
  "Kommando"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Kompatibel med alla system och enheter (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Kompatibel med moderna system och hårddiskar > 2 TB (GPT)"
 ],
 "Compression": [
  null,
  "Komprimering"
 ],
 "Confirm": [
  null,
  "Bekräfta"
 ],
 "Confirm deletion of $0": [
  null,
  "Bekräfta raderingen av $0"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Bekräfta borttagandet med en alternativ lösenfras"
 ],
 "Confirm stopping of $0": [
  null,
  "Bekräfta stoppandet av $0"
 ],
 "Content": [
  null,
  "Innehåll"
 ],
 "Copy to clipboard": [
  null,
  "Kopiera till urklipp"
 ],
 "Create": [
  null,
  "Skapa"
 ],
 "Create LVM2 volume group": [
  null,
  "Skapa LVM2 volymgrupp"
 ],
 "Create RAID device": [
  null,
  "Skapa en RAID-enhet"
 ],
 "Create Stratis pool": [
  null,
  "Skapa Stratis lagringspool"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Skapa en ögonblicksbild av filsystem $0"
 ],
 "Create devices": [
  null,
  "Skapa enheter"
 ],
 "Create filesystem": [
  null,
  "Skapa filsystem"
 ],
 "Create logical volume": [
  null,
  "Skapa en logisk volym"
 ],
 "Create new filesystem": [
  null,
  "Skapa nytt filsystem"
 ],
 "Create new logical volume": [
  null,
  "Skapa en ny logisk volym"
 ],
 "Create partition": [
  null,
  "Skapa en partition"
 ],
 "Create partition on $0": [
  null,
  "Skapa partition på $0"
 ],
 "Create partition table": [
  null,
  "Skapa partitionstabell"
 ],
 "Create snapshot": [
  null,
  "Skapa en ögonblicksbild"
 ],
 "Create thin volume": [
  null,
  "Skapa en tunn volym"
 ],
 "Create volume group": [
  null,
  "Skapa en volymgrupp"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Skapar LVM2 volymgrupp $target"
 ],
 "Creating RAID device $target": [
  null,
  "Skapar en RAID-enhet $target"
 ],
 "Creating VDO device": [
  null,
  "Skapar VDO-enhet"
 ],
 "Creating filesystem on $target": [
  null,
  "Skapar ett filsystem på $target"
 ],
 "Creating logical volume $target": [
  null,
  "Skapar en logisk volym på $target"
 ],
 "Creating partition $target": [
  null,
  "Skapar en partition på $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Skapar en ögonblicksbild av $target"
 ],
 "Currently in use": [
  null,
  "Används just nu"
 ],
 "Custom mount options": [
  null,
  "Anpassade monteringsalternativ"
 ],
 "Data": [
  null,
  "Data"
 ],
 "Data used": [
  null,
  "Data använt"
 ],
 "Deactivate": [
  null,
  "Avaktivera"
 ],
 "Deactivating $target": [
  null,
  "Avaktiverar $target"
 ],
 "Deduplication": [
  null,
  "Avduplicering"
 ],
 "Delete": [
  null,
  "Ta bort"
 ],
 "Deleting $target": [
  null,
  "Tar bort $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Tar bort LVM2 volymgruppen $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Om du tar bort en Stratis-pool raderas all data som den innehåller."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Att ta bort ett filsystem kommer att ta bort all data i det."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Att ta bort en logisk volym kommer att ta bort all data i den."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Att ta bort en partition kommer att ta bort all data i den."
 ],
 "Deleting erases all data on a RAID device.": [
  null,
  "Om du raderar raderas all data på en RAID-enhet."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Radering raderar all data på en VDO-enhet."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Om du raderar raderas all data i en volymgrupp."
 ],
 "Description": [
  null,
  "Beskrivning"
 ],
 "Device": [
  null,
  "Enhet"
 ],
 "Device file": [
  null,
  "Enhetsfil"
 ],
 "Device is read-only": [
  null,
  "Enheten är skrivskyddad"
 ],
 "Devices": [
  null,
  "Enheter"
 ],
 "Disk is OK": [
  null,
  "Disken är OK"
 ],
 "Disk is failing": [
  null,
  "Disken är på väg att gå sönder"
 ],
 "Disk passphrase": [
  null,
  "Disklösenfras"
 ],
 "Disks": [
  null,
  "Diskar"
 ],
 "Do not mount automatically on boot": [
  null,
  "Montera inte automatiskt vid start"
 ],
 "Downloading $0": [
  null,
  "Hämtar $0"
 ],
 "Drive": [
  null,
  "Enhet"
 ],
 "Drives": [
  null,
  "Enheter"
 ],
 "Edit": [
  null,
  "Redigera"
 ],
 "Edit Tang keyserver": [
  null,
  "Redigera Tang-nyckelserver"
 ],
 "Editing a key requires a free slot": [
  null,
  "Att redigera en nyckel kräver ett fritt fack"
 ],
 "Ejecting $target": [
  null,
  "Matar ut $target"
 ],
 "Emptying $target": [
  null,
  "Tömmer $target"
 ],
 "Encrypt data": [
  null,
  "Kryptera data"
 ],
 "Encrypted $0": [
  null,
  "Krypterad $0"
 ],
 "Encrypted Stratis pool $0": [
  null,
  "Krypterad Stratis pool $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Krypterad logisk volym av $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Krypterad partition av $0"
 ],
 "Encrypted volumes can not be resized here.": [
  null,
  "Storleken på krypterade volymer kan inte ändras här."
 ],
 "Encrypted volumes need to be unlocked before they can be resized.": [
  null,
  "Krypterade volymer behöver låsas upp innan deras storlek kan ändras."
 ],
 "Encryption": [
  null,
  "Kryptering"
 ],
 "Encryption options": [
  null,
  "Krypteringsalternativ"
 ],
 "Encryption type": [
  null,
  "Krypteringstyp"
 ],
 "Erasing $target": [
  null,
  "Raderar $target"
 ],
 "Error": [
  null,
  "Fel"
 ],
 "Extended partition": [
  null,
  "Utökad partition"
 ],
 "Failed": [
  null,
  "Misslyckades"
 ],
 "Filesystem": [
  null,
  "Filsystem"
 ],
 "Filesystem is locked": [
  null,
  "Filsystem är låst"
 ],
 "Filesystem name": [
  null,
  "Filsystemsnamn"
 ],
 "Filesystems": [
  null,
  "Filsystem"
 ],
 "Format": [
  null,
  "Formatera"
 ],
 "Format $0": [
  null,
  "Formatera $0"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Formatering raderar all data på en lagringsenhet."
 ],
 "Free": [
  null,
  "Ledigt"
 ],
 "Free space": [
  null,
  "Ledigt utrymme"
 ],
 "Free up space in this group: Shrink or delete other logical volumes or add another physical volume.": [
  null,
  "Frigör utrymme i denna grupp: krymp eller radera andra logiska volymer eller lägg till en ytterligare fysisk volym."
 ],
 "Go to now": [
  null,
  "Gå till nu"
 ],
 "Grow": [
  null,
  "Utöka"
 ],
 "Grow content": [
  null,
  "Utöka innehållet"
 ],
 "Grow logical size of $0": [
  null,
  "Utöka den logiska storleken av $0"
 ],
 "Grow logical volume": [
  null,
  "Utöka en logisk volym"
 ],
 "Grow to take all space": [
  null,
  "Utöka till att ta allt utrymme"
 ],
 "If this option is checked, the filesystem will not be mounted during the next boot even if it was mounted before it.  This is useful if mounting during boot is not possible, such as when a passphrase is required to unlock the filesystem but booting is unattended.": [
  null,
  "Om det här alternativet är markerat kommer filsystemet inte att monteras under nästa uppstart även om det monterades innan det. Detta är användbart om montering under uppstart inte är möjlig, till exempel när en lösenordsfras krävs för att låsa upp filsystemet men uppstart är obevakad."
 ],
 "In sync": [
  null,
  "I synk"
 ],
 "Inactive volume": [
  null,
  "Inaktiv volym"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Felaktig monteringsinformation"
 ],
 "Index memory": [
  null,
  "Indexminne"
 ],
 "Initialize": [
  null,
  "Initierar"
 ],
 "Initialize disk $0": [
  null,
  "Initierar disk $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Initiering raderar all data på en disk."
 ],
 "Install": [
  null,
  "Installera"
 ],
 "Install NFS support": [
  null,
  "Installera stöd för NFS"
 ],
 "Install Stratis support": [
  null,
  "Installera Stratis stöd"
 ],
 "Install software": [
  null,
  "Installera programvara"
 ],
 "Installing $0": [
  null,
  "Installerar $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "Att installera $0 skulle ta bort $1."
 ],
 "Installing packages": [
  null,
  "Installerar paket"
 ],
 "Invalid username or password": [
  null,
  "Felaktigt användarnamn eller lösenord"
 ],
 "Jobs": [
  null,
  "Jobb"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Nyckelfack med okända typer kan inte redigeras här"
 ],
 "Key source": [
  null,
  "Nyckelkälla"
 ],
 "Keys": [
  null,
  "Nycklar"
 ],
 "Keyserver": [
  null,
  "Nyckelserver"
 ],
 "Keyserver address": [
  null,
  "Nyckelserverns adress"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Att ta bort nyckelservern kan förhindra upplåsning av $0."
 ],
 "LVM2 member": [
  null,
  "LVM2-medlem"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 Volymgrupp"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 Volymgrupp $0"
 ],
 "Last modified: $0": [
  null,
  "Senast ändrad: $0"
 ],
 "Learn more": [
  null,
  "Mer information"
 ],
 "Loading...": [
  null,
  "Läser in …"
 ],
 "Local mount point": [
  null,
  "Lokal monteringspunkt"
 ],
 "Location": [
  null,
  "Plats"
 ],
 "Lock": [
  null,
  "Lås"
 ],
 "Locked devices": [
  null,
  "Låsta enheter"
 ],
 "Locked encrypted Stratis pool": [
  null,
  "Låst krypterad Stratis pool"
 ],
 "Locking $target": [
  null,
  "Låser $target"
 ],
 "Logical": [
  null,
  "Logisk"
 ],
 "Logical size": [
  null,
  "Logisk storlek"
 ],
 "Logical volume": [
  null,
  "Logisk volym"
 ],
 "Logical volume (snapshot)": [
  null,
  "Logisk volym (ögonblicksbild)"
 ],
 "Logical volume of $0": [
  null,
  "Logisk volym av $0"
 ],
 "Logical volumes": [
  null,
  "Logiska volymer"
 ],
 "Make sure the key hash from the Tang server matches one of the following:": [
  null,
  "Se till att kontrollsumman för nyckeln från Tang-servern matchar något av följande:"
 ],
 "Managing LVMs": [
  null,
  "Hantera LVM:er"
 ],
 "Managing NFS mounts": [
  null,
  "Hantera NFS-monteringar"
 ],
 "Managing RAIDs": [
  null,
  "Hantera RAID:ar"
 ],
 "Managing VDOs": [
  null,
  "Hantera VDO:er"
 ],
 "Managing partitions": [
  null,
  "Hantera partitioner"
 ],
 "Managing physical drives": [
  null,
  "Hantera fysiska diskar"
 ],
 "Manually check with SSH: ": [
  null,
  "Kontrollera manuellt med SSH: "
 ],
 "Marking $target as faulty": [
  null,
  "Markerar $target som felaktig"
 ],
 "Metadata used": [
  null,
  "Metadata använt"
 ],
 "Modifying $target": [
  null,
  "Modifiera $target"
 ],
 "Mount": [
  null,
  "Montering"
 ],
 "Mount also automatically on boot": [
  null,
  "Montera också automatiskt vid start"
 ],
 "Mount at boot": [
  null,
  "Montera vid uppstart"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Montera automatiskt på $0 vid start"
 ],
 "Mount configuration": [
  null,
  "Inställningar för monteringspunkter"
 ],
 "Mount filesystem": [
  null,
  "Montera filsystem"
 ],
 "Mount now": [
  null,
  "Montera nu"
 ],
 "Mount on $0 now": [
  null,
  "Montera på $0 nu"
 ],
 "Mount options": [
  null,
  "Monteringsflaggor"
 ],
 "Mount point": [
  null,
  "Monteringspunkt"
 ],
 "Mount point cannot be empty": [
  null,
  "Monteringspunkten kan inte vara tom"
 ],
 "Mount point cannot be empty.": [
  null,
  "Monteringspunkten får inte vara tom."
 ],
 "Mount point is already used for $0": [
  null,
  "Monteringspunkten är redan i användning för $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Monteringspunkten måste börja med ”/”."
 ],
 "Mount read only": [
  null,
  "Montera skrivskyddat"
 ],
 "Mounting $target": [
  null,
  "Monterar $target"
 ],
 "NFS mount": [
  null,
  "NFS-montering"
 ],
 "NFS mounts": [
  null,
  "NFS-monteringar"
 ],
 "NFS support not installed": [
  null,
  "Stöd för NFS är inte installerat"
 ],
 "Name": [
  null,
  "Namn"
 ],
 "Name can not be empty.": [
  null,
  "Namnet får inte vara tomt."
 ],
 "Name cannot be empty.": [
  null,
  "Namnet får inte vara tomt."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Namnet får inte vara längre än $0 byte"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Namnet får inte vara längre än $0 tecken"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Namnet får inte vara längre än 127 tecken."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Namnet får inte innehålla tecknet ”$0”."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Namnet får inte innehålla blanktecken."
 ],
 "Never mount at boot": [
  null,
  "Montera aldrig vid uppstart"
 ],
 "New NFS mount": [
  null,
  "Ny NFS-montering"
 ],
 "New passphrase": [
  null,
  "Ny lösenfras"
 ],
 "Next": [
  null,
  "Nästa"
 ],
 "No NFS mounts set up": [
  null,
  "Inga NFS-monteringar uppsatta"
 ],
 "No available slots": [
  null,
  "Inga tillgängliga fack"
 ],
 "No block devices are available.": [
  null,
  "Inga block enheter är tillgängliga."
 ],
 "No devices": [
  null,
  "Inga enheter"
 ],
 "No disks are available.": [
  null,
  "Inga diskar är tillgängliga."
 ],
 "No drives attached": [
  null,
  "Inga diskar är anslutna"
 ],
 "No encryption": [
  null,
  "Ingen kryptering"
 ],
 "No filesystem": [
  null,
  "Inget filsystem"
 ],
 "No filesystems": [
  null,
  "Inga filsystem"
 ],
 "No free key slots": [
  null,
  "Inga fria nyckelfack"
 ],
 "No free space": [
  null,
  "Inget ledigt utrymme"
 ],
 "No iSCSI targets set up": [
  null,
  "Inga iSCSI-mål är uppsatta"
 ],
 "No keys added": [
  null,
  "Inga nycklar tillagda"
 ],
 "No logical volumes": [
  null,
  "Inga logiska volymer"
 ],
 "No media inserted": [
  null,
  "Inget medium isatt"
 ],
 "No partitioning": [
  null,
  "Ingen partitionering"
 ],
 "Not enough space to grow.": [
  null,
  "Inte tillräckligt med utrymme för att växa."
 ],
 "Not found": [
  null,
  "Finns inte"
 ],
 "Not mounted": [
  null,
  "Inte monterat"
 ],
 "Not running": [
  null,
  "Kör inte"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old passphrase": [
  null,
  "Gammal lösenfras"
 ],
 "Only $0 of $1 are used.": [
  null,
  "Endast $0 av $1 används."
 ],
 "Operation '$operation' on $target": [
  null,
  "Åtgärden ”$operation” på $target"
 ],
 "Options": [
  null,
  "Alternativ"
 ],
 "Other devices": [
  null,
  "Andra enheter"
 ],
 "Overwrite": [
  null,
  "Skriv över"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Skriv över befintlig data med nollor (långsammare)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit kraschade"
 ],
 "Partition": [
  null,
  "Partition"
 ],
 "Partition of $0": [
  null,
  "Partition av $0"
 ],
 "Partitioned block device": [
  null,
  "Partitionerad blockenhet"
 ],
 "Partitioning": [
  null,
  "Partitionering"
 ],
 "Partitions": [
  null,
  "Partitioner"
 ],
 "Passphrase": [
  null,
  "Lösenfras"
 ],
 "Passphrase can not be empty": [
  null,
  "Lösenfrasen kan inte vara tom"
 ],
 "Passphrase cannot be empty": [
  null,
  "Lösenfrasen får inte vara tom"
 ],
 "Passphrase from any other key slot": [
  null,
  "Lösenfrasen från vilket annat nyckelfack som helst"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Att ta bort lösenfrasen kan förhindra upplåsning av $0."
 ],
 "Passphrases do not match": [
  null,
  "Lösenfraserna stämmer inte överens"
 ],
 "Password": [
  null,
  "Lösenord"
 ],
 "Path on server": [
  null,
  "Sökväg på servern"
 ],
 "Path on server cannot be empty.": [
  null,
  "Sökvägen på servern får inte vara tom."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Sökvägen på servern måste börja med ”/”."
 ],
 "Permanently delete $0?": [
  null,
  "Permanent ta bort $0?"
 ],
 "Physical": [
  null,
  "Fysiskt"
 ],
 "Physical volumes": [
  null,
  "Fysiska volymer"
 ],
 "Physical volumes can not be resized here.": [
  null,
  "Storleken på fysiska volymer kan inte ändras här."
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool för tunna logiska volymer"
 ],
 "Pool for thin volumes": [
  null,
  "Pool för tunna volymer"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool för tunt underhållna volymer"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Processes using the location": [
  null,
  "Processer som använder platsen"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Ange lösenordsfrasen för poolen på dessa blockenheter:"
 ],
 "Purpose": [
  null,
  "Syfte"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Strimlor)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Spegel)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (Strimlor av speglar)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (dedikerad paritet)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (distribuerad paritet)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (dubbel distribuerad paritet)"
 ],
 "RAID device": [
  null,
  "RAID-enhet"
 ],
 "RAID device $0": [
  null,
  "RAID-enhet $0"
 ],
 "RAID level": [
  null,
  "RAID-nivå"
 ],
 "RAID member": [
  null,
  "RAID-medlem"
 ],
 "Reboot": [
  null,
  "Starta om"
 ],
 "Recovering": [
  null,
  "Återställer"
 ],
 "Recovering RAID device $target": [
  null,
  "Återställer RAID-enhet $target"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Relaterade processer och tjänster kommer tvingas stoppa."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Relaterade processer kommer tvingas stoppa."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Relaterade tjänster kommer tvingas stoppa."
 ],
 "Removals:": [
  null,
  "Borttagningar:"
 ],
 "Remove": [
  null,
  "Ta bort"
 ],
 "Remove $0?": [
  null,
  "Ta bort $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Ta bort Tang-nyckelserver?"
 ],
 "Remove device": [
  null,
  "Ta bort enhet"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Ta bort lösenfrasen i nyckelfack $0?"
 ],
 "Removing $0": [
  null,
  "Tar bort $0"
 ],
 "Removing $target from RAID device": [
  null,
  "Tar bort $target från RAID-enheten"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Att ta bort en lösenfras utan bekräftelse av en annan lösenfras kan förhindra upplåsning eller nyckelhantering, om andra lösenfraser glöms bort eller går förlorade."
 ],
 "Removing physical volume from $target": [
  null,
  "Tar bort den fysiska volymen från $target"
 ],
 "Rename": [
  null,
  "Byt namn"
 ],
 "Rename Stratis pool": [
  null,
  "Byt namn på Stratis pool"
 ],
 "Rename filesystem": [
  null,
  "Byt namn på filsystem"
 ],
 "Rename logical volume": [
  null,
  "Byt namn på en logisk volym"
 ],
 "Rename volume group": [
  null,
  "Byt namn på en volymgrupp"
 ],
 "Renaming $target": [
  null,
  "Byter namn på $target"
 ],
 "Repairing $target": [
  null,
  "Reparerar $target"
 ],
 "Repeat passphrase": [
  null,
  "Upprepa lösenfrasen"
 ],
 "Resizing $target": [
  null,
  "Ändrar storlek på $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Ändra storlek på ett krypterat filsystem kräver upplåsning av disken. Ange en aktuell disklösenfras."
 ],
 "Reuse existing encryption": [
  null,
  "Återanvänd befintlig kryptering"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Återanvänd befintlig kryptering ($0)"
 ],
 "Running": [
  null,
  "Kör"
 ],
 "Runtime": [
  null,
  "Körtillfälle"
 ],
 "SHA1": [
  null,
  "SHA1"
 ],
 "SHA256": [
  null,
  "SHA256"
 ],
 "SMART self-test of $target": [
  null,
  "SMART-självtest av $target"
 ],
 "Save": [
  null,
  "Spara"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Spara utrymme genom att komprimera enskilda block med LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Spara utrymme genom att lagra identiska datablock bara en gång"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Att spara en ny lösenfras kräver att disken låses upp. Ge en aktuell disklösenfras."
 ],
 "Securely erasing $target": [
  null,
  "Raderar säkert $target"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server address": [
  null,
  "Serveradress"
 ],
 "Server address cannot be empty.": [
  null,
  "Serveradressen får inte vara tom."
 ],
 "Server cannot be empty.": [
  null,
  "Servern får inte vara tom."
 ],
 "Service": [
  null,
  "Tjänst"
 ],
 "Services using the location": [
  null,
  "Tjänster som använder platsen"
 ],
 "Setting up loop device $target": [
  null,
  "Sätter upp vändslingeenheten $target"
 ],
 "Show $0 device": [
  null,
  "Visa $0 enhet",
  "Visa alla $0 enheter"
 ],
 "Show $0 drive": [
  null,
  "Visa $0 disk",
  "Visa alla $0 diskar"
 ],
 "Show all": [
  null,
  "Visa alla"
 ],
 "Shrink": [
  null,
  "Krymp"
 ],
 "Shrink logical volume": [
  null,
  "Krymp en logisk volym"
 ],
 "Shrink volume": [
  null,
  "Krymp volym"
 ],
 "Size": [
  null,
  "Storlek"
 ],
 "Size cannot be negative": [
  null,
  "Storleken kan inte vara negativ"
 ],
 "Size cannot be zero": [
  null,
  "Storleken kan inte vara noll"
 ],
 "Size is too large": [
  null,
  "Storleken är för stor"
 ],
 "Size must be a number": [
  null,
  "Storleken måste vara ett tal"
 ],
 "Size must be at least $0": [
  null,
  "Storleken måste vara åtminstone $0"
 ],
 "Slot $0": [
  null,
  "Plats $0"
 ],
 "Snapshot": [
  null,
  "Ögonblicksbild"
 ],
 "Source": [
  null,
  "Källa"
 ],
 "Spare": [
  null,
  "Reserv"
 ],
 "Start": [
  null,
  "Starta"
 ],
 "Start multipath": [
  null,
  "Starta multipath"
 ],
 "Starting RAID device $target": [
  null,
  "Starta RAID-enhet $target"
 ],
 "Starting swapspace $target": [
  null,
  "Starta växlingsutrymmet $target"
 ],
 "Stop": [
  null,
  "Stoppa"
 ],
 "Stop and remove": [
  null,
  "Stoppa och ta bort"
 ],
 "Stop and unmount": [
  null,
  "Stoppa och avmontera"
 ],
 "Stop device": [
  null,
  "Stoppa enhet"
 ],
 "Stopping RAID device $target": [
  null,
  "Stoppar RAID-enhet $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Stoppar växlingsutrymmet $target"
 ],
 "Storage": [
  null,
  "Lagring"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Lagring kan inte hanteras på detta system."
 ],
 "Storage logs": [
  null,
  "Lagringsloggar"
 ],
 "Store passphrase": [
  null,
  "Lagra lösenfrasen"
 ],
 "Stored passphrase": [
  null,
  "Lagrad lösenfras"
 ],
 "Stratis member": [
  null,
  "Stratis medlem"
 ],
 "Stratis pool": [
  null,
  "Stratis-pool"
 ],
 "Stratis pool $0": [
  null,
  "Stratis-pool $0"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Kopierade till urklipp!"
 ],
 "Support is installed.": [
  null,
  "Stöd är installerat."
 ],
 "Swap": [
  null,
  "Växlingsutrymme"
 ],
 "Synchronizing RAID device $target": [
  null,
  "Synkroniserar RAID-enheten $target"
 ],
 "Tang keyserver": [
  null,
  "Tang-nyckelserver"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Paketet $0 måste installeras för att skapa Stratis-pooler."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Paketet $0 kommer att installeras för att skapa VDO-enheter."
 ],
 "The RAID array is in a degraded state": [
  null,
  "RAID-vektor är i ett nedsatt tillstånd"
 ],
 "The RAID device must be running in order to add spare disks.": [
  null,
  "RAID-enheten måste köra för att kunna lägga till reservdiskar."
 ],
 "The RAID device must be running in order to remove disks.": [
  null,
  "RAID-enheten måste köra för att kunna ta bort diskar."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Skapandet av denna VDO-enhet avslutade inte och enheten kan inte användas."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Användaren som för närvarande är inloggad har inte tillstånd att se information om nycklar."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "Disken måste låsas upp innan formatering. Ange en befintlig lösenfras."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Filsystemet har ingen permanent monteringspunkt."
 ],
 "The filesystem is already mounted at $0. Proceeding will unmount it.": [
  null,
  "Filsystemet är redan monterat på $0. Om du fortsätter avmonteras det."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Filsystemet är konfigurerat att monteras automatiskt vid uppstart men dess krypteringsbehållare kommer inte att låsas upp vid den tidpunkten."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Filsystemet är för närvarande monterat men kommer inte att monteras efter nästa uppstart."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Filsystemet är för närvarande monterat på $0 men kommer att monteras på $1 vid nästa uppstart."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Filsystemet är för närvarande monterat på $0 men kommer inte att monteras efter nästa uppstart."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Filsystemet är för närvarande inte monterat men kommer att monteras vid nästa uppstart."
 ],
 "The filesystem is not mounted.": [
  null,
  "Filsystemet är inte monterat."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Filsystemet kommer att låsas upp och monteras vid nästa uppstart. Detta kan kräva att du matar in en lösenfras."
 ],
 "The last disk of a RAID device cannot be removed.": [
  null,
  "Den sista disken i en RAID-enhet kan inte tas bort."
 ],
 "The last key slot can not be removed": [
  null,
  "Det sista nyckelfacket kan inte tas bort"
 ],
 "The last physical volume of a volume group cannot be removed.": [
  null,
  "Den sista fysiska volymen i en volymgrupp kan inte tas bort."
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "De listade processerna och tjänsterna kommer tvingas stoppa."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "De listade processerna kommer att tvingas stoppa."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "De listade tjänsterna kommer att tvingas stoppa."
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Monteringspunkten $0 används av dessa processer:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Monteringspunkten $0 används av dessa tjänster:"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Det finns enheter med flera sökvägar på systemet, men multipath-tjänsten kör inte."
 ],
 "There is not enough free space elsewhere to remove this physical volume. At least $0 more free space is needed.": [
  null,
  "Det finns inte tillräckligt med fritt utrymme någon annanstans för att ta bort denna fysiska volym. Åtminstone $0 mer ledigt utrymme behövs."
 ],
 "These changes will be made:": [
  null,
  "Dessa ändringar kommer att göras:"
 ],
 "Thin logical volume": [
  null,
  "Tunn logisk volym"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Denna NFS-montering används och endast dess alternativ kan ändras."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Denna VDO-enhet använder inte alla sina underliggande enheter."
 ],
 "This device is currently in use.": [
  null,
  "Den här enheten används för närvarande."
 ],
 "This disk cannot be removed while the device is recovering.": [
  null,
  "Denna disk kan inte tas bort medan enheten återhämtar sig."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Denna logiska volym används inte helt av innehållet."
 ],
 "This pool can not be unlocked here because its key description is not in the expected format.": [
  null,
  "Denna pool kan inte låsas upp här eftersom dess nyckelbeskrivning inte är i det förväntade formatet."
 ],
 "This volume needs to be activated before it can be resized.": [
  null,
  "Denna volym behöver aktiveras före dess storlek kan ändras."
 ],
 "Tier": [
  null,
  "Nivå"
 ],
 "Toggle": [
  null,
  "Växla"
 ],
 "Toggle bitmap": [
  null,
  "Växla bitmap"
 ],
 "Total size: $0": [
  null,
  "Total storlek: $0"
 ],
 "Trust key": [
  null,
  "Förtroendenyckel"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "Kan inte nå servern"
 ],
 "Unable to remove mount": [
  null,
  "Kan inte ta bort monteringen"
 ],
 "Unable to unmount filesystem": [
  null,
  "Kan inte avmontera filsystem"
 ],
 "Unknown": [
  null,
  "Okänd"
 ],
 "Unknown ($0)": [
  null,
  "Okänt ($0)"
 ],
 "Unknown host name": [
  null,
  "Okänt värdnamn"
 ],
 "Unknown type": [
  null,
  "Okänd typ"
 ],
 "Unlock": [
  null,
  "Lås upp"
 ],
 "Unlock automatically on boot": [
  null,
  "Lås upp automatiskt vid start"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Lås upp krypterad Stratis pool"
 ],
 "Unlock pool to see filesystems.": [
  null,
  "Lås upp pool för att se filsystem."
 ],
 "Unlocking $target": [
  null,
  "Lås upp $target"
 ],
 "Unlocking disk": [
  null,
  "Låser upp disk"
 ],
 "Unmount": [
  null,
  "Avmontera"
 ],
 "Unmount filesystem $0": [
  null,
  "Avmontera filsystem $0"
 ],
 "Unmount now": [
  null,
  "Avmontera nu"
 ],
 "Unmounting $target": [
  null,
  "Avmonterar $target"
 ],
 "Unrecognized data": [
  null,
  "Okända data"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Okända data får inte göras mindre här."
 ],
 "Unsupported volume": [
  null,
  "Volym som ej stöds"
 ],
 "Usage": [
  null,
  "Användning"
 ],
 "Usage of $0": [
  null,
  "Användning av $0"
 ],
 "Use": [
  null,
  "Använd"
 ],
 "Use compression": [
  null,
  "Använd komprimering"
 ],
 "Use deduplication": [
  null,
  "Använd deduplicering"
 ],
 "Used": [
  null,
  "Använt"
 ],
 "Used for": [
  null,
  "Används för"
 ],
 "User": [
  null,
  "Användare"
 ],
 "Username": [
  null,
  "Användarnamn"
 ],
 "Using LUKS encryption": [
  null,
  "Använder LUKS-kryptering"
 ],
 "Using Tang server": [
  null,
  "Använder Tang-server"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO-underlagsenheter kan inte göras mindre"
 ],
 "VDO device": [
  null,
  "VDO-enhet"
 ],
 "VDO device $0": [
  null,
  "VDO-enhet $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO-filsystemvolym (komprimering/deduplicering)"
 ],
 "VDO pool": [
  null,
  "VDO Pool"
 ],
 "Verify key": [
  null,
  "Verifiera nyckel"
 ],
 "Very securely erasing $target": [
  null,
  "Raderar mycket säkert $target"
 ],
 "View all logs": [
  null,
  "Visa alla loggar"
 ],
 "Volume": [
  null,
  "Volym"
 ],
 "Volume group": [
  null,
  "Volymgrupp"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Volymstorlek är $0. Innehållsstorlek är $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Väntar på att andra programvaruhanteringsåtgärder skall bli klara"
 ],
 "Write-mostly": [
  null,
  "Skriv huvudsakligen"
 ],
 "Writing": [
  null,
  "Skriver"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 byte med binärdata]"
 ],
 "[binary data]": [
  null,
  "[binärdata]"
 ],
 "[no data]": [
  null,
  "[inga data]"
 ],
 "backing device for VDO device": [
  null,
  "bakomliggande enhet för VDO-enheten"
 ],
 "delete": [
  null,
  "ta bort"
 ],
 "disk": [
  null,
  "disk"
 ],
 "drive": [
  null,
  "disk"
 ],
 "edit": [
  null,
  "redigera"
 ],
 "encryption": [
  null,
  "kryptering"
 ],
 "filesystem": [
  null,
  "filsystem"
 ],
 "format": [
  null,
  "formatera"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "grow": [
  null,
  "väx"
 ],
 "iSCSI targets": [
  null,
  "iSCSI-mål"
 ],
 "initialize": [
  null,
  "initierar"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "member of RAID device": [
  null,
  "medlem i RAID-enhet"
 ],
 "member of Stratis pool": [
  null,
  "medlem i Stratis pool"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "montering"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "never mounted at boot": [
  null,
  "Montera aldrig vid uppstart"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "none": [
  null,
  "ingen"
 ],
 "partition": [
  null,
  "partition"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "fysisk volym på LVM2 volymgrupp"
 ],
 "raid": [
  null,
  "raid"
 ],
 "read only": [
  null,
  "läs endast"
 ],
 "remove from LVM2": [
  null,
  "ta bort från LVM2"
 ],
 "remove from RAID": [
  null,
  "tar bort från RAID"
 ],
 "shrink": [
  null,
  "krymp"
 ],
 "stop": [
  null,
  "stoppa"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unknown target": [
  null,
  "okänt mål"
 ],
 "unmount": [
  null,
  "avmontera"
 ],
 "unpartitioned space on $0": [
  null,
  "opartitionerat utrymmer på $0"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "volym"
 ],
 "yes": [
  null,
  "ja"
 ],
 "storage-id-desc\u0004$0 filesystem": [
  null,
  "$0 filsystem"
 ],
 "storage-id-desc\u0004Filesystem (encrypted)": [
  null,
  "Filsystem (krypterat)"
 ],
 "storage-id-desc\u0004Locked encrypted data": [
  null,
  "Låst krypterad data"
 ],
 "storage-id-desc\u0004Other data": [
  null,
  "Andra data"
 ],
 "storage-id-desc\u0004Swap space": [
  null,
  "Växlingsutrymme"
 ],
 "storage-id-desc\u0004Unrecognized data": [
  null,
  "Okända data"
 ],
 "storage-id-desc\u0004VDO backing": [
  null,
  "VDO-underlag"
 ],
 "storage\u0004Assessment": [
  null,
  "Uppskattning"
 ],
 "storage\u0004Bitmap": [
  null,
  "bitmap"
 ],
 "storage\u0004Capacity": [
  null,
  "Kapacitet"
 ],
 "storage\u0004Device": [
  null,
  "Enhet"
 ],
 "storage\u0004Device file": [
  null,
  "Enhetsfil"
 ],
 "storage\u0004Firmware version": [
  null,
  "Version på hårdvaruprogrammet"
 ],
 "storage\u0004Model": [
  null,
  "Modell"
 ],
 "storage\u0004Multipathed devices": [
  null,
  "Flervägsenheter"
 ],
 "storage\u0004Optical drive": [
  null,
  "Optisk enhet"
 ],
 "storage\u0004RAID level": [
  null,
  "RAID-nivå"
 ],
 "storage\u0004Removable drive": [
  null,
  "Löstagbar disk"
 ],
 "storage\u0004Serial number": [
  null,
  "Serienummer"
 ],
 "storage\u0004State": [
  null,
  "Tillstånd"
 ],
 "storage\u0004UUID": [
  null,
  "UUID"
 ],
 "storage\u0004Usage": [
  null,
  "Användning"
 ],
 "storage\u0004World wide name": [
  null,
  "Världsomfattande namn"
 ],
 "format-bytes\u0004bytes": [
  null,
  "byte"
 ]
});
