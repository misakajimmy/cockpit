cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "$0 (encrypted)": [
  null,
  "$0 (מוצפן)"
 ],
 "$0 Stratis pool": [
  null,
  "מאגר Stratis‏ $0"
 ],
 "$0 block device": [
  null,
  "התקן בלוק בגודל $0"
 ],
 "$0 cache": [
  null,
  "מכלא $0"
 ],
 "$0 chunk size": [
  null,
  "גודל נתח $0"
 ],
 "$0 data": [
  null,
  "נתוני $0"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 נתונים + $1 תוספת מנוצלים מתוך $2 ($3)"
 ],
 "$0 day": [
  null,
  "יום",
  "יומיים",
  "$0 ימים",
  "$0 ימים"
 ],
 "$0 disk is missing": [
  null,
  "כונן אחד חסר",
  "$0 כוננים חסרים",
  "$0 כוננים חסרים",
  "$0 כוננים חסרים"
 ],
 "$0 disks": [
  null,
  "$0 כוננים"
 ],
 "$0 filesystems can not be made larger.": [
  null,
  "אי אפשר להגדיל $0 ממערכות הקבצים."
 ],
 "$0 filesystems can not be made smaller.": [
  null,
  "אי אפשר להקטין $0 ממערכות הקבצים."
 ],
 "$0 filesystems can not be resized here.": [
  null,
  "אי אפשר לשנות כאן גודל של $0 ממערכות הקבצים."
 ],
 "$0 hour": [
  null,
  "שעה",
  "שעתיים",
  "$0 שעות",
  "$0 שעות"
 ],
 "$0 is in use": [
  null,
  "$0 בשימוש"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 אינו זמין מאף מאגר."
 ],
 "$0 minute": [
  null,
  "דקה",
  "$0 דקות",
  "$0 דקות",
  "$0 דקות"
 ],
 "$0 month": [
  null,
  "חודש",
  "חודשיים",
  "$0 חודשים",
  "$0 חודשים"
 ],
 "$0 slot remains": [
  null,
  "נותרה משבצת אחת",
  "נותרו $0 משבצות",
  "נותרו $0 משבצות",
  "נותרו $0 משבצות"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 בשימוש מתוך $1 ($2 נחסכו)"
 ],
 "$0 week": [
  null,
  "שבוע",
  "שבועיים",
  "$0 שבועות",
  "$0 שבועות"
 ],
 "$0 will be installed.": [
  null,
  "$0 יותקן."
 ],
 "$0 year": [
  null,
  "שנה",
  "שנתיים",
  "$0 שנים",
  "$0 שנים"
 ],
 "$0, $1 free": [
  null,
  "$0,‏ $1 פנויים"
 ],
 "$name (from $host)": [
  null,
  "$name (מ־$host)"
 ],
 "(recommended)": [
  null,
  "(מומלץ)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "יום"
 ],
 "1 hour": [
  null,
  "שעה"
 ],
 "1 week": [
  null,
  "שבוע"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "5 minutes": [
  null,
  "5 דקות"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 שעות"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "כבר קיימת מערכת קבצים בשם הזה במאגר הזה."
 ],
 "A pool with this name exists already.": [
  null,
  "כבר קיים מאגר בשם הזה."
 ],
 "A spare disk needs to be added first before this disk can be removed.": [
  null,
  "יש להוסיף כונן חלופי לפני שניתן יהיה להסיר את הכונן הזה."
 ],
 "Action": [
  null,
  "פעולה"
 ],
 "Activate": [
  null,
  "הפעלה"
 ],
 "Activating $target": [
  null,
  "$target מופעל"
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "Add block devices": [
  null,
  "הוספת התקני בלוק"
 ],
 "Add disks": [
  null,
  "הוספת כוננים"
 ],
 "Add iSCSI portal": [
  null,
  "הוספת שער גישה ל־iSCSI"
 ],
 "Add key": [
  null,
  "הוספת מפתח"
 ],
 "Adding physical volume to $target": [
  null,
  "הוספת כרך פיזי אל $target"
 ],
 "Additional packages:": [
  null,
  "חבילות נוספות:"
 ],
 "Address": [
  null,
  "כתובת"
 ],
 "Address cannot be empty": [
  null,
  "הכתובת לא יכולה להיות ריקה"
 ],
 "Address is not a valid URL": [
  null,
  "הכתובת אינה תקנית"
 ],
 "At least $0 disk is needed.": [
  null,
  "נדרש כונן אחד לפחות.",
  "נדרשים $0 כוננים לפחות.",
  "נדרשים $0 כוננים לפחות.",
  "נדרשים $0 כוננים לפחות."
 ],
 "At least one block device is needed.": [
  null,
  "נדרש התקן בלוק אחד לפחות."
 ],
 "At least one disk is needed.": [
  null,
  "נדרש כונן אחד לפחות."
 ],
 "Authentication required": [
  null,
  "נדרש אימות"
 ],
 "Available targets on $0": [
  null,
  "יעדים זמינים על $0"
 ],
 "Backing device": [
  null,
  "התקן גיבוי"
 ],
 "Block": [
  null,
  "בלוק"
 ],
 "Block device for filesystems": [
  null,
  "התקן בלוק למערכות הפעלה"
 ],
 "Block devices": [
  null,
  "התקני בלוק"
 ],
 "Blocked": [
  null,
  "חסום"
 ],
 "Cache": [
  null,
  "מכלא"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Change": [
  null,
  "החלפה"
 ],
 "Change iSCSI initiator name": [
  null,
  "החלפת שם מאתחל ה־iSCSI"
 ],
 "Change passphrase": [
  null,
  "החלפת מילת צופן"
 ],
 "Checking $target": [
  null,
  "$target בבדיקה"
 ],
 "Checking RAID device $target": [
  null,
  "התקן ה־RAID‏ $target נבדק"
 ],
 "Checking and repairing RAID device $target": [
  null,
  "התקן ה־RAID‏ $target נבדק ומתוקן"
 ],
 "Checking installed software": [
  null,
  "התכנה שמותקנת נבדקת"
 ],
 "Checking related processes": [
  null,
  "התהליכים הקשורים נבדקים"
 ],
 "Chunk size": [
  null,
  "גודל נתח"
 ],
 "Cleaning up for $target": [
  null,
  "מתבצע ניקוי לכבוד $target"
 ],
 "Cleartext device": [
  null,
  "התקן טקסט גלוי"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Command": [
  null,
  "פקודה"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "תואם לכל המערכות וההתקנים (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "תואם למערכות ולכוננים חדישים > 2 ט״ב (GPT)"
 ],
 "Compression": [
  null,
  "דחיסה"
 ],
 "Confirm": [
  null,
  "אישור"
 ],
 "Confirm deletion of $0": [
  null,
  "אישור המחיקה של $0"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "אישור הסרה עם מילת צופן חלופית"
 ],
 "Confirm stopping of $0": [
  null,
  "אישור עצירת $0"
 ],
 "Content": [
  null,
  "תוכן"
 ],
 "Copy to clipboard": [
  null,
  "העתקה ללוח הגזירים"
 ],
 "Create": [
  null,
  "יצירה"
 ],
 "Create LVM2 volume group": [
  null,
  "יצירת קבוצת כרכים מסוג LVM2"
 ],
 "Create RAID device": [
  null,
  "יצירת התקן RAID"
 ],
 "Create Stratis pool": [
  null,
  "יצירת מאגר Stratis"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "יצירת תמונת מצב של מערכת הקבצים $0"
 ],
 "Create devices": [
  null,
  "יצירת התקנים"
 ],
 "Create filesystem": [
  null,
  "יצירת מערכת קבצים"
 ],
 "Create logical volume": [
  null,
  "יצירת כרך לוגי"
 ],
 "Create new filesystem": [
  null,
  "יצירת מערכת קבצים חדשה"
 ],
 "Create new logical volume": [
  null,
  "יצירת כרך לוגי חדש"
 ],
 "Create partition": [
  null,
  "יצירת מחיצה"
 ],
 "Create partition on $0": [
  null,
  "יצירת מחיצה על $0"
 ],
 "Create partition table": [
  null,
  "יצירת טבלת מחיצות"
 ],
 "Create snapshot": [
  null,
  "יצירת תמונת מצב"
 ],
 "Create thin volume": [
  null,
  "יצירת כרך רזה"
 ],
 "Create volume group": [
  null,
  "יצירת קבוצת כרכים"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "קבוצת הכרכים $target מסוג LVM2 נוצרת"
 ],
 "Creating RAID device $target": [
  null,
  "נוצר התקן RAID‏ $target"
 ],
 "Creating VDO device": [
  null,
  "נוצר התקן VDO"
 ],
 "Creating filesystem on $target": [
  null,
  "נוצרת מערכת קבצים על $target"
 ],
 "Creating logical volume $target": [
  null,
  "נוצר כרך לוגי על $target"
 ],
 "Creating partition $target": [
  null,
  "נוצרת מחיצה $target"
 ],
 "Creating snapshot of $target": [
  null,
  "נוצרת תמונת מצב של $target"
 ],
 "Currently in use": [
  null,
  "בשימוש כרגע"
 ],
 "Custom mount options": [
  null,
  "אפשרויות עיגון מותאמות אישית"
 ],
 "Data": [
  null,
  "נתונים"
 ],
 "Data used": [
  null,
  "נתונים בשימוש"
 ],
 "Deactivate": [
  null,
  "השבתה"
 ],
 "Deactivating $target": [
  null,
  "מתבצעת השבתה של $target"
 ],
 "Deduplication": [
  null,
  "הסרת כפילות"
 ],
 "Delete": [
  null,
  "מחיקה"
 ],
 "Deleting $target": [
  null,
  "$target נמחק"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "קבוצת הכרכים $target מסוג LVM2 נמחקת"
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "מחיקת מערכת קבצים תמחק את כל הנתונים שבה."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "מחיקת כרך לוגי תמחק את כל הנתונים שבו."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "מחיקת מחיצה תמחק את כל הנתונים שבה."
 ],
 "Deleting erases all data on a RAID device.": [
  null,
  "מחיקה תמחק את כל הנתונים שעל התקן ה־RAID."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "מחיקה תמחק את כל הנתונים של התקן ה־VDO."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "מחיקה מוחקת את כל הנתונים בקבוצת כרכים."
 ],
 "Description": [
  null,
  "תיאור"
 ],
 "Device": [
  null,
  "התקן"
 ],
 "Device file": [
  null,
  "קובץ התקן"
 ],
 "Device is read-only": [
  null,
  "ההתקן הוא לקריאה בלבד"
 ],
 "Devices": [
  null,
  "התקנים"
 ],
 "Disk is OK": [
  null,
  "הכונן תקין"
 ],
 "Disk is failing": [
  null,
  "הכונן נכשל"
 ],
 "Disk passphrase": [
  null,
  "מילת צופן לכונן"
 ],
 "Disks": [
  null,
  "כוננים"
 ],
 "Do not mount automatically on boot": [
  null,
  "לא לעגן אוטומטית עם העלייה"
 ],
 "Downloading $0": [
  null,
  "$0 בהורדה"
 ],
 "Drive": [
  null,
  "כונן"
 ],
 "Drives": [
  null,
  "כוננים"
 ],
 "Edit": [
  null,
  "עריכה"
 ],
 "Edit Tang keyserver": [
  null,
  "עריכת שרת מפתחות Tang"
 ],
 "Editing a key requires a free slot": [
  null,
  "עריכת מפתח דורשת משבצת פנויה"
 ],
 "Ejecting $target": [
  null,
  "$target נשלף כעת"
 ],
 "Emptying $target": [
  null,
  "$target מתרוקן"
 ],
 "Encrypt data": [
  null,
  "הצפנת נתונים"
 ],
 "Encrypted $0": [
  null,
  "$0 מוצפן"
 ],
 "Encrypted Stratis pool $0": [
  null,
  "מאגר Stratis מוצפן $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "כרך לוגי מוצפן בגודל $0"
 ],
 "Encrypted partition of $0": [
  null,
  "מחיצה מוצפנת בגודל $0"
 ],
 "Encrypted volumes can not be resized here.": [
  null,
  "לא ניתן לשנות גודל של כרכים מוצפנים מכאן."
 ],
 "Encrypted volumes need to be unlocked before they can be resized.": [
  null,
  "יש לשחרר כרכים מוצפנים לפני שניתן יהיה לשנות את גודלם."
 ],
 "Encryption": [
  null,
  "הצפנה"
 ],
 "Encryption options": [
  null,
  "אפשרויות הצפנה"
 ],
 "Encryption type": [
  null,
  "סוג הצפנה"
 ],
 "Erasing $target": [
  null,
  "$target נמחק"
 ],
 "Error": [
  null,
  "שגיאה"
 ],
 "Extended partition": [
  null,
  "מחיצה מורחבת"
 ],
 "Failed": [
  null,
  "נכשל"
 ],
 "Filesystem": [
  null,
  "מערכת קבצים"
 ],
 "Filesystem is locked": [
  null,
  "מערכת הקבצים נעולה"
 ],
 "Filesystem name": [
  null,
  "שם מערכת קבצים"
 ],
 "Filesystems": [
  null,
  "מערכות קבצים"
 ],
 "Format": [
  null,
  "פרמוט"
 ],
 "Format $0": [
  null,
  "פרמוט $0"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "פרמוט ימחק את כל הנתונים בהתקן אחסון."
 ],
 "Free": [
  null,
  "פנוי"
 ],
 "Free space": [
  null,
  "מקום פנוי"
 ],
 "Free up space in this group: Shrink or delete other logical volumes or add another physical volume.": [
  null,
  "פינוי מקום בקבוצה הזו: יש לכווץ או למחוק כרכים לוגיים אחרים או להוסיף עוד כרך פיזי."
 ],
 "Go to now": [
  null,
  "לעבור כעת"
 ],
 "Grow": [
  null,
  "הגדלה"
 ],
 "Grow content": [
  null,
  "הגדלת התוכן"
 ],
 "Grow logical size of $0": [
  null,
  "להגדיל לגודל לוגי של $0"
 ],
 "Grow logical volume": [
  null,
  "הגדלת הכרך הלוגי"
 ],
 "Grow to take all space": [
  null,
  "להגדיל על חשבון כל המקום הפנוי"
 ],
 "If this option is checked, the filesystem will not be mounted during the next boot even if it was mounted before it.  This is useful if mounting during boot is not possible, such as when a passphrase is required to unlock the filesystem but booting is unattended.": [
  null,
  "אם האפשרות הזאת מסומנת, מערכת הקבצים לא תעוגן במהלך הטעינה הבעיה אפילו אם עוגנה לפני כן. שימושי אם עיגון במהלך הטעינה אינו אפשרי, למשל כאשר נדרשת מילת צופן כדי לשחרר את נעילת מערכת הקבצים אך תהליך הטעינה מונע את זה."
 ],
 "In sync": [
  null,
  "בסנכרון"
 ],
 "Inactive volume": [
  null,
  "כרך לא פעיל"
 ],
 "Inconsistent filesystem mount": [
  null,
  "עיגון בלתי אחיד של מערכת קבצים"
 ],
 "Index memory": [
  null,
  "זיכרון אינדקס"
 ],
 "Initialize": [
  null,
  "אתחול"
 ],
 "Initialize disk $0": [
  null,
  "אתחול הכונן $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "אתחול מוחק את כל הנתונים בכונן."
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Install NFS support": [
  null,
  "התקנת תמיכה ב־NFS"
 ],
 "Install Stratis support": [
  null,
  "התקנת תמיכה ב־Stratis"
 ],
 "Install software": [
  null,
  "התקנת תכנה"
 ],
 "Installing $0": [
  null,
  "$0 בהתקנה"
 ],
 "Installing $0 would remove $1.": [
  null,
  "התקנת $0 תסיר את $1."
 ],
 "Installing packages": [
  null,
  "חבילות מותקנות"
 ],
 "Invalid username or password": [
  null,
  "שם משתמש או סיסמה שגויים"
 ],
 "Jobs": [
  null,
  "משימות"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "משבצות מפתח עם סוגים בלתי מוכרים אינן ניתנות לעריכה כאן"
 ],
 "Key source": [
  null,
  "מקור מפתח"
 ],
 "Keys": [
  null,
  "מפתחות"
 ],
 "Keyserver": [
  null,
  "שרת מפתחות"
 ],
 "Keyserver address": [
  null,
  "כתובת שרת מפתחות"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "הסרת שרת מפתחות עלולה למנוע את שחרור $0."
 ],
 "LVM2 member": [
  null,
  "חבר ב־LVM2"
 ],
 "LVM2 volume group": [
  null,
  "קבוצת כרכים ב־LVM2"
 ],
 "LVM2 volume group $0": [
  null,
  "קבוצת כרכים LVM2‏ $0"
 ],
 "Last modified: $0": [
  null,
  "שינוי אחרון: $0"
 ],
 "Learn more": [
  null,
  "מידע נוסף"
 ],
 "Loading...": [
  null,
  "בטעינה…"
 ],
 "Local mount point": [
  null,
  "נקודת עגינה מקומית"
 ],
 "Location": [
  null,
  "מיקום"
 ],
 "Lock": [
  null,
  "נעילה"
 ],
 "Locked devices": [
  null,
  "התקנים נעולים"
 ],
 "Locked encrypted Stratis pool": [
  null,
  "מאגר Stratis מוצפן נעול"
 ],
 "Locking $target": [
  null,
  "$target ננעל"
 ],
 "Logical": [
  null,
  "לוגי"
 ],
 "Logical size": [
  null,
  "גודל לוגי"
 ],
 "Logical volume": [
  null,
  "כרך לוגי"
 ],
 "Logical volume (snapshot)": [
  null,
  "כרך לוגי (תמונת מצב)"
 ],
 "Logical volume of $0": [
  null,
  "כרך לוגי בגודל $0"
 ],
 "Logical volumes": [
  null,
  "כרכים לוגיים"
 ],
 "Make sure the key hash from the Tang server matches one of the following:": [
  null,
  "נא לוודא שגיבוב המפתח משרת ה־Tang תואם לאחד מהבאים:"
 ],
 "Managing LVMs": [
  null,
  "ניהול LVMים"
 ],
 "Managing NFS mounts": [
  null,
  "ניהול עיגוני NFS"
 ],
 "Managing RAIDs": [
  null,
  "ניהול RAIDים"
 ],
 "Managing VDOs": [
  null,
  "ניהול VDOים"
 ],
 "Managing partitions": [
  null,
  "ניהול מחיצות"
 ],
 "Managing physical drives": [
  null,
  "ניהול כוננים פיזיים"
 ],
 "Manually check with SSH: ": [
  null,
  "לבדוק ידנית עם SSH: "
 ],
 "Marking $target as faulty": [
  null,
  "$target מסומן כתקול"
 ],
 "Metadata used": [
  null,
  "נתוני על בשימוש"
 ],
 "Modifying $target": [
  null,
  "מתבצע שינוי ב־$target"
 ],
 "Mount": [
  null,
  "עיגון"
 ],
 "Mount also automatically on boot": [
  null,
  "לעגן אוטומטית גם עם העלייה"
 ],
 "Mount at boot": [
  null,
  "לעגן בעלייה"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "לעגן אוטומטית אל $0 בזמן העלייה"
 ],
 "Mount configuration": [
  null,
  "הגדרות עיגון"
 ],
 "Mount filesystem": [
  null,
  "עיגון מערכת קבצים"
 ],
 "Mount now": [
  null,
  "לעגן כעת"
 ],
 "Mount on $0 now": [
  null,
  "לעגן אל $0 כעת"
 ],
 "Mount options": [
  null,
  "אפשרויות עיגון"
 ],
 "Mount point": [
  null,
  "נקודת עיגון"
 ],
 "Mount point cannot be empty": [
  null,
  "נקודת העיגון לא יכולה להיות ריקה"
 ],
 "Mount point cannot be empty.": [
  null,
  "נקודת העיגון לא יכולה להיות ריקה."
 ],
 "Mount point is already used for $0": [
  null,
  "נקודת העיגון כבר משמשת לטובת $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "נקודת העיגון חייבת להתחיל ב־„/”."
 ],
 "Mount read only": [
  null,
  "עיגון לקריאה בלבד"
 ],
 "Mounting $target": [
  null,
  "מתבצע עיגון של $target"
 ],
 "NFS mount": [
  null,
  "עיגון NFS"
 ],
 "NFS mounts": [
  null,
  "עיגוני NFS"
 ],
 "NFS support not installed": [
  null,
  "לא מותקנת תמיכה ב־NFS"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Name can not be empty.": [
  null,
  "השם לא יכול להיות ריק."
 ],
 "Name cannot be empty.": [
  null,
  "השם לא יכול להיות ריק."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "השם לא יכול להיות יותר מ־$0 בתים"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "השם לא יכול להיות ארוך מ־$0 תווים"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "השם לא יכול להיות ארוך מ־127 תווים."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "השם לא יכול להכיל את התו ‚$0’."
 ],
 "Name cannot contain whitespace.": [
  null,
  "השם לא יכול להכיל רווח."
 ],
 "Never mount at boot": [
  null,
  "לעולם לא לעגן בעלייה"
 ],
 "New NFS mount": [
  null,
  "עיגון NFS חדש"
 ],
 "New passphrase": [
  null,
  "מילת צופן חדשה"
 ],
 "Next": [
  null,
  "הבא"
 ],
 "No NFS mounts set up": [
  null,
  "לא הוקמו עיגוני NFS"
 ],
 "No available slots": [
  null,
  "אין משבצות פנויות"
 ],
 "No devices": [
  null,
  "אין התקנים"
 ],
 "No disks are available.": [
  null,
  "אין כוננים זמינים."
 ],
 "No drives attached": [
  null,
  "אף כונן לא מחובר"
 ],
 "No encryption": [
  null,
  "אין הצפנה"
 ],
 "No filesystem": [
  null,
  "אין מערכת קבצים"
 ],
 "No free key slots": [
  null,
  "אין משבצות מפתח פנויות"
 ],
 "No free space": [
  null,
  "אין מקום פנוי"
 ],
 "No iSCSI targets set up": [
  null,
  "לא הוגדרו יעדי iSCSI"
 ],
 "No keys added": [
  null,
  "לא נוספו מפתחות"
 ],
 "No logical volumes": [
  null,
  "אין כרכים לוגיים"
 ],
 "No media inserted": [
  null,
  "לא הוכנס אמצעי מדיה"
 ],
 "No partitioning": [
  null,
  "אין חלוקה למחיצות"
 ],
 "Not enough space to grow.": [
  null,
  "אין מספיק מקום כדי לגדול."
 ],
 "Not found": [
  null,
  "לא נמצא"
 ],
 "Not mounted": [
  null,
  "לא מעוגן"
 ],
 "Not running": [
  null,
  "לא פועל"
 ],
 "Ok": [
  null,
  "אישור"
 ],
 "Old passphrase": [
  null,
  "מילת צופן ישנה"
 ],
 "Only $0 of $1 are used.": [
  null,
  "רק $0 מתוך $1 מנוצלים."
 ],
 "Operation '$operation' on $target": [
  null,
  "המשימה ‚$operation’ על $target"
 ],
 "Options": [
  null,
  "אפשרויות"
 ],
 "Other devices": [
  null,
  "התקנים אחרים"
 ],
 "Overwrite": [
  null,
  "שכתוב"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "שכתוב על נתונים קיימים באפסים (אטי יותר)"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit קרס"
 ],
 "Partition": [
  null,
  "מחיצה"
 ],
 "Partition of $0": [
  null,
  "מחיצה של $0"
 ],
 "Partitioning": [
  null,
  "חלוקה למחיצות"
 ],
 "Partitions": [
  null,
  "מחיצות"
 ],
 "Passphrase": [
  null,
  "מילת צופן"
 ],
 "Passphrase can not be empty": [
  null,
  "מילת הצופן לא יכולה להיות ריקה"
 ],
 "Passphrase cannot be empty": [
  null,
  "מילת הצופן לא יכולה להיות ריקה"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "הסרת מילת הצופן עשויה למנוע את השחרור של $0."
 ],
 "Passphrases do not match": [
  null,
  "מילות הצופן אינן תואמות"
 ],
 "Password": [
  null,
  "סיסמה"
 ],
 "Path on server": [
  null,
  "נתיב בשרת"
 ],
 "Path on server cannot be empty.": [
  null,
  "הנתיב בשרת לא יכול להיות ריק."
 ],
 "Path on server must start with \"/\".": [
  null,
  "הנתיב בשרת חייב להתחיל ב־„/”."
 ],
 "Permanently delete $0?": [
  null,
  ""
 ],
 "Physical": [
  null,
  "פיזי"
 ],
 "Physical volumes": [
  null,
  "כרכים פיזיים"
 ],
 "Physical volumes can not be resized here.": [
  null,
  "כאן ניתן לשנות גודל של כרכים פיזיים."
 ],
 "Pool": [
  null,
  "מאגר"
 ],
 "Pool for thin logical volumes": [
  null,
  "מאגר לכרכים לוגיים רזים"
 ],
 "Pool for thin volumes": [
  null,
  "מאגר לכרכים רזים"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "מאגר לכרכים באפסנה צרה"
 ],
 "Port": [
  null,
  "פתחה"
 ],
 "Processes using the location": [
  null,
  ""
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  ""
 ],
 "Purpose": [
  null,
  "תכלית"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (פיזור נתונים)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (שכפול)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (פיזור נתונים משוכפלים)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (פיזור עם זוגיות בכונן ייעודי)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (פיזור עם זוגיות מפוזרת)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (פיזור עם קוד ריד-סולומון)"
 ],
 "RAID device": [
  null,
  "התקן RAID"
 ],
 "RAID device $0": [
  null,
  "התקן RAID‏ $0"
 ],
 "RAID level": [
  null,
  "רמת RAID"
 ],
 "RAID member": [
  null,
  "חבר ב־RAID"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Recovering": [
  null,
  "מתבצע שיקום"
 ],
 "Recovering RAID device $target": [
  null,
  "התקן ה־RAID‏ $target עובר שיקום"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  ""
 ],
 "Related processes will be forcefully stopped.": [
  null,
  ""
 ],
 "Related services will be forcefully stopped.": [
  null,
  ""
 ],
 "Removals:": [
  null,
  "הסרות:"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "Remove $0?": [
  null,
  "להסיר את $0?"
 ],
 "Remove Tang keyserver?": [
  null,
  "להסיר את שרת המפתחות Tang?"
 ],
 "Remove device": [
  null,
  "הסרת התקן"
 ],
 "Removing $0": [
  null,
  "$0 בהסרה"
 ],
 "Removing $target from RAID device": [
  null,
  "מתבצעת הסרה של $target מהתקן RAID"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  ""
 ],
 "Removing physical volume from $target": [
  null,
  "מתבצעת הסרה של כרך פיזי מתוך $target"
 ],
 "Rename": [
  null,
  "שינוי שם"
 ],
 "Rename logical volume": [
  null,
  "שינוי שם של כרך פיזי"
 ],
 "Rename volume group": [
  null,
  "שינוי שם של קבוצת כרכים"
 ],
 "Renaming $target": [
  null,
  "השם של $target מוחלף"
 ],
 "Repairing $target": [
  null,
  "$target מתוקן"
 ],
 "Repeat passphrase": [
  null,
  "חזרה על מילת הצופן"
 ],
 "Resizing $target": [
  null,
  "הגודל של $target משתנה"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "שינוי גודל של מערכת קבצים מוצפנת דורשת את שחרור הכונן. נא לספק את מילת הצופן הנוכחית של הכונן."
 ],
 "Reuse existing encryption ($0)": [
  null,
  ""
 ],
 "Running": [
  null,
  "פועל"
 ],
 "SHA1": [
  null,
  ""
 ],
 "SHA256": [
  null,
  ""
 ],
 "SMART self-test of $target": [
  null,
  "בדיקת SMART עצמית של $0"
 ],
 "Save": [
  null,
  "שמירה"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "ניתן לחסוך במקום על ידי דחיסת בלוקים עם LZ4 באופן פרטני"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "ניתן לחסוך במקום על ידי אחסון בלוקים עם נתונים זהים פעם אחת בלבד"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "שמירת מילת צופן חדשה דורשת את שחרור הכונן. נא לספק את מילת הצופן הנוכחית של הכונן."
 ],
 "Securely erasing $target": [
  null,
  "$target נמחק בצורה מאובטחת"
 ],
 "Server": [
  null,
  "שרת"
 ],
 "Server address": [
  null,
  "כתובת השרת"
 ],
 "Server address cannot be empty.": [
  null,
  "כתובת השרת לא יכולה להיות ריקה."
 ],
 "Server cannot be empty.": [
  null,
  "השרת לא יכול להיות ריק."
 ],
 "Service": [
  null,
  "שירות"
 ],
 "Setting up loop device $target": [
  null,
  "קם התקן לולאה $target"
 ],
 "Show $0 device": [
  null,
  "להציג את המכשיר",
  "להציג את כל $0 המכשירים",
  "להציג את כל $0 המכשירים",
  "להציג את כל $0 המכשירים"
 ],
 "Show $0 drive": [
  null,
  "להציג כונן אחד",
  "להציג את כל $0 הכוננים",
  "להציג את כל $0 הכוננים",
  "להציג את כל $0 הכוננים"
 ],
 "Show all": [
  null,
  "להציג הכול"
 ],
 "Shrink": [
  null,
  "כיווץ"
 ],
 "Shrink logical volume": [
  null,
  "כיווץ הכרך הלוגי"
 ],
 "Shrink volume": [
  null,
  "כיווץ כרך"
 ],
 "Size": [
  null,
  "גודל"
 ],
 "Size cannot be negative": [
  null,
  "הגודל לא יכול להיות שלילי"
 ],
 "Size cannot be zero": [
  null,
  "הגודל לא יכול להיות אפס"
 ],
 "Size is too large": [
  null,
  "הגודל גדול מדי"
 ],
 "Size must be a number": [
  null,
  "הגודל חייב להיות מספר"
 ],
 "Size must be at least $0": [
  null,
  "הגודל חייב להיות לפחות $0"
 ],
 "Slot $0": [
  null,
  "משבצת $0"
 ],
 "Source": [
  null,
  "מקור"
 ],
 "Spare": [
  null,
  "עודף"
 ],
 "Start": [
  null,
  "התחלה"
 ],
 "Start multipath": [
  null,
  "הפעלת רב נתיבי"
 ],
 "Starting RAID device $target": [
  null,
  "התקן ה־RAID‏ $target מתחיל"
 ],
 "Starting swapspace $target": [
  null,
  "שטח ההחלפה $target מתחיל"
 ],
 "Stop": [
  null,
  "עצירה"
 ],
 "Stop and remove": [
  null,
  "עצירה והסרה"
 ],
 "Stop and unmount": [
  null,
  "עצירה וניתוק"
 ],
 "Stop device": [
  null,
  "עצירת התקן"
 ],
 "Stopping RAID device $target": [
  null,
  "התקן ה־RAID‏ $target נעצר"
 ],
 "Stopping swapspace $target": [
  null,
  "שטח ההחלפה $target נעצר"
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Storage can not be managed on this system.": [
  null,
  "לא ניתן לנהל את האחסון במערכת הזאת."
 ],
 "Storage logs": [
  null,
  "יומני אחסון"
 ],
 "Store passphrase": [
  null,
  "אחסון מילת צופן"
 ],
 "Stored passphrase": [
  null,
  "מילת צופן מאוחסנת"
 ],
 "Successfully copied to clipboard!": [
  null,
  "ההעתקה ללוח הגזירים צלחה!"
 ],
 "Support is installed.": [
  null,
  "התמיכה מותקנת."
 ],
 "Swap": [
  null,
  "החלפה"
 ],
 "Synchronizing RAID device $target": [
  null,
  "התקן ה־RAID‏ $target מסונכרן"
 ],
 "Tang keyserver": [
  null,
  "שרת מפתחות Tang"
 ],
 "The RAID array is in a degraded state": [
  null,
  "מערך ה־RAID נמצא במצב ירוד"
 ],
 "The RAID device must be running in order to add spare disks.": [
  null,
  "התקן ה־RAID חייב לפעול כדי להוסיף כוננים עודפים."
 ],
 "The RAID device must be running in order to remove disks.": [
  null,
  "התקן ה־RAID חייב לפעול כדי להסיר כוננים."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "יצירת התקן ה־VDO הזה לא הסתיימה ולא ניתן להשתמש בהתקן."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "המשתמש שמחובר כרגע אינו מורשה לצפות במידע על מפתחות."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  ""
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "למערכת הקבצים אין נקודת עגינה קבועה."
 ],
 "The filesystem is already mounted at $0. Proceeding will unmount it.": [
  null,
  "מערכת הקבצים כבר מעוגנת תחת $0. המשך הפעולה ינתק את העיגון."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "מערכת הקבצים מוגדרת להתעגן אוטומטית עם הפעלת המערכת אבל מכולת ההצפנה שלה לא תשוחרר באותו הזמן."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "מערכת הקבצים מעוגנת כעת אך העיגון ינותק לאחר העלייה הבאה של המערכת."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "מערכת הקבצים מעוגנת למיקום $0 אך תעוגן למיקום $1 עם העלייה הבאה של המערכת."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "מערכת הקבצים מעוגנת למיקום $0 אך לא תעוגן עם העלייה הבאה של המערכת."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "מערכת הקבצים אינה מעוגנת כעת אך היא תעוגן עם ההפעלה הבאה של המערכת."
 ],
 "The filesystem is not mounted.": [
  null,
  "מערכת הקבצים אינה מעוגנת."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  ""
 ],
 "The last disk of a RAID device cannot be removed.": [
  null,
  "לא ניתן להסיר את הכונן האחרון של התקן ה־RAID."
 ],
 "The last key slot can not be removed": [
  null,
  "לא ניתן להסיר את משבצת המפתח האחרונה"
 ],
 "The last physical volume of a volume group cannot be removed.": [
  null,
  "לא ניתן להסיר את הכרך הפיזי האחרון של קבוצת כרכים."
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  ""
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  ""
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "אי אפשר לעצור בכוח את השירותים שמופיעים."
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  ""
 ],
 "The mount point $0 is in use by these services:": [
  null,
  ""
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "יש התקנים עם מגוון נתיבים במערכת אך שירות ריבוי הנתיבים אינו פועל."
 ],
 "There is not enough free space elsewhere to remove this physical volume. At least $0 more free space is needed.": [
  null,
  "אין מספיק מקום פנוי היכנשהו כדי להסיר את הכרך הפיזי הזה. נדרשים לפחות עוד $0 של מקום פנוי."
 ],
 "These changes will be made:": [
  null,
  "אלו השינויים שיתבצעו:"
 ],
 "Thin logical volume": [
  null,
  "כרך לוגי צר"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "עיגון NFS זה נמצא בשימוש ואפשר לשנות רק את האפשרויות שלו."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "התקן VDO זה אינו משתמש בכל ההתקן המגבה שלו."
 ],
 "This disk cannot be removed while the device is recovering.": [
  null,
  "לא ניתן להסיר את הכונן הזה בזמן שההתקן משתקם."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "בכרך לוגי זה לא נעשה שימוש מלא על ידי התוכן שלו."
 ],
 "This pool can not be unlocked here because its key description is not in the expected format.": [
  null,
  ""
 ],
 "This volume needs to be activated before it can be resized.": [
  null,
  "יש להפעיל את הכרך הזה לפני שיתאפשר לשנות את גודלו."
 ],
 "Tier": [
  null,
  ""
 ],
 "Toggle": [
  null,
  "בורר"
 ],
 "Toggle bitmap": [
  null,
  "החלפת מצב מפת סיביות"
 ],
 "Total size: $0": [
  null,
  "גודל כולל: $0"
 ],
 "Trust key": [
  null,
  "לתת אמון במפתח"
 ],
 "Type": [
  null,
  "סוג"
 ],
 "UUID": [
  null,
  "מזהה ייחודי"
 ],
 "Unable to reach server": [
  null,
  "לא ניתן להגיע לשרת"
 ],
 "Unable to remove mount": [
  null,
  "לא ניתן להסיר עיגון"
 ],
 "Unable to unmount filesystem": [
  null,
  "לא ניתן לנתק את מערכת הקבצים"
 ],
 "Unknown": [
  null,
  "לא ידוע"
 ],
 "Unknown ($0)": [
  null,
  "לא ידוע ($0)"
 ],
 "Unknown host name": [
  null,
  "שם המארח לא ידוע"
 ],
 "Unknown type": [
  null,
  "סוג לא ידוע"
 ],
 "Unlock": [
  null,
  "שחרור"
 ],
 "Unlocking $target": [
  null,
  "$target משוחרר"
 ],
 "Unlocking disk": [
  null,
  "הכונן משוחרר"
 ],
 "Unmount": [
  null,
  "ניתוק"
 ],
 "Unmount now": [
  null,
  "לנתק כעת"
 ],
 "Unmounting $target": [
  null,
  "$target מנותק"
 ],
 "Unrecognized data": [
  null,
  "נתונים לא מזוהים"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "לא ניתן להקטין כאן נתונים בלתי מזוהים."
 ],
 "Unsupported volume": [
  null,
  "כרך לא נתמך"
 ],
 "Usage": [
  null,
  "שימוש"
 ],
 "Use compression": [
  null,
  "להשתמש בדחיסה"
 ],
 "Use deduplication": [
  null,
  "להשתמש בהסרת כפילות"
 ],
 "Used": [
  null,
  "בשימוש"
 ],
 "User": [
  null,
  "משתמש"
 ],
 "Username": [
  null,
  "שם משתמש"
 ],
 "Using LUKS encryption": [
  null,
  "באמצעות הצפנת LUKS"
 ],
 "Using Tang server": [
  null,
  "באמצעות שרת Tang"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "אין אפשרות להקטין התקני גיבוי VDO"
 ],
 "VDO device": [
  null,
  "התקן VDO"
 ],
 "VDO device $0": [
  null,
  "התקן VDO‏ $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  ""
 ],
 "Verify key": [
  null,
  "אימות מפתח"
 ],
 "Very securely erasing $target": [
  null,
  "$target נמחק באופן מאוד מאובטח"
 ],
 "Volume": [
  null,
  "כרך"
 ],
 "Volume group": [
  null,
  "קבוצת כרכים"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "גודל הכרך הוא $0. גודל התוכן הוא $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "בהמתנה לסיום פעולות ניהול תכנה אחרות"
 ],
 "Write-mostly": [
  null,
  "בעיקר כתיבה"
 ],
 "Writing": [
  null,
  "מתבצעת כתיבה"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 בתים של נתונים בינריים]"
 ],
 "[binary data]": [
  null,
  "[נתונים בינריים]"
 ],
 "[no data]": [
  null,
  "[אין נתונים]"
 ],
 "disk": [
  null,
  "כונן"
 ],
 "drive": [
  null,
  "כונן"
 ],
 "edit": [
  null,
  "עריכה"
 ],
 "encryption": [
  null,
  "הצפנה"
 ],
 "filesystem": [
  null,
  "מערכת קבצים"
 ],
 "format": [
  null,
  "פרמוט"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "grow": [
  null,
  ""
 ],
 "iSCSI targets": [
  null,
  "יעדי iSCSI"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "עיגון"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "none": [
  null,
  "אין"
 ],
 "partition": [
  null,
  "מחיצה"
 ],
 "raid": [
  null,
  "raid"
 ],
 "read only": [
  null,
  "קריאה בלבד"
 ],
 "remove from LVM2": [
  null,
  ""
 ],
 "stop": [
  null,
  "עצירה"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unknown target": [
  null,
  "יעד לא ידוע"
 ],
 "unmount": [
  null,
  "ניתוק"
 ],
 "unpartitioned space on $0": [
  null,
  "מקום שאינו מחיצה ב־$0"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "כרך"
 ],
 "yes": [
  null,
  "כן"
 ],
 "storage-id-desc\u0004$0 filesystem": [
  null,
  "מערכת קבצים $0"
 ],
 "storage-id-desc\u0004Filesystem (encrypted)": [
  null,
  "מערכת קבצים (מוצפנת)"
 ],
 "storage-id-desc\u0004Locked encrypted data": [
  null,
  "נתונים מוצפנים נעולים"
 ],
 "storage-id-desc\u0004Other data": [
  null,
  "נתונים אחרים"
 ],
 "storage-id-desc\u0004Swap space": [
  null,
  "שטח החלפה"
 ],
 "storage-id-desc\u0004Unrecognized data": [
  null,
  "נתונים לא מזוהים"
 ],
 "storage-id-desc\u0004VDO backing": [
  null,
  "גיבוי VDO"
 ],
 "storage\u0004Assessment": [
  null,
  "הערכה"
 ],
 "storage\u0004Bitmap": [
  null,
  "מפת סיביות"
 ],
 "storage\u0004Capacity": [
  null,
  "קיבולת"
 ],
 "storage\u0004Device": [
  null,
  "התקן"
 ],
 "storage\u0004Device file": [
  null,
  "קובץ התקן"
 ],
 "storage\u0004Firmware version": [
  null,
  "גרסת קושחה"
 ],
 "storage\u0004Model": [
  null,
  "דגם"
 ],
 "storage\u0004Multipathed devices": [
  null,
  "התקנים מרובי־נתיבים"
 ],
 "storage\u0004Optical drive": [
  null,
  "כונן אופטי"
 ],
 "storage\u0004RAID level": [
  null,
  "רמת RAID"
 ],
 "storage\u0004Removable drive": [
  null,
  "כונן נתיק"
 ],
 "storage\u0004Serial number": [
  null,
  "מספר סידורי"
 ],
 "storage\u0004State": [
  null,
  "מצב"
 ],
 "storage\u0004UUID": [
  null,
  "מזהה ייחודי"
 ],
 "storage\u0004World wide name": [
  null,
  "שם בינלאומי (WWN)"
 ],
 "format-bytes\u0004bytes": [
  null,
  "בתים"
 ]
});
