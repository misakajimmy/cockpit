cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "$0 (encrypted)": [
  null,
  "$0 (versleuteld)"
 ],
 "$0 Stratis pool": [
  null,
  "$0 Stratis-pool"
 ],
 "$0 block device": [
  null,
  "$0 blokapparaat"
 ],
 "$0 cache": [
  null,
  "$0 cache"
 ],
 "$0 chunk size": [
  null,
  "$0 brokgrootte"
 ],
 "$0 data": [
  null,
  "$0 data"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 data + $1 overhead gebruikt van $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 dag",
  "$0 dagen"
 ],
 "$0 disk is missing": [
  null,
  "$0 schijf ontbreekt",
  "$0 schijven ontbreken"
 ],
 "$0 disks": [
  null,
  "$0 schijven"
 ],
 "$0 filesystems can not be made larger.": [
  null,
  "Bestandssystemen kunnen niet uitgebreid worden."
 ],
 "$0 filesystems can not be made smaller.": [
  null,
  "Bestandssystemen kunnen niet verkleind worden."
 ],
 "$0 filesystems can not be resized here.": [
  null,
  "De grootte van bestandssystemen kan hier niet gewijzigd worden."
 ],
 "$0 hour": [
  null,
  "$0 uur",
  "$0 uren"
 ],
 "$0 is in use": [
  null,
  "$0 is in gebruik"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 is van geen enkele repository beschikbaar."
 ],
 "$0 minute": [
  null,
  "$0 minuut",
  "$0 minuten"
 ],
 "$0 month": [
  null,
  "$0 maand",
  "$0 maanden"
 ],
 "$0 of unknown tier": [
  null,
  "$0 van onbekend niveau"
 ],
 "$0 slot remains": [
  null,
  "$0 slot blijft over",
  "$0 slots blijven over"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 gebruikt van $1 ($2 opgeslagen)"
 ],
 "$0 week": [
  null,
  "$0 week",
  "$0 weken"
 ],
 "$0 will be installed.": [
  null,
  "$0 zal geïnstalleerd worden."
 ],
 "$0 year": [
  null,
  "$0 jaar",
  "$0 jaren"
 ],
 "$0, $1 free": [
  null,
  "$0, $1 vrij"
 ],
 "$name (from $host)": [
  null,
  "$name (van $host)"
 ],
 "(recommended)": [
  null,
  "(aanbevolen)"
 ],
 "1 MiB": [
  null,
  "1 MiB"
 ],
 "1 day": [
  null,
  "1 dag"
 ],
 "1 hour": [
  null,
  "1 uur"
 ],
 "1 week": [
  null,
  "1 week"
 ],
 "128 KiB": [
  null,
  "128 KiB"
 ],
 "16 KiB": [
  null,
  "16 KiB"
 ],
 "2 MiB": [
  null,
  "2 MiB"
 ],
 "32 KiB": [
  null,
  "32 KiB"
 ],
 "4 KiB": [
  null,
  "4 KiB"
 ],
 "5 minutes": [
  null,
  "5 minuten"
 ],
 "512 KiB": [
  null,
  "512 KiB"
 ],
 "6 hours": [
  null,
  "6 uren"
 ],
 "64 KiB": [
  null,
  "64 KiB"
 ],
 "8 KiB": [
  null,
  "8 KiB"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Er bestaat al een bestandssysteem met deze naam in deze pool."
 ],
 "A pool with this name exists already.": [
  null,
  "Er bestaat al een pool met deze naam."
 ],
 "A spare disk needs to be added first before this disk can be removed.": [
  null,
  "Een extra schijf dient toegevoegd te worden voordat deze schijf kan worden verwijderd."
 ],
 "Action": [
  null,
  "Actie"
 ],
 "Activate": [
  null,
  "Activeren"
 ],
 "Activating $target": [
  null,
  "Activeren $target"
 ],
 "Add": [
  null,
  "Toevoegen"
 ],
 "Add block devices": [
  null,
  "Voeg blokapparaten toe"
 ],
 "Add disks": [
  null,
  "Schijven toevoegen"
 ],
 "Add iSCSI portal": [
  null,
  "iSCSI-portaal toevoegen"
 ],
 "Add key": [
  null,
  "Sleutel toevoegen"
 ],
 "Adding physical volume to $target": [
  null,
  "Toevoegen van fysieke volume aan $target"
 ],
 "Additional packages:": [
  null,
  "Extra pakketten:"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "Address cannot be empty": [
  null,
  "Adres mag niet leeg zijn"
 ],
 "Address is not a valid URL": [
  null,
  "Adres is geen geldige URL"
 ],
 "At least $0 disk is needed.": [
  null,
  "Minimaal $0 schijf is noodzakelijk.",
  "Minimaal $0 schijven zijn noodzakelijk."
 ],
 "At least one block device is needed.": [
  null,
  "Minimaal één blokapparaat is noodzakelijk."
 ],
 "At least one disk is needed.": [
  null,
  "Minimaal een schijf is noodzakelijk."
 ],
 "Authentication required": [
  null,
  "Authenticatie is vereist"
 ],
 "Available targets on $0": [
  null,
  "Beschikbare doelen op $0"
 ],
 "Backing device": [
  null,
  "Ondersteunend apparaat"
 ],
 "Block": [
  null,
  "Blok"
 ],
 "Block device for filesystems": [
  null,
  "Blok apparaat voor bestandsystemen"
 ],
 "Block devices": [
  null,
  "Blokapparaten"
 ],
 "Blocked": [
  null,
  "Geblokkeerd"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Change": [
  null,
  "Verandering"
 ],
 "Change iSCSI initiator name": [
  null,
  "Verander naam van de iSCSI-initiator"
 ],
 "Change passphrase": [
  null,
  "Verander wachtzin"
 ],
 "Checking $target": [
  null,
  "Controleren van $target"
 ],
 "Checking RAID device $target": [
  null,
  "Controleren van RAID-apparaat $target"
 ],
 "Checking and repairing RAID device $target": [
  null,
  "Controleren en repareren van RAID-apparaat $target"
 ],
 "Checking installed software": [
  null,
  "Controleren op geïnstalleerde software"
 ],
 "Checking related processes": [
  null,
  "Controleren op gerelateerde processen"
 ],
 "Chunk size": [
  null,
  "Brok grootte"
 ],
 "Cleaning up for $target": [
  null,
  "Opschonen voor $target"
 ],
 "Cleartext device": [
  null,
  "Cleartext-apparaat"
 ],
 "Close": [
  null,
  "Sluiten"
 ],
 "Command": [
  null,
  "Commando"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Compatibel met alle systemen en apparaten (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Verenigbaar met moderne systemen en harde schijven > 2TB (GPT)"
 ],
 "Compression": [
  null,
  "Compressie"
 ],
 "Confirm": [
  null,
  "Bevestigen"
 ],
 "Confirm deletion of $0": [
  null,
  "Bevestig het verwijderen van $0"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Bevestig verwijderen met een alternatieve wachtzin"
 ],
 "Confirm stopping of $0": [
  null,
  "Bevestig het stoppen van $0"
 ],
 "Content": [
  null,
  "Inhoud"
 ],
 "Copy to clipboard": [
  null,
  "Kopiëren naar clipboard"
 ],
 "Create": [
  null,
  "Aanmaken"
 ],
 "Create LVM2 volume group": [
  null,
  "Aanmaken LVM2-volumegroep"
 ],
 "Create RAID device": [
  null,
  "Maak RAID-apparaat aan"
 ],
 "Create Stratis pool": [
  null,
  "Maak Stratus pool aan"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Snapshot van bestandssysteem $0 aanmaken"
 ],
 "Create devices": [
  null,
  "Maak apparaten aan"
 ],
 "Create filesystem": [
  null,
  "Bestandssysteem aanmaken"
 ],
 "Create logical volume": [
  null,
  "Maak logische volume aan"
 ],
 "Create new filesystem": [
  null,
  "Nieuw bestandssysteem aanmaken"
 ],
 "Create new logical volume": [
  null,
  "Maak nieuwe logische volume aan"
 ],
 "Create partition": [
  null,
  "Partitie aanmaken"
 ],
 "Create partition on $0": [
  null,
  "Partitie aanmaken op $0"
 ],
 "Create partition table": [
  null,
  "Partitietabel aanmaken"
 ],
 "Create snapshot": [
  null,
  "Maak snapshot aan"
 ],
 "Create thin volume": [
  null,
  "Maak dun volume aan"
 ],
 "Create volume group": [
  null,
  "Maak volumegroep aan"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "LVM2-Volumegroep $target aanmaken"
 ],
 "Creating RAID device $target": [
  null,
  "RAID-apparaat $target aanmaken"
 ],
 "Creating VDO device": [
  null,
  "VDO-apparaat aanmaken"
 ],
 "Creating filesystem on $target": [
  null,
  "Bestandssysteem op $target aanmaken"
 ],
 "Creating logical volume $target": [
  null,
  "Logisch volume $target aanmaken"
 ],
 "Creating partition $target": [
  null,
  "Partitie $target aanmaken"
 ],
 "Creating snapshot of $target": [
  null,
  "Snapshot van $target aanmaken"
 ],
 "Currently in use": [
  null,
  "Momenteel in gebruik"
 ],
 "Custom mount options": [
  null,
  "Aangepaste aankoppelopties"
 ],
 "Data": [
  null,
  "Data"
 ],
 "Data used": [
  null,
  "Gebruikte data"
 ],
 "Deactivate": [
  null,
  "Deactiveren"
 ],
 "Deactivating $target": [
  null,
  "$target deactiveren"
 ],
 "Deduplication": [
  null,
  "Deduplicatie"
 ],
 "Delete": [
  null,
  "Verwijderen"
 ],
 "Deleting $target": [
  null,
  "Verwijder $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "LVM2-volumegroep $target verwijderen"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "Verwijderen van een Stratis pool zal alle data die het bevat wissen."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "Verwijderen van een bestandssysteem zal alle data erop wissen."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Verwijderen van een logische volume zal alle data erop wissen."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Verwijderen van een partitie zal alle data erop wissen."
 ],
 "Deleting erases all data on a RAID device.": [
  null,
  "Verwijderen vernietigt alle data op een RAID-apparaat."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "Verwijderen vernietigt alle data op een VDO-apparaat."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "Verwijderen vernietigt alle data op een volumegroep."
 ],
 "Description": [
  null,
  "Beschrijving"
 ],
 "Device": [
  null,
  "Apparaat"
 ],
 "Device file": [
  null,
  "Apparaatbestand"
 ],
 "Device is read-only": [
  null,
  "Apparaat is alleen-lezen"
 ],
 "Devices": [
  null,
  "Apparaten"
 ],
 "Disk is OK": [
  null,
  "Schijf is OK"
 ],
 "Disk is failing": [
  null,
  "Schijf werkt niet"
 ],
 "Disk passphrase": [
  null,
  "Schijf wachtzin"
 ],
 "Disks": [
  null,
  "Schijven"
 ],
 "Do not mount automatically on boot": [
  null,
  "Niet automatisch aankoppelen tijdens het opstarten"
 ],
 "Downloading $0": [
  null,
  "$0 downloaden"
 ],
 "Drive": [
  null,
  "Station"
 ],
 "Drives": [
  null,
  "Stations"
 ],
 "Edit": [
  null,
  "Bewerken"
 ],
 "Edit Tang keyserver": [
  null,
  "Bewerk Tang sleutelserver"
 ],
 "Editing a key requires a free slot": [
  null,
  "Een sleutel bewerken vereist een vrij slot"
 ],
 "Ejecting $target": [
  null,
  "$target uitwerpen"
 ],
 "Emptying $target": [
  null,
  "$target leegmaken"
 ],
 "Encrypt data": [
  null,
  "Data versleutelen"
 ],
 "Encrypted $0": [
  null,
  "$0 versleuteld"
 ],
 "Encrypted Stratis pool $0": [
  null,
  "Versleutelde Stratis pool $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Versleutelde logische volume van $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Versleutelde partitie van $0"
 ],
 "Encrypted volumes can not be resized here.": [
  null,
  "Versleutelde volumes kunnen hier niet in grootte worden aangepast."
 ],
 "Encrypted volumes need to be unlocked before they can be resized.": [
  null,
  "Versleutelde volumes moeten worden ontgrendeld voordat ze in grootte kunnen worden aangepast."
 ],
 "Encryption": [
  null,
  "Versleuteling"
 ],
 "Encryption options": [
  null,
  "Versleutelingsopties"
 ],
 "Encryption type": [
  null,
  "Versleutelingstype"
 ],
 "Erasing $target": [
  null,
  "$target wissen"
 ],
 "Error": [
  null,
  "Fout"
 ],
 "Extended partition": [
  null,
  "Uitgebreide partitie"
 ],
 "Failed": [
  null,
  "Mislukt"
 ],
 "Filesystem": [
  null,
  "Bestandssysteem"
 ],
 "Filesystem is locked": [
  null,
  "Bestandssysteem is vergrendeld"
 ],
 "Filesystem name": [
  null,
  "Bestandssysteemnaam"
 ],
 "Filesystems": [
  null,
  "Bestandssystemen"
 ],
 "Format": [
  null,
  "Formatteren"
 ],
 "Format $0": [
  null,
  "$0 formatteren"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Formatteren verwijdert alle data op een opslagapparaat."
 ],
 "Free": [
  null,
  "Vrij"
 ],
 "Free space": [
  null,
  "Vrije ruimte"
 ],
 "Free up space in this group: Shrink or delete other logical volumes or add another physical volume.": [
  null,
  "Maak ruimte vrij in deze groep: verklein of verwijder andere logische volumes of voeg een ander fysiek volume toe."
 ],
 "Go to now": [
  null,
  "Ga nu naar"
 ],
 "Grow": [
  null,
  "Vergroten"
 ],
 "Grow content": [
  null,
  "Vergroot inhoud"
 ],
 "Grow logical size of $0": [
  null,
  "Vergroot logische grootte van $0"
 ],
 "Grow logical volume": [
  null,
  "Vergroot logische volume"
 ],
 "Grow to take all space": [
  null,
  "Vergroot om alle ruimte in te nemen"
 ],
 "If this option is checked, the filesystem will not be mounted during the next boot even if it was mounted before it.  This is useful if mounting during boot is not possible, such as when a passphrase is required to unlock the filesystem but booting is unattended.": [
  null,
  "Als deze optie is aangevinkt, zal het bestandssysteem niet worden aangekoppeld tijdens de volgende keer opstarten, zelfs als het eerder was aangekoppeld.  Dit is handig als aankoppelen tijdens het opstarten niet mogelijk is, zoals wanneer een wachtzin vereist is om het bestandssysteem te ontgrendelen, maar het opstarten zonder toezicht is."
 ],
 "In sync": [
  null,
  "Synchroon"
 ],
 "Inactive volume": [
  null,
  "Inactieve volume"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Inconsistente bestandssysteemkoppeling"
 ],
 "Index memory": [
  null,
  "Indexgeheugen"
 ],
 "Initialize": [
  null,
  "Initialiseren"
 ],
 "Initialize disk $0": [
  null,
  "Initialiseren van schijf $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "Initialiseren verwijdert alle data op een schijf."
 ],
 "Install": [
  null,
  "Installeren"
 ],
 "Install NFS support": [
  null,
  "Installeer NFS-ondersteuning"
 ],
 "Install Stratis support": [
  null,
  "Installeer Stratis-ondersteuning"
 ],
 "Install software": [
  null,
  "Installeer software"
 ],
 "Installing $0": [
  null,
  "$0 installeren"
 ],
 "Installing $0 would remove $1.": [
  null,
  "Als je $0 installeert, wordt $1 verwijderd."
 ],
 "Installing packages": [
  null,
  "Pakketten installeren"
 ],
 "Invalid username or password": [
  null,
  "Ongeldige gebruikersnaam of wachtwoord"
 ],
 "Jobs": [
  null,
  "Taken"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Sleutelslots met onbekende typen kunnen hier niet worden bewerkt"
 ],
 "Key source": [
  null,
  "Sleutelbron"
 ],
 "Keys": [
  null,
  "Sleutels"
 ],
 "Keyserver": [
  null,
  "Sleutelserver"
 ],
 "Keyserver address": [
  null,
  "Sleutelserveradres"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Het verwijderen van keyserver kan voorkomen dat $0 wordt ontgrendeld."
 ],
 "LVM2 member": [
  null,
  "LVM2 lid"
 ],
 "LVM2 volume group": [
  null,
  "LVM2 volumegroep"
 ],
 "LVM2 volume group $0": [
  null,
  "LVM2 volumegroep $0"
 ],
 "Last modified: $0": [
  null,
  "Laatst gewijzigd: $0"
 ],
 "Learn more": [
  null,
  "Kom meer te weten"
 ],
 "Loading...": [
  null,
  "Laden..."
 ],
 "Local mount point": [
  null,
  "Lokale aankoppelpunten"
 ],
 "Location": [
  null,
  "Locatie"
 ],
 "Lock": [
  null,
  "Slot"
 ],
 "Locked devices": [
  null,
  "Vergrendelde apparaten"
 ],
 "Locked encrypted Stratis pool": [
  null,
  "Vergrendelde versleutelde Stratis pool"
 ],
 "Locking $target": [
  null,
  "$target vergrendelen"
 ],
 "Logical": [
  null,
  "Logisch"
 ],
 "Logical size": [
  null,
  "Logische grootte"
 ],
 "Logical volume": [
  null,
  "Logische volume"
 ],
 "Logical volume (snapshot)": [
  null,
  "Logische volume (Snapshot)"
 ],
 "Logical volume of $0": [
  null,
  "Logische volume van $0"
 ],
 "Logical volumes": [
  null,
  "Logische volumes"
 ],
 "Make sure the key hash from the Tang server matches one of the following:": [
  null,
  "Zorg ervoor dat de sleutelhash van de Tang-server overeenkomt met een van de volgende:"
 ],
 "Managing LVMs": [
  null,
  "LVM's beheren"
 ],
 "Managing NFS mounts": [
  null,
  "NFS-aankoppelingen beheren"
 ],
 "Managing RAIDs": [
  null,
  "RAID's beheren"
 ],
 "Managing VDOs": [
  null,
  "VDO's beheren"
 ],
 "Managing partitions": [
  null,
  "Partities beheren"
 ],
 "Managing physical drives": [
  null,
  "Fysieke schijven beheren"
 ],
 "Manually check with SSH: ": [
  null,
  "Handmatig controleren met SSH: "
 ],
 "Marking $target as faulty": [
  null,
  "$target als defect markeren"
 ],
 "Metadata used": [
  null,
  "Gebruikte metadata"
 ],
 "Modifying $target": [
  null,
  "$target aanpassen"
 ],
 "Mount": [
  null,
  "Aankoppelen"
 ],
 "Mount also automatically on boot": [
  null,
  "Koppel ook automatisch aan tijdens het opstarten"
 ],
 "Mount at boot": [
  null,
  "Koppel aan tijdens het opstarten"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Koppel automatisch aan op $0 tijdens het opstarten"
 ],
 "Mount configuration": [
  null,
  "Aankoppelconfiguratie"
 ],
 "Mount filesystem": [
  null,
  "Bestandssysteem aankoppelen"
 ],
 "Mount now": [
  null,
  "Koppel nu aan"
 ],
 "Mount on $0 now": [
  null,
  "Koppel nu aan op $0"
 ],
 "Mount options": [
  null,
  "Aankoppelopties"
 ],
 "Mount point": [
  null,
  "Aankoppelpunt"
 ],
 "Mount point cannot be empty": [
  null,
  "Aankoppelpunt mag niet leeg zijn"
 ],
 "Mount point cannot be empty.": [
  null,
  "Aankoppelpunt mag niet leeg zijn."
 ],
 "Mount point is already used for $0": [
  null,
  "Aankoppelpunt wordt al gebruikt voor $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Aankoppelpunt moet beginnen met \"/\"."
 ],
 "Mount read only": [
  null,
  "Koppel alleen-lezen aan"
 ],
 "Mounting $target": [
  null,
  "$target aankoppelen"
 ],
 "NFS mount": [
  null,
  "NFS-aankoppeling"
 ],
 "NFS mounts": [
  null,
  "NFS-aankoppelingen"
 ],
 "NFS support not installed": [
  null,
  "NFS-ondersteuning niet geïnstalleerd"
 ],
 "Name": [
  null,
  "Naam"
 ],
 "Name can not be empty.": [
  null,
  "Naam mag niet leeg zijn."
 ],
 "Name cannot be empty.": [
  null,
  "Naam mag niet leeg zijn."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Naam mag niet langer zijn dan $0 bytes"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Naam mag niet langer dan $0 lettertekens"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Naam mag niet langer zijn dan 127 lettertekens."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Naam mag het letterteken '$0' niet bevatten."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Naam mag geen spaties bevatten."
 ],
 "Never mount at boot": [
  null,
  "Nooit aankoppelen tijdens het opstarten"
 ],
 "New NFS mount": [
  null,
  "Nieuwe NFS-aankoppeling"
 ],
 "New passphrase": [
  null,
  "Nieuwe wachtzin"
 ],
 "Next": [
  null,
  "Volgende"
 ],
 "No NFS mounts set up": [
  null,
  "Geen NFS-aankoppelingen ingesteld"
 ],
 "No available slots": [
  null,
  "Geen slots beschikbaar"
 ],
 "No block devices are available.": [
  null,
  "Geen blokapparaten beschikbaar."
 ],
 "No devices": [
  null,
  "Geen apparaten"
 ],
 "No disks are available.": [
  null,
  "Geen schijven beschikbaar."
 ],
 "No drives attached": [
  null,
  "Geen schijven aangesloten"
 ],
 "No encryption": [
  null,
  "Geen versleuteling"
 ],
 "No filesystem": [
  null,
  "Geen bestandssysteem"
 ],
 "No filesystems": [
  null,
  "Geen bestandssystemen"
 ],
 "No free key slots": [
  null,
  "Geen vrije sleutel slots"
 ],
 "No free space": [
  null,
  "Geen vrije ruimte"
 ],
 "No iSCSI targets set up": [
  null,
  "Geen iSCSI-doelen ingesteld"
 ],
 "No keys added": [
  null,
  "Geen sleutels toegevoegd"
 ],
 "No logical volumes": [
  null,
  "Geen logische volumes"
 ],
 "No media inserted": [
  null,
  "Geen media geplaatst"
 ],
 "No partitioning": [
  null,
  "Geen partitionering"
 ],
 "Not enough space to grow.": [
  null,
  "Niet genoeg ruimte om te groeien."
 ],
 "Not found": [
  null,
  "Niet gevonden"
 ],
 "Not mounted": [
  null,
  "Niet aangekoppeld"
 ],
 "Not running": [
  null,
  "Niet actief"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old passphrase": [
  null,
  "Oude wachtzin"
 ],
 "Only $0 of $1 are used.": [
  null,
  "Alleen $0 van $1 worden gebruikt."
 ],
 "Operation '$operation' on $target": [
  null,
  "Bewerking '$operation' op $target"
 ],
 "Options": [
  null,
  "Opties"
 ],
 "Other devices": [
  null,
  "Andere apparaten"
 ],
 "Overwrite": [
  null,
  "Overschrijven"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Bestaande data overschrijven met nullen (langzamer)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "PackageKit is gecrasht"
 ],
 "Partition": [
  null,
  "Partitie"
 ],
 "Partition of $0": [
  null,
  "Partitie van $0"
 ],
 "Partitioned block device": [
  null,
  "Gepartitioneerd blokapparaat"
 ],
 "Partitioning": [
  null,
  "Partitionering"
 ],
 "Partitions": [
  null,
  "Partities"
 ],
 "Passphrase": [
  null,
  "Wachtzin"
 ],
 "Passphrase can not be empty": [
  null,
  "Wachtzin mag niet leeg zijn"
 ],
 "Passphrase cannot be empty": [
  null,
  "Wachtzin mag niet leeg zijn"
 ],
 "Passphrase from any other key slot": [
  null,
  "Wachtzin van een ander sleutelslot"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Verwijdering van wachtzin kan voorkomen dat $0 wordt ontgrendeld."
 ],
 "Passphrases do not match": [
  null,
  "Wachtzinnen komen niet overeen"
 ],
 "Password": [
  null,
  "Wachtwoord"
 ],
 "Path on server": [
  null,
  "Pad op server"
 ],
 "Path on server cannot be empty.": [
  null,
  "Pad op server mag niet leeg zijn."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Pad op server moet beginnen met \"/\"."
 ],
 "Permanently delete $0?": [
  null,
  "$0 permanent verwijderen?"
 ],
 "Physical": [
  null,
  "Fysiek"
 ],
 "Physical volumes": [
  null,
  "Fysieke volumes"
 ],
 "Physical volumes can not be resized here.": [
  null,
  "Fysieke volumes kunnen hier niet aangepast worden."
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool voor dunne logische volumes"
 ],
 "Pool for thin volumes": [
  null,
  "Pool voor dunne volumes"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool voor dun ingerichte volumes"
 ],
 "Port": [
  null,
  "Poort"
 ],
 "Processes using the location": [
  null,
  "Processen die de locatie gebruiken"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Geef de wachtzin voor de pool op deze blokapparaten:"
 ],
 "Purpose": [
  null,
  "Doel"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (stripe)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (spiegel)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (stripe van spiegels)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (toegewijde pariteit)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (gedistribueerde pariteit)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (dubbel gedistribueerde pariteit)"
 ],
 "RAID device": [
  null,
  "RAID-apparaat"
 ],
 "RAID device $0": [
  null,
  "RAID-apparaat $0"
 ],
 "RAID level": [
  null,
  "RAID-niveau"
 ],
 "RAID member": [
  null,
  "RAID-lid"
 ],
 "Reading": [
  null,
  "Lezen"
 ],
 "Reboot": [
  null,
  "Opnieuw opstarten"
 ],
 "Recovering": [
  null,
  "Herstellen"
 ],
 "Recovering RAID device $target": [
  null,
  "RAID-apparaat $target herstellen"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Gerelateerde processen en services worden met kracht gestopt."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Gerelateerde processen worden met kracht gestopt."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Gerelateerde services worden met kracht gestopt."
 ],
 "Removals:": [
  null,
  "Verwijderingen:"
 ],
 "Remove": [
  null,
  "Verwijderen"
 ],
 "Remove $0?": [
  null,
  "$0 verwijderen?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Tang-sleutelserver verwijderen?"
 ],
 "Remove device": [
  null,
  "Verwijder apparaat"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Wachtzin in sleutelslot $0 verwijderen?"
 ],
 "Removing $0": [
  null,
  "$0 verwijderen"
 ],
 "Removing $target from RAID device": [
  null,
  "$target verwijderen uit RAID-apparaat"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "Het verwijderen van een wachtzin zonder bevestiging van een andere wachtzin kan ontgrendeling of sleutelbeheer voorkomen als andere wachtzinnen worden vergeten of verloren gaan."
 ],
 "Removing physical volume from $target": [
  null,
  "Fysiek volume verwijderen uit $target"
 ],
 "Rename": [
  null,
  "Hernoemen"
 ],
 "Rename Stratis pool": [
  null,
  "Naam van Stratis pool wijzigen"
 ],
 "Rename filesystem": [
  null,
  "Bestandssysteem hernoemen"
 ],
 "Rename logical volume": [
  null,
  "Hernoemen logische volume"
 ],
 "Rename volume group": [
  null,
  "Hernoem volumegroep"
 ],
 "Renaming $target": [
  null,
  "Hernoem $target"
 ],
 "Repairing $target": [
  null,
  "$target repareren"
 ],
 "Repeat passphrase": [
  null,
  "Herhaal wachtzin"
 ],
 "Resizing $target": [
  null,
  "Grootte van $target wijzigen"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Het wijzigen van de grootte van een versleuteld bestandssysteem vereist dat de schijf wordt ontgrendeld. Geef een huidige wachtzin voor de schijf op."
 ],
 "Reuse existing encryption": [
  null,
  "Bestaande versleuteling hergebruiken"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Hergebruiken van bestaande versleuteling ($0)"
 ],
 "Running": [
  null,
  "Uitvoeren"
 ],
 "Runtime": [
  null,
  "Runtime"
 ],
 "SHA1": [
  null,
  "SHA1"
 ],
 "SHA256": [
  null,
  "SHA256"
 ],
 "SMART self-test of $target": [
  null,
  "SMART zelftest van $target"
 ],
 "Save": [
  null,
  "Opslaan"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Bespaar ruimte door afzonderlijke blokken te comprimeren met LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Bespaar ruimte door identieke datablokken slechts één keer op te slaan"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Voor het opslaan van een nieuwe wachtzin moet de schijf worden ontgrendeld. Geef een huidige wachtzin voor de schijf op."
 ],
 "Securely erasing $target": [
  null,
  "$target veilig wissen"
 ],
 "Server": [
  null,
  "Server"
 ],
 "Server address": [
  null,
  "Serveradres"
 ],
 "Server address cannot be empty.": [
  null,
  "Serveradres mag niet leeg zijn."
 ],
 "Server cannot be empty.": [
  null,
  "Server mag niet leeg zijn."
 ],
 "Service": [
  null,
  "Service"
 ],
 "Services using the location": [
  null,
  "Services die gebruik maken van de locatie"
 ],
 "Setting up loop device $target": [
  null,
  "Loop apparaat $target instellen"
 ],
 "Show $0 device": [
  null,
  "Toon $0 apparaat",
  "Toon alle $0 apparaten"
 ],
 "Show $0 drive": [
  null,
  "Toon $0 station",
  "Toon alle $0 stations"
 ],
 "Show all": [
  null,
  "Toon alles"
 ],
 "Shrink": [
  null,
  "Krimpen"
 ],
 "Shrink logical volume": [
  null,
  "Krimp logische volume"
 ],
 "Shrink volume": [
  null,
  "Krimp volume"
 ],
 "Size": [
  null,
  "Grootte"
 ],
 "Size cannot be negative": [
  null,
  "Grootte mag niet negatief zijn"
 ],
 "Size cannot be zero": [
  null,
  "Grootte mag niet nul zijn"
 ],
 "Size is too large": [
  null,
  "Grootte is te groot"
 ],
 "Size must be a number": [
  null,
  "Grootte moet een getal zijn"
 ],
 "Size must be at least $0": [
  null,
  "Grootte moet tenminste #0 zijn"
 ],
 "Slot $0": [
  null,
  "Slot $0"
 ],
 "Snapshot": [
  null,
  "Snapshot"
 ],
 "Source": [
  null,
  "Bron"
 ],
 "Spare": [
  null,
  "Reserve"
 ],
 "Start": [
  null,
  "Start"
 ],
 "Start multipath": [
  null,
  "Start multipath"
 ],
 "Starting RAID device $target": [
  null,
  "RAID-apparaat $target starten"
 ],
 "Starting swapspace $target": [
  null,
  "Swapspace $target starten"
 ],
 "Stop": [
  null,
  "Stop"
 ],
 "Stop and remove": [
  null,
  "Stop en verwijder"
 ],
 "Stop and unmount": [
  null,
  "Stoppen en ontkoppelen"
 ],
 "Stop device": [
  null,
  "Stop apparaat"
 ],
 "Stopping RAID device $target": [
  null,
  "RAID-apparaat $target stoppen"
 ],
 "Stopping swapspace $target": [
  null,
  "Swapspace $target stoppen"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Opslag kan op dit systeem niet beheerd worden."
 ],
 "Storage logs": [
  null,
  "Opslaglogboeken"
 ],
 "Store passphrase": [
  null,
  "Sla wachtzin op"
 ],
 "Stored passphrase": [
  null,
  "Opgeslagen wachtzin"
 ],
 "Stratis member": [
  null,
  "Stratis lid"
 ],
 "Stratis pool": [
  null,
  "Stratis-pool"
 ],
 "Stratis pool $0": [
  null,
  "Stratis-pool $0"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Succesvol naar het klembord gekopieerd!"
 ],
 "Support is installed.": [
  null,
  "Ondersteuning is geïnstalleerd."
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Synchronizing RAID device $target": [
  null,
  "RAID-apparaat $target synchroniseren"
 ],
 "Tang keyserver": [
  null,
  "Tang sleutelserver"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Het $0 pakket moet worden geïnstalleerd om Stratis pools aan te maken."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Het $0 pakket zal worden geïnstalleerd om VDO-apparaten aan te maken."
 ],
 "The RAID array is in a degraded state": [
  null,
  "De RAID-array bevindt zich in een slechte staat"
 ],
 "The RAID device must be running in order to add spare disks.": [
  null,
  "Het RAID-apparaat moet actief zijn om een extra schijven toe te kunnen voegen."
 ],
 "The RAID device must be running in order to remove disks.": [
  null,
  "Het RAID apparaat moet actief zijn om een extra schijven te kunnen verwijderen."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Het aanmaken van dit VDO-apparaat is niet voltooid en het apparaat kan niet gebruikt worden."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "De momenteel ingelogde gebruiker mag geen informatie over sleutels zien."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "De schijf moet worden ontgrendeld voor het formatteren.  Geef een bestaande wachtzin op."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Het bestandssysteem heeft geen permanent koppelpunt."
 ],
 "The filesystem is already mounted at $0. Proceeding will unmount it.": [
  null,
  "Het bestandssysteem is al aangekoppeld op $0. Als je doorgaat, wordt het ontkoppeld."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Het bestandssysteem is geconfigureerd om automatisch te worden aangekoppeld bij het opstarten, maar de encryptiecontainer wordt op dat moment niet ontgrendeld."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Het bestandssysteem is momenteel aangekoppeld, maar wordt niet aangekoppeld na de volgende keer opstarten."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Het bestandssysteem is momenteel aangekoppeld op $0 maar zal worden aangekoppeld op $1 bij de volgende opstart."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Het bestandssysteem is momenteel aangekoppeld op $0 maar zal niet aangekoppeld worden na de volgende opstart."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Het bestandssysteem is momenteel niet aangekoppeld, maar wordt bij de volgende opstart aangekoppeld."
 ],
 "The filesystem is not mounted.": [
  null,
  "Het bestandssysteem is niet aangekoppeld."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Het bestandssysteem wordt ontgrendeld en aangekoppeld bij de volgende keer opstarten. Hiervoor moet mogelijk een wachtzin worden ingevoerd."
 ],
 "The last disk of a RAID device cannot be removed.": [
  null,
  "De laatste schijf van een RAID-apparaat kan niet worden verwijderd."
 ],
 "The last key slot can not be removed": [
  null,
  "De laatste sleutelslot kan niet verwijderd worden"
 ],
 "The last physical volume of a volume group cannot be removed.": [
  null,
  "Het laatste fysieke volume van een volumegroep kan niet verwijderd worden."
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "De vermelde processen en services worden met kracht gestopt."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "De vermelde processen worden met kracht gestopt."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "De vermelde services worden met kracht gestopt."
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Het aankoppelpunt $0 is in gebruik bij deze processen:"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Het aankoppelpunt $0 is in gebruik bij deze services:"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Er zijn apparaten met meerdere paden op het systeem, maar de multipath-service is niet actief."
 ],
 "There is not enough free space elsewhere to remove this physical volume. At least $0 more free space is needed.": [
  null,
  "Er is elders onvoldoende vrije ruimte om dit fysieke volume te verwijderen. Er is minimaal $0 meer vrije ruimte nodig."
 ],
 "These changes will be made:": [
  null,
  "Deze veranderingen zullen worden gemaakt:"
 ],
 "Thin logical volume": [
  null,
  "Dunne logische volume"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Deze NFS-mount is in gebruik en alleen de opties kunnen gewijzigd worden."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Dit VDO-apparaat gebruikt niet al zijn achtergrondapparatuur."
 ],
 "This device is currently in use.": [
  null,
  "Dit apparaat is momenteel in gebruik."
 ],
 "This disk cannot be removed while the device is recovering.": [
  null,
  "Deze schijf kan niet worden verwijderd gedurende de herstel periode."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Dit logische volume wordt niet volledig gebruikt door de inhoud."
 ],
 "This pool can not be unlocked here because its key description is not in the expected format.": [
  null,
  "Deze pool kan hier niet worden ontgrendeld omdat de sleutelbeschrijving niet in het verwachte formaat is."
 ],
 "This volume needs to be activated before it can be resized.": [
  null,
  "Dit volume moet worden geactiveerd voordat het in grootte kan worden aangepast."
 ],
 "Tier": [
  null,
  "Niveau"
 ],
 "Toggle": [
  null,
  "Wissel"
 ],
 "Toggle bitmap": [
  null,
  "Wissel bitmap"
 ],
 "Total size: $0": [
  null,
  "Totale grootte: $0"
 ],
 "Trust key": [
  null,
  "Vertrouwenssleutel"
 ],
 "Type": [
  null,
  "Type"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "Kan server niet bereiken"
 ],
 "Unable to remove mount": [
  null,
  "Kan aankoppeling niet verwijderen"
 ],
 "Unable to unmount filesystem": [
  null,
  "Kan bestandssysteem niet afkoppelen"
 ],
 "Unknown": [
  null,
  "Onbekend"
 ],
 "Unknown ($0)": [
  null,
  "Onbekend ($0)"
 ],
 "Unknown host name": [
  null,
  "Onbekende hostnaam"
 ],
 "Unknown type": [
  null,
  "Onbekend type"
 ],
 "Unlock": [
  null,
  "Ontgrendelen"
 ],
 "Unlock automatically on boot": [
  null,
  "Automatisch ontgrendelen bij opstarten"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Ontgrendel versleutelde Stratis pool"
 ],
 "Unlock pool to see filesystems.": [
  null,
  "Ontgrendel pool om bestandssystemen te zien."
 ],
 "Unlocking $target": [
  null,
  "Ontgrendelen $target"
 ],
 "Unlocking disk": [
  null,
  "Schijf ontgrendelen"
 ],
 "Unmount": [
  null,
  "Afkoppelen"
 ],
 "Unmount filesystem $0": [
  null,
  "Bestandssysteem $0 afkoppelen"
 ],
 "Unmount now": [
  null,
  "Nu afkoppelen"
 ],
 "Unmounting $target": [
  null,
  "$target afkoppelen"
 ],
 "Unrecognized data": [
  null,
  "Onbekende data"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Onbekende data kan hier niet kleiner gemaakt worden."
 ],
 "Unsupported volume": [
  null,
  "Niet-ondersteunde volume"
 ],
 "Usage": [
  null,
  "Gebruik"
 ],
 "Usage of $0": [
  null,
  "Gebruik van $0"
 ],
 "Use": [
  null,
  "Gebruik"
 ],
 "Use compression": [
  null,
  "Gebruik compressie"
 ],
 "Use deduplication": [
  null,
  "Gebruik deduplicatie"
 ],
 "Used": [
  null,
  "Gebruikt"
 ],
 "Used for": [
  null,
  "Gebruikt voor"
 ],
 "User": [
  null,
  "Gebruiker"
 ],
 "Username": [
  null,
  "Gebruikersnaam"
 ],
 "Using LUKS encryption": [
  null,
  "Gebruikt LUKS-versleuteling"
 ],
 "Using Tang server": [
  null,
  "Gebruikt Tang-server"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "VDO-ondersteuningsapparaten kunnen niet kleiner gemaakt worden"
 ],
 "VDO device": [
  null,
  "VDO-apparaat"
 ],
 "VDO device $0": [
  null,
  "VDO-apparaat $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "VDO-bestandssysteemvolume (compressie/deduplicatie)"
 ],
 "VDO pool": [
  null,
  "VDO-pool"
 ],
 "Verify key": [
  null,
  "Verifieer sleutel"
 ],
 "Very securely erasing $target": [
  null,
  "Zeer veilig wissen van $target"
 ],
 "View all logs": [
  null,
  "Bekijk alle logboeken"
 ],
 "Volume": [
  null,
  "Volume"
 ],
 "Volume group": [
  null,
  "Volumegroep"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Volumegrootte is $0. Inhoudsgrootte is $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Wachten tot andere softwarebeheerhandelingen voltooid zijn"
 ],
 "Write-mostly": [
  null,
  "Meestal-schrijven"
 ],
 "Writing": [
  null,
  "Schrijven"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 bytes binaire data]"
 ],
 "[binary data]": [
  null,
  "[binaire data]"
 ],
 "[no data]": [
  null,
  "[geen data]"
 ],
 "backing device for VDO device": [
  null,
  "steunapparaat voor VDO-apparaat"
 ],
 "delete": [
  null,
  "verwijderen"
 ],
 "disk": [
  null,
  "schijf"
 ],
 "drive": [
  null,
  "station"
 ],
 "edit": [
  null,
  "bewerken"
 ],
 "encryption": [
  null,
  "versleuteling"
 ],
 "filesystem": [
  null,
  "bestandssysteem"
 ],
 "format": [
  null,
  "formatteren"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "grow": [
  null,
  "toenemen"
 ],
 "iSCSI targets": [
  null,
  "iSCSI-doelen"
 ],
 "initialize": [
  null,
  "initialiseren"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "member of RAID device": [
  null,
  "onderdeel van RAID-apparaat"
 ],
 "member of Stratis pool": [
  null,
  "onderdeel van Stratis-pool"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "aankoppelen"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "never mounted at boot": [
  null,
  "nooit aangekoppeld tijdens het opstarten"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "none": [
  null,
  "geen"
 ],
 "partition": [
  null,
  "partitie"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "fysieke volume van LVM2-volumegroep"
 ],
 "raid": [
  null,
  "raid"
 ],
 "read only": [
  null,
  "alleen-lezen"
 ],
 "remove from LVM2": [
  null,
  "verwijderen uit LVM2"
 ],
 "remove from RAID": [
  null,
  "verwijderen uit RAID"
 ],
 "shrink": [
  null,
  "krimpen"
 ],
 "stop": [
  null,
  "stop"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unknown target": [
  null,
  "onbekend doel"
 ],
 "unmount": [
  null,
  "afkoppelen"
 ],
 "unpartitioned space on $0": [
  null,
  "niet-gepartitioneerde ruimte op $0"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "volume"
 ],
 "yes": [
  null,
  "ja"
 ],
 "storage-id-desc\u0004$0 filesystem": [
  null,
  "$0 bestandssysteem"
 ],
 "storage-id-desc\u0004Filesystem (encrypted)": [
  null,
  "Bestandssysteem (versleuteld)"
 ],
 "storage-id-desc\u0004Locked encrypted data": [
  null,
  "Vergrendelde versleutelde data"
 ],
 "storage-id-desc\u0004Other data": [
  null,
  "Andere data"
 ],
 "storage-id-desc\u0004Swap space": [
  null,
  "Swapruimte"
 ],
 "storage-id-desc\u0004Unrecognized data": [
  null,
  "Onbekende data"
 ],
 "storage-id-desc\u0004VDO backing": [
  null,
  "VDO-ondersteuning"
 ],
 "storage\u0004Assessment": [
  null,
  "Beoordeling"
 ],
 "storage\u0004Bitmap": [
  null,
  "Bitmap"
 ],
 "storage\u0004Capacity": [
  null,
  "Capaciteit"
 ],
 "storage\u0004Device": [
  null,
  "Apparaat"
 ],
 "storage\u0004Device file": [
  null,
  "Apparaatbestand"
 ],
 "storage\u0004Firmware version": [
  null,
  "Firmwareversie"
 ],
 "storage\u0004Model": [
  null,
  "Model"
 ],
 "storage\u0004Multipathed devices": [
  null,
  "Multipad apparaten"
 ],
 "storage\u0004Optical drive": [
  null,
  "Optisch station"
 ],
 "storage\u0004RAID level": [
  null,
  "RAID-niveau"
 ],
 "storage\u0004Removable drive": [
  null,
  "Verwijderbaar station"
 ],
 "storage\u0004Serial number": [
  null,
  "Serienummer"
 ],
 "storage\u0004State": [
  null,
  "Toestand"
 ],
 "storage\u0004UUID": [
  null,
  "UUID"
 ],
 "storage\u0004Usage": [
  null,
  "Gebruik"
 ],
 "storage\u0004World wide name": [
  null,
  "Wereldwijde naam"
 ],
 "format-bytes\u0004bytes": [
  null,
  "bytes"
 ]
});
