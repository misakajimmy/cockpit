cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "$0 (encrypted)": [
  null,
  "$0 (chiffré)"
 ],
 "$0 Stratis pool": [
  null,
  "$0 Pool Stratis"
 ],
 "$0 block device": [
  null,
  "$0 périphérique bloc"
 ],
 "$0 cache": [
  null,
  "$0 cache"
 ],
 "$0 chunk size": [
  null,
  "$0 Taille de bloc"
 ],
 "$0 data": [
  null,
  "$0 données"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 données + $1 surcharge utilisée de $2 ( $3 )"
 ],
 "$0 day": [
  null,
  "$0 jour",
  "$0 jours"
 ],
 "$0 disk is missing": [
  null,
  "$0 disque est manquant",
  "$0 disques sont manquants"
 ],
 "$0 disks": [
  null,
  "$0 Disques"
 ],
 "$0 filesystems can not be made larger.": [
  null,
  "$0 les systèmes de fichiers ne peuvent pas être agrandis."
 ],
 "$0 filesystems can not be made smaller.": [
  null,
  "$0 les systèmes de fichiers ne peuvent pas être réduits."
 ],
 "$0 filesystems can not be resized here.": [
  null,
  "$0 les systèmes de fichiers ne peuvent pas être redimensionnés ici."
 ],
 "$0 hour": [
  null,
  "$0 heure",
  "$0 heures"
 ],
 "$0 is in use": [
  null,
  "$0 est en cours d’utilisation"
 ],
 "$0 is not available from any repository.": [
  null,
  "$0 n’est disponible dans aucun référentiel."
 ],
 "$0 minute": [
  null,
  "$0 minute",
  "$0 minutes"
 ],
 "$0 month": [
  null,
  "$0 mois",
  "$0 mois"
 ],
 "$0 of unknown tier": [
  null,
  "$0 de niveau inconnu"
 ],
 "$0 slot remains": [
  null,
  "$0 il reste un créneau",
  "$0 logements restants"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 utilisé de $1 ($2 enregistré)"
 ],
 "$0 week": [
  null,
  "$0 semaine",
  "$0 semaines"
 ],
 "$0 will be installed.": [
  null,
  "$0 sera installé."
 ],
 "$0 year": [
  null,
  "$0 an",
  "$0 ans"
 ],
 "$0, $1 free": [
  null,
  "$0, $1 disponible"
 ],
 "$name (from $host)": [
  null,
  "$name (de $host )"
 ],
 "(recommended)": [
  null,
  "(recommandé)"
 ],
 "1 MiB": [
  null,
  "1 Mio"
 ],
 "1 day": [
  null,
  "1 jour"
 ],
 "1 hour": [
  null,
  "1 heure"
 ],
 "1 week": [
  null,
  "1 semaine"
 ],
 "128 KiB": [
  null,
  "128 Kio"
 ],
 "16 KiB": [
  null,
  "16 Kio"
 ],
 "2 MiB": [
  null,
  "2 Mio"
 ],
 "32 KiB": [
  null,
  "32 Kio"
 ],
 "4 KiB": [
  null,
  "4 Kio"
 ],
 "5 minutes": [
  null,
  "5 minutes"
 ],
 "512 KiB": [
  null,
  "512 Kio"
 ],
 "6 hours": [
  null,
  "6 heures"
 ],
 "64 KiB": [
  null,
  "64 Kio"
 ],
 "8 KiB": [
  null,
  "8 Kio"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Un système de fichiers portant ce nom existe déjà dans ce pool."
 ],
 "A pool with this name exists already.": [
  null,
  "Un pool portant ce nom existe déjà."
 ],
 "A spare disk needs to be added first before this disk can be removed.": [
  null,
  "Un disque de rechange doit être ajouté en premier avant que ce disque puisse être retiré."
 ],
 "Action": [
  null,
  "Action"
 ],
 "Activate": [
  null,
  "Activer"
 ],
 "Activating $target": [
  null,
  "Activation de $target"
 ],
 "Add": [
  null,
  "Ajouter"
 ],
 "Add block devices": [
  null,
  "Ajouter des blocs de périphériques"
 ],
 "Add disks": [
  null,
  "Ajouter des disques"
 ],
 "Add iSCSI portal": [
  null,
  "Ajouter un portail iSCSI"
 ],
 "Add key": [
  null,
  "Ajouter une clé"
 ],
 "Adding physical volume to $target": [
  null,
  "Ajout d’un volume physique à $target"
 ],
 "Additional packages:": [
  null,
  "Paquets supplémentaires :"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "Address cannot be empty": [
  null,
  "L’adresse ne peut pas être vide"
 ],
 "Address is not a valid URL": [
  null,
  "L’adresse ne correspond pas à une URL valide"
 ],
 "At least $0 disk is needed.": [
  null,
  "Au moins $0 disque est nécessaire.",
  "Au moins $0 disques sont nécessaires."
 ],
 "At least one block device is needed.": [
  null,
  "Au moins un périphérique en mode bloc est nécessaire."
 ],
 "At least one disk is needed.": [
  null,
  "Au moins un disque est nécessaire."
 ],
 "Authentication required": [
  null,
  "Authentification requise"
 ],
 "Available targets on $0": [
  null,
  "Cibles disponibles sur $0"
 ],
 "Backing device": [
  null,
  "Périphérique de sauvegarde"
 ],
 "Block": [
  null,
  "Bloc"
 ],
 "Block device for filesystems": [
  null,
  "Périphérique bloc pour système de fichiers"
 ],
 "Block devices": [
  null,
  "Périphérique en mode bloc"
 ],
 "Blocked": [
  null,
  "Bloqué"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Change": [
  null,
  "Modification"
 ],
 "Change iSCSI initiator name": [
  null,
  "Modifier le nom de l’initiateur iSCSI"
 ],
 "Change passphrase": [
  null,
  "Modifier la phrase secrète"
 ],
 "Checking $target": [
  null,
  "Vérification $target"
 ],
 "Checking RAID device $target": [
  null,
  "Vérification du périphérique RAID $target"
 ],
 "Checking and repairing RAID device $target": [
  null,
  "Vérification et réparation du périphérique RAID $target"
 ],
 "Checking installed software": [
  null,
  "Vérification des logiciels installés"
 ],
 "Checking related processes": [
  null,
  "Vérification des processus connexes"
 ],
 "Chunk size": [
  null,
  "Taille de bloc"
 ],
 "Cleaning up for $target": [
  null,
  "Nettoyage pour $target"
 ],
 "Cleartext device": [
  null,
  "Périphérique en clair"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Command": [
  null,
  "Commander"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Compatible avec tous les systèmes et périphériques (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Compatible avec les systèmes modernes et les disques durs > 2 To (GPT)"
 ],
 "Compression": [
  null,
  "Compression"
 ],
 "Confirm": [
  null,
  "Confirmer"
 ],
 "Confirm deletion of $0": [
  null,
  "Confirmer la suppression de $0"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Confirmer la suppression avec une phrase secrète alternative"
 ],
 "Confirm stopping of $0": [
  null,
  "Confirmer l'arrêt de $0"
 ],
 "Content": [
  null,
  "Contenu"
 ],
 "Copy to clipboard": [
  null,
  "Copier dans le presse-papier"
 ],
 "Create": [
  null,
  "Créer"
 ],
 "Create LVM2 volume group": [
  null,
  "Créer un groupe de volume LVM2"
 ],
 "Create RAID device": [
  null,
  "Créer Périphérique RAID"
 ],
 "Create Stratis pool": [
  null,
  "Créer un pool Stratis"
 ],
 "Create a snapshot of filesystem $0": [
  null,
  "Créer un instantané du système de fichiers $0"
 ],
 "Create devices": [
  null,
  "Créer des partitions"
 ],
 "Create filesystem": [
  null,
  "Créer un système de fichiers"
 ],
 "Create logical volume": [
  null,
  "Créer un volume logique"
 ],
 "Create new filesystem": [
  null,
  "Créer un nouveau système de fichiers"
 ],
 "Create new logical volume": [
  null,
  "Créer un nouveau volume logique"
 ],
 "Create partition": [
  null,
  "Créer Partition"
 ],
 "Create partition on $0": [
  null,
  "Créer une partition sur $0"
 ],
 "Create partition table": [
  null,
  "Créer une table de partition"
 ],
 "Create snapshot": [
  null,
  "Créer Instantané"
 ],
 "Create thin volume": [
  null,
  "Créer Volume dynamique"
 ],
 "Create volume group": [
  null,
  "Créer Groupe de volumes"
 ],
 "Creating LVM2 volume group $target": [
  null,
  "Création d’un groupe de volumes LVM2 $target"
 ],
 "Creating RAID device $target": [
  null,
  "Création d’un périphérique RAID $target"
 ],
 "Creating VDO device": [
  null,
  "Création d’un périphérique VDO"
 ],
 "Creating filesystem on $target": [
  null,
  "Création d’un système de fichiers sur $target"
 ],
 "Creating logical volume $target": [
  null,
  "Création du volume logique $target"
 ],
 "Creating partition $target": [
  null,
  "Création de la partition $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Création d’un instantané de $target"
 ],
 "Currently in use": [
  null,
  "Actuellement en cours d’utilisation"
 ],
 "Custom mount options": [
  null,
  "Options de montage personnalisées"
 ],
 "Data": [
  null,
  "Données"
 ],
 "Data used": [
  null,
  "Données utilisées"
 ],
 "Deactivate": [
  null,
  "Désactiver"
 ],
 "Deactivating $target": [
  null,
  "Désactivation de $target"
 ],
 "Deduplication": [
  null,
  "Déduplication"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Deleting $target": [
  null,
  "Suppression de $target"
 ],
 "Deleting LVM2 volume group $target": [
  null,
  "Suppression d’un groupe de volumes LVM2 $target"
 ],
 "Deleting a Stratis pool will erase all data it contains.": [
  null,
  "La suppression d’un pool Stratis efface toutes les données qu’il contient."
 ],
 "Deleting a filesystem will delete all data in it.": [
  null,
  "La suppression d’un système de fichiers entraîne la suppression de toutes les données qu’il contient."
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "La suppression d’un volume logique supprimera toutes les données qu’il contient."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "La suppression d’une partition supprimera toutes les données qui s’y trouvent."
 ],
 "Deleting erases all data on a RAID device.": [
  null,
  "La suppression efface toutes les données d’un périphérique RAID."
 ],
 "Deleting erases all data on a VDO device.": [
  null,
  "La suppression efface toutes les données d’un périphérique VDO."
 ],
 "Deleting erases all data on a volume group.": [
  null,
  "La suppression efface toutes les données d’un groupe de volumes."
 ],
 "Description": [
  null,
  "Description"
 ],
 "Device": [
  null,
  "Périphérique"
 ],
 "Device file": [
  null,
  "Fichier de périphérique"
 ],
 "Device is read-only": [
  null,
  "Périphérique en lecture seule"
 ],
 "Devices": [
  null,
  "Périphériques"
 ],
 "Disk is OK": [
  null,
  "Le disque est OK"
 ],
 "Disk is failing": [
  null,
  "Le disque est défaillant"
 ],
 "Disk passphrase": [
  null,
  "Phrase secrète du disque"
 ],
 "Disks": [
  null,
  "Disques"
 ],
 "Do not mount automatically on boot": [
  null,
  "Ne pas monter automatiquement au démarrage"
 ],
 "Downloading $0": [
  null,
  "Téléchargement $0"
 ],
 "Drive": [
  null,
  "Lecteur"
 ],
 "Drives": [
  null,
  "Lecteur"
 ],
 "Edit": [
  null,
  "Modifier"
 ],
 "Edit Tang keyserver": [
  null,
  "Modifier le serveur de clés Tang"
 ],
 "Editing a key requires a free slot": [
  null,
  "La modification d’une clé nécessite un emplacement libre"
 ],
 "Ejecting $target": [
  null,
  "Éjecter $target"
 ],
 "Emptying $target": [
  null,
  "$target en cours de vidage"
 ],
 "Encrypt data": [
  null,
  "Chiffrer les données"
 ],
 "Encrypted $0": [
  null,
  "Chiffré $0"
 ],
 "Encrypted Stratis pool $0": [
  null,
  "Pool Stratis chiffré $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Volume logique chiffré de $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Partition chiffrée de $0"
 ],
 "Encrypted volumes can not be resized here.": [
  null,
  "Les volumes chiffrés ne peuvent pas être redimensionnés ici."
 ],
 "Encrypted volumes need to be unlocked before they can be resized.": [
  null,
  "Les volumes chiffrés doivent être déverrouillés avant de pouvoir être redimensionnés."
 ],
 "Encryption": [
  null,
  "Chiffrement"
 ],
 "Encryption options": [
  null,
  "Options de chiffrement"
 ],
 "Encryption type": [
  null,
  "Type de chiffrement"
 ],
 "Erasing $target": [
  null,
  "Effacement de $target"
 ],
 "Error": [
  null,
  "Erreur"
 ],
 "Extended partition": [
  null,
  "Partition étendue"
 ],
 "Failed": [
  null,
  "Échoué"
 ],
 "Filesystem": [
  null,
  "Système de fichiers"
 ],
 "Filesystem is locked": [
  null,
  "Le système de fichiers est verrouillé"
 ],
 "Filesystem name": [
  null,
  "Nom du système de fichiers"
 ],
 "Filesystems": [
  null,
  "Systèmes de fichiers"
 ],
 "Format": [
  null,
  "Formater"
 ],
 "Format $0": [
  null,
  "Formater $0"
 ],
 "Formatting erases all data on a storage device.": [
  null,
  "Le formatage efface toutes les données d’un périphérique de stockage."
 ],
 "Free": [
  null,
  "Libre"
 ],
 "Free space": [
  null,
  "Espace libre"
 ],
 "Free up space in this group: Shrink or delete other logical volumes or add another physical volume.": [
  null,
  "Libérez de l’espace dans ce groupe : réduire ou supprimer les autres volumes logiques ou ajouter un autre volume physique."
 ],
 "Go to now": [
  null,
  "Aller à maintenant"
 ],
 "Grow": [
  null,
  "Augmenter"
 ],
 "Grow content": [
  null,
  "Augmenter le contenu"
 ],
 "Grow logical size of $0": [
  null,
  "Augmenter la taille logique de $0"
 ],
 "Grow logical volume": [
  null,
  "Augmenter le volume logique"
 ],
 "Grow to take all space": [
  null,
  "Augmenter en vue de prendre tout l’espace"
 ],
 "If this option is checked, the filesystem will not be mounted during the next boot even if it was mounted before it.  This is useful if mounting during boot is not possible, such as when a passphrase is required to unlock the filesystem but booting is unattended.": [
  null,
  "Si cette option est cochée, le système de fichiers ne sera pas monté lors du prochain démarrage, même s’il a été monté avant. Ceci est utile si le montage pendant le démarrage n’est pas possible, par exemple lorsqu’une phrase secrète est nécessaire pour déverrouiller le système de fichiers mais que le démarrage est sans surveillance."
 ],
 "In sync": [
  null,
  "En sync"
 ],
 "Inactive volume": [
  null,
  "Volume inactif"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Montage de système de fichiers incohérent"
 ],
 "Index memory": [
  null,
  "Mémoire de l’index"
 ],
 "Initialize": [
  null,
  "Initialiser"
 ],
 "Initialize disk $0": [
  null,
  "Initialiser le disque $0"
 ],
 "Initializing erases all data on a disk.": [
  null,
  "L’initialisation efface toutes les données d’un disque."
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Install NFS support": [
  null,
  "Installer la prise en charge NFS"
 ],
 "Install Stratis support": [
  null,
  "Installer le support Stratis"
 ],
 "Install software": [
  null,
  "Installer le logiciel"
 ],
 "Installing $0": [
  null,
  "Installation de $0"
 ],
 "Installing $0 would remove $1.": [
  null,
  "L’installation de $0 supprimerait $1."
 ],
 "Installing packages": [
  null,
  "Installation des paquets"
 ],
 "Invalid username or password": [
  null,
  "Nom d’utilisateur ou mot de passe non valide"
 ],
 "Jobs": [
  null,
  "Tâches"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Les emplacements de clé de type inconnu ne peuvent pas être édités ici"
 ],
 "Key source": [
  null,
  "Source de la clé"
 ],
 "Keys": [
  null,
  "Clés"
 ],
 "Keyserver": [
  null,
  "Serveur de clés"
 ],
 "Keyserver address": [
  null,
  "Adresse du serveur"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "La suppression du serveur de clés peut empêcher le déverrouillage de $0."
 ],
 "LVM2 member": [
  null,
  "Membre de LVM2"
 ],
 "LVM2 volume group": [
  null,
  "Groupe de volumes LVM2"
 ],
 "LVM2 volume group $0": [
  null,
  "Groupe de volumes LVM2 $0"
 ],
 "Last modified: $0": [
  null,
  "Dernière modification : $0"
 ],
 "Learn more": [
  null,
  "En savoir plus"
 ],
 "Loading...": [
  null,
  "Chargement…"
 ],
 "Local mount point": [
  null,
  "Point de montage local"
 ],
 "Location": [
  null,
  "Emplacement"
 ],
 "Lock": [
  null,
  "Verrouillage"
 ],
 "Locked devices": [
  null,
  "Périphériques verrouillés"
 ],
 "Locked encrypted Stratis pool": [
  null,
  "Pool Stratis verrouillé et chiffré"
 ],
 "Locking $target": [
  null,
  "Verrouillage de $target"
 ],
 "Logical": [
  null,
  "Logique"
 ],
 "Logical size": [
  null,
  "Taille logique"
 ],
 "Logical volume": [
  null,
  "Volume logique"
 ],
 "Logical volume (snapshot)": [
  null,
  "Volume logique (instantané)"
 ],
 "Logical volume of $0": [
  null,
  "Volume logique de $0"
 ],
 "Logical volumes": [
  null,
  "Volume logique"
 ],
 "Make sure the key hash from the Tang server matches one of the following:": [
  null,
  "Assurez-vous que le hachage de la clé du serveur Tang corresponde à l’un des suivants :"
 ],
 "Managing LVMs": [
  null,
  "Gestion des LVM"
 ],
 "Managing NFS mounts": [
  null,
  "Gérer les montages NFS"
 ],
 "Managing RAIDs": [
  null,
  "Gestion des RAID"
 ],
 "Managing VDOs": [
  null,
  "Gestion des ODV"
 ],
 "Managing partitions": [
  null,
  "Gestion des partitions"
 ],
 "Managing physical drives": [
  null,
  "Gestion des lecteurs physiques"
 ],
 "Manually check with SSH: ": [
  null,
  "Vérifier manuellement avec SSH : "
 ],
 "Marking $target as faulty": [
  null,
  "Marquage de $target comme défectueux"
 ],
 "Metadata used": [
  null,
  "Méta-données utilisées"
 ],
 "Modifying $target": [
  null,
  "Modifier $target"
 ],
 "Mount": [
  null,
  "Monter"
 ],
 "Mount also automatically on boot": [
  null,
  "Monter automatiquement au démarrage également"
 ],
 "Mount at boot": [
  null,
  "Monter au démarrage"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Montage automatique $0 au démarrage"
 ],
 "Mount configuration": [
  null,
  "Configuration de montage"
 ],
 "Mount filesystem": [
  null,
  "Monter le système de fichiers"
 ],
 "Mount now": [
  null,
  "Monter maintenant"
 ],
 "Mount on $0 now": [
  null,
  "Montez sur $0 maintenant"
 ],
 "Mount options": [
  null,
  "Options de montage"
 ],
 "Mount point": [
  null,
  "Point de montage"
 ],
 "Mount point cannot be empty": [
  null,
  "Le point de montage ne peut pas être vide"
 ],
 "Mount point cannot be empty.": [
  null,
  "Le point de montage ne peut pas être vide."
 ],
 "Mount point is already used for $0": [
  null,
  "Le point de montage est déjà utilisé pour $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Le point de montage doit commencer par « / »."
 ],
 "Mount read only": [
  null,
  "Monter en lecture seule"
 ],
 "Mounting $target": [
  null,
  "Montage de $target"
 ],
 "NFS mount": [
  null,
  "Point de montage NFS"
 ],
 "NFS mounts": [
  null,
  "Points de montage NFS"
 ],
 "NFS support not installed": [
  null,
  "Prise en charge NFS non installée"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Name can not be empty.": [
  null,
  "Le nom ne peut pas être vide."
 ],
 "Name cannot be empty.": [
  null,
  "Le nom ne peut pas être vide."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Le nom ne peut pas dépasser $0 octets"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Le nom ne peut pas dépasser $0 caractères"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Le nom ne peut pas dépasser 127 caractères."
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Le nom ne peut pas contenir le caractère « $0 »."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Le nom ne peut pas contenir d’espace."
 ],
 "Never mount at boot": [
  null,
  "Ne jamais monter au démarrage"
 ],
 "New NFS mount": [
  null,
  "Nouveau point de montage NFS"
 ],
 "New passphrase": [
  null,
  "Nouvelle phrase secrète"
 ],
 "Next": [
  null,
  "Prochain"
 ],
 "No NFS mounts set up": [
  null,
  "Aucun point de montage NFS configuré"
 ],
 "No available slots": [
  null,
  "Pas d’emplacements disponibles"
 ],
 "No block devices are available.": [
  null,
  "Aucun périphérique en mode bloc n’est disponible."
 ],
 "No devices": [
  null,
  "Aucun périphérique"
 ],
 "No disks are available.": [
  null,
  "Aucun disque disponible."
 ],
 "No drives attached": [
  null,
  "Aucun lecteur relié"
 ],
 "No encryption": [
  null,
  "Pas de cryptage"
 ],
 "No filesystem": [
  null,
  "Aucun système de fichiers"
 ],
 "No filesystems": [
  null,
  "Aucun système de fichiers"
 ],
 "No free key slots": [
  null,
  "Pas d’emplacements libres pour les clés"
 ],
 "No free space": [
  null,
  "Pas d’espace libre"
 ],
 "No iSCSI targets set up": [
  null,
  "Aucune cible iSCSI configurée"
 ],
 "No keys added": [
  null,
  "Aucune clé n’a été ajoutée"
 ],
 "No logical volumes": [
  null,
  "Pas de volumes logiques"
 ],
 "No media inserted": [
  null,
  "Aucun média inséré"
 ],
 "No partitioning": [
  null,
  "Pas de partitionnement"
 ],
 "Not enough space to grow.": [
  null,
  "Espace insuffisant pour propager."
 ],
 "Not found": [
  null,
  "Non trouvé"
 ],
 "Not mounted": [
  null,
  "Non monté"
 ],
 "Not running": [
  null,
  "Pas en cours d’exécution"
 ],
 "Ok": [
  null,
  "Ok"
 ],
 "Old passphrase": [
  null,
  "Ancienne phrase secrète"
 ],
 "Only $0 of $1 are used.": [
  null,
  "Seulement $0 de $1 sont utilisés."
 ],
 "Operation '$operation' on $target": [
  null,
  "Opération « $operation » sur $target"
 ],
 "Options": [
  null,
  "Options"
 ],
 "Other devices": [
  null,
  "Autres périphériques"
 ],
 "Overwrite": [
  null,
  "Écraser"
 ],
 "Overwrite existing data with zeros (slower)": [
  null,
  "Ecraser les données existantes avec des zéros (plus lent)"
 ],
 "PID": [
  null,
  "PID"
 ],
 "PackageKit crashed": [
  null,
  "Plantage de « PackageKit »"
 ],
 "Partition": [
  null,
  "Partition"
 ],
 "Partition of $0": [
  null,
  "Partition de $0"
 ],
 "Partitioned block device": [
  null,
  "Périphérique en mode bloc partitionné"
 ],
 "Partitioning": [
  null,
  "Partitionnement"
 ],
 "Partitions": [
  null,
  "Partitions"
 ],
 "Passphrase": [
  null,
  "Phrase secrète"
 ],
 "Passphrase can not be empty": [
  null,
  "La phrase secrète ne peut pas être vide"
 ],
 "Passphrase cannot be empty": [
  null,
  "La phrase secrète ne peut pas être vide"
 ],
 "Passphrase from any other key slot": [
  null,
  "Phrase secrète de n’importe quel autre emplacement de clé"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "La suppression de la phrase secrète peut empêcher le déverrouillage de $0."
 ],
 "Passphrases do not match": [
  null,
  "Les phrases secrète ne correspondent pas"
 ],
 "Password": [
  null,
  "Mot de passe"
 ],
 "Path on server": [
  null,
  "Chemin sur le serveur"
 ],
 "Path on server cannot be empty.": [
  null,
  "Le chemin sur le serveur ne peut pas être vide."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Le chemin sur le serveur doit commencer par « / »."
 ],
 "Permanently delete $0?": [
  null,
  "Supprimer définitivement $0 ?"
 ],
 "Physical": [
  null,
  "Physique"
 ],
 "Physical volumes": [
  null,
  "Volumes physiques"
 ],
 "Physical volumes can not be resized here.": [
  null,
  "Les volumes physiques ne peuvent pas être redimensionnés ici."
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Pool for thin logical volumes": [
  null,
  "Pool pour les volumes logiques dynamiques"
 ],
 "Pool for thin volumes": [
  null,
  "Pool pour les volumes dynamiques"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Pool pour les volumes à provisionnement dynamique"
 ],
 "Port": [
  null,
  "Port"
 ],
 "Processes using the location": [
  null,
  "Processus utilisant l’emplacement"
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  "Fournissez la phrase secrète pour le pool sur ces périphériques en mode bloc :"
 ],
 "Purpose": [
  null,
  "Objectif"
 ],
 "RAID ($0)": [
  null,
  "RAID ( $0 )"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (Bande)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (Miroir)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (Bande de miroirs)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (Parité dédiée)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (Parité répartie)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (Double parité répartie)"
 ],
 "RAID device": [
  null,
  "Périphérique RAID"
 ],
 "RAID device $0": [
  null,
  "Périphérique RAID $0"
 ],
 "RAID level": [
  null,
  "Niveau RAID"
 ],
 "RAID member": [
  null,
  "Membre RAID"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Recovering": [
  null,
  "Recouvrement"
 ],
 "Recovering RAID device $target": [
  null,
  "Recouvrement du périphérique RAID $target"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  "Les processus et services connexes seront arrêtés de force."
 ],
 "Related processes will be forcefully stopped.": [
  null,
  "Les processus connexes seront arrêtés de force."
 ],
 "Related services will be forcefully stopped.": [
  null,
  "Les services connexes seront arrêtés par la force."
 ],
 "Removals:": [
  null,
  "Suppressions :"
 ],
 "Remove": [
  null,
  "Retirer"
 ],
 "Remove $0?": [
  null,
  "Supprimer $0 ?"
 ],
 "Remove Tang keyserver?": [
  null,
  "Supprimer le serveur de clés Tang ?"
 ],
 "Remove device": [
  null,
  "Supprimer le périphérique"
 ],
 "Remove passphrase in key slot $0?": [
  null,
  "Supprimer la phrase de secrète dans l’emplacement de la clé $0 ?"
 ],
 "Removing $0": [
  null,
  "Suppression de $0"
 ],
 "Removing $target from RAID device": [
  null,
  "Supprimer $target du périphérique RAID"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  "La suppression d’une phrase secrète sans confirmation d’une autre phrase secrète peut empêcher le déverrouillage ou la gestion des clés, si d’autres phrases secrète sont oubliées ou perdues."
 ],
 "Removing physical volume from $target": [
  null,
  "Suppression du volume physique de $target"
 ],
 "Rename": [
  null,
  "Renommer"
 ],
 "Rename Stratis pool": [
  null,
  "Renommer le pool Stratis"
 ],
 "Rename filesystem": [
  null,
  "Renommer le système de fichiers"
 ],
 "Rename logical volume": [
  null,
  "Renommer le volume logique"
 ],
 "Rename volume group": [
  null,
  "Renommer le groupe de volumes"
 ],
 "Renaming $target": [
  null,
  "Renommer $target"
 ],
 "Repairing $target": [
  null,
  "Réparer $target"
 ],
 "Repeat passphrase": [
  null,
  "Répéter la phrase secrète"
 ],
 "Resizing $target": [
  null,
  "Redimensionnement $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Il faut déverrouiller le disque pour pouvoir redimensionner un système de fichier chiffré. Veuillez fournir une phrase secrète actuelle."
 ],
 "Reuse existing encryption": [
  null,
  "Réutiliser le cryptage existant"
 ],
 "Reuse existing encryption ($0)": [
  null,
  "Réutilisation du cryptage existant ($0)"
 ],
 "Running": [
  null,
  "En cours"
 ],
 "Runtime": [
  null,
  "Temps d’exécution"
 ],
 "SHA1": [
  null,
  "SHA1"
 ],
 "SHA256": [
  null,
  "SHA256"
 ],
 "SMART self-test of $target": [
  null,
  "SMART auto-test de $target"
 ],
 "Save": [
  null,
  "Enregistrer"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Économiser de l’espace en compressant les blocs individuels avec LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Économiser de l’espace en stockant une seule fois les blocs de données identiques"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Pour enregistrer une nouvelle phrase secrète, il faut déverrouiller le disque. Veuillez fournir une phrase secrète actuelle."
 ],
 "Securely erasing $target": [
  null,
  "Effacer en toute sécurité $target"
 ],
 "Server": [
  null,
  "Serveur"
 ],
 "Server address": [
  null,
  "Adresse du serveur"
 ],
 "Server address cannot be empty.": [
  null,
  "L’adresse du serveur ne peut pas être vide."
 ],
 "Server cannot be empty.": [
  null,
  "Le serveur ne peut pas être vide."
 ],
 "Service": [
  null,
  "Service"
 ],
 "Services using the location": [
  null,
  "Services utilisant l’emplacement"
 ],
 "Setting up loop device $target": [
  null,
  "Configuration du périphérique de boucle $target"
 ],
 "Show $0 device": [
  null,
  "Afficher le périphérique $0",
  "Afficher tous les périphériques $0"
 ],
 "Show $0 drive": [
  null,
  "Afficher $0 lecteur",
  "Afficher tous les lecteurs $0"
 ],
 "Show all": [
  null,
  "Tout afficher"
 ],
 "Shrink": [
  null,
  "Réduire"
 ],
 "Shrink logical volume": [
  null,
  "Réduire le volume logique"
 ],
 "Shrink volume": [
  null,
  "Réduire le volume"
 ],
 "Size": [
  null,
  "Taille"
 ],
 "Size cannot be negative": [
  null,
  "La taille ne peut pas être négative"
 ],
 "Size cannot be zero": [
  null,
  "La taille ne peut pas être nulle"
 ],
 "Size is too large": [
  null,
  "La taille est trop grande"
 ],
 "Size must be a number": [
  null,
  "La taille doit correspondre à un nombre"
 ],
 "Size must be at least $0": [
  null,
  "La taille doit être au moins $0"
 ],
 "Slot $0": [
  null,
  "Emplacement $0"
 ],
 "Snapshot": [
  null,
  "Instantané"
 ],
 "Source": [
  null,
  "La source"
 ],
 "Spare": [
  null,
  "De rechange"
 ],
 "Start": [
  null,
  "Démarrer"
 ],
 "Start multipath": [
  null,
  "Démarrer Multipath"
 ],
 "Starting RAID device $target": [
  null,
  "Démarrage du périphérique RAID $target"
 ],
 "Starting swapspace $target": [
  null,
  "Démarrage de swapspace $target"
 ],
 "Stop": [
  null,
  "Arrêter"
 ],
 "Stop and remove": [
  null,
  "Arrêter et retirer"
 ],
 "Stop and unmount": [
  null,
  "Arrêter et démonter"
 ],
 "Stop device": [
  null,
  "Arrêter le périphérique"
 ],
 "Stopping RAID device $target": [
  null,
  "Arrêt du périphérique RAID $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Arrêt de l’espace d’échange $target"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Le stockage ne peut pas être géré sur ce système."
 ],
 "Storage logs": [
  null,
  "Journaux de stockage"
 ],
 "Store passphrase": [
  null,
  "Stocker la phrase secrète"
 ],
 "Stored passphrase": [
  null,
  "Phrase secrète stockée"
 ],
 "Stratis member": [
  null,
  "Membre de Stratis"
 ],
 "Stratis pool": [
  null,
  "Pool Stratis"
 ],
 "Stratis pool $0": [
  null,
  "Pool Stratis $0"
 ],
 "Successfully copied to clipboard!": [
  null,
  "Copié avec succès dans le presse-papiers !"
 ],
 "Support is installed.": [
  null,
  "La prise en charge est installée."
 ],
 "Swap": [
  null,
  "Swap"
 ],
 "Synchronizing RAID device $target": [
  null,
  "Synchronisation du périphérique RAID $target"
 ],
 "Tang keyserver": [
  null,
  "Serveur de clés Tang"
 ],
 "The $0 package must be installed to create Stratis pools.": [
  null,
  "Le paquet $0 doit être installé pour créer des pools Stratis."
 ],
 "The $0 package will be installed to create VDO devices.": [
  null,
  "Le paquet $0 sera installé pour créer des périphériques VDO."
 ],
 "The RAID array is in a degraded state": [
  null,
  "Le RAID Array est dans un état dégradé"
 ],
 "The RAID device must be running in order to add spare disks.": [
  null,
  "Le périphérique RAID doit être en cours d’exécution pour pouvoir ajouter des disques supplémentaires."
 ],
 "The RAID device must be running in order to remove disks.": [
  null,
  "Le périphérique RAID doit être en cours d’exécution pour pouvoir supprimer les disques."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "La création de ce périphérique VDO n’est pas terminée et l’appareil ne peut pas être utilisé."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "L’utilisateur actuellement connecté n’est pas autorisé à voir les informations sur les clés."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  "Le disque doit être déverrouillé avant d'être formaté. Veuillez fournir une phrase secrète existante."
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "Le système de fichiers n’a pas de point de montage permanent."
 ],
 "The filesystem is already mounted at $0. Proceeding will unmount it.": [
  null,
  "Le système de fichiers est déjà monté à $0. La procédure le démontera."
 ],
 "The filesystem is configured to be automatically mounted on boot but its encryption container will not be unlocked at that time.": [
  null,
  "Le système de fichiers est configuré pour être automatiquement monté au démarrage mais son conteneur de cryptage ne sera pas déverrouillé à ce moment-là."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Le système de fichiers est actuellement monté mais ne le sera plus après le prochain démarrage."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Le système de fichiers est actuellement monté sur $0 mais sera monté sur $1 au prochain démarrage."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Le système de fichiers est actuellement monté $0mais ne sera pas monté après le prochain démarrage."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Le système de fichiers n’est pas actuellement monté mais sera monté au prochain démarrage."
 ],
 "The filesystem is not mounted.": [
  null,
  "Le système de fichiers n’est pas monté."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  "Le système de fichiers sera déverrouillé et monté au prochain démarrage. Cela peut nécessiter la saisie d’une phrase secrète."
 ],
 "The last disk of a RAID device cannot be removed.": [
  null,
  "Le dernier disque d’un périphérique RAID ne peut pas être supprimé."
 ],
 "The last key slot can not be removed": [
  null,
  "Le dernier logement de clé ne peut pas être retiré"
 ],
 "The last physical volume of a volume group cannot be removed.": [
  null,
  "Le dernier volume physique d’un groupe de volumes ne peut pas être supprimé."
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  "Les processus et services listés seront stoppés en force."
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  "Les processus énumérés seront stoppés en force."
 ],
 "The listed services will be forcefully stopped.": [
  null,
  "Les services répertoriés seront stoppés en force."
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  "Le point de montage $0 est utilisé par ces processus :"
 ],
 "The mount point $0 is in use by these services:": [
  null,
  "Le point de montage $0 est utilisé par ces services :"
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "Il y a des périphériques avec plusieurs chemins sur le système, mais le service multipath n’est pas en cours d’exécution."
 ],
 "There is not enough free space elsewhere to remove this physical volume. At least $0 more free space is needed.": [
  null,
  "Il n’y a pas assez d’espace libre ailleurs pour supprimer ce volume physique. Il faut au moins $0 plus d’espace libre."
 ],
 "These changes will be made:": [
  null,
  "Ces changements seront effectués :"
 ],
 "Thin logical volume": [
  null,
  "Volume logique dynamique"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Ce montage NFS est en cours d’utilisation et seules ses options peuvent être modifiées."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Ce périphérique VDO n’utilise pas tout son périphérique de sauvegarde."
 ],
 "This device is currently in use.": [
  null,
  "Ce périphérique est actuellement en cours d’utilisation."
 ],
 "This disk cannot be removed while the device is recovering.": [
  null,
  "Ce disque ne peut pas être retiré pendant le recouvrement du périphérique."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Ce volume logique n’est pas complètement utilisé par son contenu."
 ],
 "This pool can not be unlocked here because its key description is not in the expected format.": [
  null,
  "Ce pool ne peut pas être déverrouillé ici car la description de sa clé n’est pas dans le format attendu."
 ],
 "This volume needs to be activated before it can be resized.": [
  null,
  "Ce volume doit être activé avant de pouvoir être redimensionné."
 ],
 "Tier": [
  null,
  "Niveau"
 ],
 "Toggle": [
  null,
  "Basculer"
 ],
 "Toggle bitmap": [
  null,
  "Basculer l’image bitmap"
 ],
 "Total size: $0": [
  null,
  "Taille totale : $0"
 ],
 "Trust key": [
  null,
  "Clé de confiance"
 ],
 "Type": [
  null,
  "Type"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "Incapable d’atteindre le serveur"
 ],
 "Unable to remove mount": [
  null,
  "Incapable de supprimer le montage"
 ],
 "Unable to unmount filesystem": [
  null,
  "Incapable de démonter le système de fichiers"
 ],
 "Unknown": [
  null,
  "Inconnu"
 ],
 "Unknown ($0)": [
  null,
  "Inconnu ( $0 )"
 ],
 "Unknown host name": [
  null,
  "Nom d’hôte inconnu"
 ],
 "Unknown type": [
  null,
  "Type inconnu"
 ],
 "Unlock": [
  null,
  "Déverrouiller"
 ],
 "Unlock automatically on boot": [
  null,
  "Déverrouillage automatique au démarrage"
 ],
 "Unlock encrypted Stratis pool": [
  null,
  "Déverrouiller le pool Stratis crypté"
 ],
 "Unlock pool to see filesystems.": [
  null,
  "Déverrouiller le pool pour voir les systèmes de fichiers."
 ],
 "Unlocking $target": [
  null,
  "Déverrouillage $target"
 ],
 "Unlocking disk": [
  null,
  "Déverrouillage du disque"
 ],
 "Unmount": [
  null,
  "Démonter"
 ],
 "Unmount filesystem $0": [
  null,
  "Démonter le système de fichiers $0"
 ],
 "Unmount now": [
  null,
  "Supprimer le montage maintenant"
 ],
 "Unmounting $target": [
  null,
  "Démonter $target"
 ],
 "Unrecognized data": [
  null,
  "Données non reconnues"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Les données non reconnues ne peuvent pas être plus petites ici."
 ],
 "Unsupported volume": [
  null,
  "Volume non pris en charge"
 ],
 "Usage": [
  null,
  "Utilisation"
 ],
 "Usage of $0": [
  null,
  "Utilisation de $0"
 ],
 "Use": [
  null,
  "Utiliser"
 ],
 "Use compression": [
  null,
  "Utiliser la compression"
 ],
 "Use deduplication": [
  null,
  "Déduplication"
 ],
 "Used": [
  null,
  "Utilisé"
 ],
 "Used for": [
  null,
  "Utilisé pour"
 ],
 "User": [
  null,
  "Utilisateur"
 ],
 "Username": [
  null,
  "Nom d’utilisateur"
 ],
 "Using LUKS encryption": [
  null,
  "Utiliser le cryptage LUKS"
 ],
 "Using Tang server": [
  null,
  "Utilisation du serveur Tang"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Les sauvegardes VDO ne peuvent pas être plus petits"
 ],
 "VDO device": [
  null,
  "Périphérique VDO"
 ],
 "VDO device $0": [
  null,
  "Périphérique VDO $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  "Volume du système de fichiers VDO (compression/dédoublonnage)"
 ],
 "VDO pool": [
  null,
  "Pool VDO"
 ],
 "Verify key": [
  null,
  "Vérifier la clé"
 ],
 "Very securely erasing $target": [
  null,
  "Effacement très sécurisé de $target"
 ],
 "View all logs": [
  null,
  "Voir tous les journaux"
 ],
 "Volume": [
  null,
  "Volume"
 ],
 "Volume group": [
  null,
  "Groupe de volumes"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "La taille du volume est $0. La taille du contenu est $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Attente de la fin des autres opérations de gestion du logiciel"
 ],
 "Write-mostly": [
  null,
  "Écriture - le plus souvent"
 ],
 "Writing": [
  null,
  "Écriture"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[ $0 octets de données binaires]"
 ],
 "[binary data]": [
  null,
  "[données binaires]"
 ],
 "[no data]": [
  null,
  "[pas de données]"
 ],
 "backing device for VDO device": [
  null,
  "périphérique de sauvegarde pour périphérique VDO"
 ],
 "delete": [
  null,
  "supprimer"
 ],
 "disk": [
  null,
  "disque"
 ],
 "drive": [
  null,
  "disque"
 ],
 "edit": [
  null,
  "modifier"
 ],
 "encryption": [
  null,
  "chiffrement"
 ],
 "filesystem": [
  null,
  "système de fichiers"
 ],
 "format": [
  null,
  "formater"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "grow": [
  null,
  "développer"
 ],
 "iSCSI targets": [
  null,
  "Cibles iSCSI"
 ],
 "initialize": [
  null,
  "initialiser"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "member of RAID device": [
  null,
  "membre du périphérique RAID"
 ],
 "member of Stratis pool": [
  null,
  "membre du pool Stratis"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "monter"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "never mounted at boot": [
  null,
  "jamais monté au démarrage"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "none": [
  null,
  "aucun"
 ],
 "partition": [
  null,
  "partition"
 ],
 "physical volume of LVM2 volume group": [
  null,
  "volume physique du groupe de volumes LVM2"
 ],
 "raid": [
  null,
  "raid"
 ],
 "read only": [
  null,
  "lecture seule"
 ],
 "remove from LVM2": [
  null,
  "retirer de LVM2"
 ],
 "remove from RAID": [
  null,
  "retirer du RAID"
 ],
 "shrink": [
  null,
  "réduire"
 ],
 "stop": [
  null,
  "arrêter"
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unknown target": [
  null,
  "cible inconnue"
 ],
 "unmount": [
  null,
  "Démonter"
 ],
 "unpartitioned space on $0": [
  null,
  "espace non partitionné sur $0"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "volume"
 ],
 "yes": [
  null,
  "oui"
 ],
 "storage-id-desc\u0004$0 filesystem": [
  null,
  "$0 système de fichiers"
 ],
 "storage-id-desc\u0004Filesystem (encrypted)": [
  null,
  "Système de fichiers (crypté)"
 ],
 "storage-id-desc\u0004Locked encrypted data": [
  null,
  "Données chiffrées verrouillées"
 ],
 "storage-id-desc\u0004Other data": [
  null,
  "Autre informations"
 ],
 "storage-id-desc\u0004Swap space": [
  null,
  "Espace swap"
 ],
 "storage-id-desc\u0004Unrecognized data": [
  null,
  "Données non reconnues"
 ],
 "storage-id-desc\u0004VDO backing": [
  null,
  "Sauvegarde VDO"
 ],
 "storage\u0004Assessment": [
  null,
  "Évaluation"
 ],
 "storage\u0004Bitmap": [
  null,
  "Bitmap"
 ],
 "storage\u0004Capacity": [
  null,
  "Capacité"
 ],
 "storage\u0004Device": [
  null,
  "Périphérique"
 ],
 "storage\u0004Device file": [
  null,
  "Fichier de périphérique"
 ],
 "storage\u0004Firmware version": [
  null,
  "Version du micrologiciel"
 ],
 "storage\u0004Model": [
  null,
  "Modèle"
 ],
 "storage\u0004Multipathed devices": [
  null,
  "Gestion des appareils multi-trajets"
 ],
 "storage\u0004Optical drive": [
  null,
  "Lecteur optique"
 ],
 "storage\u0004RAID level": [
  null,
  "Niveau RAID"
 ],
 "storage\u0004Removable drive": [
  null,
  "Lecteur amovible"
 ],
 "storage\u0004Serial number": [
  null,
  "Numéro de série"
 ],
 "storage\u0004State": [
  null,
  "État"
 ],
 "storage\u0004UUID": [
  null,
  "UUID"
 ],
 "storage\u0004Usage": [
  null,
  "Utilisation"
 ],
 "storage\u0004World wide name": [
  null,
  "WW Nom"
 ],
 "format-bytes\u0004bytes": [
  null,
  "octets"
 ]
});
