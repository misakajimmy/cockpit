cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "ru",
  "language-direction": "ltr"
 },
 "$0 (encrypted)": [
  null,
  "$0 (зашифровано)"
 ],
 "$0 Stratis pool": [
  null,
  "$0 буфер Stratis"
 ],
 "$0 block device": [
  null,
  "$0 Блочное устройство"
 ],
 "$0 cache": [
  null,
  "Кэш $0"
 ],
 "$0 chunk size": [
  null,
  "размер блока: $0"
 ],
 "$0 data": [
  null,
  "$0 данные"
 ],
 "$0 data + $1 overhead used of $2 ($3)": [
  null,
  "$0 данных + $1 служебной информации использовано из $2 ($3)"
 ],
 "$0 day": [
  null,
  "$0 день",
  "$0 дня",
  "$0 дней"
 ],
 "$0 disk is missing": [
  null,
  "$0 диск отсутствует",
  "$0 диска отсутствуют",
  "$0 дисков отсутствуют"
 ],
 "$0 disks": [
  null,
  "дисков: $0"
 ],
 "$0 filesystems can not be made larger.": [
  null,
  "Файловые системы $0 не могут быть увеличены."
 ],
 "$0 filesystems can not be made smaller.": [
  null,
  "Файловые системы $0 не могут быть уменьшены."
 ],
 "$0 filesystems can not be resized here.": [
  null,
  "Размер файловых систем $0 невозможно изменить здесь."
 ],
 "$0 hour": [
  null,
  "$0 час",
  "$0 часа",
  "$0 часов"
 ],
 "$0 is in use": [
  null,
  "$0 используется"
 ],
 "$0 is not available from any repository.": [
  null,
  "Компонент $0 недоступен в репозиториях."
 ],
 "$0 minute": [
  null,
  "$0 минута",
  "$0 минуты",
  "$0 минут"
 ],
 "$0 month": [
  null,
  "$0 месяц",
  "$0 месяца",
  "$0 месяцев"
 ],
 "$0 of unknown tier": [
  null,
  "$0 неизвестного уровня"
 ],
 "$0 slot remains": [
  null,
  "Остался $0 слот",
  "Осталось $0 слота",
  "Осталось $0 слотов"
 ],
 "$0 used of $1 ($2 saved)": [
  null,
  "$0 использовано из $1 ($2 сэкономлено)"
 ],
 "$0 week": [
  null,
  "$0 неделя",
  "$0 недели",
  "$0 недель"
 ],
 "$0 will be installed.": [
  null,
  "Будет выполнена установка $0."
 ],
 "$0 year": [
  null,
  "$0 год",
  "$0 года",
  "$0 лет"
 ],
 "$0, $1 free": [
  null,
  "$0, свободно $1"
 ],
 "$name (from $host)": [
  null,
  "$name (от $host)"
 ],
 "(recommended)": [
  null,
  "(рекомендовано)"
 ],
 "1 MiB": [
  null,
  "1 МиБ"
 ],
 "1 day": [
  null,
  "1 день"
 ],
 "1 hour": [
  null,
  "1 час"
 ],
 "1 week": [
  null,
  "1 неделя"
 ],
 "128 KiB": [
  null,
  "128 КиБ"
 ],
 "16 KiB": [
  null,
  "16 КиБ"
 ],
 "2 MiB": [
  null,
  "2 МиБ"
 ],
 "32 KiB": [
  null,
  "32 КиБ"
 ],
 "4 KiB": [
  null,
  "4 КиБ"
 ],
 "5 minutes": [
  null,
  "5 минут"
 ],
 "512 KiB": [
  null,
  "512 КиБ"
 ],
 "6 hours": [
  null,
  "6 часов"
 ],
 "64 KiB": [
  null,
  "64 КиБ"
 ],
 "8 KiB": [
  null,
  "8 КиБ"
 ],
 "A filesystem with this name exists already in this pool.": [
  null,
  "Файловая система с таким именем уже существует в этом пуле."
 ],
 "A pool with this name exists already.": [
  null,
  "Пул с таким названием уже существует."
 ],
 "A spare disk needs to be added first before this disk can be removed.": [
  null,
  "Перед тем, как этот диск можно будет удалить, необходимо добавить запасной диск."
 ],
 "Action": [
  null,
  "Действие"
 ],
 "Activate": [
  null,
  "Включить"
 ],
 "Activating $target": [
  null,
  "Включение $target"
 ],
 "Add": [
  null,
  "Добавить"
 ],
 "Add block devices": [
  null,
  "Добавить блочные устройства"
 ],
 "Add disks": [
  null,
  "Добавление дисков"
 ],
 "Add iSCSI portal": [
  null,
  "Добавить портал iSCSI"
 ],
 "Add key": [
  null,
  "Добавить ключ"
 ],
 "Adding physical volume to $target": [
  null,
  "Добавление физического тома в $target"
 ],
 "Additional packages:": [
  null,
  "Дополнительные пакеты:"
 ],
 "Address": [
  null,
  "Адрес"
 ],
 "Address cannot be empty": [
  null,
  "Адрес не может быть пустым"
 ],
 "Address is not a valid URL": [
  null,
  "Недопустимое значение URL-адреса"
 ],
 "At least $0 disk is needed.": [
  null,
  "Необходим хотя бы $0 диск.",
  "Необходимо хотя бы $0 диска.",
  "Необходимо хотя бы $0 дисков."
 ],
 "At least one block device is needed.": [
  null,
  "Необходимо хотя бы одно блочное устройство."
 ],
 "At least one disk is needed.": [
  null,
  "Необходим хотя бы один диск."
 ],
 "Authentication required": [
  null,
  "Необходима проверка подлинности"
 ],
 "Available targets on $0": [
  null,
  "Доступные цели на $0"
 ],
 "Backing device": [
  null,
  "Резервное устройство"
 ],
 "Block": [
  null,
  "Блок"
 ],
 "Block device for filesystems": [
  null,
  "Устройство блочного ввода-вывода для файловых систем"
 ],
 "Block devices": [
  null,
  "Блочные устройства"
 ],
 "Blocked": [
  null,
  "Заблокировано"
 ],
 "Cache": [
  null,
  "Кэш"
 ],
 "Cancel": [
  null,
  "Отмена"
 ],
 "Change": [
  null,
  "Изменить"
 ],
 "Change iSCSI initiator name": [
  null,
  "Изменить имя инициатора iSCSI"
 ],
 "Change passphrase": [
  null,
  "Изменить парольную фразу"
 ],
 "Checking $target": [
  null,
  "Проверка $target"
 ],
 "Checking RAID device $target": [
  null,
  "Проверка RAID-устройства $target"
 ],
 "Checking and repairing RAID device $target": [
  null,
  "Проверка и восстановление RAID-устройства $target"
 ],
 "Checking installed software": [
  null,
  "Проверка установленного программного обеспечения"
 ],
 "Checking related processes": [
  null,
  "Проверка связанных процессов"
 ],
 "Chunk size": [
  null,
  "Размер блока"
 ],
 "Cleaning up for $target": [
  null,
  "Очистка данных $target"
 ],
 "Cleartext device": [
  null,
  "Устройство с открытым текстом"
 ],
 "Close": [
  null,
  "Закрыть"
 ],
 "Command": [
  null,
  "Команда"
 ],
 "Compatible with all systems and devices (MBR)": [
  null,
  "Совместимость со всеми системами и устройствами (MBR)"
 ],
 "Compatible with modern system and hard disks > 2TB (GPT)": [
  null,
  "Совместимость с современными системами и жёсткими дисками объёмом более 2 ТБ (GPT)"
 ],
 "Compression": [
  null,
  "Сжатие"
 ],
 "Confirm": [
  null,
  "Подтверждение"
 ],
 "Confirm deletion of $0": [
  null,
  "Подтвердите удаление $0"
 ],
 "Confirm removal with an alternate passphrase": [
  null,
  "Подтвердите удаление с помощью альтернативной кодовой фразы"
 ],
 "Confirm stopping of $0": [
  null,
  "Подтвердите остановку $0"
 ],
 "Content": [
  null,
  "Содержимое"
 ],
 "Copy to clipboard": [
  null,
  "Копировать в буфер обмена"
 ],
 "Create": [
  null,
  "Создать"
 ],
 "Create RAID device": [
  null,
  "Создание RAID-устройства"
 ],
 "Create devices": [
  null,
  "Создать устройства"
 ],
 "Create logical volume": [
  null,
  "Создание логического тома"
 ],
 "Create new logical volume": [
  null,
  "Создать новый логический том"
 ],
 "Create partition": [
  null,
  "Создать раздел"
 ],
 "Create partition on $0": [
  null,
  "Создание раздела на $0"
 ],
 "Create partition table": [
  null,
  "Создать таблицу разделов"
 ],
 "Create snapshot": [
  null,
  "Создание моментального снимка"
 ],
 "Create thin volume": [
  null,
  "Создать тонкий том"
 ],
 "Create volume group": [
  null,
  "Создать группу томов"
 ],
 "Creating RAID device $target": [
  null,
  "Создание RAID-устройства $target"
 ],
 "Creating filesystem on $target": [
  null,
  "Создание файловой системы на $target"
 ],
 "Creating logical volume $target": [
  null,
  "Создание логического тома $target"
 ],
 "Creating partition $target": [
  null,
  "Создание раздела $target"
 ],
 "Creating snapshot of $target": [
  null,
  "Создание моментального снимка $target"
 ],
 "Custom mount options": [
  null,
  "Пользовательские параметры подключения"
 ],
 "Data used": [
  null,
  "Использованные данные"
 ],
 "Deactivate": [
  null,
  "Отключить"
 ],
 "Deactivating $target": [
  null,
  "Отключение $target"
 ],
 "Deduplication": [
  null,
  "Дедупликация"
 ],
 "Delete": [
  null,
  "Удалить"
 ],
 "Deleting $target": [
  null,
  "Удаление $target"
 ],
 "Deleting a logical volume will delete all data in it.": [
  null,
  "Удаление логического тома приведёт к удалению всех данных в нём."
 ],
 "Deleting a partition will delete all data in it.": [
  null,
  "Удаление раздела приведёт к удалению всех данных в нём."
 ],
 "Description": [
  null,
  "Описание"
 ],
 "Device": [
  null,
  "Устройство"
 ],
 "Device file": [
  null,
  "Файл устройства"
 ],
 "Device is read-only": [
  null,
  "Устройство доступно только для чтения"
 ],
 "Devices": [
  null,
  "Устройства"
 ],
 "Disk is OK": [
  null,
  "Диск в порядке"
 ],
 "Disk passphrase": [
  null,
  "Парольная фраза диска"
 ],
 "Disks": [
  null,
  "Диски"
 ],
 "Do not mount automatically on boot": [
  null,
  "Не монтировать автоматически при загрузке"
 ],
 "Downloading $0": [
  null,
  "Загрузка $0"
 ],
 "Drive": [
  null,
  "Устройство"
 ],
 "Drives": [
  null,
  "Диски"
 ],
 "Edit": [
  null,
  "Изменить"
 ],
 "Edit Tang keyserver": [
  null,
  "Изменение сервера криптографических ключей Tang"
 ],
 "Editing a key requires a free slot": [
  null,
  "Для редактирования ключа необходим свободный слот"
 ],
 "Ejecting $target": [
  null,
  "Извлечение $target"
 ],
 "Emptying $target": [
  null,
  "Очистка $target"
 ],
 "Encrypt data": [
  null,
  "Шифровать данные"
 ],
 "Encrypted $0": [
  null,
  "Зашифрованный $0"
 ],
 "Encrypted logical volume of $0": [
  null,
  "Зашифрованный логический том $0"
 ],
 "Encrypted partition of $0": [
  null,
  "Зашифрованный раздел $0"
 ],
 "Encrypted volumes can not be resized here.": [
  null,
  "Размер зашифрованных томов невозможно изменить здесь."
 ],
 "Encrypted volumes need to be unlocked before they can be resized.": [
  null,
  "Зашифрованные тома необходимо разблокировать, прежде чем станет возможным изменение их размера."
 ],
 "Encryption": [
  null,
  "Шифрование"
 ],
 "Encryption options": [
  null,
  "Параметры шифрования"
 ],
 "Erasing $target": [
  null,
  "Стирание $target"
 ],
 "Error": [
  null,
  "Ошибка"
 ],
 "Extended partition": [
  null,
  "Дополнительный раздел"
 ],
 "Failed": [
  null,
  "Сбой"
 ],
 "Filesystem": [
  null,
  "Файловая система"
 ],
 "Filesystem name": [
  null,
  "Имя файловой системы"
 ],
 "Filesystems": [
  null,
  "Файловые системы"
 ],
 "Format": [
  null,
  "Форматировать"
 ],
 "Format $0": [
  null,
  "Форматирование $0"
 ],
 "Free": [
  null,
  "Свободно"
 ],
 "Free space": [
  null,
  "свободного места"
 ],
 "Free up space in this group: Shrink or delete other logical volumes or add another physical volume.": [
  null,
  "Освободите место в этой группе: сожмите или удалите другие логические тома или добавьте новый физический том."
 ],
 "Go to now": [
  null,
  "Текущий момент"
 ],
 "Grow": [
  null,
  "Расширить"
 ],
 "Grow content": [
  null,
  "Расширить содержимое"
 ],
 "Grow logical size of $0": [
  null,
  "Расширение логического размера $0"
 ],
 "Grow logical volume": [
  null,
  "Расширение логического тома"
 ],
 "Grow to take all space": [
  null,
  "Расширить на всё пространство"
 ],
 "If this option is checked, the filesystem will not be mounted during the next boot even if it was mounted before it.  This is useful if mounting during boot is not possible, such as when a passphrase is required to unlock the filesystem but booting is unattended.": [
  null,
  ""
 ],
 "In sync": [
  null,
  "Синхронизировано"
 ],
 "Inactive volume": [
  null,
  "Неактивный том"
 ],
 "Inconsistent filesystem mount": [
  null,
  "Неправильное монтирование файловой системы"
 ],
 "Index memory": [
  null,
  "Память индексов"
 ],
 "Install": [
  null,
  "Установить"
 ],
 "Install NFS support": [
  null,
  "Установка поддержки NFS"
 ],
 "Install software": [
  null,
  "Установка программного обеспечения"
 ],
 "Installing $0": [
  null,
  "Установка $0"
 ],
 "Invalid username or password": [
  null,
  "Недопустимое имя пользователя или пароль"
 ],
 "Jobs": [
  null,
  "Задания"
 ],
 "Key slots with unknown types can not be edited here": [
  null,
  "Слоты для ключей с неизвестными типами нельзя изменить здесь"
 ],
 "Key source": [
  null,
  "Источник ключа"
 ],
 "Keys": [
  null,
  "Ключи"
 ],
 "Keyserver": [
  null,
  "Сервер криптографических ключей"
 ],
 "Keyserver address": [
  null,
  "Адрес сервера криптографических ключей"
 ],
 "Keyserver removal may prevent unlocking $0.": [
  null,
  "Удаление сервера криптографических ключей может помешать разблокировке $0."
 ],
 "Learn more": [
  null,
  "Подробнее..."
 ],
 "Loading...": [
  null,
  "Загрузка..."
 ],
 "Local mount point": [
  null,
  "Локальная точка подключения"
 ],
 "Location": [
  null,
  "Расположение"
 ],
 "Lock": [
  null,
  "Заблокировать"
 ],
 "Locking $target": [
  null,
  "Блокировка $target"
 ],
 "Logical": [
  null,
  "Логический размер"
 ],
 "Logical size": [
  null,
  "Логический размер"
 ],
 "Logical volume": [
  null,
  "Логический том"
 ],
 "Logical volume (snapshot)": [
  null,
  "Логический том (моментальный снимок)"
 ],
 "Logical volume of $0": [
  null,
  "Логический том $0"
 ],
 "Managing partitions": [
  null,
  "Управление разделами"
 ],
 "Manually check with SSH: ": [
  null,
  "Проверить вручную через SSH: "
 ],
 "Marking $target as faulty": [
  null,
  "Маркировка $target как неисправного"
 ],
 "Metadata used": [
  null,
  "Используемые метаданные"
 ],
 "Modifying $target": [
  null,
  "Изменение $target"
 ],
 "Mount": [
  null,
  "Подключение"
 ],
 "Mount also automatically on boot": [
  null,
  "Монтировать также автоматически при загрузке"
 ],
 "Mount at boot": [
  null,
  "Подключение при загрузке"
 ],
 "Mount automatically on $0 on boot": [
  null,
  "Монтировать автоматически на $0 при загрузке"
 ],
 "Mount configuration": [
  null,
  "Настройки монтирования"
 ],
 "Mount filesystem": [
  null,
  "Монтировать файловую систему"
 ],
 "Mount now": [
  null,
  "Монтировать сейчас"
 ],
 "Mount on $0 now": [
  null,
  "Монтировать на $0 сейчас"
 ],
 "Mount options": [
  null,
  "Параметры подключения"
 ],
 "Mount point": [
  null,
  "Точка подключения"
 ],
 "Mount point cannot be empty": [
  null,
  "Точка монтирования не может быть пустой"
 ],
 "Mount point cannot be empty.": [
  null,
  "Точка подключения не может быть пуста."
 ],
 "Mount point is already used for $0": [
  null,
  "Точка монтирования уже используется для $0"
 ],
 "Mount point must start with \"/\".": [
  null,
  "Точка подключения должна начинаться с символа «/»."
 ],
 "Mount read only": [
  null,
  "Подключение только для чтения"
 ],
 "Mounting $target": [
  null,
  "Подключение $target"
 ],
 "NFS mount": [
  null,
  "Подключение по NFS"
 ],
 "NFS mounts": [
  null,
  "Подключения по NFS"
 ],
 "NFS support not installed": [
  null,
  "Поддержка NFS не установлена"
 ],
 "Name": [
  null,
  "Имя"
 ],
 "Name can not be empty.": [
  null,
  "Имя не должно быть пустым."
 ],
 "Name cannot be empty.": [
  null,
  "Имя не должно быть пустым."
 ],
 "Name cannot be longer than $0 bytes": [
  null,
  "Длина имени в байтах не должна превышать $0"
 ],
 "Name cannot be longer than $0 characters": [
  null,
  "Длина имени в символах не должна превышать $0"
 ],
 "Name cannot be longer than 127 characters.": [
  null,
  "Длина имени должна составлять не более 127 символов"
 ],
 "Name cannot contain the character '$0'.": [
  null,
  "Имя не должно содержать знак «$0»."
 ],
 "Name cannot contain whitespace.": [
  null,
  "Имя не должно содержать пробелы."
 ],
 "New NFS mount": [
  null,
  "Новое подключение по NFS"
 ],
 "New passphrase": [
  null,
  "Новая парольная фраза"
 ],
 "Next": [
  null,
  "Далее"
 ],
 "No NFS mounts set up": [
  null,
  "Подключения по NFS отсутствуют"
 ],
 "No available slots": [
  null,
  "Нет доступных слотов"
 ],
 "No devices": [
  null,
  "Нет устройств"
 ],
 "No disks are available.": [
  null,
  "Нет доступных дисков."
 ],
 "No drives attached": [
  null,
  "Нет присоединённых дисков"
 ],
 "No filesystem": [
  null,
  "Нет файловой системы"
 ],
 "No free key slots": [
  null,
  "Нет свободных слотов для ключей"
 ],
 "No free space": [
  null,
  "Нет свободного места"
 ],
 "No iSCSI targets set up": [
  null,
  "Нет установленных целей iSCSI"
 ],
 "No keys added": [
  null,
  "Нет добавленных ключей"
 ],
 "No logical volumes": [
  null,
  "Нет логических томов"
 ],
 "No media inserted": [
  null,
  "Носитель не вставлен"
 ],
 "No partitioning": [
  null,
  "Без разбиения"
 ],
 "Not enough space to grow.": [
  null,
  "Недостаточно места для увеличения."
 ],
 "Not found": [
  null,
  "Не найдено"
 ],
 "Not mounted": [
  null,
  "Не подключено"
 ],
 "Not running": [
  null,
  "Не работает"
 ],
 "Ok": [
  null,
  "OK"
 ],
 "Old passphrase": [
  null,
  "Старая парольная фраза"
 ],
 "Only $0 of $1 are used.": [
  null,
  "Используется только $0 из $1."
 ],
 "Operation '$operation' on $target": [
  null,
  "Операция «$operation» над $target"
 ],
 "Options": [
  null,
  "Параметры"
 ],
 "Other devices": [
  null,
  "Другие устройства"
 ],
 "PackageKit crashed": [
  null,
  "Сбой PackageKit"
 ],
 "Partition": [
  null,
  "Раздел"
 ],
 "Partition of $0": [
  null,
  "Раздел $0"
 ],
 "Partitioning": [
  null,
  "Разбиение"
 ],
 "Passphrase": [
  null,
  "Парольная фраза"
 ],
 "Passphrase cannot be empty": [
  null,
  "Парольная фраза не может быть пустой"
 ],
 "Passphrase removal may prevent unlocking $0.": [
  null,
  "Удаление парольной фразы может мешать разблокировке $0"
 ],
 "Passphrases do not match": [
  null,
  "Парольные фразы не совпадают"
 ],
 "Password": [
  null,
  "Пароль"
 ],
 "Path on server": [
  null,
  "Путь на сервере"
 ],
 "Path on server cannot be empty.": [
  null,
  "Путь на сервере не может быть пустым."
 ],
 "Path on server must start with \"/\".": [
  null,
  "Путь на сервере должен начинаться с символа «/»."
 ],
 "Permanently delete $0?": [
  null,
  ""
 ],
 "Physical": [
  null,
  "Физический размер"
 ],
 "Physical volumes": [
  null,
  "Физические тома"
 ],
 "Physical volumes can not be resized here.": [
  null,
  "Размер физических томов невозможно изменить здесь."
 ],
 "Pool": [
  null,
  "Пул"
 ],
 "Pool for thin logical volumes": [
  null,
  "Пул для тонких логических томов"
 ],
 "Pool for thin volumes": [
  null,
  "Пул для тонких томов"
 ],
 "Pool for thinly provisioned volumes": [
  null,
  "Пул для «тонко» резервируемых томов"
 ],
 "Port": [
  null,
  "Порт"
 ],
 "Processes using the location": [
  null,
  ""
 ],
 "Provide the passphrase for the pool on these block devices:": [
  null,
  ""
 ],
 "Purpose": [
  null,
  "Назначение"
 ],
 "RAID ($0)": [
  null,
  "RAID ($0)"
 ],
 "RAID 0": [
  null,
  "RAID 0"
 ],
 "RAID 0 (stripe)": [
  null,
  "RAID 0 (чередование)"
 ],
 "RAID 1": [
  null,
  "RAID 1"
 ],
 "RAID 1 (mirror)": [
  null,
  "RAID 1 (зеркалирование)"
 ],
 "RAID 10": [
  null,
  "RAID 10"
 ],
 "RAID 10 (stripe of mirrors)": [
  null,
  "RAID 10 (чередование зеркалирования)"
 ],
 "RAID 4": [
  null,
  "RAID 4"
 ],
 "RAID 4 (dedicated parity)": [
  null,
  "RAID 4 (выделенная чётность)"
 ],
 "RAID 5": [
  null,
  "RAID 5"
 ],
 "RAID 5 (distributed parity)": [
  null,
  "RAID 5 (распределённая чётность)"
 ],
 "RAID 6": [
  null,
  "RAID 6"
 ],
 "RAID 6 (double distributed parity)": [
  null,
  "RAID 6 (двойная распределённая чётность)"
 ],
 "RAID device": [
  null,
  "RAID-устройство"
 ],
 "RAID device $0": [
  null,
  "RAID-устройство $0"
 ],
 "RAID level": [
  null,
  "Уровень RAID"
 ],
 "RAID member": [
  null,
  "Участник RAID-массива"
 ],
 "Reboot": [
  null,
  "Перезагрузка"
 ],
 "Recovering": [
  null,
  "Восстановливается"
 ],
 "Recovering RAID device $target": [
  null,
  "Восстановление RAID-устройства $target"
 ],
 "Related processes and services will be forcefully stopped.": [
  null,
  ""
 ],
 "Related processes will be forcefully stopped.": [
  null,
  ""
 ],
 "Related services will be forcefully stopped.": [
  null,
  ""
 ],
 "Removals:": [
  null,
  "Для удаления:"
 ],
 "Remove": [
  null,
  "Удалить"
 ],
 "Remove $0?": [
  null,
  "Удалить $0?"
 ],
 "Remove device": [
  null,
  "Удалить устройство"
 ],
 "Removing $0": [
  null,
  "Удаление $0"
 ],
 "Removing $target from RAID device": [
  null,
  "Удаление $target с RAID-устройства"
 ],
 "Removing a passphrase without confirmation of another passphrase may prevent unlocking or key management, if other passphrases are forgotten or lost.": [
  null,
  ""
 ],
 "Removing physical volume from $target": [
  null,
  "Удаление физического тома из $target"
 ],
 "Rename": [
  null,
  "Переименовать"
 ],
 "Rename logical volume": [
  null,
  "Переименование логического тома"
 ],
 "Rename volume group": [
  null,
  "Переименование группы томов"
 ],
 "Renaming $target": [
  null,
  "Переименование $target"
 ],
 "Repairing $target": [
  null,
  "Восстановление $target"
 ],
 "Repeat passphrase": [
  null,
  "Подтверждение парольной фразы"
 ],
 "Resizing $target": [
  null,
  "Изменение размера $target"
 ],
 "Resizing an encrypted filesystem requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Для изменения размера зашифрованной файловой системы необходимо разблокировать диск. Введите парольную фразу текущего диска."
 ],
 "Reuse existing encryption ($0)": [
  null,
  ""
 ],
 "Running": [
  null,
  "Работает"
 ],
 "SHA1": [
  null,
  ""
 ],
 "SHA256": [
  null,
  ""
 ],
 "SMART self-test of $target": [
  null,
  "SMART самопроверка $target"
 ],
 "Save": [
  null,
  "Сохранить"
 ],
 "Save space by compressing individual blocks with LZ4": [
  null,
  "Экономьте место, сжимая отдельные блоки по алгоритму LZ4"
 ],
 "Save space by storing identical data blocks just once": [
  null,
  "Экономьте место, сохраняя блоки идентичных данных лишь один раз"
 ],
 "Saving a new passphrase requires unlocking the disk. Please provide a current disk passphrase.": [
  null,
  "Для сохранения новой парольной фразы требуется снятие блокировки диска. Укажите действующую парольную фразу диска."
 ],
 "Securely erasing $target": [
  null,
  "Надёжное стирание $target"
 ],
 "Server": [
  null,
  "Сервер"
 ],
 "Server address": [
  null,
  "Адрес сервера"
 ],
 "Server address cannot be empty.": [
  null,
  "Адрес сервера не может быть пустым."
 ],
 "Server cannot be empty.": [
  null,
  "Сервер не может быть пустым."
 ],
 "Service": [
  null,
  "Служба"
 ],
 "Setting up loop device $target": [
  null,
  "Настройка петлевого устройства $target"
 ],
 "Show all": [
  null,
  "Показать все"
 ],
 "Shrink": [
  null,
  "Сжать"
 ],
 "Shrink logical volume": [
  null,
  "Сжатие логического тома"
 ],
 "Shrink volume": [
  null,
  "Сжать том"
 ],
 "Size": [
  null,
  "Размер"
 ],
 "Size cannot be negative": [
  null,
  "Размер не может быть отрицательным"
 ],
 "Size cannot be zero": [
  null,
  "Размер не может быть равен нулю"
 ],
 "Size is too large": [
  null,
  "Слишком большой размер"
 ],
 "Size must be a number": [
  null,
  "Размер должен быть числом"
 ],
 "Size must be at least $0": [
  null,
  "Размер должен быть не менее $0"
 ],
 "Slot $0": [
  null,
  "Слот $0"
 ],
 "Source": [
  null,
  "Источник"
 ],
 "Spare": [
  null,
  "В запасе"
 ],
 "Start": [
  null,
  "Запустить"
 ],
 "Start multipath": [
  null,
  "Запустить multipath"
 ],
 "Starting RAID device $target": [
  null,
  "Запуск RAID-устройства $target"
 ],
 "Starting swapspace $target": [
  null,
  "Запуск области подкачки $target"
 ],
 "Stop": [
  null,
  "Остановить"
 ],
 "Stop and remove": [
  null,
  "Остановить и удалить"
 ],
 "Stop and unmount": [
  null,
  "Остановить и отключить"
 ],
 "Stop device": [
  null,
  "Остановить устройство"
 ],
 "Stopping RAID device $target": [
  null,
  "Остановка RAID-устройства $target"
 ],
 "Stopping swapspace $target": [
  null,
  "Остановка области подкачки $target"
 ],
 "Storage": [
  null,
  "Хранилище"
 ],
 "Storage can not be managed on this system.": [
  null,
  "Управление хранилищем недоступно в данной системе."
 ],
 "Storage logs": [
  null,
  "Журналы хранения"
 ],
 "Store passphrase": [
  null,
  "Хранить парольную фразу"
 ],
 "Stored passphrase": [
  null,
  "Сохранённая парольная фраза"
 ],
 "Support is installed.": [
  null,
  "Поддержка установлена."
 ],
 "Swap": [
  null,
  "Подкачка"
 ],
 "Synchronizing RAID device $target": [
  null,
  "Синхронизация RAID-устройства $target"
 ],
 "Tang keyserver": [
  null,
  "Сервер криптографических ключей Tang"
 ],
 "The RAID array is in a degraded state": [
  null,
  "RAID-массив находится в состоянии сбоя"
 ],
 "The RAID device must be running in order to add spare disks.": [
  null,
  "RAID-устройство должно быть запущено для добавления запасных дисков."
 ],
 "The RAID device must be running in order to remove disks.": [
  null,
  "RAID-устройство должно быть запущено для удаления дисков."
 ],
 "The creation of this VDO device did not finish and the device can't be used.": [
  null,
  "Создание данного устройства VDO не завершилось, поэтому устройство не может быть использовано."
 ],
 "The currently logged in user is not permitted to see information about keys.": [
  null,
  "Текущему пользователю не разрешено просматривать сведения о ключах."
 ],
 "The disk needs to be unlocked before formatting.  Please provide a existing passphrase.": [
  null,
  ""
 ],
 "The filesystem has no permanent mount point.": [
  null,
  "У этой файловой системы нет постоянной точки монтирования."
 ],
 "The filesystem is currently mounted but will not be mounted after the next boot.": [
  null,
  "Файловая система сейчас смонтирована, после следующей загрузки не будет смонтирована."
 ],
 "The filesystem is currently mounted on $0 but will be mounted on $1 on the next boot.": [
  null,
  "Файловая система сейчас смонтирована на $0, но при следующей загрузке будет монтироваться на $1."
 ],
 "The filesystem is currently mounted on $0 but will not be mounted after the next boot.": [
  null,
  "Файловая система сейчас смонтирована на $0, но не будет монтироваться при следующей загрузке."
 ],
 "The filesystem is currently not mounted but will be mounted on the next boot.": [
  null,
  "Файловая система сейчас не смонтирована, но будет монтироваться при следующей загрузке."
 ],
 "The filesystem is not mounted.": [
  null,
  "Файловая система не смонтирована."
 ],
 "The filesystem will be unlocked and mounted on the next boot. This might require inputting a passphrase.": [
  null,
  ""
 ],
 "The last disk of a RAID device cannot be removed.": [
  null,
  "Последний диск RAID-устройства не может быть удалён."
 ],
 "The last key slot can not be removed": [
  null,
  "Последний слот для ключа не может быть удалён"
 ],
 "The last physical volume of a volume group cannot be removed.": [
  null,
  "Последний физический том группы томов не может быть удалён."
 ],
 "The listed processes and services will be forcefully stopped.": [
  null,
  ""
 ],
 "The listed processes will be forcefully stopped.": [
  null,
  ""
 ],
 "The listed services will be forcefully stopped.": [
  null,
  ""
 ],
 "The mount point $0 is in use by these processes:": [
  null,
  ""
 ],
 "The mount point $0 is in use by these services:": [
  null,
  ""
 ],
 "There are devices with multiple paths on the system, but the multipath service is not running.": [
  null,
  "В системе есть устройства, использующие несколько путей, но служба multipath не работает."
 ],
 "There is not enough free space elsewhere to remove this physical volume. At least $0 more free space is needed.": [
  null,
  "Для удаления этого физического тома в других местах недостаточно свободного места. Требуется по крайней мере на $0 свободного места больше."
 ],
 "Thin logical volume": [
  null,
  "Тонкий логический том"
 ],
 "This NFS mount is in use and only its options can be changed.": [
  null,
  "Данное подключение по NFS используется. Возможно только изменение его параметров."
 ],
 "This VDO device does not use all of its backing device.": [
  null,
  "Данное устройство VDO не полностью использует резервное устройство."
 ],
 "This disk cannot be removed while the device is recovering.": [
  null,
  "Этот диск не может быть удалён во время восстановления устройства."
 ],
 "This logical volume is not completely used by its content.": [
  null,
  "Логический том используется содержимым не до конца."
 ],
 "This pool can not be unlocked here because its key description is not in the expected format.": [
  null,
  ""
 ],
 "This volume needs to be activated before it can be resized.": [
  null,
  "Этот том необходимо активировать, прежде чем можно будет изменить его размер."
 ],
 "Tier": [
  null,
  ""
 ],
 "Toggle": [
  null,
  ""
 ],
 "Toggle bitmap": [
  null,
  ""
 ],
 "Total size: $0": [
  null,
  "Общий размер: $0"
 ],
 "Trust key": [
  null,
  "Ключ доверия"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Unable to reach server": [
  null,
  "Не удаётся связаться с сервером"
 ],
 "Unable to remove mount": [
  null,
  "Не удаётся удалить подключение"
 ],
 "Unable to unmount filesystem": [
  null,
  "Не удаётся отключить файловую систему"
 ],
 "Unknown": [
  null,
  "Неизвестно"
 ],
 "Unknown ($0)": [
  null,
  "Неизвестно ($0)"
 ],
 "Unknown host name": [
  null,
  "Неизвестное имя узла"
 ],
 "Unknown type": [
  null,
  "Неизвестный тип"
 ],
 "Unlock": [
  null,
  "Разблокировать"
 ],
 "Unlocking $target": [
  null,
  "Снятие блокировки $target"
 ],
 "Unmount": [
  null,
  "Отключить"
 ],
 "Unmount now": [
  null,
  "Размонтировать сейчас"
 ],
 "Unmounting $target": [
  null,
  "Отключение $target"
 ],
 "Unrecognized data": [
  null,
  "Нераспознанные данные"
 ],
 "Unrecognized data can not be made smaller here.": [
  null,
  "Нераспознанные данные не могут быть уменьшены здесь."
 ],
 "Unsupported volume": [
  null,
  "Неподдерживаемый том"
 ],
 "Usage": [
  null,
  "Использование"
 ],
 "Used": [
  null,
  "Использовано"
 ],
 "User": [
  null,
  "Пользователь"
 ],
 "Username": [
  null,
  "Имя пользователя"
 ],
 "VDO backing devices can not be made smaller": [
  null,
  "Устройства резервирования VDO не могут быть уменьшены"
 ],
 "VDO device": [
  null,
  "Устройство VDO"
 ],
 "VDO device $0": [
  null,
  "Устройство VDO $0"
 ],
 "VDO filesystem volume (compression/deduplication)": [
  null,
  ""
 ],
 "Verify key": [
  null,
  "Проверка ключа"
 ],
 "Very securely erasing $target": [
  null,
  "Крайне надёжное стирание $target"
 ],
 "View all logs": [
  null,
  ""
 ],
 "Volume": [
  null,
  "Том"
 ],
 "Volume group": [
  null,
  "Группа томов"
 ],
 "Volume size is $0. Content size is $1.": [
  null,
  "Размер тома составляет $0. Содержимое занимает $1."
 ],
 "Waiting for other software management operations to finish": [
  null,
  "Ожидание завершения других операций управления программным обеспечением"
 ],
 "Write-mostly": [
  null,
  "В основном запись"
 ],
 "Writing": [
  null,
  "Запись"
 ],
 "[$0 bytes of binary data]": [
  null,
  "[$0 байтов двоичных данных]"
 ],
 "[binary data]": [
  null,
  "[двоичные данные]"
 ],
 "[no data]": [
  null,
  "[нет данных]"
 ],
 "disk": [
  null,
  "диск"
 ],
 "drive": [
  null,
  "привод"
 ],
 "edit": [
  null,
  "редактировать"
 ],
 "encryption": [
  null,
  "шифрование"
 ],
 "filesystem": [
  null,
  "файловая система"
 ],
 "format": [
  null,
  "форматировать"
 ],
 "fstab": [
  null,
  "fstab"
 ],
 "grow": [
  null,
  ""
 ],
 "iSCSI targets": [
  null,
  "Цели iSCSI"
 ],
 "iscsi": [
  null,
  "iscsi"
 ],
 "luks": [
  null,
  "luks"
 ],
 "lvm2": [
  null,
  "lvm2"
 ],
 "mkfs": [
  null,
  "mkfs"
 ],
 "mount": [
  null,
  "монтировать"
 ],
 "nbde": [
  null,
  "nbde"
 ],
 "nfs": [
  null,
  "nfs"
 ],
 "none": [
  null,
  "нет"
 ],
 "partition": [
  null,
  "раздел"
 ],
 "raid": [
  null,
  "RAID"
 ],
 "read only": [
  null,
  "только для чтения"
 ],
 "remove from LVM2": [
  null,
  ""
 ],
 "stop": [
  null,
  ""
 ],
 "tang": [
  null,
  "tang"
 ],
 "udisks": [
  null,
  "udisks"
 ],
 "unknown target": [
  null,
  "неизвестная цель"
 ],
 "unmount": [
  null,
  "размонтировать"
 ],
 "unpartitioned space on $0": [
  null,
  "неразмеченная область диска на $0"
 ],
 "vdo": [
  null,
  "vdo"
 ],
 "volume": [
  null,
  "том"
 ],
 "yes": [
  null,
  "да"
 ],
 "storage-id-desc\u0004$0 filesystem": [
  null,
  "Файловая система $0"
 ],
 "storage-id-desc\u0004Other data": [
  null,
  "Другие данные"
 ],
 "storage-id-desc\u0004Swap space": [
  null,
  "Область подкачки"
 ],
 "storage-id-desc\u0004Unrecognized data": [
  null,
  "Нераспознанные данные"
 ],
 "storage-id-desc\u0004VDO backing": [
  null,
  "Резервирование VDO"
 ],
 "storage\u0004Assessment": [
  null,
  "Оценка"
 ],
 "storage\u0004Bitmap": [
  null,
  "Битовая карта"
 ],
 "storage\u0004Capacity": [
  null,
  "Ёмкость"
 ],
 "storage\u0004Device": [
  null,
  "Устройство"
 ],
 "storage\u0004Device file": [
  null,
  "Файл устройства"
 ],
 "storage\u0004Firmware version": [
  null,
  "Версия микропрограммы"
 ],
 "storage\u0004Model": [
  null,
  "Модель"
 ],
 "storage\u0004Multipathed devices": [
  null,
  "Многоканальные устройства"
 ],
 "storage\u0004Optical drive": [
  null,
  "Оптический привод"
 ],
 "storage\u0004RAID level": [
  null,
  "Уровень RAID"
 ],
 "storage\u0004Removable drive": [
  null,
  "Съёмный носитель"
 ],
 "storage\u0004Serial number": [
  null,
  "Серийный номер"
 ],
 "storage\u0004State": [
  null,
  "Состояние"
 ],
 "storage\u0004UUID": [
  null,
  "UUID"
 ],
 "storage\u0004World wide name": [
  null,
  "WWN-имя"
 ],
 "format-bytes\u0004bytes": [
  null,
  "байтов"
 ]
});
